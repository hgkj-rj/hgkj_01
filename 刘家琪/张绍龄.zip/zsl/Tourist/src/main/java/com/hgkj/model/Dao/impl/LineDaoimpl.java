package com.hgkj.model.Dao.impl;

import com.hgkj.model.Dao.LineDao;
import com.hgkj.model.entity.Line;
import com.hgkj.model.entity.Linetype;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
@Repository
@Transactional
public class LineDaoimpl implements LineDao {
    @Autowired
    private SessionFactory sessionFactory;
    private Session session;
    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    public Session getSession(){
        return sessionFactory.getCurrentSession();
    }

    @Override
    public int getpageDao(int pagesize, String time) {
        int total=0;
        Query query = this.getSession().createQuery("select count(*) from Line where teamBuy=1 and beginTime<? and endTime>?").setParameter(0,time).setParameter(1,time);
        total = ((Number)query.iterate().next()).intValue();
        return total;
    }

    @Override
    public List<Line> allLineDao(int pageIndex, int pagesize, String time) {
        String hql = "from Line where teamBuy=1 and beginTime<? and endTime>?";
        List<Line> lineList = getSession().createQuery(hql).setParameter(0,time).setParameter(1,time).setFirstResult((pageIndex-1)*pagesize).setMaxResults(pagesize).list();
        return lineList;
    }

    @Override
    public List<Line> allLineDao() {
        Query query = getSession().createQuery("from Line");
        return query.list();
    }

    @Override
    public List<Line> allGroupDao() {
        Query query = getSession().createQuery("from Line order by onTime desc ");
        return query.list();
    }

    @Override
    public List<Line> allGroupLineDao() {
        Query query = getSession().createQuery("from Line where teamBuy=1 order by onTime desc ");
        return query.list();
    }

    @Override
    public List<Line> toIndexLineDao(String lineTypeId) {
        List<Line> lineList = getSession().createQuery("from Line where linetype.lineTypeId=?").setParameter(0,lineTypeId).list();
        return lineList;
    }

    @Override
    public List<Line> oneLineDao() {
        List<Line> lineList = getSession().createQuery("from  Line  where days=? order by onTime desc ").setParameter(0,"1天").setMaxResults(9).list();
        return lineList;
    }

    @Override
    public List<Line> twoLineDao() {
        List<Line> lineList = getSession().createQuery("from  Line  where days=? order by onTime desc ").setParameter(0,"2天").setMaxResults(9).list();
        return lineList;
    }

    @Override
    public List<Line> moreLineDao() {
        List<Line> lineList = getSession().createQuery("from  Line  where days!=? and days!=? order by onTime desc ").setParameter(0,"1天").setParameter(1,"2天").setMaxResults(9).list();
        return lineList;
    }

    @Override
    public boolean addLineDao(Line line) {
        Boolean flag = false;
        session=getSession();
        Linetype linetype = session.load(Linetype.class,line.getLinetype().getLineTypeId());
        line.setLinetype(linetype);
        try {
            session.save(line);
            flag=true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return flag;
    }

    @Override
    public boolean updateLineDao(Line line) {
        Boolean flag = false;
        session=getSession();
        Linetype linetype = session.load(Linetype.class,line.getLinetype().getLineTypeId());
        line.setLinetype(linetype);
        try {
            session.update(line);
            flag=true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return flag;
    }

    @Override
    public Line getLineByIdDao(String lineId) {

        session=getSession();
        String hql = "from Line where lineId=?";
        Line line = (Line) session.createQuery(hql).setParameter(0,lineId).uniqueResult();
        return line;
    }
}
