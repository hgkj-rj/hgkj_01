package com.workmoney.model.entity;

import java.util.Objects;

/**
 * user@Bright Rain .
 * 2019/6/21.
 */
public class Subsidy {
    private int subsidyId;
    private String subsidyName;
    private String subsidyMoney;

    public int getSubsidyId() {
        return subsidyId;
    }

    public void setSubsidyId(int subsidyId) {
        this.subsidyId = subsidyId;
    }

    public String getSubsidyName() {
        return subsidyName;
    }

    public void setSubsidyName(String subsidyName) {
        this.subsidyName = subsidyName;
    }

    public String getSubsidyMoney() {
        return subsidyMoney;
    }

    public void setSubsidyMoney(String subsidyMoney) {
        this.subsidyMoney = subsidyMoney;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Subsidy subsidy = (Subsidy) o;
        return subsidyId == subsidy.subsidyId &&
                Objects.equals(subsidyName, subsidy.subsidyName) &&
                Objects.equals(subsidyMoney, subsidy.subsidyMoney);
    }

    @Override
    public int hashCode() {
        return Objects.hash(subsidyId, subsidyName, subsidyMoney);
    }
}
