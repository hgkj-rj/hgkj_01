package com.hgkj.controler.action;

import com.hgkj.model.entity.Line;
import com.hgkj.model.service.LineService;
import com.opensymphony.xwork2.ActionContext;
import org.apache.struts2.ServletActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import java.util.List;

@Controller
@Namespace("/ht")
@ParentPackage("json-default")
public class TeamAction {
    @Autowired
    private LineService lineService;
    private Line line;

    public LineService getLineService() {
        return lineService;
    }

    public void setLineService(LineService lineService) {
        this.lineService = lineService;
    }

    public Line getLine() {
        return line;
    }

    public void setLine(Line line) {
        this.line = line;
    }
    @Action(value = "allTeamupdAction",results = @Result(name = "all",type = "redirect",location = "teamShow.jsp"))
    public String allTeamupdAction(){
        System.out.println("11111111111111");
        List<Line> allLineList=lineService.allLineService();
        /*System.out.println(line.getDays()+line.getVehicle()+"2222222222222");*/
        ActionContext.getContext().getSession().put("allLineList",allLineList);
        return "all";
    }
    @Action(value = "teamByIdAction",results = @Result(name = "find",type = "redirect",location = "updateTeamLine.jsp"))
    public String teamByIdAction(){
        Line line1=lineService.teamByIdService(line.getLineId());
        ServletActionContext.getRequest().getSession().setAttribute("line",line1);
        return "find";
    }
    @Action(value = "updTeamAction",results ={ @Result(name = "update",type = "redirectAction",params = {"actionName","allTeamupdAction"}),
            @Result(name = "error",type = "redirect",location = "updateTeamLine.jsp")})
    public String updTeamAction() {
        boolean rs = lineService.updTeamService(line);
        if (rs) {
            return "update";

        } else {
            return "error";
        }
    }
}
