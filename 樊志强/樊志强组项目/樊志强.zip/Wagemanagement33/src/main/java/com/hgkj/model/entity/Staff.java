package com.hgkj.model.entity;



public class Staff {
    private int staffId;
    private String staffName;
    private String staffPwd;
    private String staffSex;
    private String staffAddress;
    private String staffTel;
    private String staffEmail;
    private String staffState;

    private Level level;

    private Role role;

    private Department department;

    private Shop shop;

    public Level getLevel() {
        return level;
    }

    public Role getRole() {
        return role;
    }

    public Department getDepartment() {
        return department;
    }

    public Shop getShop() {
        return shop;
    }

    public void setLevel(Level level) {
        this.level = level;
    }

    public void setRole(Role role) {
        this.role = role;
    }

    public void setDepartment(Department department) {
        this.department = department;
    }

    public void setShop(Shop shop) {
        this.shop = shop;
    }

    public int getStaffId() {
        return staffId;
    }

    public void setStaffId(int staffId) {
        this.staffId = staffId;
    }

    public String getStaffName() {
        return staffName;
    }

    public void setStaffName(String staffName) {
        this.staffName = staffName;
    }

    public String getStaffPwd() {
        return staffPwd;
    }

    public void setStaffPwd(String staffPwd) {
        this.staffPwd = staffPwd;
    }

    public String getStaffSex() {
        return staffSex;
    }

    public void setStaffSex(String staffSex) {
        this.staffSex = staffSex;
    }

    public String getStaffAddress() {
        return staffAddress;
    }

    public void setStaffAddress(String staffAddress) {
        this.staffAddress = staffAddress;
    }

    public String getStaffTel() {
        return staffTel;
    }

    public void setStaffTel(String staffTel) {
        this.staffTel = staffTel;
    }

    public String getStaffEmail() {
        return staffEmail;
    }

    public void setStaffEmail(String staffEmail) {
        this.staffEmail = staffEmail;
    }

    public String getStaffState() {
        return staffState;
    }

    public void setStaffState(String staffState) {
        this.staffState = staffState;
    }

    @Override
    public String toString() {
        return "Staff{" +
                "staffId=" + staffId +
                ", staffName='" + staffName + '\'' +
                ", staffPwd='" + staffPwd + '\'' +
                ", staffSex='" + staffSex + '\'' +
                ", staffAddress='" + staffAddress + '\'' +
                ", staffTel='" + staffTel + '\'' +
                ", staffEmail='" + staffEmail + '\'' +
                ", staffState='" + staffState + '\'' +
                ", level=" + level +
                ", role=" + role +
                ", department=" + department +
                ", shop=" + shop +
                '}';
    }
}
