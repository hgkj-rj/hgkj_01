/*
Navicat MySQL Data Transfer

Source Server         : fuxi
Source Server Version : 50720
Source Host           : localhost:3306
Source Database       : tourism

Target Server Type    : MYSQL
Target Server Version : 50720
File Encoding         : 65001

Date: 2019-07-08 12:47:12
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `car`
-- ----------------------------
DROP TABLE IF EXISTS `car`;
CREATE TABLE `car` (
  `carId` int(10) NOT NULL AUTO_INCREMENT,
  `customerId` int(10) NOT NULL,
  `lineId` varchar(36) NOT NULL,
  `time` datetime NOT NULL,
  PRIMARY KEY (`carId`),
  KEY `FKhbpwxw3p9or49q5aa678er23c` (`lineId`),
  KEY `FKnlkm0xh8b93fphff487wyh9bi` (`customerId`),
  CONSTRAINT `FKhbpwxw3p9or49q5aa678er23c` FOREIGN KEY (`lineId`) REFERENCES `line` (`lineId`),
  CONSTRAINT `FKnlkm0xh8b93fphff487wyh9bi` FOREIGN KEY (`customerId`) REFERENCES `customer` (`customerId`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of car
-- ----------------------------
INSERT INTO `car` VALUES ('1', '1', '14Z', '2019-07-06 00:00:00');
INSERT INTO `car` VALUES ('2', '2', '380', '2019-05-05 00:00:00');
INSERT INTO `car` VALUES ('9', '2', '9XN', '2019-07-06 14:20:31');
INSERT INTO `car` VALUES ('12', '1', 'EL7', '2019-07-06 04:25:11');
INSERT INTO `car` VALUES ('13', '1', '80U', '2019-07-06 04:25:26');
INSERT INTO `car` VALUES ('14', '1', 'AU1', '2019-07-06 04:25:37');
INSERT INTO `car` VALUES ('15', '1', '77A', '2019-07-06 04:25:57');
INSERT INTO `car` VALUES ('16', '1', '380', '2019-07-06 04:27:10');
INSERT INTO `car` VALUES ('17', '1', '62R', '2019-07-06 04:27:43');
INSERT INTO `car` VALUES ('19', '1', '380', '2019-07-08 10:33:01');

-- ----------------------------
-- Table structure for `customer`
-- ----------------------------
DROP TABLE IF EXISTS `customer`;
CREATE TABLE `customer` (
  `customerId` int(10) NOT NULL AUTO_INCREMENT,
  `account` varchar(12) NOT NULL,
  `name` varchar(12) NOT NULL,
  `password` varchar(12) NOT NULL,
  `gender` char(2) NOT NULL,
  `identityId` varchar(18) NOT NULL,
  `tel` varchar(11) NOT NULL,
  `type` int(1) DEFAULT NULL,
  PRIMARY KEY (`customerId`),
  UNIQUE KEY `yuesu1` (`account`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of customer
-- ----------------------------
INSERT INTO `customer` VALUES ('1', 'ltq', '林糖柒', 'ltq', '女', '42070420000506002x', '17376896004', '1');
INSERT INTO `customer` VALUES ('2', 'hynhyn', '胡亚楠', 'hynhyn', '女', '420704199903040022', '13683753309', null);

-- ----------------------------
-- Table structure for `line`
-- ----------------------------
DROP TABLE IF EXISTS `line`;
CREATE TABLE `line` (
  `lineId` varchar(12) NOT NULL,
  `lineTypeId` varchar(36) NOT NULL,
  `lineName` varchar(15) NOT NULL,
  `days` varchar(12) NOT NULL,
  `vehicle` char(2) NOT NULL,
  `introduction` varchar(400) DEFAULT NULL,
  `reason` varchar(100) DEFAULT NULL,
  `arrange` varchar(100) DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  `teamBuy` int(1) DEFAULT NULL,
  `teamBuyPrice` decimal(10,2) DEFAULT NULL,
  `beginTime` datetime DEFAULT NULL,
  `endTime` datetime DEFAULT NULL,
  `onTime` datetime NOT NULL,
  PRIMARY KEY (`lineId`),
  KEY `FKd7h38nar3c77x5uw44ddn6nyf` (`lineTypeId`),
  CONSTRAINT `FKd7h38nar3c77x5uw44ddn6nyf` FOREIGN KEY (`lineTypeId`) REFERENCES `linetype` (`lineTypeId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of line
-- ----------------------------
INSERT INTO `line` VALUES ('146', '1L9VRG', '22', '2', '飞机', '', '', '', '11.00', null, null, null, null, '2019-07-04 03:08:04');
INSERT INTO `line` VALUES ('14Z', '1L9VRG', '22', '2', '轮船', '', '', '', '11.00', null, null, null, null, '2019-07-04 03:09:04');
INSERT INTO `line` VALUES ('380', '32c8f4', '11', '1', '飞机', '', '', '', '11.00', null, null, null, null, '2019-07-04 02:38:23');
INSERT INTO `line` VALUES ('62R', '32c8f4', '11', '1', '飞机', '', '', '', '11.00', null, null, null, null, '2019-07-04 02:37:56');
INSERT INTO `line` VALUES ('77A', '32c8f4', '11', '1', '飞机', '', '', '', '11.00', null, null, null, null, '2019-07-04 02:34:28');
INSERT INTO `line` VALUES ('77X', '32c8f4', '11', '1', '飞机', '', '', '', '11.00', null, null, null, null, '2019-07-04 03:02:50');
INSERT INTO `line` VALUES ('7da', '32c8f4', '11', '1', '飞机', '', '', '', '11.00', null, null, null, null, '2019-07-04 02:36:53');
INSERT INTO `line` VALUES ('80U', 'oW6va1', '武汉欢乐谷', '1', '自驾', '中国文化公园第一连锁品牌，创立于1998年，以“打造世界一流的连锁文化公园”为愿景，旨在为不同的城市，带来同样的欢乐', '', '', '170.00', '1', '150.00', '2019-07-01 00:00:00', '2019-07-03 00:00:00', '2019-06-27 10:50:17');
INSERT INTO `line` VALUES ('9XN', '1L9VRG', '22', '2', '飞机', '', '', '', '11.00', null, null, null, null, '2019-07-04 03:08:32');
INSERT INTO `line` VALUES ('AU1', '1L9VRG', '22', '2', '飞机', '', '', '', '2.00', null, null, null, null, '2019-07-04 03:11:22');
INSERT INTO `line` VALUES ('BvU', '32c8f4', '11', '1', '飞机', '', '', '', '11.00', null, null, null, null, '2019-07-04 02:36:03');
INSERT INTO `line` VALUES ('dLb', '000000', '33', '3', '飞机', '', '', '', '33.00', '1', '150.00', '2019-07-01 00:00:00', '2019-07-11 00:00:00', '2019-07-08 10:25:56');
INSERT INTO `line` VALUES ('e33', '1L9VRG', '22', '2', '飞机', '', '', '', '1199.00', '1', '1000.00', '2019-07-06 00:00:00', '2019-07-11 00:00:00', '2019-07-04 03:10:40');
INSERT INTO `line` VALUES ('EL7', '56464a', '昆大丽双飞', '6', '飞机', '[清明]<昆大丽双飞6日游>约惠云南，1晚温泉酒店，减100', '11', '11', '1199.00', '1', null, '2019-07-01 00:00:00', '2019-07-11 00:00:00', '2019-06-29 12:08:32');
INSERT INTO `line` VALUES ('g2r', '32c8f4', '11', '1', '飞机', '', '', '', '11.00', null, null, null, null, '2019-07-04 02:37:21');
INSERT INTO `line` VALUES ('Ib8', '32c8f4', '海南三亚', '5', '飞机', '<海南三亚国光豪生5日自助游>国际品牌酒店，专享悠闲度假', '', '', '2920.00', '1', '2800.00', '2019-07-06 00:00:00', '2019-07-11 00:00:00', '2019-07-01 05:10:57');
INSERT INTO `line` VALUES ('O8d', '32c8f4', '11', '1', '飞机', '', '', '', '11.00', null, null, null, null, '2019-07-04 02:35:02');
INSERT INTO `line` VALUES ('pBA', '1L9VRG', '22', '2', '飞机', '', '', '', '22.00', null, null, null, null, '2019-07-04 03:09:55');
INSERT INTO `line` VALUES ('Spx', '1L9VRG', '22', '1', '飞机', '', '', '', '11.00', null, null, null, null, '2019-07-04 03:07:24');
INSERT INTO `line` VALUES ('v2U', '1L9VRG', '香港迪士尼', '2', '飞机', '香港迪士尼乐园(Disneyland,Hong Kong)的面积只有126.82公顷，是全球面积最小的迪士尼乐园，是世界上的第五个迪士尼乐园。', '', '', '55.00', '1', '50.00', '2019-07-01 00:00:00', '2019-07-03 00:00:00', '2019-07-01 05:05:25');
INSERT INTO `line` VALUES ('v55', '1L9VRG', '22', '2', '飞机', '', '', '', '22.00', null, null, null, null, '2019-07-04 03:09:28');
INSERT INTO `line` VALUES ('wu3', '32c8f4', '11', '1', '飞机', '', '', '', '11.00', null, null, null, null, '2019-07-04 02:35:31');
INSERT INTO `line` VALUES ('xR2', '1L9VRG', '22', '2', '飞机', '', '', '', '2.00', null, null, null, null, '2019-07-04 03:10:19');
INSERT INTO `line` VALUES ('Z37', '32c8f4', '海南双飞', '5', '飞机', '1晚分界洲海景住宿，蜜月专享，恋恋海豚湾', '', '', '3517.00', null, null, null, null, '2019-06-26 00:00:00');

-- ----------------------------
-- Table structure for `linetype`
-- ----------------------------
DROP TABLE IF EXISTS `linetype`;
CREATE TABLE `linetype` (
  `lineTypeId` varchar(36) NOT NULL,
  `typeName` varchar(10) NOT NULL,
  `time` datetime NOT NULL,
  `icon` varchar(100) NOT NULL,
  PRIMARY KEY (`lineTypeId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of linetype
-- ----------------------------
INSERT INTO `linetype` VALUES ('000000', '22', '2019-06-29 00:00:00', '22');
INSERT INTO `linetype` VALUES ('1L9VRG', '境外游', '2019-06-29 12:36:20', 'upload/-42e34ef8f9a42434.jpg');
INSERT INTO `linetype` VALUES ('32c8f4', '境内游', '2019-06-25 00:00:00', 'upload/4d86fbc07ee22e22.jpg');
INSERT INTO `linetype` VALUES ('56464a', '海岛游', '2019-06-25 00:00:00', 'upload/1_194450_6.jpg');
INSERT INTO `linetype` VALUES ('815If8', '境外游1', '2019-07-08 10:24:26', 'upload/1fe2d737f03abc1e.jpg');
INSERT INTO `linetype` VALUES ('oW6va1', '自驾游', '2019-06-25 08:12:04', 'upload/1000(2).jpg');

-- ----------------------------
-- Table structure for `orderdetail`
-- ----------------------------
DROP TABLE IF EXISTS `orderdetail`;
CREATE TABLE `orderdetail` (
  `odId` varchar(36) NOT NULL,
  `customerId` int(10) NOT NULL,
  `lineName` varchar(15) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `orderDate` datetime NOT NULL,
  `travelDate` datetime NOT NULL,
  `total` decimal(10,2) NOT NULL,
  `lineId` varchar(36) NOT NULL,
  `state` int(1) NOT NULL,
  PRIMARY KEY (`odId`),
  KEY `FK9ekcai9ip4xa8jad14ogyxh5a` (`lineId`),
  KEY `FKsqcxmronu0l82njcqq91bslik` (`customerId`),
  CONSTRAINT `FK9ekcai9ip4xa8jad14ogyxh5a` FOREIGN KEY (`lineId`) REFERENCES `line` (`lineId`),
  CONSTRAINT `FKsqcxmronu0l82njcqq91bslik` FOREIGN KEY (`customerId`) REFERENCES `customer` (`customerId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of orderdetail
-- ----------------------------

-- ----------------------------
-- Table structure for `picture`
-- ----------------------------
DROP TABLE IF EXISTS `picture`;
CREATE TABLE `picture` (
  `pictureId` int(10) NOT NULL AUTO_INCREMENT,
  `introduction` varchar(20) NOT NULL,
  `name` varchar(500) NOT NULL,
  `lineId` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`pictureId`),
  KEY `FKajxrh3n0rdhg235h7vf6r64l` (`lineId`),
  CONSTRAINT `FKajxrh3n0rdhg235h7vf6r64l` FOREIGN KEY (`lineId`) REFERENCES `line` (`lineId`)
) ENGINE=InnoDB AUTO_INCREMENT=105 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of picture
-- ----------------------------
INSERT INTO `picture` VALUES ('9', '123', 'upload/13f6adc2ee8b2e0c.jpg', '80U');
INSERT INTO `picture` VALUES ('10', '222', 'upload/null3b2d9ffce072cc3a.jpg', '80U');
INSERT INTO `picture` VALUES ('11', '333', 'upload/null7b1673c73ad3e9d1.jpg', '80U');
INSERT INTO `picture` VALUES ('12', '456', 'upload/null-6f697701af74c1e0.jpg', '80U');
INSERT INTO `picture` VALUES ('13', '123', 'upload/1000(3).jpg', 'Z37');
INSERT INTO `picture` VALUES ('14', '123', 'upload/1000(2).jpg', 'Z37');
INSERT INTO `picture` VALUES ('15', '123', 'upload/20160728084937782.jpg', 'Z37');
INSERT INTO `picture` VALUES ('16', '123', 'upload/3704957_2-130FG24410.jpg', 'Z37');
INSERT INTO `picture` VALUES ('17', '0', 'upload/null-1c55a6ae37d86b09.jpg', 'v2U');
INSERT INTO `picture` VALUES ('18', '1', 'upload/333543754ac644be.jpg', 'v2U');
INSERT INTO `picture` VALUES ('19', '2', 'upload/null-7d1a2d8be1e158e2.jpg', 'v2U');
INSERT INTO `picture` VALUES ('20', '3', 'upload/1555755542_C18AE3871AC771EB412F840D1A26B6D9.jpg', 'v2U');
INSERT INTO `picture` VALUES ('21', '0', 'upload/null-71c3acccd102cba7.jpg', 'Ib8');
INSERT INTO `picture` VALUES ('22', '1', 'upload/null-1e7e064b327a87e5.jpg', 'Ib8');
INSERT INTO `picture` VALUES ('23', '2', 'upload/null-1c55a6ae37d86b09.jpg', 'Ib8');
INSERT INTO `picture` VALUES ('24', '3', 'upload/null5a6a6f0ba73f35d8.jpg', 'Ib8');
INSERT INTO `picture` VALUES ('25', '222', 'upload/null5a6a6f0ba73f35d8.jpg', 'EL7');
INSERT INTO `picture` VALUES ('26', '2222', 'upload/null5a6a6f0ba73f35d8.jpg', 'EL7');
INSERT INTO `picture` VALUES ('27', '3333', 'upload/null5a6a6f0ba73f35d8.jpg', 'EL7');
INSERT INTO `picture` VALUES ('28', '4444', 'upload/null5a6a6f0ba73f35d8.jpg', 'EL7');
INSERT INTO `picture` VALUES ('29', '0', 'upload/1fe2d737f03abc1e.jpg', '77A');
INSERT INTO `picture` VALUES ('30', '0', 'upload/4d86fbc07ee22e22.jpg', '77A');
INSERT INTO `picture` VALUES ('31', '0', 'upload/13f6adc2ee8b2e0c.jpg', '77A');
INSERT INTO `picture` VALUES ('32', '0', 'upload/-42e34ef8f9a42434.jpg', '77A');
INSERT INTO `picture` VALUES ('33', '0', 'upload/1000(2).jpg', 'O8d');
INSERT INTO `picture` VALUES ('34', '0', 'upload/1000(3).jpg', 'O8d');
INSERT INTO `picture` VALUES ('35', '0', 'upload/4d86fbc07ee22e22.jpg', 'O8d');
INSERT INTO `picture` VALUES ('36', '0', 'upload/1000(4).jpg', 'O8d');
INSERT INTO `picture` VALUES ('37', '0', 'upload/549addb68610bdf6.jpg', 'wu3');
INSERT INTO `picture` VALUES ('38', '0', 'upload/1fe2d737f03abc1e.jpg', 'wu3');
INSERT INTO `picture` VALUES ('39', '0', 'upload/13f6adc2ee8b2e0c.jpg', 'wu3');
INSERT INTO `picture` VALUES ('40', '0', 'upload/-42e34ef8f9a42434.jpg', 'wu3');
INSERT INTO `picture` VALUES ('41', '0', 'upload/-1840ce45afd7c145.jpg', 'BvU');
INSERT INTO `picture` VALUES ('42', '0', 'upload/1000(4).jpg', 'BvU');
INSERT INTO `picture` VALUES ('43', '0', 'upload/1000(5).jpg', 'BvU');
INSERT INTO `picture` VALUES ('44', '0', 'upload/1000(4).jpg', 'BvU');
INSERT INTO `picture` VALUES ('45', '0', 'upload/3449971_01.jpg', '7da');
INSERT INTO `picture` VALUES ('46', '0', 'upload/null5a6a6f0ba73f35d8.jpg', '7da');
INSERT INTO `picture` VALUES ('47', '0', 'upload/null-6e9587b316acbcdd.jpg', '7da');
INSERT INTO `picture` VALUES ('48', '0', 'upload/1555755542_C18AE3871AC771EB412F840D1A26B6D9.jpg', '7da');
INSERT INTO `picture` VALUES ('49', '0', 'upload/333543754ac644be.jpg', 'g2r');
INSERT INTO `picture` VALUES ('50', '0', 'upload/3449971_01.jpg', 'g2r');
INSERT INTO `picture` VALUES ('51', '0', 'upload/null-1e7e064b327a87e5.jpg', 'g2r');
INSERT INTO `picture` VALUES ('52', '0', 'upload/null-1c55a6ae37d86b09.jpg', 'g2r');
INSERT INTO `picture` VALUES ('53', '0', 'upload/1_194450_6.jpg', '62R');
INSERT INTO `picture` VALUES ('54', '0', 'upload/333543754ac644be.jpg', '62R');
INSERT INTO `picture` VALUES ('55', '0', 'upload/1000(2).jpg', '62R');
INSERT INTO `picture` VALUES ('56', '0', 'upload/1000.jpg', '62R');
INSERT INTO `picture` VALUES ('57', '0', 'upload/1fe2d737f03abc1e.jpg', '380');
INSERT INTO `picture` VALUES ('58', '0', 'upload/1555755542_C18AE3871AC771EB412F840D1A26B6D9.jpg', '380');
INSERT INTO `picture` VALUES ('59', '0', 'upload/-1840ce45afd7c145.jpg', '380');
INSERT INTO `picture` VALUES ('60', '0', 'upload/3449971_01.jpg', '380');
INSERT INTO `picture` VALUES ('61', '0', 'upload/13f6adc2ee8b2e0c.jpg', '77X');
INSERT INTO `picture` VALUES ('62', '0', 'upload/-42e34ef8f9a42434.jpg', '77X');
INSERT INTO `picture` VALUES ('63', '0', 'upload/-1840ce45afd7c145.jpg', '77X');
INSERT INTO `picture` VALUES ('64', '0', 'upload/1000.jpg', '77X');
INSERT INTO `picture` VALUES ('65', '0', 'upload/-42e34ef8f9a42434.jpg', 'Spx');
INSERT INTO `picture` VALUES ('66', '0', 'upload/3449971_01.jpg', 'Spx');
INSERT INTO `picture` VALUES ('67', '0', 'upload/-42e34ef8f9a42434.jpg', 'Spx');
INSERT INTO `picture` VALUES ('68', '', 'upload/13f6adc2ee8b2e0c.jpg', 'Spx');
INSERT INTO `picture` VALUES ('69', '0', 'upload/20160728084937782.jpg', '146');
INSERT INTO `picture` VALUES ('70', '0', 'upload/1000(4).jpg', '146');
INSERT INTO `picture` VALUES ('71', '0', 'upload/20160728084937782.jpg', '146');
INSERT INTO `picture` VALUES ('72', '0', 'upload/null5a6a6f0ba73f35d8.jpg', '146');
INSERT INTO `picture` VALUES ('73', '0', 'upload/1000(4).jpg', '9XN');
INSERT INTO `picture` VALUES ('74', '0', 'upload/-1840ce45afd7c145.jpg', '9XN');
INSERT INTO `picture` VALUES ('75', '0', 'upload/null5a6a6f0ba73f35d8.jpg', '9XN');
INSERT INTO `picture` VALUES ('76', '0', 'upload/2016033109132213736.jpg', '9XN');
INSERT INTO `picture` VALUES ('77', '0', 'upload/1000(4).jpg', '14Z');
INSERT INTO `picture` VALUES ('78', '0', 'upload/1000(4).jpg', '14Z');
INSERT INTO `picture` VALUES ('79', '0', 'upload/20150904014041_Lw8Cv.jpeg', '14Z');
INSERT INTO `picture` VALUES ('80', '0', 'upload/13f6adc2ee8b2e0c.jpg', '14Z');
INSERT INTO `picture` VALUES ('81', '0', 'upload/1_194450_6.jpg', 'v55');
INSERT INTO `picture` VALUES ('82', '0', 'upload/1fe2d737f03abc1e.jpg', 'v55');
INSERT INTO `picture` VALUES ('83', '0', 'upload/1fe2d737f03abc1e.jpg', 'v55');
INSERT INTO `picture` VALUES ('84', '0', 'upload/-1840ce45afd7c145.jpg', 'v55');
INSERT INTO `picture` VALUES ('85', '0', 'upload/1000(5).jpg', 'pBA');
INSERT INTO `picture` VALUES ('86', '0', 'upload/1000(4).jpg', 'pBA');
INSERT INTO `picture` VALUES ('87', '0', 'upload/13f6adc2ee8b2e0c.jpg', 'pBA');
INSERT INTO `picture` VALUES ('88', '0', 'upload/-42e34ef8f9a42434.jpg', 'pBA');
INSERT INTO `picture` VALUES ('89', '0', 'upload/20160728084937782.jpg', 'xR2');
INSERT INTO `picture` VALUES ('90', '0', 'upload/1fe2d737f03abc1e.jpg', 'xR2');
INSERT INTO `picture` VALUES ('91', '0', 'upload/13f6adc2ee8b2e0c.jpg', 'xR2');
INSERT INTO `picture` VALUES ('92', '0', 'upload/-42e34ef8f9a42434.jpg', 'xR2');
INSERT INTO `picture` VALUES ('93', '0', 'upload/13f6adc2ee8b2e0c.jpg', 'e33');
INSERT INTO `picture` VALUES ('94', '0', 'upload/13f6adc2ee8b2e0c.jpg', 'e33');
INSERT INTO `picture` VALUES ('95', '0', 'upload/-42e34ef8f9a42434.jpg', 'e33');
INSERT INTO `picture` VALUES ('96', '0', 'upload/3704957_2-130FG24410.jpg', 'e33');
INSERT INTO `picture` VALUES ('97', '0', 'upload/-42e34ef8f9a42434.jpg', 'AU1');
INSERT INTO `picture` VALUES ('98', '0', 'upload/1000(5).jpg', 'AU1');
INSERT INTO `picture` VALUES ('99', '0', 'upload/1000(4).jpg', 'AU1');
INSERT INTO `picture` VALUES ('100', '0', 'upload/333543754ac644be.jpg', 'AU1');
INSERT INTO `picture` VALUES ('101', '0', 'upload/1fe2d737f03abc1e.jpg', 'dLb');
INSERT INTO `picture` VALUES ('102', '0', 'upload/1fe2d737f03abc1e.jpg', 'dLb');
INSERT INTO `picture` VALUES ('103', '0', 'upload/4d86fbc07ee22e22.jpg', 'dLb');
INSERT INTO `picture` VALUES ('104', '0', 'upload/13f6adc2ee8b2e0c.jpg', 'dLb');

-- ----------------------------
-- Table structure for `tourist`
-- ----------------------------
DROP TABLE IF EXISTS `tourist`;
CREATE TABLE `tourist` (
  `touristId` varchar(36) NOT NULL,
  `IdCard` varchar(18) NOT NULL,
  `tel` varchar(11) NOT NULL,
  `realName` varchar(12) NOT NULL,
  `odId` varchar(36) NOT NULL,
  PRIMARY KEY (`touristId`),
  KEY `FKblt47nskahin01p6cl7i0ph0s` (`odId`),
  CONSTRAINT `FKblt47nskahin01p6cl7i0ph0s` FOREIGN KEY (`odId`) REFERENCES `orderdetail` (`odId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tourist
-- ----------------------------
