package com.hgkj.model.service.impl;

import com.hgkj.model.dao.Shopdao;
import com.hgkj.model.entity.Shop;
import com.hgkj.model.service.ShopService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public class ShopServiceimpl implements ShopService {
    @Autowired
    private Shopdao shopdao;

    public void setShopdao(Shopdao shopdao) {
        this.shopdao = shopdao;
    }


    @Override
    public List<Shop> allShopService() {
        return shopdao.allShopdao();
    }

    @Override
    public boolean addShopService(Shop shop) {
        return shopdao.addShopdao(shop);
    }

    @Override
    public boolean deleteShopService(int shopId) {
        return shopdao.deleteShopdao(shopId);
    }

    @Override
    public boolean updateShopService(Shop shop) {
        return shopdao.updateShopdao(shop);
    }

    @Override
    public Shop shop(int shopId) {
        return shopdao.shop(shopId);
    }
}
