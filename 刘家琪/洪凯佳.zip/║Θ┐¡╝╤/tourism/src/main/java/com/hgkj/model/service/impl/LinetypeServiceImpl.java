package com.hgkj.model.service.impl;

import com.hgkj.model.dao.LinetypeDao;
import com.hgkj.model.entity.Linetype;
import com.hgkj.model.service.LinetypeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class LinetypeServiceImpl implements LinetypeService {
    @Autowired
    private LinetypeDao linetypeDao;

    public void setLinetypeDao(LinetypeDao linetypeDao) {
        this.linetypeDao = linetypeDao;
    }

    @Override
    public List<Linetype> allLinetypeService() {
        return linetypeDao.allLinetypeDao();
    }

    @Override
    public boolean addLinetypeService(Linetype linetype) {
        return linetypeDao.addLinetypeDao(linetype);
    }

    @Override
    public boolean deleteLinetypeService(Linetype linetype) {
        return linetypeDao.deleteLinetypeDao(linetype);
    }

    @Override
    public boolean updateLinetypeService(Linetype linetype) {
        return linetypeDao.updateLinetypeDao(linetype);
    }

    @Override
    public Linetype getLinetypeByIdService(String lineTypeId) {
        return linetypeDao.getLinetypeByIdDao(lineTypeId);
    }
}
