package com.hjh.model.service.Impl;

import com.hjh.model.dao.AdminDao;
import com.hjh.model.entity.Customer;
import com.hjh.model.service.AdminService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AdminServiceImpl implements AdminService {

    @Autowired
    private AdminDao adminDao;

    public void setAdminDao(AdminDao adminDao) {
        this.adminDao = adminDao;
    }

    public AdminDao getAdminDao() {
        return adminDao;
    }

    @Override
    public Customer AdminLoginService(Customer customer) {
        return adminDao.AdminLoginDao(customer);
    }

    @Override
    public boolean AddadminService(Customer customer) {
        return adminDao.AddadminDao(customer);
    }
}
