package com.workmoney.util;

import com.workmoney.model.entity.Staff;

/**
 * user@Bright Rain .
 * 2019/7/3.
 */
public class StaffChild extends Staff {
}
