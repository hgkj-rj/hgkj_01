package com.hgkj.controller.action;

import com.hgkj.model.entity.Attendance;
import com.hgkj.model.service.AttendanceService;
import com.opensymphony.xwork2.ActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import java.util.List;

@Controller
@Namespace("/")
@ParentPackage("struts-default")
public class AttendanceAction {
    public int attId;
    private Attendance attendance;

    @Autowired
    private AttendanceService attendanceService;

    public void setAttendanceService(AttendanceService attendanceService) {
        this.attendanceService = attendanceService;
    }

    @Action(value = "allAttendance",results =
            {@Result(name = "all",type = "redirect",location = "html/KaoQingList.jsp")})
    public String allAttendance(){
        List<Attendance> attendanceList = attendanceService.allAttendanceService();
        ActionContext.getContext().getSession().put("attendanceList",attendanceList);
        return "all";
    }

    @Action(value = "addAttendance",results =
            {@Result(name = "all",type = "redirectAction",location = "allAttendance")})
    public String addAttendance(){
        attendanceService.addAttendanceService(attendance);
        return "all";
    }

    @Action(value = "deleteAttendance",results =
            {@Result(name = "all",type = "redirectAction",location = "allAttendance")})
    public String deleteAttendance(){
        attendanceService.deleteAttendanceService(attId);
        return "all";
    }

    @Action(value = "updateAttendance",results =
            {@Result(name = "all",type = "redirectAction",location = "allAttendance")})
    public String updateDepartment(){
        attendanceService.updateAttendanceService(attendance);
        return "all";
    }

    @Action(value = "attendance",results =
            {@Result(name = "all",type = "redirect",location = "html/KaoQingUpdate.jsp")})
    public String attendance(){
        Attendance attendance =  attendanceService.attendance(attId);
        ActionContext.getContext().getSession().put("attendance",attendance);
        return "all";
    }





    public int getAttId() {
        return attId;
    }

    public void setAttId(int attId) {
        this.attId = attId;
    }

    public Attendance getAttendance() {
        return attendance;
    }

    public void setAttendance(Attendance attendance) {
        this.attendance = attendance;
    }
}
