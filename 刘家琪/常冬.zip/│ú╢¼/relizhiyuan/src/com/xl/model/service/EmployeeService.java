package com.xl.model.service;

import com.xl.model.entity.Employee;

import java.util.List;

public interface EmployeeService {
    public int EmployeeService(int employee);
    public List<Employee> allEmployeeService(int pageIndex,int pageSize);
    public boolean addEmployeeService(Employee employee);
    public boolean deleteEmployeeService(int employeeId);
    public boolean updateEmployeeService(Employee employee);
}
