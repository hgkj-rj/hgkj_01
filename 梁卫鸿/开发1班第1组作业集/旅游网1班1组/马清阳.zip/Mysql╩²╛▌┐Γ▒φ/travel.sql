/*
 Navicat Premium Data Transfer

 Source Server         : MQL
 Source Server Type    : MySQL
 Source Server Version : 50724
 Source Host           : localhost:3306
 Source Schema         : travel

 Target Server Type    : MySQL
 Target Server Version : 50724
 File Encoding         : 65001

 Date: 07/07/2019 23:35:11
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for car
-- ----------------------------
DROP TABLE IF EXISTS `car`;
CREATE TABLE `car`  (
  `carId` int(11) NOT NULL AUTO_INCREMENT COMMENT '购物车编号',
  `customerId` int(11) NOT NULL COMMENT '客户编号',
  `lineId` varchar(36) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '线路编号',
  `time` datetime(0) NOT NULL COMMENT '线路添加至购物车时间',
  PRIMARY KEY (`carId`) USING BTREE,
  INDEX `FKnlkm0xh8b93fphff487wyh9bi`(`customerId`) USING BTREE,
  INDEX `FKc6b6alxff72xk3ymm0uifq3id`(`lineId`) USING BTREE,
  CONSTRAINT `car_ibfk_1` FOREIGN KEY (`customerId`) REFERENCES `customer` (`customerId`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `car_ibfk_2` FOREIGN KEY (`lineId`) REFERENCES `line` (`lineId`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of car
-- ----------------------------
INSERT INTO `car` VALUES (1, 1, 'JWY101', '2019-06-15 18:12:44');

-- ----------------------------
-- Table structure for customer
-- ----------------------------
DROP TABLE IF EXISTS `customer`;
CREATE TABLE `customer`  (
  `customerId` int(11) NOT NULL AUTO_INCREMENT COMMENT '客户编号',
  `account` varchar(12) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '客户账号',
  `name` varchar(15) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '客户真实姓名',
  `password` varchar(12) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '密码',
  `gender` char(8) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '性别',
  `identityId` varchar(18) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '客户身份证号',
  `tel` varchar(11) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '客户手机号码',
  `type` int(255) NULL DEFAULT NULL COMMENT '状态（值为1时为系统管理员）',
  PRIMARY KEY (`customerId`) USING BTREE,
  UNIQUE INDEX `account`(`account`) USING BTREE COMMENT '唯一的键'
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of customer
-- ----------------------------
INSERT INTO `customer` VALUES (1, 'jack', 'jack', '123', '男', '420581199707141416', '13771179558', 1);
INSERT INTO `customer` VALUES (2, 'Marlucid', 'Marlucid', '123456', '男', '420581199804172514', '18995882563', NULL);

-- ----------------------------
-- Table structure for line
-- ----------------------------
DROP TABLE IF EXISTS `line`;
CREATE TABLE `line`  (
  `lineId` varchar(12) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '线路编号',
  `lineTypeId` varchar(12) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '线路类型编号',
  `lineName` varchar(15) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '线路名称',
  `days` varchar(12) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '出游天数',
  `vehicle` char(2) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '出游交通工具',
  `introduction` varchar(400) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '线路简介',
  `reason` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '线路推荐理由',
  `arrange` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '线路行程安排',
  `price` decimal(10, 2) NOT NULL COMMENT '线路价格',
  `teamBuy` int(20) NULL DEFAULT NULL COMMENT '团购路线（值为1时为团购路线）',
  `teamBuyPrice` decimal(10, 2) NULL DEFAULT NULL COMMENT '线路团购价格',
  `beginTime` datetime(0) NULL DEFAULT NULL COMMENT '线路团购开始时间',
  `endTime` datetime(0) NULL DEFAULT NULL COMMENT '线路团购结束时间',
  `onTime` datetime(0) NOT NULL COMMENT '线路添加时间',
  PRIMARY KEY (`lineId`) USING BTREE,
  INDEX `FKd7h38nar3c77x5uw44ddn6nyf`(`lineTypeId`) USING BTREE,
  CONSTRAINT `line_ibfk_1` FOREIGN KEY (`lineTypeId`) REFERENCES `linetype` (`lineTypeId`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of line
-- ----------------------------
INSERT INTO `line` VALUES ('JNY012', '222', '香港5日游 ', '5天', '高铁', NULL, NULL, NULL, 1850.00, NULL, NULL, NULL, NULL, '2019-07-01 16:58:26');
INSERT INTO `line` VALUES ('JNY121', '222', '丽江7日游', '7天', '高铁', NULL, NULL, NULL, 1450.00, 1, 1300.00, '2019-06-20 11:29:31', '2019-06-27 16:29:55', '2019-07-01 13:00:26');
INSERT INTO `line` VALUES ('JWY101', '333', '三亚3日游', '3天', '飞机', NULL, NULL, NULL, 1680.00, NULL, NULL, NULL, NULL, '2019-07-01 11:55:17');
INSERT INTO `line` VALUES ('JWY103', '444', '泰国7日游', '7天', '飞机', '', '', '', 2890.00, NULL, NULL, NULL, NULL, '2019-07-03 00:00:00');
INSERT INTO `line` VALUES ('JWY104', '333', '巴黎7日游', '7天', '飞机', NULL, NULL, NULL, 2600.00, 1, 2300.00, '2019-06-22 13:30:15', '2019-06-29 10:30:31', '2019-07-02 10:02:21');

-- ----------------------------
-- Table structure for linetype
-- ----------------------------
DROP TABLE IF EXISTS `linetype`;
CREATE TABLE `linetype`  (
  `lineTypeId` varchar(36) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '线路类型编号',
  `typeName` varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '线路类型名称',
  `time` datetime(0) NOT NULL COMMENT '线路类型添加时间',
  `icon` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '线路类型图标名',
  PRIMARY KEY (`lineTypeId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of linetype
-- ----------------------------
INSERT INTO `linetype` VALUES ('222', '国际游', '2019-07-02 00:00:00', 'img/泰国苏梅岛.jpg');
INSERT INTO `linetype` VALUES ('333', '境外游', '2019-06-30 10:53:48', '222');
INSERT INTO `linetype` VALUES ('444', '境外游 — 泰国', '2019-07-03 00:00:00', 'img/埃菲尔铁塔.jpg');
INSERT INTO `linetype` VALUES ('JNY01', '境内游—故宫', '2019-07-04 00:00:00', 'img/故宫.jpg');
INSERT INTO `linetype` VALUES ('JNY02', '境内游—香港', '2019-07-04 00:00:00', 'img/香港.jpg');

-- ----------------------------
-- Table structure for orderdetail
-- ----------------------------
DROP TABLE IF EXISTS `orderdetail`;
CREATE TABLE `orderdetail`  (
  `odId` varchar(36) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '订单编号',
  `customerId` int(11) NOT NULL COMMENT '客户编号',
  `lineName` varchar(15) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '线路名称',
  `price` decimal(10, 2) NOT NULL COMMENT '线路价格',
  `orderDate` datetime(0) NOT NULL COMMENT '下订单日期',
  `travelDate` datetime(0) NOT NULL COMMENT '出游日期',
  `total` decimal(10, 2) NOT NULL COMMENT '总价',
  `lineId` varchar(36) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '线路编号',
  `state` int(20) NOT NULL COMMENT '订单状态（值为1显示，0不显示）',
  PRIMARY KEY (`odId`) USING BTREE,
  INDEX `FK_5`(`customerId`) USING BTREE,
  INDEX `FK52pm7uha76cd6vt1h0blytxda`(`lineId`) USING BTREE,
  CONSTRAINT `orderdetail_ibfk_1` FOREIGN KEY (`customerId`) REFERENCES `customer` (`customerId`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `orderdetail_ibfk_2` FOREIGN KEY (`lineId`) REFERENCES `line` (`lineId`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of orderdetail
-- ----------------------------
INSERT INTO `orderdetail` VALUES ('JWY1001', 1, '三亚3日游', 1680.00, '2019-06-15 15:09:11', '2019-07-18 17:09:50', 1700.00, 'JWY101', 1);

-- ----------------------------
-- Table structure for ot_detail
-- ----------------------------
DROP TABLE IF EXISTS `ot_detail`;
CREATE TABLE `ot_detail`  (
  `otId` int(255) NOT NULL AUTO_INCREMENT COMMENT '订单游客信息编号',
  `odId` varchar(36) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '订单编号',
  `touristId` varchar(36) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '游客信息编号',
  PRIMARY KEY (`otId`) USING BTREE,
  INDEX `FK_7`(`odId`) USING BTREE,
  INDEX `FK_8`(`touristId`) USING BTREE,
  CONSTRAINT `FK_7` FOREIGN KEY (`odId`) REFERENCES `orderdetail` (`odId`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `FK_8` FOREIGN KEY (`touristId`) REFERENCES `tourist` (`touristId`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of ot_detail
-- ----------------------------
INSERT INTO `ot_detail` VALUES (1, 'JWY1001', 'JWY0001');

-- ----------------------------
-- Table structure for picture
-- ----------------------------
DROP TABLE IF EXISTS `picture`;
CREATE TABLE `picture`  (
  `pictureId` int(36) NOT NULL AUTO_INCREMENT COMMENT '图片编号',
  `introduction` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '图片介绍',
  `name` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '图片名称',
  `lineId` varchar(36) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '线路编号',
  PRIMARY KEY (`pictureId`) USING BTREE,
  INDEX `FK_4`(`lineId`) USING BTREE,
  CONSTRAINT `FK_4` FOREIGN KEY (`lineId`) REFERENCES `line` (`lineId`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of picture
-- ----------------------------
INSERT INTO `picture` VALUES (1, '天之涯、海之角', '三亚', 'JWY101');

-- ----------------------------
-- Table structure for tourist
-- ----------------------------
DROP TABLE IF EXISTS `tourist`;
CREATE TABLE `tourist`  (
  `touristId` varchar(36) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '游客信息编号',
  `IDCard` varchar(36) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '游客身份证号',
  `tel` varchar(15) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '游客手机号',
  `realName` varchar(15) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '游客真实姓名',
  PRIMARY KEY (`touristId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of tourist
-- ----------------------------
INSERT INTO `tourist` VALUES ('JWY0001', '420581199912072357', '13672589941', 'rose');

SET FOREIGN_KEY_CHECKS = 1;
