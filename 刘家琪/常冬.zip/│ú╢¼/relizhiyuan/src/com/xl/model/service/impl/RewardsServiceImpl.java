package com.xl.model.service.impl;

import com.xl.model.dao.RewardsDao;
import com.xl.model.dao.impl.RewardsDaoImpl;
import com.xl.model.entity.Rewards;
import com.xl.model.service.RewardsService;

import java.util.List;

public class RewardsServiceImpl implements RewardsService {
    private RewardsDao RewardsDao=new RewardsDaoImpl();
    @Override
    public int RewardsService(int pageSize) {
        return RewardsDao.RewardsDao(pageSize);
    }

    @Override
    public List<Rewards> allRewardsService(int pageIndex, int pageSize) {
        return RewardsDao.allRewardsDao(pageIndex,pageSize);
    }

    @Override
    public Rewards getRewardsByIdService(int cjId) {
        return RewardsDao.getRewardsByIdDao(cjId);
    }

    @Override
    public boolean addRewardsService(Rewards rewards) {
        return RewardsDao.addRewardsDao(rewards);
    }

    @Override
    public boolean deleteRewardsService(int rewards) {
        return RewardsDao.deleteRewardsDao(rewards);
    }

    @Override
    public boolean updateRewardsService(Rewards rewards) {
        return RewardsDao.updateRewardsDao(rewards);
    }
}
