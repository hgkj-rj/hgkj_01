package com.hgkj.contrloer.action;

import com.hgkj.model.entity.Shop;
import com.hgkj.model.entity.SubsidyLog;
import com.hgkj.model.service.SubsidyLogService;
import org.apache.struts2.ServletActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import java.util.List;

@Controller
@Namespace("/")
@ParentPackage("struts-default")
public class SubsidyLogAction {
    @Autowired
    private SubsidyLogService subsidyLogService;
    private SubsidyLog subsidyLog;

    public SubsidyLog getSubsidyLog() {
        return subsidyLog;
    }

    public void setSubsidyLog(SubsidyLog subsidyLog) {
        this.subsidyLog = subsidyLog;
    }

    public void setSubsidyLogService(SubsidyLogService subsidyLogService) {
        this.subsidyLogService = subsidyLogService;
    }

    @Action(value = "allsubsidyLog",results = @Result(name = "all",type = "redirect",location = "/html/subsidyLogList.jsp"))
    public String allsubsidyLog(){
        System.out.println("查询所有补贴记录");
        List<SubsidyLog> subsidyLogList=subsidyLogService.allSubsidyLogService();
        ServletActionContext.getRequest().getSession().setAttribute("subsidyLogList",subsidyLogList);
        return "all";
    }

    @Action(value = "addsubsidyLog",results = @Result(name = "adds",type = "redirectAction",params = {"actionName","allsubsidyLog"}))
    public String addsubsidyLog(){
        boolean r=subsidyLogService.addSubsidyLogService(subsidyLog);
        if (r==true){
            return "adds";
        }else {
            return "adde";
        }
    }

    @Action(value = "delsubsidyLog",results = @Result(name = "dels",type = "redirectAction",params = {"actionName","allsubsidyLog"}))
    public String deletesubsidyLog(){
        boolean r=subsidyLogService.deleteSubsidyLogService(subsidyLog.getStblogId());
        if (r==true){
            return "dels";
        }else {
            return "dele";
        }
    }

    @Action(value = "updsubsidyLog",results = @Result(name = "upds",type = "redirectAction",params = {"actionName","allsubsidyLog"}))
    public String UpdsubsidyLog(){
        boolean r=subsidyLogService.updateSubsidyLogService(subsidyLog);
        if (r==true){
            return "upds";
        }else {
            return "upde";
        }
    }

    @Action(value = "getByIdsubsidyLogs",results = {@Result(name = "getByIds",type = "redirect",location = "/html/")})
    public String getByIdsubsidyLog(){
        SubsidyLog subsidyLog1=subsidyLogService.getByIdSubsidyLogService(subsidyLog.getStblogId());
        ServletActionContext.getRequest().getSession().setAttribute("subsidyLog1",subsidyLog1);
        return "getByIds";
    }
}
