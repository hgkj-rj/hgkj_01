/*
 Navicat Premium Data Transfer

 Source Server         : MySQL
 Source Server Type    : MySQL
 Source Server Version : 50720
 Source Host           : localhost:3306
 Source Schema         : travel

 Target Server Type    : MySQL
 Target Server Version : 50720
 File Encoding         : 65001

 Date: 08/07/2019 09:56:29
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for ot_detail
-- ----------------------------
DROP TABLE IF EXISTS `ot_detail`;
CREATE TABLE `ot_detail`  (
  `otID` int(255) NOT NULL AUTO_INCREMENT,
  `odID` varchar(36) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `touristID` varchar(36) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`otID`) USING BTREE,
  INDEX `FK_OTDetail_odI`(`odID`) USING BTREE,
  INDEX `FK_OTDetail_tourist`(`touristID`) USING BTREE,
  CONSTRAINT `FK_OTDetail_odI` FOREIGN KEY (`odID`) REFERENCES `orderdetail` (`odID`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `FK_OTDetail_tourist` FOREIGN KEY (`touristID`) REFERENCES `tourist` (`touristID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 16 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of ot_detail
-- ----------------------------
INSERT INTO `ot_detail` VALUES (1, 'yk212', 'yk945');
INSERT INTO `ot_detail` VALUES (2, 'yk212', 'yk741');
INSERT INTO `ot_detail` VALUES (3, 'yk212', 'yk825');
INSERT INTO `ot_detail` VALUES (4, 'yk405', 'yk165');
INSERT INTO `ot_detail` VALUES (5, 'yk405', 'yk660');
INSERT INTO `ot_detail` VALUES (6, 'yk405', 'yk627');
INSERT INTO `ot_detail` VALUES (7, 'yk509', 'yk480');
INSERT INTO `ot_detail` VALUES (8, 'yk509', 'yk376');
INSERT INTO `ot_detail` VALUES (9, 'yk509', 'yk76');
INSERT INTO `ot_detail` VALUES (10, 'yk744', 'yk235');
INSERT INTO `ot_detail` VALUES (11, 'yk144', 'yk693');
INSERT INTO `ot_detail` VALUES (12, 'yk310', 'yk499');
INSERT INTO `ot_detail` VALUES (13, 'yk401', 'yk276');
INSERT INTO `ot_detail` VALUES (14, 'yk638', 'yk913');
INSERT INTO `ot_detail` VALUES (15, 'yk848', 'yk818');

SET FOREIGN_KEY_CHECKS = 1;
