package com.hgkj.model.dao.impl;

import com.hgkj.model.dao.LevelDao;
import com.hgkj.model.entity.Department;
import com.hgkj.model.entity.Level;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
@Transactional
public class LevelDaoImpl implements LevelDao {
    @Autowired
    private SessionFactory sessionFactory;
    private Transaction transaction;

    public Transaction getTransaction() {
        return transaction;
    }

    public void setTransaction(Transaction transaction) {
        this.transaction = transaction;
    }

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }
    public Session getSession(){
        return sessionFactory.getCurrentSession();
    }

    @Override
    public List<Level> allLevelDao() {
        Query query=getSession().createQuery("from Level");
        return query.list();
    }

    @Override
    public boolean addLevelDao(Level level) {
        boolean flag=false;
        try {
            getSession().save(level);
            flag=true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return flag;
    }

    @Override
    public boolean updateLevelDao(Level level) {
        boolean flag=false;
        try {
            getSession().update(level);
            flag=true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return flag;
    }

    @Override
    public boolean deleteLevelDao(int levelId) {
        boolean flag=false;
        Level level=new Level();
        level.setLevelId(levelId);
        try {
            getSession().delete(level);
            flag=true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return flag;
    }

    @Override
    public Level getByIdLevelDao(int levelId) {
        Level level=getSession().get(Level.class,levelId);
        return level;
    }
}
