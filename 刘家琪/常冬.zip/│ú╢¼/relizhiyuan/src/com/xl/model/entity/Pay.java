package com.xl.model.entity;

public class Pay {
    private int payId;
    private String payName;
    private String payMo;
    private int payBase;
    private int payOt;
    private int payLe;
    private int payAtt;
    private int payAb;
private int payBx;
private int payRw;

    public Pay() {
    }

    public Pay(String payName, String payMo, int payBase, int payOt, int payLe, int payAtt, int payAb, int payBx, int payRw) {
        this.payName = payName;
        this.payMo = payMo;
        this.payBase = payBase;
        this.payOt = payOt;
        this.payLe = payLe;
        this.payAtt = payAtt;
        this.payAb = payAb;
        this.payBx = payBx;
        this.payRw = payRw;
    }

    public int getPayId() {
        return payId;
    }

    public void setPayId(int payId) {
        this.payId = payId;
    }

    public String getPayName() {
        return payName;
    }

    public void setPayName(String payName) {
        this.payName = payName;
    }

    public String getPayMo() {
        return payMo;
    }

    public void setPayMo(String payMo) {
        this.payMo = payMo;
    }

    public int getPayBase() {
        return payBase;
    }

    public void setPayBase(int payBase) {
        this.payBase = payBase;
    }

    public int getPayOt() {
        return payOt;
    }

    public void setPayOt(int payOt) {
        this.payOt = payOt;
    }

    public int getPayLe() {
        return payLe;
    }

    public void setPayLe(int payLe) {
        this.payLe = payLe;
    }

    public int getPayAtt() {
        return payAtt;
    }

    public void setPayAtt(int payAtt) {
        this.payAtt = payAtt;
    }

    public int getPayAb() {
        return payAb;
    }

    public void setPayAb(int payAb) {
        this.payAb = payAb;
    }



    public int getPayBx() {
        return payBx;
    }

    public void setPayBx(int payBx) {
        this.payBx = payBx;
    }

    public int getPayRw() {
        return payRw;
    }

    public void setPayRw(int payRw) {
        this.payRw = payRw;
    }


}
