package com.mqy.model.dao.impl;

import com.mqy.model.dao.OrderdetailDao;

/**
 * @Author:马清阳
 * @Date:2019/6/26 22:35
 * InteliJ IDEA 1.8
 */
public class OrderdetailDaoImpl implements OrderdetailDao {
}
