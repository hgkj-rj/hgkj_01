package com.hjh.model.service;

import com.hjh.model.entity.Line;

import java.util.List;

public interface LineService {
    public List<Line> AllLine();
    public boolean AddLine(Line line);
    public boolean UpingLine(Line line);
    public Line GetLine(String lineid);
}
