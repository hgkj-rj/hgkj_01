package com.hgkj.model.service;

import com.hgkj.model.entity.SubsidyLog;

import java.util.List;

public interface SubsidyLogService {
    List<SubsidyLog> allSubsidyLogService();
    boolean addSubsidyLogService(SubsidyLog subsidyLog);
    boolean updateSubsidyLogService(SubsidyLog subsidyLog);
    boolean deleteSubsidyLogService(int stblogId);
    SubsidyLog getByIdSubsidyLogService(int stblogId);
}
