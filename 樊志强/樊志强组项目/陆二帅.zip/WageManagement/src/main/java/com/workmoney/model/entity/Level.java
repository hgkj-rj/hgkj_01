package com.workmoney.model.entity;

import java.math.BigDecimal;
import java.util.Objects;

/**
 * user@Bright Rain .
 * 2019/6/21.
 */
public class Level {
    private int levelId;
    private String levelName;
    private BigDecimal levelPrice;

    public int getLevelId() {
        return levelId;
    }

    public void setLevelId(int levelId) {
        this.levelId = levelId;
    }

    public String getLevelName() {
        return levelName;
    }

    public void setLevelName(String levelName) {
        this.levelName = levelName;
    }

    public BigDecimal getLevelPrice() {
        return levelPrice;
    }

    public void setLevelPrice(BigDecimal levelPrice) {
        this.levelPrice = levelPrice;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Level level = (Level) o;
        return levelId == level.levelId &&
                Objects.equals(levelName, level.levelName) &&
                Objects.equals(levelPrice, level.levelPrice);
    }

    @Override
    public int hashCode() {
        return Objects.hash(levelId, levelName, levelPrice);
    }
}
