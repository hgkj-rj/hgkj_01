package com.hgkj.model.service;

import com.hgkj.model.entity.Attendance;

import java.util.List;

public interface AttendanceZBService {
    List<Attendance> allAttendanceService();
    boolean addAttendanceService(Attendance attendance);
    boolean updateAttendanceService(Attendance attendance);
    boolean deleteAttendanceService(int attId);
    Attendance getByIdAttendanceService(int attId);
}
