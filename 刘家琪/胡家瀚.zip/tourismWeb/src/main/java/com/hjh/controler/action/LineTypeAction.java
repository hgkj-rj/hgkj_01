package com.hjh.controler.action;

import com.hjh.model.entity.Linetype;
import com.hjh.model.service.LineTypeService;
import com.opensymphony.xwork2.ActionContext;
import org.apache.commons.io.FileUtils;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

@Controller
@Namespace("/")
@ParentPackage("json-default")
public class LineTypeAction {
    @Autowired
    private LineTypeService lineTypeService;
    @Autowired
    private Linetype linetype;
    private File upload;
    private String uploadFileName;
    List<Linetype> linetypeList;

    public List<Linetype> getLinetypeList() {
        return linetypeList;
    }

    public void setLinetypeList(List<Linetype> linetypeList) {
        this.linetypeList = linetypeList;
    }

    public File getUpload() {
        return upload;
    }

    public void setUpload(File upload) {
        this.upload = upload;
    }

    public String getUploadFileName() {
        return uploadFileName;
    }

    public void setUploadFileName(String uploadFileName) {
        this.uploadFileName = uploadFileName;
    }

    public LineTypeService getLineTypeService() {
        return lineTypeService;
    }

    public void setLineTypeService(LineTypeService lineTypeService) {
        this.lineTypeService = lineTypeService;
    }

    public Linetype getLinetype() {
        return linetype;
    }

    public void setLinetype(Linetype linetype) {
        this.linetype = linetype;
    }

    @Action(value = "AllLineType",results = {@Result(name = "all",type = "redirect",location = "/ht/allLineType.jsp")})
    public String AllLineType(){
        List<Linetype> linetypeList = lineTypeService.AllLineTypeDao();
        ActionContext.getContext().getSession().put("linetypeList",linetypeList);
        return "all";
    }
    @Action(value = "AddLineType",results = {@Result(name = "add",type = "redirectAction",location = "AllLineType.action")
            ,@Result(name = "error",type = "redirectAction",location = "")})
    public String AddLineType() throws Exception {
        String path = "F://Web//tourismWeb//src//main//webapp//ht//images//images//";
        File file = new File(path);
        if (!file.exists()){
            file.mkdir();
        }
        FileUtils.copyFile(upload,new File(file,uploadFileName));
        linetype.setIocn(uploadFileName);
        linetype.setLineTypeid(lineTypeService.GetRan());
        SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
        linetype.setTime(sdf.format(new Date()));
        if (lineTypeService.AddLine(linetype)){
            return "add";
        }else {
            return "error";
        }
    }
    @Action(value = "UpLineType",results = {@Result(name = "up",type = "redirectAction",location = "AllLineType.action"),
            @Result(name = "error",type = "redirectAction",location = "/ht/upLineType.jsp")})
    public String UpLineType() throws Exception{
        String path = "F://Web//tourismWeb//src//main//webapp//ht//images//images//";
        File file = new File(path);
        if (!file.exists()){
            file.mkdir();
        }
        FileUtils.copyFile(upload,new File(file,uploadFileName));
        linetype.setIocn(uploadFileName);
        if (lineTypeService.UpingLineType(linetype)){
            return "up";
        }else {
            return "error";
        }
    }
    @Action(value = "ByIdLineTpye",results = {@Result(name = "ById",type = "redirect",location = "/ht/upLineType.jsp")})
    public String ByIdLineTpye(){
        Linetype linetype1 = lineTypeService.GetLineType(linetype.getLineTypeid());
        ActionContext.getContext().getSession().put("linetype",linetype1);
        return "ById";
    }
    @Action(value = "allLineType",results = {@Result(name = "all",type = "json",params = {"root","linetypeList"})})
    public String allLineType(){
        linetypeList = lineTypeService.AllLineTypeDao();
        return "all";
    }
}
