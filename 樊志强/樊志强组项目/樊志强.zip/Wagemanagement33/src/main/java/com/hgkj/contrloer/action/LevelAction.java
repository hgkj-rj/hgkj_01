package com.hgkj.contrloer.action;

import com.hgkj.model.entity.Level;
import com.hgkj.model.entity.Shop;
import com.hgkj.model.service.LevelService;
import com.opensymphony.xwork2.ActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import java.util.List;

@Controller
@Namespace("/")
@ParentPackage("json-default")
public class LevelAction {
    @Autowired
    private LevelService levelService;
    private Level level;
    private int id;
    @Action(value = "alllevel",results = {@Result(name = "all",type = "redirect",location = "html/levelList.jsp")})
    public String allreward(){
        List<Level> levelList=levelService.alllevelService();
        ActionContext.getContext().getSession().put("levelList",levelList);
        return "all";
    }
    @Action(value = "insertlevel",results = {@Result(name = "insert",type = "redirect",location = "alllevel")})
    public String insert(){
       levelService.insertlevelService(level);
        return "insert";
    }
    @Action(value = "deletelevel",results = {@Result(name = "delete",type = "json",params = {"root","delete"})})
    public String delete(){
        levelService.deletelevelService(id);
        return "delete";
    }
    @Action(value = "updatelevel",results = {@Result(name = "update",type = "redirectAction",location = "alllevel"),@Result(name = "noupdate",type = "redirect",location = "../levelList.jsp")})
    public String update(){
        if (levelService.updatelevelService(level)){
            return "update";
        }else {
            return "noupdate";
        }
    }
    @Action(value = "getlevel",results = {@Result(name = "get",type = "redirect",location = "html/levelupdate.jsp")})
    public String getrewardmanage(){
        level=levelService.getlevelByIdService(id);
        ActionContext.getContext().getSession().put("level",level);
        return "get";
    }
    public void setLevelService(LevelService levelService) {
        this.levelService = levelService;
    }

    public void setLevel(Level level) {
        this.level = level;
    }

    public Level getLevel() {
        return level;
    }

    public void setId(int id) {
        this.id = id;
    }
}
