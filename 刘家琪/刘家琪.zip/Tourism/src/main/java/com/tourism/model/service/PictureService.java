package com.tourism.model.service;

import com.tourism.model.entity.Picture;

import java.util.List;

public interface PictureService {
    public List<Picture> allPictureService();
    public List<Picture> findPictureService(String lineId);
    public List<Picture> findlineService(String lineTypeId);
    public boolean addPictureService(Picture picture);
    public boolean updatePictureService(Picture picture);
}
