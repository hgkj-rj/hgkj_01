package com.hgkj.model.service.impl;

import com.hgkj.model.dao.CarDao;
import com.hgkj.model.entity.Car;
import com.hgkj.model.service.CarService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CarServiceImpl implements CarService {
    @Autowired
    private CarDao carDao;

    public CarDao getCarDao() {
        return carDao;
    }

    public void setCarDao(CarDao carDao) {
        this.carDao = carDao;
    }

    @Override
    public List<Car> allCarService() {
        return carDao.allCarDao();
    }

    @Override
    public boolean addCarService(Car car) {
        return carDao.addCarDao(car);
    }

    @Override
    public boolean deleteCarService(Car car) {
        return carDao.deleteCarDao(car);
    }

    @Override
    public boolean updateCarService(Car car) {
        return carDao.updateCarDao(car);
    }

    @Override
    public Car getCarByIdService(String carId) {
        return carDao.getCarByIdDao(carId);
    }
}
