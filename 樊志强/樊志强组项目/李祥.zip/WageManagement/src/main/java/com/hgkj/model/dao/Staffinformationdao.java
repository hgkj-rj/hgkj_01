package com.hgkj.model.dao;

import com.hgkj.model.entity.Staff;

import java.util.List;

public interface Staffinformationdao {
    public Staff getByIdDao(int staffId);
    public List<Staff> allStaffdao();
    public boolean addStaffdao(Staff staff);
    public boolean deleteStaffdao(int staffId);
    public boolean updateStaffdao(Staff staff);
}
