/*
Navicat MySQL Data Transfer

Source Server         : login
Source Server Version : 50720
Source Host           : localhost:3306
Source Database       : tourism

Target Server Type    : MYSQL
Target Server Version : 50720
File Encoding         : 65001

Date: 2019-07-08 13:00:21
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `car`
-- ----------------------------
DROP TABLE IF EXISTS `car`;
CREATE TABLE `car` (
  `carId` int(11) NOT NULL AUTO_INCREMENT,
  `customerID` int(11) NOT NULL,
  `lineID` varchar(36) NOT NULL,
  `time` datetime NOT NULL,
  PRIMARY KEY (`carId`),
  KEY `car_cust_2` (`lineID`),
  KEY `FKno1l94875exi2qlwvkxklg2o5` (`customerID`),
  CONSTRAINT `FKno1l94875exi2qlwvkxklg2o5` FOREIGN KEY (`customerID`) REFERENCES `customer` (`customerID`),
  CONSTRAINT `car_cust` FOREIGN KEY (`customerID`) REFERENCES `customer` (`customerID`),
  CONSTRAINT `car_cust_2` FOREIGN KEY (`lineID`) REFERENCES `line` (`lineID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of car
-- ----------------------------

-- ----------------------------
-- Table structure for `customer`
-- ----------------------------
DROP TABLE IF EXISTS `customer`;
CREATE TABLE `customer` (
  `customerID` int(255) NOT NULL AUTO_INCREMENT,
  `account` varchar(12) NOT NULL,
  `name` varchar(12) NOT NULL,
  `password` varchar(12) NOT NULL,
  `gender` char(2) NOT NULL,
  `identityID` varchar(18) NOT NULL,
  `tel` varchar(11) NOT NULL,
  `type` int(11) DEFAULT '0',
  PRIMARY KEY (`customerID`),
  UNIQUE KEY `a_u` (`account`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of customer
-- ----------------------------
INSERT INTO `customer` VALUES ('1', '1001', 'zhangsan', '1111', '男', '372321199404249660', '12345678910', null);
INSERT INTO `customer` VALUES ('2', '0001', 'root', '1234', '男', '340421199911162770', '12345678910', '1');

-- ----------------------------
-- Table structure for `line`
-- ----------------------------
DROP TABLE IF EXISTS `line`;
CREATE TABLE `line` (
  `lineID` varchar(12) NOT NULL,
  `lineTypeID` varchar(12) NOT NULL,
  `lineName` varchar(15) NOT NULL,
  `days` varchar(12) NOT NULL,
  `vehicle` char(2) NOT NULL,
  `introduction` varchar(400) DEFAULT NULL,
  `reason` varchar(100) DEFAULT NULL,
  `arrange` varchar(100) DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  `teamBuy` int(11) DEFAULT NULL,
  `teamBuyPrice` decimal(10,2) DEFAULT NULL,
  `beginTime` datetime DEFAULT NULL,
  `endTime` datetime DEFAULT NULL,
  `onTime` datetime NOT NULL,
  PRIMARY KEY (`lineID`),
  KEY `FKmjcgyxrw5nra0fu5p55q3lv7v` (`lineTypeID`),
  CONSTRAINT `FKmjcgyxrw5nra0fu5p55q3lv7v` FOREIGN KEY (`lineTypeID`) REFERENCES `linetype` (`lineTypeID`),
  CONSTRAINT `line_lineType` FOREIGN KEY (`lineTypeID`) REFERENCES `linetype` (`lineTypeID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of line
-- ----------------------------
INSERT INTO `line` VALUES ('1', '1', '1111', '4', '飞机', '境内游', '快捷', '湖北-黑龙江', '2000.00', '1', '1700.00', '2019-06-25 18:00:00', '2019-06-25 20:00:00', '2019-06-24 16:48:24');

-- ----------------------------
-- Table structure for `linetype`
-- ----------------------------
DROP TABLE IF EXISTS `linetype`;
CREATE TABLE `linetype` (
  `lineTypeID` varchar(36) NOT NULL,
  `typeName` varchar(10) NOT NULL,
  `time` datetime NOT NULL,
  `icon` varchar(20) NOT NULL,
  PRIMARY KEY (`lineTypeID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of linetype
-- ----------------------------
INSERT INTO `linetype` VALUES ('1', '境内游', '2019-06-24 16:49:31', '1');
INSERT INTO `linetype` VALUES ('2', '境外游', '2019-06-24 16:51:59', '2');
INSERT INTO `linetype` VALUES ('3', '埃及三日游', '2019-06-24 16:52:26', '3');

-- ----------------------------
-- Table structure for `orderdetail`
-- ----------------------------
DROP TABLE IF EXISTS `orderdetail`;
CREATE TABLE `orderdetail` (
  `odID` varchar(36) NOT NULL,
  `customerID` int(11) NOT NULL,
  `lineName` varchar(15) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `orderDate` datetime NOT NULL,
  `travelDate` datetime NOT NULL,
  `total` decimal(10,2) NOT NULL,
  `lineID` varchar(36) NOT NULL,
  `state` int(11) NOT NULL,
  PRIMARY KEY (`odID`),
  KEY `order_cust` (`customerID`),
  KEY `order_cust_2` (`lineID`),
  CONSTRAINT `order_cust` FOREIGN KEY (`customerID`) REFERENCES `customer` (`customerID`),
  CONSTRAINT `order_cust_2` FOREIGN KEY (`lineID`) REFERENCES `line` (`lineID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of orderdetail
-- ----------------------------

-- ----------------------------
-- Table structure for `picture`
-- ----------------------------
DROP TABLE IF EXISTS `picture`;
CREATE TABLE `picture` (
  `pictureID` int(11) NOT NULL AUTO_INCREMENT,
  `introduction` varchar(20) NOT NULL,
  `name` varchar(20) NOT NULL,
  `lineID` varchar(36) NOT NULL,
  PRIMARY KEY (`pictureID`),
  KEY `pic_ine` (`lineID`),
  CONSTRAINT `pic_ine` FOREIGN KEY (`lineID`) REFERENCES `line` (`lineID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of picture
-- ----------------------------
INSERT INTO `picture` VALUES ('1', '1111', '境内游', '1');

-- ----------------------------
-- Table structure for `tourist`
-- ----------------------------
DROP TABLE IF EXISTS `tourist`;
CREATE TABLE `tourist` (
  `touristID` varchar(36) NOT NULL,
  `IDCard` varchar(36) NOT NULL,
  `tel` varchar(15) NOT NULL,
  `realName` decimal(10,2) NOT NULL,
  `odID` varchar(36) NOT NULL,
  PRIMARY KEY (`touristID`),
  KEY `tourist_order` (`odID`),
  CONSTRAINT `tourist_order` FOREIGN KEY (`odID`) REFERENCES `orderdetail` (`odID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tourist
-- ----------------------------
