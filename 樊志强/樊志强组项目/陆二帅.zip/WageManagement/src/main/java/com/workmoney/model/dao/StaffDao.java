package com.workmoney.model.dao;

import com.workmoney.model.entity.Staff;
import com.workmoney.util.SercharStaff;
import com.workmoney.util.SercharStaffUpload;

import java.util.List;

/**
 * user@Bright Rain .
 * 2019/6/24.
 */
public interface StaffDao {

    /**
     * 登陆
     * @param staff
     * @return
     */
    Staff getStaffLoginDao(Staff staff);

    /**
     * 修改密码
     * @param staff
     * @return
     */
    Staff updateStaffPwdByIdDao(Staff staff);

    /**
     * 查询所有员工
     * @return
     */
    List<Staff> getStaffListSercharDao();

    /**
     * 根据查询条件查询
     * @param sercharStaff
     * @return
     */
    List<Staff> sercharStaffByNameAndMonthDao(SercharStaff sercharStaff);

    /**
     * 修改备注
     * @param staffId
     * @param remark
     * @return
     */
    boolean updateStaffRemarkByIdDao(int staffId, String remark);
}
