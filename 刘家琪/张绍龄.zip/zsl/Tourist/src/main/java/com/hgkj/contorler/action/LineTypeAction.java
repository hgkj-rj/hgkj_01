package com.hgkj.contorler.action;

import com.hgkj.model.Service.LineTypeService;
import com.hgkj.model.entity.Linetype;
import com.opensymphony.xwork2.ActionContext;
import org.apache.struts2.ServletActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import javax.servlet.ServletContext;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Random;

@Controller
@Namespace("/")
@ParentPackage("struts-default")
public class LineTypeAction {
    @Autowired
    private LineTypeService lineTypeService;
    private  File photo;
    private  String photoFileName;
    private  String photoContentType;
    private Linetype linetype;
    public File getPhoto() {
        return photo;
    }

    public void setPhoto(File photo) {
        this.photo = photo;
    }

    public String getPhotoFileName() {
        return photoFileName;
    }

    public void setPhotoFileName(String photoFileName) {
        this.photoFileName = photoFileName;
    }

    public String getPhotoContentType() {
        return photoContentType;
    }

    public void setPhotoContentType(String photoContentType) {
        this.photoContentType = photoContentType;
    }

    public LineTypeService getLineTypeService() {
        return lineTypeService;
    }
    public void setLineTypeService(LineTypeService lineTypeService) {
        this.lineTypeService = lineTypeService;
    }
    public void setLinetype(Linetype linetype) {
        this.linetype = linetype;
    }

    public Linetype getLinetype() {
        return linetype;
    }

    @Action(value = "allLinetype",results = @Result(name = "all",type = "redirect",location = "/seeLineType.jsp"))
    public String allLinetype(){
        List<Linetype> linetypeList = lineTypeService.allLineTypeService();
        ActionContext.getContext().getSession().put("linetypeList",linetypeList);
        return "all";
    }
    @Action(value = "findLineType",results = @Result(name = "find",type = "redirect",location = "/updatelineType.jsp"))
    public String findLineType(){
        linetype = lineTypeService.getLineByIdService(linetype.getLineTypeId());
        ActionContext.getContext().getSession().put("linetype",linetype);
        return "find";
    }
    @Action(value = "addLineType" ,results = {@Result(name = "add",type = "redirectAction",location = "allLinetype.action"),
            @Result(name = "error",type = "redirect",location = "/addlineType.jsp")})
    public String  addLineType(){
        ServletContext servletContext = ServletActionContext.getServletContext();
        String filePath = servletContext.getRealPath("upload");
        File file = new File(filePath);
        if(!file.exists()){
            file.mkdir();
        }
        photo.renameTo(new File(file,photoFileName));
        linetype.setIcon("upload/"+photoFileName);
        Date date = new Date();
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd:hh:mm:ss");
        linetype.setTime(dateFormat.format(date));
        linetype.setLineTypeId(getCharAndNumr(6));
        boolean flag = lineTypeService.addLineTypeService(linetype);
        if(flag) {
            return "add";
        }else
            return "error";
    }
    @Action(value = "updateLineType" ,results = {@Result(name = "update",type = "redirectAction",location = "allLinetype.action"),
            @Result(name = "error",type = "redirect",location = "/updatelineType.jsp")})
    public  String updateLineType(){
      if(photoFileName==null){
          File tempFile = new File(linetype.getIcon().trim());
          String fileName = tempFile.getName();
          linetype.setIcon("upload/"+fileName);
      }else {
          ServletContext application = ServletActionContext.getServletContext();
          String filePath = application.getRealPath("upload");
          File file = new File(filePath);
          if(!file.exists()){
              file.mkdir();
          }
          photo.renameTo(new File(file,photoFileName));
          linetype.setIcon("upload/"+photoFileName);
      }
      boolean flag = lineTypeService.updateLineTypeService(linetype);
      if (flag){
          return "update";
      }
      return "error";
    }

    public static String getCharAndNumr(int length) {
        String val = "";
        Random random = new Random();
        for (int i = 0; i < length; i++) {
            // 输出字母还是数字
            String charOrNum = random.nextInt(2) % 2 == 0 ? "char" : "num";
            // 字符串
            if ("char".equalsIgnoreCase(charOrNum)) {
                // 取得大写字母还是小写字母
                int choice = random.nextInt(2) % 2 == 0 ? 65 : 97;
                val += (char) (choice + random.nextInt(26));
            } else if ("num".equalsIgnoreCase(charOrNum)) { // 数字
                val += String.valueOf(random.nextInt(10));
            }
        }
        return val;
    }
}
