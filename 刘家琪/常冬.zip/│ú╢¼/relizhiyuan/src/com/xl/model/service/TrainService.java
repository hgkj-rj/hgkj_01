package com.xl.model.service;

import com.xl.model.entity.Train;

import java.util.List;

public interface TrainService {
    public int TrainService(int pageSize);
    public List<Train> allTrainService(int pageIndex, int pageSize);
    public Train getTrainByIdService(int TrainId);
    public boolean addTrainService(Train train);
    public boolean deleteTrainService(Train train);
    public boolean updateTrainService(Train train);}
