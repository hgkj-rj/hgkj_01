package com.mqy.controler.action;

import com.mqy.model.entity.Picture;
import com.mqy.model.service.PictureService;
import com.opensymphony.xwork2.ActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import java.util.List;

@Controller
@Namespace("/")
@ParentPackage("struts-default")
public class PictureAction {
    private Picture picture;

    @Autowired
    private PictureService pictureService;

    public void setPictureService(PictureService pictureService) {
        this.pictureService = pictureService;
    }

    /**
     * ��ѯ����ͼƬ
     * @return
     */
    @Action(value = "allPictureAction", results = {
       @Result(name = "all", type = "redirect", location = "ht/picture.jsp")
    })
   public String allPicture(){
        List<Picture> pictureList=pictureService.allPictureService();
        ActionContext.getContext().getSession().put("pictureList",pictureList);
        return "all";
   }

   /* @Action(value = "addPictureAction", results = {@Result(name = "add", type = "redirectAction", params = {"actionName", "allPictureAction"})})
    public String addPicture(){
        pictureService.addPictureService(picture);
        return "add";
  }
    @Action(value = "deletePictureAction",results = {@Result(name = "delete",type = "redirectAction", params = {"actionName", "allPictureAction"})})
    public String deletePicture(){
        pictureService.deletePictureService(picture.getPictureId());
      List<Picture> pictureList=pictureService.allPictureService();
      ActionContext.getContext().getSession().put("pictureList",pictureList);
        return "delete";
  }*/
    public Picture getPicture() {
        return picture;
    }

    public void setPicture(Picture picture) {
        this.picture = picture;
    }
}
