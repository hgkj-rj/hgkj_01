package com.workmoney.model.dao;

import com.workmoney.model.entity.Level;

import java.util.List;

/**
 * user@Bright Rain .
 * 2019/6/30.
 */
public interface LevelDao {

    List<Level> getAllLevelDao();

    /**
     * 添加等级
     * @return
     */
    void addLevelDao(Level level);
    /**
     * 删除等级
     * @return
     */
    void delLevelDao(Level level);
    /**
     * 获取等级
     * @return
     */
    Level getLevelDao(Level level);
    /**
     * 修改等级
     * @return
     */
    void updateLevel(Level level);
}
