package com.hgkj.model.dao.impl;

import com.hgkj.model.dao.ShopDao;
import com.hgkj.model.entity.Department;
import com.hgkj.model.entity.Shop;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
@Repository
@Transactional
public class ShopDaoImpl implements ShopDao {
    @Autowired
    private SessionFactory sessionFactory;
    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }
    public Session session(){
        return sessionFactory.getCurrentSession();
    }

    @Override
    public List<Shop> allshopDao() {
        String hql="from Shop ";
        List<Shop> list=session().createQuery(hql).list();
        return list;
    }

    @Override
    public boolean insertshopDao(Shop shop) {
        boolean b=false;
        session().save(shop);
        b=true;
        return b;
    }

    @Override
    public boolean deleteshopDao(int id) {
        boolean a=false;
        String hql="delete Shop where shopId=?";
        int b=session().createQuery(hql).setParameter(0,id).executeUpdate();
        if (b!=0){
            a=true;
        }
        return a;
    }

    @Override
    public boolean updateshopDao(Shop shop) {
        boolean a=false;
        String hql="update Shop set shopName=?,shopAddress=?,shopRemark=?,shopState=?,shopSupervisor=?where shopId=?";
        int b=session().createQuery(hql).setParameter(0,shop.getShopName()).setParameter(1,shop.getShopAddress()).setParameter(2,shop.getShopRemark()).setParameter(3,shop.getShopState()).setParameter(4,shop.getShopSupervisor()).setParameter(5,shop.getShopId()).executeUpdate();
        if (b!=0){
            a=true;
        }
        return a;
    }

    @Override
    public Shop getshopByIdDao(int id) {
        String hql="from Shop where shopId=?";
        Shop shop=(Shop) session().createQuery(hql).setParameter(0,id).uniqueResult();
        return shop;
    }
}
