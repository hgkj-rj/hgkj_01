package com.hjh.model.dao.Imp;

import com.hjh.model.dao.AdminDao;
import com.hjh.model.entity.Customer;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
@Transactional
public class AdminDaoImpl implements AdminDao {

    @Autowired
    private SessionFactory sessionFactory;

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    public SessionFactory getSessionFactory() {
        return sessionFactory;
    }

    public Session getSession(){
        return sessionFactory.getCurrentSession();
    }

    @Override
    public Customer AdminLoginDao(Customer customer) {
        String hql = "from Customer where accout=? and password=?";
        Session session = getSession();
        Customer customer1 = null;
        try {
            customer1 = (Customer) session.createQuery(hql).setParameter(0,customer.getAccout()).setParameter(1,customer.getPassword()).list().get(0);
        } catch (Exception e) {
            return customer1;
        }
        return customer1;
    }

    @Override
    public boolean AddadminDao(Customer customer) {
        boolean flag = false;
        Session session = getSession();
        try {
            session.save(customer);
            flag = true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return flag;
    }
}
