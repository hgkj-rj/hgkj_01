package com.hgkj.model.entity;

import java.math.BigDecimal;

public class RewardLog {
    private Integer rewlogId;
    private BigDecimal rewMoney;
    private String rewlogTime;

    public Integer getRewlogId() {
        return rewlogId;
    }

    public void setRewlogId(Integer rewlogId) {
        this.rewlogId = rewlogId;
    }

    public BigDecimal getRewPrice() {
        return rewMoney;
    }

    public void setRewPrice(BigDecimal rewPrice) {
        this.rewMoney = rewMoney;
    }

    public String getRewlogTime() {
        return rewlogTime;
    }

    public void setRewlogTime(String rewlogTime) {
        this.rewlogTime = rewlogTime;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        RewardLog rewardLog = (RewardLog) o;

        if (rewlogId != null ? !rewlogId.equals(rewardLog.rewlogId) : rewardLog.rewlogId != null) return false;
        if (rewMoney != null ? !rewMoney.equals(rewardLog.rewMoney) : rewardLog.rewMoney != null) return false;
        if (rewlogTime != null ? !rewlogTime.equals(rewardLog.rewlogTime) : rewardLog.rewlogTime != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = rewlogId != null ? rewlogId.hashCode() : 0;
        result = 31 * result + (rewMoney != null ? rewMoney.hashCode() : 0);
        result = 31 * result + (rewlogTime != null ? rewlogTime.hashCode() : 0);
        return result;
    }
}
