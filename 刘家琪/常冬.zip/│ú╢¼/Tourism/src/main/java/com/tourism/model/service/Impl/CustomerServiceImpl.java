package com.tourism.model.service.Impl;

import com.tourism.model.dao.CustomerDao;
import com.tourism.model.entity.Customer;
import com.tourism.model.service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CustomerServiceImpl implements CustomerService {
    @Autowired
    private CustomerDao customerDao;
    public CustomerDao getCustomerDao(){

        return customerDao;
    }
    public void setCustomerDao(CustomerDao customerDao){

        this.customerDao=customerDao;
    }
    @Override
    public Customer loginService(Customer customer) {

        return customerDao.loginDao(customer);
    }

    @Override
    public boolean addCustomerService(Customer customer) {

        return customerDao.addCustomerDao(customer);
    }
}
