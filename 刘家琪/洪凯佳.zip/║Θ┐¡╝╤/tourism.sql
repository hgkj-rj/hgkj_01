/*
 Navicat MySQL Data Transfer

 Source Server         : m
 Source Server Type    : MySQL
 Source Server Version : 50624
 Source Host           : localhost:3306
 Source Schema         : tourism

 Target Server Type    : MySQL
 Target Server Version : 50624
 File Encoding         : 65001

 Date: 08/07/2019 16:19:15
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for car
-- ----------------------------
DROP TABLE IF EXISTS `car`;
CREATE TABLE `car`  (
  `carID` int(20) NOT NULL AUTO_INCREMENT,
  `customerID` int(20) NOT NULL,
  `lineID` varchar(36) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `time` datetime(6) NOT NULL,
  PRIMARY KEY (`carID`) USING BTREE,
  INDEX `FKno1l94875exi2qlwvkxklg2o5`(`customerID`) USING BTREE,
  INDEX `FKc6b6alxff72xk3ymm0uifq3id`(`lineID`) USING BTREE,
  CONSTRAINT `FKc6b6alxff72xk3ymm0uifq3id` FOREIGN KEY (`lineID`) REFERENCES `line` (`lineID`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `FKno1l94875exi2qlwvkxklg2o5` FOREIGN KEY (`customerID`) REFERENCES `customer` (`customerID`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `ak_2` FOREIGN KEY (`customerID`) REFERENCES `customer` (`customerID`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `ak_3` FOREIGN KEY (`lineID`) REFERENCES `line` (`lineID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Table structure for customer
-- ----------------------------
DROP TABLE IF EXISTS `customer`;
CREATE TABLE `customer`  (
  `customerID` int(20) NOT NULL AUTO_INCREMENT,
  `account` varchar(12) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `name` varchar(12) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `password` varchar(12) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `gender` char(10) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `identityID` varchar(18) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `tel` varchar(11) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `type` int(20) NULL DEFAULT 0,
  PRIMARY KEY (`customerID`) USING BTREE,
  UNIQUE INDEX `ak`(`account`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 6 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of customer
-- ----------------------------
INSERT INTO `customer` VALUES (1, '2718890213', '张三', '77uui8', '男', '421182198008794232', '18070809090', 1);
INSERT INTO `customer` VALUES (2, '2222222222', '李四', '213000', '男', '421189199809214134', '15213456411', 1);
INSERT INTO `customer` VALUES (3, '3333333333', '王五', 'qwerkl', '女', '256125465316711231', '21421674511', 0);
INSERT INTO `customer` VALUES (5, '2222333', 'hong', '212121', 'radio', '421182199808234134', '15572329354', NULL);

-- ----------------------------
-- Table structure for line
-- ----------------------------
DROP TABLE IF EXISTS `line`;
CREATE TABLE `line`  (
  `lineID` varchar(12) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `lineTypeID` varchar(12) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `lineName` varchar(15) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `days` varchar(12) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `vehicle` char(2) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `introduction` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `reason` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `arrange` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `price` decimal(10, 2) NOT NULL,
  `teamBuy` int(255) NULL DEFAULT 0,
  `teamBuyPrice` decimal(10, 2) NULL DEFAULT NULL,
  `beginTime` datetime(6) NULL DEFAULT NULL,
  `endTime` datetime(6) NULL DEFAULT NULL,
  `onTime` datetime(6) NOT NULL,
  PRIMARY KEY (`lineID`) USING BTREE,
  INDEX `FKd7h38nar3c77x5uw44ddn6nyf`(`lineTypeID`) USING BTREE,
  CONSTRAINT `FKd7h38nar3c77x5uw44ddn6nyf` FOREIGN KEY (`lineTypeID`) REFERENCES `linetype` (`lineTypeID`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `ak_1` FOREIGN KEY (`lineTypeID`) REFERENCES `linetype` (`lineTypeID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of line
-- ----------------------------
INSERT INTO `line` VALUES ('1', '2', '国内3日游', '3', '地铁', 'wu', 'wu', 'wu', 100.00, 1, 90.00, '2019-06-15 17:38:29.000000', '2019-06-23 17:39:24.000000', '2019-06-16 17:39:36.000000');
INSERT INTO `line` VALUES ('2', '2', '大巴3日坐', '3', '大巴', 'wu', 'wu', 'wu', 20.00, 1, 20.00, '2019-06-01 17:45:15.000000', '2019-06-04 17:45:21.000000', '2019-06-02 17:45:25.000000');
INSERT INTO `line` VALUES ('C00', '1', '国内7日游', '7', '地铁', 'wu', 'wu', 'wu', 168.00, 1, 20.00, '2019-04-13 14:04:22.000000', '2019-05-21 14:04:39.000000', '2019-07-08 01:58:23.000000');

-- ----------------------------
-- Table structure for linetype
-- ----------------------------
DROP TABLE IF EXISTS `linetype`;
CREATE TABLE `linetype`  (
  `lineTypeID` varchar(36) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `typeName` varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `time` datetime(0) NOT NULL,
  `icon` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`lineTypeID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of linetype
-- ----------------------------
INSERT INTO `linetype` VALUES ('1', '境内游', '2019-07-08 02:15:33', 'upload/tjjd.jpg');
INSERT INTO `linetype` VALUES ('2', '境外游', '2019-06-14 17:29:55', 'upload/zx.jpg');
INSERT INTO `linetype` VALUES ('21i756', '境外游', '2019-07-08 01:09:30', 'upload/zx.jpg');
INSERT INTO `linetype` VALUES ('3', '境外游', '2019-06-10 17:32:36', 'upload/zx.jpg');
INSERT INTO `linetype` VALUES ('3H7171', '境外游', '2019-07-02 05:45:57', 'upload/zx.jpg');
INSERT INTO `linetype` VALUES ('4', '境内游', '2019-06-13 17:32:52', 'upload/zx.jpg');
INSERT INTO `linetype` VALUES ('4p4Y08', '经', '2019-07-08 01:20:43', 'uploadzx.jpg');
INSERT INTO `linetype` VALUES ('5', '境内游', '2019-06-12 17:33:13', 'upload/zx.jpg');
INSERT INTO `linetype` VALUES ('6eaH1b', '境内游', '2019-07-02 05:25:07', 'upload/zx.jpg');
INSERT INTO `linetype` VALUES ('90w4ID', '海岛游', '2019-07-02 05:42:05', 'upload/zx.jpg');
INSERT INTO `linetype` VALUES ('ds3jQn', '看看了', '2019-07-08 02:05:40', 'upload/zx.jpg');
INSERT INTO `linetype` VALUES ('j6zc88', '国外游', '2019-07-05 03:04:08', 'upload/zx.jpg');
INSERT INTO `linetype` VALUES ('JK998z', '海岛游', '2019-07-02 05:45:17', 'upload/zx.jpg');
INSERT INTO `linetype` VALUES ('su314n', 'm', '2019-07-08 02:16:03', 'upload/hd.jpg');

-- ----------------------------
-- Table structure for orderdetail
-- ----------------------------
DROP TABLE IF EXISTS `orderdetail`;
CREATE TABLE `orderdetail`  (
  `odID` varchar(36) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `customerID` int(20) NOT NULL,
  `lineName` varchar(15) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `price` decimal(10, 2) NOT NULL,
  `orderDate` datetime(6) NOT NULL,
  `travelDate` datetime(6) NOT NULL,
  `total` decimal(10, 2) NOT NULL,
  `lineID` varchar(36) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `state` int(20) NOT NULL DEFAULT 0,
  PRIMARY KEY (`odID`) USING BTREE,
  INDEX `ak_5`(`customerID`) USING BTREE,
  INDEX `ak_6`(`lineID`) USING BTREE,
  CONSTRAINT `ak_5` FOREIGN KEY (`customerID`) REFERENCES `customer` (`customerID`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `ak_6` FOREIGN KEY (`lineID`) REFERENCES `line` (`lineID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Table structure for picture
-- ----------------------------
DROP TABLE IF EXISTS `picture`;
CREATE TABLE `picture`  (
  `pictureID` int(20) NOT NULL AUTO_INCREMENT,
  `introduction` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `name` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `lineID` varchar(36) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`pictureID`) USING BTREE,
  INDEX `FKfawrfkab2v4n4xum1frvd5w3p`(`lineID`) USING BTREE,
  CONSTRAINT `FKfawrfkab2v4n4xum1frvd5w3p` FOREIGN KEY (`lineID`) REFERENCES `line` (`lineID`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `ak_4` FOREIGN KEY (`lineID`) REFERENCES `line` (`lineID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of picture
-- ----------------------------
INSERT INTO `picture` VALUES (1, 'sad', 'upload/bb2.jpg', 'C00');
INSERT INTO `picture` VALUES (2, 'sss', 'upload/bb3.jpg', 'C00');
INSERT INTO `picture` VALUES (3, 'sss', 'upload/bb1.jpg', 'C00');
INSERT INTO `picture` VALUES (4, 'sss', 'upload/banner2.jpg', 'C00');

-- ----------------------------
-- Table structure for tourist
-- ----------------------------
DROP TABLE IF EXISTS `tourist`;
CREATE TABLE `tourist`  (
  `touristID` varchar(36) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `IDCard` varchar(18) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `tel` varchar(11) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `realName` varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `odID` varchar(36) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`touristID`) USING BTREE,
  INDEX `ak_7`(`odID`) USING BTREE,
  CONSTRAINT `ak_7` FOREIGN KEY (`odID`) REFERENCES `orderdetail` (`odID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

SET FOREIGN_KEY_CHECKS = 1;
