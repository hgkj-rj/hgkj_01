package com.hgkj.model.service.impl;

import com.hgkj.model.dao.Departmentdao;
import com.hgkj.model.entity.Department;
import com.hgkj.model.service.DepartmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class departmentServiceimpl implements DepartmentService  {
    @Autowired
    private Departmentdao departmentdao;

    public void setDepartmentdao(Departmentdao departmentdao) {
        this.departmentdao = departmentdao;
    }


    @Override
    public List<Department> allDepartmentService() {
        return departmentdao.allDepartmentdao();
    }

    @Override
    public boolean addDepartmentService(Department department) {
        return departmentdao.addDepartmentdao(department);
    }

    @Override
    public boolean deleteDepartmentService(int depId) {
        return departmentdao.deleteDepartmentdao(depId);
    }

    @Override
    public boolean updateDepartmentService(Department department) {
        return departmentdao.updateDepartmentdao(department);
    }

    @Override
    public Department department(int depId) {
        return departmentdao.department(depId);
    }
}
