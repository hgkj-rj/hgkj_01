package com.hgkj.model.dao.impl;

import com.hgkj.model.dao.Shopdao;
import com.hgkj.model.entity.Shop;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;


@Repository
@Transactional
public class Shopdaoimpl implements Shopdao {
    @Autowired
    public SessionFactory sessionFactory;

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    private Session session(){
       return sessionFactory.getCurrentSession();
    }

    @Override
    public List<Shop> allShopdao() {
        Query query = session().createQuery("from Shop");
        return query.list();
    }

    @Override
    public boolean addShopdao(Shop shop) {
        session().save(shop);
        return false;
    }

    @Override
    public boolean deleteShopdao(int shopId) {
        Shop shop = session().get(Shop.class,shopId);
        session().delete(shop);
        return false;
    }

    @Override
    public boolean updateShopdao(Shop shop) {
        session().update(shop);
        return false;
    }

    @Override
    public Shop shop(int shopId) {
        Shop shop = session().get(Shop.class,shopId);
        return shop;
    }
}
