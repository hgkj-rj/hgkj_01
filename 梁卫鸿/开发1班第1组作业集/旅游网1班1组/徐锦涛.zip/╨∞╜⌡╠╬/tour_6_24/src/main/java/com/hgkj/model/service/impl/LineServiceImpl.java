package com.hgkj.model.service.impl;

import com.hgkj.model.dao.LineDao;
import com.hgkj.model.entity.Line;
import com.hgkj.model.service.LineService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class LineServiceImpl implements LineService {
    @Autowired
    private LineDao lineDao;

    public void setLineDao(LineDao lineDao) {
        this.lineDao = lineDao;
    }

    @Override
    public List<Line> allLineService() {
        return lineDao.allLineDao();
    }

    @Override
    public Line lineByIdService(String lineID) {
        return lineDao.lineByIdDao(lineID);
    }

    @Override
    public boolean linedeleteService(String lineID) {
        return lineDao.linedeleteDao(lineID);
    }

    @Override
    public boolean lineAddService(Line line) {
        return lineDao.lineAddDao(line);
    }
}
