package com.tourism.model.service.impl;

import com.tourism.model.dao.LineTypeDao;
import com.tourism.model.entity.Linetype;
import com.tourism.model.service.LineTypeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class LineTypeServiceImpl implements LineTypeService {
    @Autowired
    private LineTypeDao lineTypeDao;

    public LineTypeDao getLineTypeDao() {
        return lineTypeDao;
    }

    public void setLineTypeDao(LineTypeDao lineTypeDao) {
        this.lineTypeDao = lineTypeDao;
    }

    @Override
    public List<Linetype> allLineTypeService() {
        return lineTypeDao.allLineTypeDao();
    }

    @Override
    public List<Linetype> fourLineTypeService() {
        return lineTypeDao.fourLineTypeDao();
    }

    @Override
    public boolean addLineTypeService(Linetype linetype) {
        return lineTypeDao.addLineTypeDao(linetype);
    }

    @Override
    public boolean updateLineTypeService(Linetype linetype) {
        return lineTypeDao.updateLineTypeDao(linetype);
    }

    @Override
    public Linetype getLineTypeByIdService(String lineTypeId) {
        return lineTypeDao.getLineTypeByIdDao(lineTypeId);
    }

    @Override
    public Linetype getLastService() {
        return lineTypeDao.getLastDao();
    }
}
