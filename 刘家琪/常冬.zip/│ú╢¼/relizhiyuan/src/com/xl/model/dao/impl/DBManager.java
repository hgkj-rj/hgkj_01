package com.xl.model.dao.impl;

import java.sql.*;

public class DBManager {
    private static final String driver="com.mysql.jdbc.Driver";
    private static final String url="jdbc:mysql://localhost:3306/rlzy?characterEncoding=utf-8";
    private static final String userName="root";
    private static final String userPwd="123123";
    public  static Connection getConnection(){
        Connection connection=null;
        try {
            Class.forName(driver);
            connection=DriverManager.getConnection(url,userName,userPwd);
        } catch (Exception e) {
            System.out.println("数据连接异常");
            e.printStackTrace();
        }
        return  connection;
    }
    public  static  boolean executeUpdate(String sql,Object[] objs){
        boolean flag=false;
        Connection connection=getConnection();
        PreparedStatement preparedStatement=null;
        try {
            preparedStatement=connection.prepareStatement(sql);
            for(int i=0;i<objs.length;i++){
                preparedStatement.setObject(i+1,objs[i]);
            }
            int count=preparedStatement.executeUpdate();
            if(count>0){
                flag=true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            closeAll(connection,preparedStatement);
        }
        return flag;
    }
    public  static void closeAll(Connection connection,Statement statement,ResultSet resultSet){
        try {
            if(resultSet!=null){
                resultSet.close();
            }
            if(statement!=null){
                statement.close();
            }
            if(connection!=null){
                connection.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public  static void closeAll(Connection connection,Statement statement){
        try {
            if(statement!=null){
                statement.close();
            }
            if(connection!=null){
                connection.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
