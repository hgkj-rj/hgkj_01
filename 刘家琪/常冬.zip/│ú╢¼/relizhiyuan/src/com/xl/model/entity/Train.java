package com.xl.model.entity;

public class Train {
    private int trainId;
    private String trainName;
    private String trainTheme;
    private String trainTime;
    private String trainVenue;
    private String trainRy;
    private String trainBz;
    public Train(){}
    public Train(String trainName, String trainTheme, String trainTime, String trainVenue, String trainRy, String trainBz) {
        this.trainName = trainName;
        this.trainTheme = trainTheme;
        this.trainTime = trainTime;
        this.trainVenue = trainVenue;
        this.trainRy = trainRy;
        this.trainBz = trainBz;
    }

    public int getTrainId() {
        return trainId;
    }

    public void setTrainId(int trainId) {
        this.trainId = trainId;
    }

    public String getTrainName() {
        return trainName;
    }

    public void setTrainName(String trainName) {
        this.trainName = trainName;
    }

    public String getTrainTheme() {
        return trainTheme;
    }

    public void setTrainTheme(String trainTheme) {
        this.trainTheme = trainTheme;
    }

    public String getTrainTime() {
        return trainTime;
    }

    public void setTrainTime(String trainTime) {
        this.trainTime = trainTime;
    }

    public String getTrainVenue() {
        return trainVenue;
    }

    public void setTrainVenue(String trainVenue) {
        this.trainVenue = trainVenue;
    }

    public String getTrainRy() {
        return trainRy;
    }

    public void setTrainRy(String trainRy) {
        this.trainRy = trainRy;
    }

    public String getTrainBz() {
        return trainBz;
    }

    public void setTrainBz(String trainBz) {
        this.trainBz = trainBz;
    }
}
