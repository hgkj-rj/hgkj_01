package com.hgkj.model.service;

import com.hgkj.model.entity.Shop;

import java.util.List;

public interface ShopService {
    public List<Shop> allShopService();
    public boolean addShopService(Shop shop);
    public boolean deleteShopService(int shopId);
    public boolean updateShopService(Shop shop);
    public Shop shop(int shopId);
}
