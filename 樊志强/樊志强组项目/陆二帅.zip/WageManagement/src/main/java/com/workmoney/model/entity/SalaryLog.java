package com.workmoney.model.entity;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Objects;

/**
 * user@Bright Rain .
 * 2019/6/21.
 */
public class SalaryLog {
    private int sallogId;
    private Integer staffId;
    private String staffName;
    private String shopName;
    private String levelName;
    private Timestamp salTime;
    private BigDecimal levelPrice;
    private String attPercent;
    private String totalSubsidy;
    private String totalReward;
    private String salaryOld;
    private String salaryTrue;
    private String sallogRemark;

    public int getSallogId() {
        return sallogId;
    }

    public void setSallogId(int sallogId) {
        this.sallogId = sallogId;
    }

    public Integer getStaffId() {
        return staffId;
    }

    public void setStaffId(Integer staffId) {
        this.staffId = staffId;
    }

    public String getStaffName() {
        return staffName;
    }

    public void setStaffName(String staffName) {
        this.staffName = staffName;
    }

    public String getShopName() {
        return shopName;
    }

    public void setShopName(String shopName) {
        this.shopName = shopName;
    }

    public String getLevelName() {
        return levelName;
    }

    public void setLevelName(String levelName) {
        this.levelName = levelName;
    }

    public Timestamp getSalTime() {
        return salTime;
    }

    public void setSalTime(Timestamp salTime) {
        this.salTime = salTime;
    }

    public BigDecimal getLevelPrice() {
        return levelPrice;
    }

    public void setLevelPrice(BigDecimal levelPrice) {
        this.levelPrice = levelPrice;
    }

    public String getAttPercent() {
        return attPercent;
    }

    public void setAttPercent(String attPercent) {
        this.attPercent = attPercent;
    }

    public String getTotalSubsidy() {
        return totalSubsidy;
    }

    public void setTotalSubsidy(String totalSubsidy) {
        this.totalSubsidy = totalSubsidy;
    }

    public String getTotalReward() {
        return totalReward;
    }

    public void setTotalReward(String totalReward) {
        this.totalReward = totalReward;
    }

    public String getSalaryOld() {
        return salaryOld;
    }

    public void setSalaryOld(String salaryOld) {
        this.salaryOld = salaryOld;
    }

    public String getSalaryTrue() {
        return salaryTrue;
    }

    public void setSalaryTrue(String salaryTrue) {
        this.salaryTrue = salaryTrue;
    }

    public String getSallogRemark() {
        return sallogRemark;
    }

    public void setSallogRemark(String sallogRemark) {
        this.sallogRemark = sallogRemark;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        SalaryLog salaryLog = (SalaryLog) o;
        return sallogId == salaryLog.sallogId &&
                Objects.equals(staffId, salaryLog.staffId) &&
                Objects.equals(staffName, salaryLog.staffName) &&
                Objects.equals(shopName, salaryLog.shopName) &&
                Objects.equals(levelName, salaryLog.levelName) &&
                Objects.equals(salTime, salaryLog.salTime) &&
                Objects.equals(levelPrice, salaryLog.levelPrice) &&
                Objects.equals(attPercent, salaryLog.attPercent) &&
                Objects.equals(totalSubsidy, salaryLog.totalSubsidy) &&
                Objects.equals(totalReward, salaryLog.totalReward) &&
                Objects.equals(salaryOld, salaryLog.salaryOld) &&
                Objects.equals(salaryTrue, salaryLog.salaryTrue) &&
                Objects.equals(sallogRemark, salaryLog.sallogRemark);
    }

    @Override
    public int hashCode() {
        return Objects.hash(sallogId, staffId, staffName, shopName, levelName, salTime, levelPrice, attPercent, totalSubsidy, totalReward, salaryOld, salaryTrue, sallogRemark);
    }
}
