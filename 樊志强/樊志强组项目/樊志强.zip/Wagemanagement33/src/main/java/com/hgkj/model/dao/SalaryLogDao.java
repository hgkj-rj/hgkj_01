package com.hgkj.model.dao;


import com.hgkj.model.entity.AttendanceLog;
import com.hgkj.model.entity.SalaryLog;

import java.util.List;

public interface SalaryLogDao {
    //根据Id显示工资记录
    public List<SalaryLog> getsubsidyDao(int id);
    //显示所有工资记录
    public List<SalaryLog> allsubsidyDao();
    //根据Id查询考勤详情
    public List<AttendanceLog> allAttendanceLogDao(int id);
}
