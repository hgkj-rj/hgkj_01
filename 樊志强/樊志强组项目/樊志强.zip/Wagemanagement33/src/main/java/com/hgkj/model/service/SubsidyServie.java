package com.hgkj.model.service;

import com.hgkj.model.entity.Subsidy;

import java.util.List;

public interface SubsidyServie {
    public List<Subsidy> allSubsidy();

    public boolean  addSubsidy(Subsidy subsidy);

    public boolean   delSubsidy(Subsidy subsidy);

    public boolean  updSubsidy(Subsidy subsidy);

    public Subsidy querySubsidy(Subsidy subsidy);
}
