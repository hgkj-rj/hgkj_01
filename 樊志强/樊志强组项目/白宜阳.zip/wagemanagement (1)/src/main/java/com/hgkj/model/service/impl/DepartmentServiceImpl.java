package com.hgkj.model.service.impl;

import com.hgkj.model.dao.DepartmentDao;
import com.hgkj.model.entity.Department;
import com.hgkj.model.service.DepartmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DepartmentServiceImpl implements DepartmentService {
    @Autowired
    private DepartmentDao departmentDao;

    public void setDepartmentDao(DepartmentDao departmentDao) {
        this.departmentDao = departmentDao;
    }

    @Override
    public List<Department> allDepartmentService() {
        return departmentDao.allDepartmentDao();
    }

    @Override
    public boolean addDepartmentService(Department department) {
        return departmentDao.addDepartmentDao(department);
    }

    @Override
    public boolean updateDepartmentService(Department department) {
        return departmentDao.updateDepartmentDao(department);
    }

    @Override
    public boolean deleteDepartmentService(int depId) {
        return departmentDao.deleteDepartmentDao(depId);
    }

    @Override
    public Department getByIdDepartmentService(int depId) {
        return departmentDao.getByIdDepartmentDao(depId);
    }
}
