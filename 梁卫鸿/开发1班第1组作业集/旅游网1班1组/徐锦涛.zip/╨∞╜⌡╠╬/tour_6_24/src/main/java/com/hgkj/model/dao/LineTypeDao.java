package com.hgkj.model.dao;

import com.hgkj.model.entity.Linetype;

import java.util.List;

public interface LineTypeDao {
    public List<Linetype> lineTypeAllDao();
    public boolean lineTypeAddDao(String lineTypeID, String typeName, String icon);
    public boolean lineTypeDeleteDao(String lineTypeID);
    public Linetype lineTypeIdDao(String lineTypeID);
    public boolean lineTypeUpdateDao(String lineTypeID, String typeName, String icon);
}
