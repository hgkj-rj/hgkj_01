package com.workmoney.model.service;

import com.workmoney.model.dao.AttendanceinfDao;
import com.workmoney.model.entity.Attendance;
import com.workmoney.model.entity.AttendanceLog;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * user@Bright Rain .
 * 2019/6/25.
 */
@Service
public class AttendanceServiceImpl implements AttendanceService{

    @Autowired
    private AttendanceinfDao dao;

    @Override
    public List<AttendanceLog> getAllAttendanceLog(int shopManagerId) {
        return dao.getAllAttendanceLog(shopManagerId);
    }

    @Override
    public List<Attendance> getAttendanceType() {
        List<Attendance> list = dao.getAttendanceTypeDao();
        return list;
    }

    @Override
    public void addAttendanceService(AttendanceLog attendance) {
        dao.addAttendanceDao(attendance);
    }

    @Override
    public AttendanceLog getAttendanceLogById(int staffId, Integer shopId) {

        AttendanceLog attendanceLog=  dao.AttendanceLogByIdDao( staffId,  shopId);

        return attendanceLog;
    }

    @Override
    public void attendanceEditAction(AttendanceLog attendanceLog) {
        dao.attendanceEditAction(attendanceLog);
    }

    @Override
    public void delAttendanceLog(AttendanceLog attendanceLog) {
        dao.delAttendanceLogDao(attendanceLog);
    }

    @Override
    public List<AttendanceLog> attendanceInfoService(int staffId) {
        return dao.attendanceInfoDao(staffId);
    }


    public void setDao(AttendanceinfDao dao) {
        this.dao = dao;
    }
}
