package com.hgkj.controller.action;


import com.hgkj.model.entity.Shop;
import com.hgkj.model.service.ShopService;
import com.opensymphony.xwork2.ActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import java.util.List;

@Controller
@Namespace("/")
@ParentPackage("struts-default")
public class ShopAction {
    public int shopId;
    private Shop shop;

    @Autowired
    public ShopService shopService;

    public void setShopService(ShopService shopService) {
        this.shopService = shopService;
    }

    @Action(value = "allShop",results =
            {@Result(name = "all",type = "redirect",location = "html/ShopList.jsp")})
    public String allShop(){
        List<Shop>shopList = shopService.allShopService();
        ActionContext.getContext().getSession().put("shopList",shopList);
        return "all";
    }

    @Action(value = "addShop",results =
            {@Result(name = "all",type = "redirectAction",location = "allShop")})
    public String addShop(){
        shopService.addShopService(shop);
        return "all";
    }

    @Action(value = "deleteShop",results =
            {@Result(name = "all",type = "redirectAction",location = "allShop")})
    public String deleteShop(){
        shopService.deleteShopService(shopId);
        return "all";
    }

    @Action(value = "updateShop",results =
            {@Result(name = "all",type = "redirectAction",location = "allShop")})
    public String updateShop(){
        shopService.updateShopService(shop);
        return "all";
    }

    @Action(value = "shop",results =
            {@Result(name = "all",type = "redirect",location = "html/ShopUpdate.jsp")})
    public String shop(){
        Shop shop = shopService.shop(shopId);
        ActionContext.getContext().getSession().put("shop",shop);
        return "all";
    }
















    public int getShopId() {
        return shopId;
    }

    public void setShopId(int shopId) {
        this.shopId = shopId;
    }

    public Shop getShop() {
        return shop;
    }

    public void setShop(Shop shop) {
        this.shop = shop;
    }
}
