package com.tourism.model.dao.Impl;

import com.tourism.model.dao.LineDao;

import com.tourism.model.entity.Line;
import com.tourism.model.entity.Linetype;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
@Repository
@Transactional
@Service
public class LineDaoImpl implements LineDao {
    @Autowired
    private SessionFactory sessionFactory;
    private Session session;

    public SessionFactory getSessionFactory() {
        return sessionFactory;
    }

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    public Session getSession() {
        return session;
    }

    public void setSession(Session session) {
        this.session = session;
    }
    @Override
    public boolean addLineDao(Line line) {
        boolean flag=false;
        session =getSession();
        try {
            session.save(line);
            flag=true;
        }catch (Exception e){
            e.printStackTrace();
        }
        return flag;
    }

    @Override
    public boolean updateLineDao(Line line) {
        boolean flag=false;
        session =getSession();
       Linetype linetype=(Linetype) session.load(Linetype.class,line.getLineId());

        try {
            session.update(line);
            flag=true;
        }catch (Exception e){
            e.printStackTrace();
        }
        return flag;
    }

    @Override
    public List<Line> allLineDao() {

        Query query=getSession().createQuery("from Line ");
        return query.list();
    }

    @Override
    public Line getLineByIdDao(String lineId) {
        session=getSession();
        String hql="from Line where lineId=? ";
        Line line=(Line) session.createQuery(hql).setParameter(0,lineId).uniqueResult();
        return line;
    }
}
