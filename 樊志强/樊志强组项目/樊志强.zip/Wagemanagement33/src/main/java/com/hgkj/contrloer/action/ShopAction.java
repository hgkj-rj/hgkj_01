package com.hgkj.contrloer.action;

import com.hgkj.model.entity.Department;
import com.hgkj.model.entity.Shop;
import com.hgkj.model.service.ShopService;
import com.opensymphony.xwork2.ActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import java.util.List;

@Controller
@Namespace("/")
@ParentPackage("json-default")
public class ShopAction {
    @Autowired
    private ShopService shopService;
    private Shop shop;
    private int id;
    @Action(value = "allshop",results = {@Result(name = "all",type = "redirect",location = "html/shopList.jsp")})
    public String allreward(){
        List<Shop> shopList=shopService.allshopService();
        ActionContext.getContext().getSession().put("shopList",shopList);
        return "all";
    }
    @Action(value = "insertshop",results = {@Result(name = "insert",type = "redirect",location = "allshop")})
    public String insert(){
        shopService.insertshopService(shop);
        return "insert";
    }
    @Action(value = "deleteshop",results = {@Result(name = "delete",type = "json",params = {"root","delete"})})
    public String delete(){
        shopService.deleteshopService(id);
        return "delete";
    }
    @Action(value = "updateshop",results = {@Result(name = "update",type = "redirectAction",location = "allshop"),@Result(name = "noupdate",type = "redirect",location = "../shopList.jsp")})
    public String update(){
        if (shopService.updateshopService(shop)){
            return "update";
        }else {
            return "noupdate";
        }
    }
    @Action(value = "getshop",results = {@Result(name = "get",type = "redirect",location = "html/shopupdate.jsp")})
    public String getrewardmanage(){
        shop=shopService.getshopByIdService(id);
        ActionContext.getContext().getSession().put("shop",shop);
        return "get";
    }
    public void setShopService(ShopService shopService) {
        this.shopService = shopService;
    }

    public void setShop(Shop shop) {
        this.shop = shop;
    }

    public Shop getShop() {
        return shop;
    }

    public void setId(int id) {
        this.id = id;
    }
}
