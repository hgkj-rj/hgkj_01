package com.hgkj.model.service.impl;

import com.hgkj.model.dao.LevelDao;
import com.hgkj.model.entity.Level;
import com.hgkj.model.service.LevelService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class LevelServiceImpl implements LevelService {
    @Autowired
    private LevelDao levelDao;

    public void setLevelDao(LevelDao levelDao) {
        this.levelDao = levelDao;
    }

    @Override
    public List<Level> allLevelService() {
        return levelDao.allLevelDao();
    }

    @Override
    public boolean addLevelService(Level level) {
        return levelDao.addLevelDao(level);
    }

    @Override
    public boolean updateLevelService(Level level) {
        return levelDao.updateLevelDao(level);
    }

    @Override
    public boolean deleteLevelService(int levelId) {
        return levelDao.deleteLevelDao(levelId);
    }

    @Override
    public Level getByIdLevelService(int levelId) {
        return levelDao.getByIdLevelDao(levelId);
    }
}
