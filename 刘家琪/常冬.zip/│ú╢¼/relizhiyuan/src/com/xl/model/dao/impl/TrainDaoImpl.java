package com.xl.model.dao.impl;

import com.xl.model.dao.TrainDao;
import com.xl.model.entity.Department;
import com.xl.model.entity.Train;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class TrainDaoImpl implements TrainDao {
    @Override
    public int TrainDao(int pageSize) {
        int totalPage=0;
        Connection connection=DBManager.getConnection();
        PreparedStatement preparedStatement=null;
        ResultSet resultSet=null;
        String sql="select count(*) from train";
        try {
            preparedStatement=connection.prepareStatement(sql);
            resultSet=preparedStatement.executeQuery();
            if (resultSet.next()){
                totalPage=(resultSet.getInt(1)-1)/pageSize+1;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            DBManager.closeAll(connection,preparedStatement,resultSet);
        }
        return totalPage;
    }


    @Override
    public List<Train> allTrainDao(int pageIndex, int pageSize) {
        List<Train> trainList=new ArrayList<>();
        Connection connection=DBManager.getConnection();
        PreparedStatement preparedStatement=null;
        ResultSet resultSet=null;
        String sql="select * from train limit  ?,?";
        try {
            preparedStatement=connection.prepareStatement(sql);
            preparedStatement.setInt(1,(pageIndex-1)*pageSize);
            preparedStatement.setInt(2,pageSize);
            resultSet=preparedStatement.executeQuery();
            while (resultSet.next()){
               Train train=new Train();
                train.setTrainId(resultSet.getInt("trainId"));
                train.setTrainName(resultSet.getString("trainName"));
                train.setTrainTheme(resultSet.getString("trainTheme"));
                train.setTrainTime(resultSet.getString("trainTime"));
                train.setTrainVenue(resultSet.getString("trainVenue"));
                train.setTrainRy(resultSet.getString("trainRy"));
                train.setTrainBz(resultSet.getString("trainBz"));
                trainList.add(train);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            DBManager.closeAll(connection,preparedStatement,resultSet);
        }
        return trainList;
    }

    @Override
    public Train getTrainByIdDao(int departmentId) {

        Train train=new Train();
        Connection connection=DBManager.getConnection();
        PreparedStatement preparedStatement=null;
        ResultSet resultSet=null;
        String sql="select * from train where trainId=?";
        try {
            preparedStatement=connection.prepareStatement(sql);
            preparedStatement.setInt(1,departmentId);
            resultSet=preparedStatement.executeQuery();
            while (resultSet.next()){
                train.setTrainId(resultSet.getInt("trainId"));
                train.setTrainName(resultSet.getString("trainName"));
                train.setTrainTheme(resultSet.getString("trainTheme"));
                train.setTrainTime(resultSet.getString("trainTime"));
                train.setTrainVenue(resultSet.getString("trainVenue"));
                train.setTrainRy(resultSet.getString("trainRy"));
                train.setTrainBz(resultSet.getString("trainBz"));
            }
        }catch (SQLException e){
            e.printStackTrace();
        }finally {
            DBManager.closeAll(connection,preparedStatement,resultSet);
        }
        return train;

    }

    @Override
    public boolean addTrainDao(Train train) {
        String sql = "insert into train(trainName,trainTheme,trainTime,trainVenue,trainRy,trainBz) values(?,?,?,?,?,?)";
        Object[] objects = {train.getTrainName(),train.getTrainTheme(), train.getTrainTime(),train.getTrainVenue(),train.getTrainRy(),train.getTrainBz()};
        return DBManager.executeUpdate(sql,objects);
    }

    @Override
    public boolean deleteTrainDao(Train train) {
        String sql = "delete from train where trainId=?";
        Object[] objects = {train};
        return DBManager.executeUpdate(sql,objects);
    }

    @Override
    public boolean updateTrainDao(Train train) {
        String sql = "update train set trainName=?,trainTheme=?,trainTime=?,trainVenue=?,trainRy=?,trainBz=? where trainId=?";
        Object[] objects = {train.getTrainName(),train.getTrainTheme(), train.getTrainTime(),train.getTrainVenue(),train.getTrainRy(),train.getTrainBz(),train.getTrainId()};
        return DBManager.executeUpdate(sql,objects);
    }
}
