package com.hgkj.contrloer.action;

import com.hgkj.model.entity.Department;
import com.hgkj.model.entity.Subsidy;
import com.hgkj.model.service.DepartmentService;
import org.apache.struts2.ServletActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import java.util.List;

@Controller
@Namespace("/")
@ParentPackage("struts-default")
public class DepartmentAction {
    @Autowired
    private DepartmentService departmentService;
    private Department department;

    public Department getDepartment() {
        return department;
    }

    public void setDepartment(Department department) {
        this.department = department;
    }

    public void setDepartmentService(DepartmentService departmentService) {
        this.departmentService = departmentService;
    }

    @Action(value = "alldepartment",results = @Result(name = "all",type = "redirect",location = "/html/departmentList.jsp"))
    public String alldepartment(){
        List<Department> departmentList=departmentService.allDepartmentService();
        ServletActionContext.getRequest().getSession().setAttribute("departmentList",departmentList);
        return "all";
    }

    @Action(value = "adddepartment",results = @Result(name = "adds",type = "redirectAction",params = {"actionName","alldepartment"}))
    public String adddepartment(){
        boolean r=departmentService.addDepartmentService(department);
        if (r==true){
            return "adds";
        }else {
            return "adde";
        }
    }

    @Action(value = "deldepartment",results = @Result(name = "dels",type = "redirectAction",params = {"actionName","alldepartment"}))
    public String deletedepartment(){
        boolean r=departmentService.deleteDepartmentService(department.getDepId());
        if (r==true){
            return "dels";
        }else {
            return "dele";
        }
    }

    @Action(value = "upddepartment",results = @Result(name = "upds",type = "redirectAction",params = {"actionName","alldepartment"}))
    public String Upddepartment(){
        boolean r=departmentService.updateDepartmentService(department);
        if (r==true){
            return "upds";
        }else {
            return "upde";
        }
    }

    @Action(value = "getByIddepartments",results = {@Result(name = "getByIds",type = "redirect",location = "/html/departmentUpdate.jsp")})
    public String getByIddepartment(){
        Department department1=departmentService.getByIdDepartmentService(department.getDepId());
        ServletActionContext.getRequest().getSession().setAttribute("department1",department1);
        return "getByIds";
    }
}
