package com.tourism.model.service.impl;

import com.tourism.model.dao.TouristDao;
import com.tourism.model.service.TouristService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class TouristServiceImpl implements TouristService {
    @Autowired
    private TouristDao touristDao;
}
