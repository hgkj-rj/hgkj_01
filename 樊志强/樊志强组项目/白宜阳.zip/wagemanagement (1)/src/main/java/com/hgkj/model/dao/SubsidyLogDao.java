package com.hgkj.model.dao;

import com.hgkj.model.entity.SubsidyLog;

import java.util.List;

public interface SubsidyLogDao {
    List<SubsidyLog> allSubsidyLogDao();
    boolean addSubsidyLogDao(SubsidyLog subsidyLog);
    boolean updateSubsidyLogDao(SubsidyLog subsidyLog);
    boolean deleteSubsidyLogDao(int stblogId);
    SubsidyLog getByIdSubsidyLogDao(int stblogId);
}
