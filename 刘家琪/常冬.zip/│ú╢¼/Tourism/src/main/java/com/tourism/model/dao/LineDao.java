package com.tourism.model.dao;

import com.tourism.model.entity.Line;
import com.tourism.model.entity.Linetype;

import java.util.List;

public interface LineDao {
    public boolean addLineDao(Line line);
    public boolean updateLineDao(Line line);
    public List<Line> allLineDao();
    public Line getLineByIdDao(String lineId);
}
