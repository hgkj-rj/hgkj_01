package com.tourism.controler.action;

import com.opensymphony.xwork2.ActionContext;
import com.tourism.model.entity.Customer;
import com.tourism.model.service.CustomerService;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

@Controller
@Namespace("/")
@ParentPackage("struts-default")
public class CustomerAction {
    @Autowired
    private CustomerService customerService;
    private Customer customer;

    public CustomerService getCustomerService() {
        return customerService;
    }

    public void setCustomerService(CustomerService customerService) {
        this.customerService = customerService;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    @Action(value = "qtlogin",results = {@Result(name = "login",type = "redirectAction",location = "toIndex.action"),
            @Result(name = "loginerror",type = "redirect",location = "/login.jsp")})
    public String qtLogin(){
        customer = customerService.loginService(customer);
        if (customer!=null){
            ActionContext.getContext().getSession().put("customer",customer);
            return "login";
        }else {
            return "loginerror";
        }

    }

    @Action(value = "htlogin",results = {@Result(name = "login",type = "redirect",location = "/htindex.jsp"),
            @Result(name = "loginerror",type = "redirect",location = "/adminlogin.jsp")})
    public String htLogin(){
        customer = customerService.loginService(customer);
        if (customer!=null){
            if (customer.getType()!=null){
                if (customer.getType()==1){
                    ActionContext.getContext().getSession().put("customer1",customer);
                    return "login";
                }
            }
        }
        return "loginerror";

    }

    @Action(value = "addCustomer",results = {@Result(name = "add",type = "redirect",location = "/login.jsp"),
            @Result(name = "error",type = "redirect",location = "/regist.jsp")})
    public String addCustomer(){
        boolean flag = customerService.addCustomerService(customer);
        if (flag){
            return "add";
        }
        return "error";
    }

    @Action(value = "qttuichu",results = {@Result(name = "tui",type = "redirect",location = "/index.jsp")})
    public String qttuichu(){
        ActionContext.getContext().getSession().remove("customer");
        return "tui";
    }

    @Action(value = "httuichu",results = {@Result(name = "tui",type = "redirect",location = "/adminlogin.jsp")})
    public String httuichu(){
        ActionContext.getContext().getSession().remove("customer1");
        return "tui";
    }
}
