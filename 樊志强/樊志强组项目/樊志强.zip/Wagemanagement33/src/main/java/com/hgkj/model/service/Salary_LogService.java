package com.hgkj.model.service;

import com.hgkj.model.entity.AttendanceLog;
import com.hgkj.model.entity.SalaryLog;
import com.hgkj.model.entity.Staff;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

public interface Salary_LogService {

    public List<SalaryLog> allSalaryList();

    public List<SalaryLog> querySalaryService(Staff staff);

    public List SalaryLog_AttendanceLog(int staffId);

    public   List<SalaryLog>  dimquery(String name);


    public List<SalaryLog> Salary_Next(int index);

    public int Salary_Pages();

    public List<SalaryLog> Salary_End(Staff staff);

    public boolean addSalaryService(SalaryLog salaryLog);

    public boolean updSalaryService(SalaryLog salaryLog);

    public boolean delSalaryService(SalaryLog salaryLog);
}
