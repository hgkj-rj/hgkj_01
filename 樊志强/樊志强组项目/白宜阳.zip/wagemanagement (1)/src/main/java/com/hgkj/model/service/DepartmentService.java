package com.hgkj.model.service;

import com.hgkj.model.entity.Department;

import java.util.List;

public interface DepartmentService {
    List<Department> allDepartmentService();
    boolean addDepartmentService(Department department);
    boolean updateDepartmentService(Department department);
    boolean deleteDepartmentService(int depId);
    Department getByIdDepartmentService(int depId);
}
