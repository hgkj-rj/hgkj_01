package com.hjh.model.entity;

import java.math.BigDecimal;
import java.sql.Timestamp;

public class Orderdetail {
    private String odid;
    private String lineName;
    private BigDecimal price;
    private Timestamp orderdate;
    private Timestamp traveldate;
    private BigDecimal total;
    private int state;

    public String getOdid() {
        return odid;
    }

    public void setOdid(String odid) {
        this.odid = odid;
    }

    public String getLineName() {
        return lineName;
    }

    public void setLineName(String lineName) {
        this.lineName = lineName;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public Timestamp getOrderdate() {
        return orderdate;
    }

    public void setOrderdate(Timestamp orderdate) {
        this.orderdate = orderdate;
    }

    public Timestamp getTraveldate() {
        return traveldate;
    }

    public void setTraveldate(Timestamp traveldate) {
        this.traveldate = traveldate;
    }

    public BigDecimal getTotal() {
        return total;
    }

    public void setTotal(BigDecimal total) {
        this.total = total;
    }

    public int getState() {
        return state;
    }

    public void setState(int state) {
        this.state = state;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Orderdetail that = (Orderdetail) o;

        if (state != that.state) return false;
        if (odid != null ? !odid.equals(that.odid) : that.odid != null) return false;
        if (lineName != null ? !lineName.equals(that.lineName) : that.lineName != null) return false;
        if (price != null ? !price.equals(that.price) : that.price != null) return false;
        if (orderdate != null ? !orderdate.equals(that.orderdate) : that.orderdate != null) return false;
        if (traveldate != null ? !traveldate.equals(that.traveldate) : that.traveldate != null) return false;
        if (total != null ? !total.equals(that.total) : that.total != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = odid != null ? odid.hashCode() : 0;
        result = 31 * result + (lineName != null ? lineName.hashCode() : 0);
        result = 31 * result + (price != null ? price.hashCode() : 0);
        result = 31 * result + (orderdate != null ? orderdate.hashCode() : 0);
        result = 31 * result + (traveldate != null ? traveldate.hashCode() : 0);
        result = 31 * result + (total != null ? total.hashCode() : 0);
        result = 31 * result + state;
        return result;
    }
}
