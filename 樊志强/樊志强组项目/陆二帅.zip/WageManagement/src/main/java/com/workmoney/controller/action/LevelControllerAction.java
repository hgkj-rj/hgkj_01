package com.workmoney.controller.action;

import com.workmoney.model.entity.Level;
import com.workmoney.model.service.LevelService;
import org.apache.struts2.ServletActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import javax.servlet.http.HttpSession;
import java.util.List;

/**
 * user@Bright Rain .
 * 2019/6/30.
 */
@ParentPackage("struts-default")
@Namespace("/")
@Controller
public class LevelControllerAction {

    @Autowired
    private LevelService service;

    private Level level;

    @Action(value = "/addlevelAction",results = {@Result(name = "success",type = "redirectAction",location = "getAllLevelAction")})
    public String addlevelAction(){

        service.addLevelService(level);
        return "success";
    }

    /**
     * 修改
     * @return
     */

    @Action(value = "/editlevelAction",results = {@Result(name = "success",type = "redirectAction",location = "getAllLevelAction")})
    public String editlevelAction(){
        service.updateLevel(level);
        return "success";
    }

    /**
     * 去往修改页面
     * @return
     */
    @Action(value = "/goEditlevelByIdAction",results = {@Result(name = "success",type = "redirect",location = "html/LevelEdit.jsp")})
    public String goEditlevelByIdAction(){
        HttpSession session = ServletActionContext.getRequest().getSession();
        Level level1 = service.getLevelService(level);
        session.setAttribute("level",level1);
        return "success";
    }

    /**
     * 删除
     * @return
     */
    @Action(value = "/dellevelByIdAction",results = {@Result(name = "success",type = "redirectAction",location = "getAllLevelAction")})
    public String dellevelByIdAction(){
        service.delLevelService(level);
        return "success";
    }

    /**
     * 获取所有
     * @return
     */
    @Action(value = "/getAllLevelAction",results = {@Result(name = "success",type = "redirect",location = "html/LevelList.jsp")})
    public String getAllLevelAction(){

        HttpSession session = ServletActionContext.getRequest().getSession();
        List<Level> levelList = service.getAllLevelService();
        session.setAttribute("levelList",levelList);
        return "success";
    }

    public Level getLevel() {
        return level;
    }

    public void setLevel(Level level) {
        this.level = level;
    }
}
