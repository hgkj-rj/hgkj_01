package com.tourism.controler.action;

import com.opensymphony.xwork2.ActionContext;
import com.tourism.model.entity.Line;
import com.tourism.model.entity.Linetype;
import com.tourism.model.entity.Picture;
import com.tourism.model.service.LineService;
import com.tourism.model.service.LineTypeService;
import com.tourism.model.service.PictureService;
import org.apache.struts2.ServletActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import javax.servlet.ServletContext;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Random;

@Controller
@Namespace("/")
@ParentPackage("struts-default")
public class LineAction {
    @Autowired
    private LineService lineService;
    @Autowired
    private PictureService pictureService;
    @Autowired
    private LineTypeService lineTypeService;
    private Line line;
    private Picture picture;
    private List<Picture> pictures;
    private File[] upload;
    private String[] uploadFileName;
    private String[] uploadContentType;
    private Picture picture0;
    private Picture picture1;
    private Picture picture2;
    private Picture picture3;
    private int pageindex;

    public int getPageindex() {
        return pageindex;
    }

    public void setPageindex(int pageindex) {
        this.pageindex = pageindex;
    }

    public LineService getLineService() {
        return lineService;
    }

    public void setLineService(LineService lineService) {
        this.lineService = lineService;
    }

    public Line getLine() {
        return line;
    }

    public void setLine(Line line) {
        this.line = line;
    }

    public PictureService getPictureService() {
        return pictureService;
    }

    public void setPictureService(PictureService pictureService) {
        this.pictureService = pictureService;
    }

    public Picture getPicture() {
        return picture;
    }

    public void setPicture(Picture picture) {
        this.picture = picture;
    }

    public LineTypeService getLineTypeService() {
        return lineTypeService;
    }

    public void setLineTypeService(LineTypeService lineTypeService) {
        this.lineTypeService = lineTypeService;
    }

    public List<Picture> getPictures() {
        return pictures;
    }

    public void setPictures(List<Picture> pictures) {
        this.pictures = pictures;
    }

    public Picture getPicture1() {
        return picture1;
    }

    public void setPicture1(Picture picture1) {
        this.picture1 = picture1;
    }

    public Picture getPicture2() {
        return picture2;
    }

    public void setPicture2(Picture picture2) {
        this.picture2 = picture2;
    }

    public Picture getPicture3() {
        return picture3;
    }

    public void setPicture3(Picture picture3) {
        this.picture3 = picture3;
    }


    public Picture getPicture0() {
        return picture0;
    }

    public void setPicture0(Picture picture0) {
        this.picture0 = picture0;
    }

    public File[] getUpload() {
        return upload;
    }

    public void setUpload(File[] upload) {
        this.upload = upload;
    }

    public String[] getUploadFileName() {
        return uploadFileName;
    }

    public void setUploadFileName(String[] uploadFileName) {
        this.uploadFileName = uploadFileName;
    }

    public String[] getUploadContentType() {
        return uploadContentType;
    }

    public void setUploadContentType(String[] uploadContentType) {
        this.uploadContentType = uploadContentType;
    }

    @Action(value = "allLine",results = @Result(name = "all",type = "redirect",location = "/allLine.jsp"))
    public String allLine(){
        List<Line> lineList = lineService.allLineService();
        ActionContext.getContext().getSession().put("lineList",lineList);
        return "all";
    }

    @Action(value = "toIndex",results = @Result(name = "all",type = "redirect",location = "/index.jsp"))
    public String toIndex(){
        List<Linetype> linetypeList = lineTypeService.fourLineTypeService();
        ActionContext.getContext().getSession().put("linetypeList",linetypeList);
        String lineTypeId;
        if(line==null){
            Linetype linetype = lineTypeService.getLastService();
            lineTypeId = linetype.getLineTypeId();
        }else {
            lineTypeId = line.getLinetype().getLineTypeId();
        }
        List<Picture> pictureList1= pictureService.findlineService(lineTypeId);
        ActionContext.getContext().getSession().put("pictureList1",pictureList1);

        String typeId = "32c8f4";
        List<Line> lineList11 = lineService.toIndexLineService(typeId);
        ActionContext.getContext().getSession().put("lineList11",lineList11);

        typeId = "1L9VRG";
        List<Line> lineList22 = lineService.toIndexLineService(typeId);
        ActionContext.getContext().getSession().put("lineList22",lineList22);

        typeId = "56464a";
        List<Line> lineList33 = lineService.toIndexLineService(typeId);
        ActionContext.getContext().getSession().put("lineList33",lineList33);

        typeId = "oW6va1";
        List<Line> lineList44 = lineService.toIndexLineService(typeId);
        ActionContext.getContext().getSession().put("lineList44",lineList44);


        List<Line> lineList1 = lineService.allLineService();
        ActionContext.getContext().getSession().put("lineList1",lineList1);

        List<Line> lineListYi = lineService.yiLineService();
        ActionContext.getContext().getSession().put("lineListYi",lineListYi);
        List<Line> lineListEr = lineService.erLineService();
        ActionContext.getContext().getSession().put("lineListEr",lineListEr);
        List<Line> lineListDuo = lineService.duoLineService();
        ActionContext.getContext().getSession().put("lineListDuo",lineListDuo);

        List<Picture> pictureList =pictureService.allPictureService();
        ActionContext.getContext().getSession().put("pictureList",pictureList);
        return "all";
    }

    @Action(value = "toGroup",results = @Result(name = "all",type = "redirect",location = "/group.jsp"))
    public String toGroup(){
        if (pageindex==0){
            pageindex=1;
        }
        int pagesize = 6;
        Date date = new Date();
        SimpleDateFormat dateFormat= new SimpleDateFormat("yyyy-MM-dd :hh:mm:ss");
        String time = dateFormat.format(date);
        int totalpage = lineService.gettotalpageService(pagesize,time);
        totalpage = (totalpage+pagesize-1)/pagesize;
        if (pageindex<1){
            pageindex = 1;
        }else if (pageindex>totalpage){
            pageindex = totalpage;
        }
        ActionContext.getContext().getSession().put("pageindex",pageindex);
        ActionContext.getContext().getSession().put("totalpage",totalpage);
        List<Line> lineList =lineService.allLineService(pageindex,pagesize,time);
        ActionContext.getContext().getSession().put("lineList",lineList);
        return "all";
    }

    @Action(value = "toDetail",results = @Result(name = "all",type = "redirect",location = "/detail.jsp"))
    public String toDetail(){
        line = lineService.getLineByIdService(line.getLineId());
        ActionContext.getContext().getSession().put("line",line);
        List<Picture> pictureList=pictureService.findPictureService(line.getLineId());
        ActionContext.getContext().getSession().put("pictureList",pictureList);
        return "all";
    }

    @Action(value = "toOrder",results = @Result(name = "all",type = "redirect",location = "/order.jsp"))
    public String toOrder(){
        line = lineService.getLineByIdService(line.getLineId());
        ActionContext.getContext().getSession().put("line",line);
        return "all";
    }

    @Action(value = "allTuanGou",results = @Result(name = "all",type = "redirect",location = "/allTuanGou.jsp"))
    public String allTuanGou(){
        List<Line> lineList = lineService.allTuanGouLineService();
        ActionContext.getContext().getSession().put("lineList",lineList);
        return "all";
    }

    @Action(value = "allTuanGouLine",results = @Result(name = "all",type = "redirect",location = "/allTuanGouXianLu.jsp"))
    public String allTuanGouLine(){
        List<Line> lineList = lineService.allLineService();
        ActionContext.getContext().getSession().put("lineList",lineList);
        return "all";
    }

    @Action(value = "addLine",results = {@Result(name = "add",type = "redirectAction",location = "allLine.action"),
            @Result(name = "error",type = "redirect",location = "/addLine.jsp")})
    public String addLine(){
        boolean flag = false;
        ServletContext application = ServletActionContext.getServletContext();
        String filePath = application.getRealPath("upload");
        File file=new File(filePath);
        if(!file.exists()){
            file.mkdirs();
        }
        for (int i=0;i<upload.length;i++){
            upload[i].renameTo(new File(file,uploadFileName[i]));
        }
        Date date = new Date();
        SimpleDateFormat dateFormat= new SimpleDateFormat("yyyy-MM-dd :hh:mm:ss");
        line.setOnTime(dateFormat.format(date));
        line.setLineId(getCharAndNumr(3));
        flag = lineService.addLineService(line);
        if (!flag){
            return "error";
        }
        for (int i=0;i<4;i++){
            pictures.get(i).setLine(line);
            pictures.get(i).setName("upload/"+uploadFileName[i]);
            flag = pictureService.addPictureService(pictures.get(i));
            if (!flag){
                return "error";
            }
        }
        return "add";
    }

    @Action(value = "toaddLine",results = @Result(name = "toadd",type = "redirect",location = "/addLine.jsp"))
    public String toaddLine(){
        List<Linetype> linetypeList = lineTypeService.allLineTypeService();
        ActionContext.getContext().getSession().put("linetypeList",linetypeList);
        return "toadd";
    }

    @Action(value = "findLine",results = {@Result(name = "find",type = "redirect",location = "/updateLine.jsp")})
    public String findLineType(){
        line = lineService.getLineByIdService(line.getLineId());
        List<Picture> pictureList = pictureService.findPictureService(line.getLineId());
        ActionContext.getContext().getSession().put("line",line);
        ActionContext.getContext().getSession().put("pictureList",pictureList);
        List<Linetype> linetypeList = lineTypeService.allLineTypeService();
        ActionContext.getContext().getSession().put("linetypeList",linetypeList);
        return "find";
    }

    @Action(value = "findTuanGouLine",results = {@Result(name = "find",type = "redirect",location = "/updateTuanGouXinXi.jsp")})
    public String findTuanGouLine(){
        line = lineService.getLineByIdService(line.getLineId());
        List<Picture> pictureList = pictureService.findPictureService(line.getLineId());
        ActionContext.getContext().getSession().put("line",line);
        ActionContext.getContext().getSession().put("pictureList",pictureList);
        List<Linetype> linetypeList = lineTypeService.allLineTypeService();
        ActionContext.getContext().getSession().put("linetypeList",linetypeList);
        return "find";
    }

    @Action(value = "updateLine",results = {@Result(name = "update",type = "redirectAction",location = "allLine.action"),
            @Result(name = "error",type = "redirect",location = "/updateLine.jsp")})
    public String updateLine(){
        boolean flag = false;
        if (upload!=null){
            ServletContext application = ServletActionContext.getServletContext();
            String filePath = application.getRealPath("upload");
            File file=new File(filePath);
            if(!file.exists()){
                file.mkdirs();
            }
            for (int i=0;i<upload.length;i++){
                upload[i].renameTo(new File(file,uploadFileName[i]));
            }
        }

        flag = lineService.updateLineService(line);
        if (!flag){
            return "error";
        }
        picture0.setLine(line);
        picture1.setLine(line);
        picture2.setLine(line);
        picture3.setLine(line);

        File tempFile0 =new File(picture0.getName().trim());
        String fileName0 = tempFile0.getName();
        picture0.setName("upload/"+fileName0);

        File tempFile1 =new File(picture1.getName().trim());
        String fileName1 = tempFile1.getName();
        picture1.setName("upload/"+fileName1);

        File tempFile2 =new File(picture2.getName().trim());
        String fileName2 = tempFile2.getName();
        picture2.setName("upload/"+fileName2);

        File tempFile3 =new File(picture3.getName().trim());
        String fileName3 = tempFile3.getName();
        picture3.setName("upload/"+fileName3);

        flag = pictureService.updatePictureService(picture0);
            if (!flag){
            return "error";
        }

        flag = pictureService.updatePictureService(picture1);
        if (!flag){
            return "error";
        }

        flag = pictureService.updatePictureService(picture2);
        if (!flag){
            return "error";
        }

        flag = pictureService.updatePictureService(picture3);
        if (!flag){
            return "error";
        }

        return "update";
    }

    @Action(value = "updateTuanGouLine",results = {@Result(name = "update",type = "redirectAction",location = "allTuanGou.action"),
            @Result(name = "error",type = "redirect",location = "/updateTuanGouXinXi.jsp")})
    public String updateTuanGouLine(){
        boolean flag = false;
        line.setTeamBuy(1);
        flag = lineService.updateLineService(line);
        if (!flag){
            return "error";
        }
        return "update";
    }

    public static String getCharAndNumr(int length) {
        String val = "";
        Random random = new Random();
        for (int i = 0; i < length; i++) {
            // 输出字母还是数字
            String charOrNum = random.nextInt(2) % 2 == 0 ? "char" : "num";
            // 字符串
            if ("char".equalsIgnoreCase(charOrNum)) {
                // 取得大写字母还是小写字母
                int choice = random.nextInt(2) % 2 == 0 ? 65 : 97;
                val += (char) (choice + random.nextInt(26));
            } else if ("num".equalsIgnoreCase(charOrNum)) { // 数字
                val += String.valueOf(random.nextInt(10));
            }
        }
        return val;
    }
}
