package com.workmoney.model.entity;

import java.util.Objects;

/**
 * user@Bright Rain .
 * 2019/6/21.
 */
public class Shop {
    private int shopId;
    private String shopName;
    private String shopAddress;
    private String shopState;
    private String shopSupervisor;
    private String shopRemark;

    public int getShopId() {
        return shopId;
    }

    public void setShopId(int shopId) {
        this.shopId = shopId;
    }

    public String getShopName() {
        return shopName;
    }

    public void setShopName(String shopName) {
        this.shopName = shopName;
    }

    public String getShopAddress() {
        return shopAddress;
    }

    public void setShopAddress(String shopAddress) {
        this.shopAddress = shopAddress;
    }

    public String getShopState() {
        return shopState;
    }

    public void setShopState(String shopState) {
        this.shopState = shopState;
    }

    public String getShopSupervisor() {
        return shopSupervisor;
    }

    public void setShopSupervisor(String shopSupervisor) {
        this.shopSupervisor = shopSupervisor;
    }

    public String getShopRemark() {
        return shopRemark;
    }

    public void setShopRemark(String shopRemark) {
        this.shopRemark = shopRemark;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Shop shop = (Shop) o;
        return shopId == shop.shopId &&
                Objects.equals(shopName, shop.shopName) &&
                Objects.equals(shopAddress, shop.shopAddress) &&
                Objects.equals(shopState, shop.shopState) &&
                Objects.equals(shopSupervisor, shop.shopSupervisor) &&
                Objects.equals(shopRemark, shop.shopRemark);
    }

    @Override
    public int hashCode() {
        return Objects.hash(shopId, shopName, shopAddress, shopState, shopSupervisor, shopRemark);
    }
}
