package com.hgkj.controller.action;


import com.hgkj.model.entity.*;
import com.hgkj.model.service.StaffUserService;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;


@Controller
@Namespace("/")
@ParentPackage("struts-default")
public class UpdateResetpassAction {
    private String StaffPwd;
    private String staffPwd1;
    private String staffPwd2;
    private String staffPwd3;
    private int staffId;
    private  Staff staff;
//    private Level level;
//    private Shop shop;
//    private Role role;
//    private Department department;
    @Autowired
    private StaffUserService staffUserService;


    @Action(value = "panduan",results = {
            @Result(name = "success",type = "redirect",location = "welcome/welcome.jsp"),
            @Result(name = "false",type = "redirect",location ="html/resetpass.jsp" )})
    public String panduna(){
        System.out.println(staff.getStaffPwd());
        System.out.println(staffPwd1);
        System.out.println(staffPwd2);
        System.out.println(staffPwd3);
        String result = null;

        if(staffPwd1.equals(staffPwd2)){
            if(staff.getStaffPwd().equals(staffPwd3)){
                System.out.println(staff.getStaffId());
                staffUserService.updateResetpassService(staff);
                result="success";
            }else {
                System.out.println("密码不一致");
            }
        }else {
            System.out.println("原密码错误");
            result ="false";
        }
        return result;
    }

    public String getStaffPwd() {
        return StaffPwd;
    }

    public void setStaffPwd(String staffPwd) {
        StaffPwd = staffPwd;
    }

    public String getStaffPwd1() {
        return staffPwd1;
    }

    public void setStaffPwd1(String staffPwd1) {
        this.staffPwd1 = staffPwd1;
    }

    public String getStaffPwd2() {
        return staffPwd2;
    }

    public void setStaffPwd2(String staffPwd2) {
        this.staffPwd2 = staffPwd2;
    }

    public String getStaffPwd3() {
        return staffPwd3;
    }

    public void setStaffPwd3(String staffPwd3) {
        this.staffPwd3 = staffPwd3;
    }

    public int getStaffId() {
        return staffId;
    }

    public void setStaffId(int staffId) {
        this.staffId = staffId;
    }

    public Staff getStaff() {
        return staff;
    }

    public void setStaff(Staff staff) {
        this.staff = staff;
    }

    public StaffUserService getStaffUserService() {
        return staffUserService;
    }

    public void setStaffUserService(StaffUserService staffUserService) {
        this.staffUserService = staffUserService;
    }
}
