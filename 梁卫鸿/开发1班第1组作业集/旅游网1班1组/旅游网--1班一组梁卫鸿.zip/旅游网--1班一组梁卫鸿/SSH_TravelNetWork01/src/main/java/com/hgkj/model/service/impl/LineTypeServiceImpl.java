package com.hgkj.model.service.impl;

import com.hgkj.model.dao.LineTypeDao;
import com.hgkj.model.entity.Linetype;
import com.hgkj.model.service.LineTypeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class LineTypeServiceImpl implements LineTypeService {
    @Autowired
    private LineTypeDao lineTypeDao;

    public void setLineTypeDao(LineTypeDao lineTypeDao) {
        this.lineTypeDao = lineTypeDao;
    }

    @Override
    public List<Linetype> lineTypeAllService() {
        return lineTypeDao.lineTypeAllDao();
    }

    @Override
    public boolean lineTypeAddService(String lineTypeId,String typeName,String icon) {
        return lineTypeDao.lineTypeAddDao(lineTypeId,typeName,icon);
    }

    @Override
    public boolean lineTypeDeleteService(String lineTypeId) {
        return lineTypeDao.lineTypeDeleteDao(lineTypeId);
    }

    @Override
    public Linetype lineTypeIdService(String lineTypeId) {
        return lineTypeDao.lineTypeIdDao(lineTypeId);
    }

    @Override
    public boolean lineTypeUpdateService(String lineTypeId,String typeName,String icon) {
        return lineTypeDao.lineTypeUpdateDao(lineTypeId,typeName,icon);
    }
}
