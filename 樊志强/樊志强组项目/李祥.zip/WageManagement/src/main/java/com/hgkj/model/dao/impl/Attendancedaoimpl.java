package com.hgkj.model.dao.impl;

import com.hgkj.model.dao.Attendancedao;
import com.hgkj.model.entity.Attendance;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
@Transactional
public class Attendancedaoimpl implements Attendancedao{
    @Autowired
    public SessionFactory sessionFactory;

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    private Session session(){
       return sessionFactory.getCurrentSession();
    }

    @Override
    public List<Attendance> allAttendancedao() {
        Query query = session().createQuery("from Attendance ");
        return query.list();
    }

    @Override
    public boolean addAttendancedao(Attendance attendance) {
        session().save(attendance);
        return false;
    }

    @Override
    public boolean deleteAttendancedao(int attId) {
        Attendance attendance = session().get(Attendance.class,attId);
        session().delete(attendance);
        return false;
    }

    @Override
    public boolean updateAttendancedao(Attendance attendance) {
        session().update(attendance);
        return false;
    }

    @Override
    public Attendance attendance(int attId) {
        Attendance autowired = session().get(Attendance.class,attId);
        return autowired;
    }
}
