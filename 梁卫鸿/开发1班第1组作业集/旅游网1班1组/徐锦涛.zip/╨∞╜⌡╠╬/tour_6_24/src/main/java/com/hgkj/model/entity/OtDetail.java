package com.hgkj.model.entity;

public class OtDetail {
    private int otID;

    public int getOtID() {
        return otID;
    }

    public void setOtID(int otID) {
        this.otID = otID;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        OtDetail otDetail = (OtDetail) o;

        if (otID != otDetail.otID) return false;

        return true;
    }

    @Override
    public int hashCode() {
        return otID;
    }
}
