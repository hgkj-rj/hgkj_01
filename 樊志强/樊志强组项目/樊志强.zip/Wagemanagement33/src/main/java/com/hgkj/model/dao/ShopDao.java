package com.hgkj.model.dao;

import com.hgkj.model.entity.Shop;

import java.util.List;

public interface ShopDao {
    //查询所有店铺类别
    public List<Shop> allshopDao();
    //添加店铺类别
    public boolean insertshopDao(Shop shop);
    //删除店铺类别
    public boolean deleteshopDao(int id);
    //修改店铺类别
    public boolean updateshopDao(Shop shop);
    //根据Id获取店铺信息
    public Shop getshopByIdDao(int id);
}
