package com.hgkj.model.service;

import com.hgkj.model.entity.Level;

import java.util.List;

public interface LevelService {
    public List<Level> allLevelService();
    public boolean addLevelService(Level level);
    public boolean deleteLevelService(int levelId);
    public boolean updateLeveService(Level level);
    public Level level(int levelId);
}
