package com.hgkj.model.service;

import com.hgkj.model.entity.Linetype;

import java.util.List;

public interface LineTypeService {

    /*添加路线*/
    public boolean addLineTypeService(Linetype linetype);
    /*查询所有路线*/
    public List<Linetype> allLineTypeSerivce();
    /*删除路线*/
    public boolean deleteLineTypeService(Integer id);
    /*得到路线*/
    public Linetype getOneLineTypeService(Integer id);
    /*修改路线*/
    public boolean updateLineTypeService(Linetype linetype);
    /*得到图片*/
    public String getIconLineTypeService(Integer id);
    /*查询所有的路线安排*/
    public List<Linetype> getTypeNameService();
    /*在前台显示线路类型*/
    public List<Linetype> ShowTypeNameService();
}
