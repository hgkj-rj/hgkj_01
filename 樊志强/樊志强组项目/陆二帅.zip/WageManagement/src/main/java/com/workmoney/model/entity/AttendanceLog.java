package com.workmoney.model.entity;

import java.sql.Timestamp;
import java.util.Objects;

/**
 * user@Bright Rain .
 * 2019/6/21.
 */
public class AttendanceLog {
    private int attenlogId;
    private String attlogCount;
    private Timestamp attlogTime;

    private Staff staff;

    private Attendance attendance;

    public Staff getStaff() {
        return staff;
    }

    public void setStaff(Staff staff) {
        this.staff = staff;
    }

    public Attendance getAttendance() {
        return attendance;
    }

    public void setAttendance(Attendance attendance) {
        this.attendance = attendance;
    }

    public int getAttenlogId() {
        return attenlogId;
    }

    public void setAttenlogId(int attenlogId) {
        this.attenlogId = attenlogId;
    }

    public String getAttlogCount() {
        return attlogCount;
    }

    public void setAttlogCount(String attlogCount) {
        this.attlogCount = attlogCount;
    }

    public Timestamp getAttlogTime() {
        return attlogTime;
    }

    public void setAttlogTime(Timestamp attlogTime) {
        this.attlogTime = attlogTime;
    }


}
