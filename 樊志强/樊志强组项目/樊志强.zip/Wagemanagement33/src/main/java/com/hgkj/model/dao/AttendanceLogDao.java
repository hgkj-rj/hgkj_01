package com.hgkj.model.dao;

import com.hgkj.model.entity.AttendanceLog;

import java.util.List;

public interface AttendanceLogDao {
    //查询所有补贴类别
    public List<AttendanceLog> allAttendanceLogDao();
    //添加补贴类别
    public boolean insertAttendanceLogDao(AttendanceLog attendanceLog);
    //删除补贴类别
    public boolean deleteAttendanceLogDao(int id);
    //修改补贴类别
    public boolean updateAttendanceLogDao(AttendanceLog attendanceLog);
    //根据Id获取补贴信息
    public AttendanceLog getAttendanceLogByIdDao(int id);
}
