package com.workmoney.model.dao.impl;

import com.workmoney.model.dao.KaoQinDao;
import com.workmoney.model.entity.Attendance;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * user@Bright Rain .
 * 2019/6/29.
 */
@Repository
@Transactional
public class KaoQinDaoImpl implements KaoQinDao {
    @Autowired
    private SessionFactory sessionFactory;

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    @Override
    public List<Attendance> getAllAttendanceDao() {
        Session session = sessionFactory.getCurrentSession();
        String hql = "from Attendance ";
        List<Attendance> departmentList = session.createQuery(hql, Attendance.class).list();
        return departmentList;
    }

    @Override
    public void addAttendanceDao(Attendance attendance) {
        Session session = sessionFactory.getCurrentSession();
        session.save(attendance);
    }

    @Override
    public void delAttendanceDao(Attendance attendance) {
        Session session = sessionFactory.getCurrentSession();
        session.delete(attendance);
    }

    @Override
    public Attendance getAttendanceDao(Attendance attendance) {
        Session session = sessionFactory.getCurrentSession();
        Attendance attendance1 = session.get(Attendance.class, attendance.getAttId());
        return attendance1;
    }

    @Override
    public void updateAttendance(Attendance attendance) {
        Session session = sessionFactory.getCurrentSession();
       session.update(attendance);
    }
}
