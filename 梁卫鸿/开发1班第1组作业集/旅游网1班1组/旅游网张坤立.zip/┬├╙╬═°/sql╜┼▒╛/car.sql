/*
 Navicat Premium Data Transfer

 Source Server         : Mysql
 Source Server Type    : MySQL
 Source Server Version : 50724
 Source Host           : localhost:3306
 Source Schema         : travel

 Target Server Type    : MySQL
 Target Server Version : 50724
 File Encoding         : 65001

 Date: 08/07/2019 09:53:41
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for car
-- ----------------------------
DROP TABLE IF EXISTS `car`;
CREATE TABLE `car`  (
  `carID` int(11) NOT NULL COMMENT '购物车编号，主键，自增长',
  `customerID` int(11) NOT NULL COMMENT '客户编号，外键',
  `lineID` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '线路编号，外键',
  `time` datetime(0) NOT NULL COMMENT '线路添加至购物车的时间',
  PRIMARY KEY (`carID`) USING BTREE,
  INDEX `FK_CAR_CUSTOMER`(`customerID`) USING BTREE,
  INDEX `FKc6b6alxff72xk3ymm0uifq3id`(`lineID`) USING BTREE,
  CONSTRAINT `FK_CAR_CUSTOMER` FOREIGN KEY (`customerID`) REFERENCES `customer` (`customerID`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `FKc6b6alxff72xk3ymm0uifq3id` FOREIGN KEY (`lineID`) REFERENCES `line` (`lineID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of car
-- ----------------------------
INSERT INTO `car` VALUES (1, 1, '1', '2019-06-27 14:44:57');
INSERT INTO `car` VALUES (2, 1, '2', '2019-07-01 17:28:41');
INSERT INTO `car` VALUES (3, 5, '3', '2019-07-01 17:29:17');

SET FOREIGN_KEY_CHECKS = 1;
