package com.hgkj.model.dao.impl;

import com.hgkj.model.dao.SubsidyDao;
import com.hgkj.model.entity.Subsidy;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
@Repository
@Transactional
public class SubsidyDaoImpl implements SubsidyDao {
    @Autowired
    private SessionFactory sessionFactory;
    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }
    public Session session(){
        return sessionFactory.getCurrentSession();
    }
    @Override
    public List<Subsidy> allsubsidyDao() {
        String hql="from Subsidy ";
        List<Subsidy> list=session().createQuery(hql).list();
        return list;
    }

    @Override
    public boolean insertsubsidyDao(Subsidy subsidy) {
        boolean b=false;
        session().save(subsidy);
        b=true;
        return b;
    }

    @Override
    public boolean deletesubsidyDao(int id) {
        boolean a=false;
        String hql="delete Subsidy where subsidyId=?";
        int b=session().createQuery(hql).setParameter(0,id).executeUpdate();
        if (b!=0){
            a=true;
        }
        return a;
    }

    @Override
    public boolean updatesubsidyDao(Subsidy subsidy) {
        boolean a=false;
        String hql="update Subsidy set subsidyName=?,subsidyMoney=?where subsidyId=?";
        int b=session().createQuery(hql).setParameter(0,subsidy.getSubsidyName()).setParameter(1,subsidy.getSubsidyMoney()).setParameter(2,subsidy.getSubsidyId()).executeUpdate();
        if (b!=0){
            a=true;
        }
        return a;
    }

    @Override
    public Subsidy getsubsidyByIdDao(int id) {
        String hql="from Subsidy where subsidyId=?";
        Subsidy subsidy=(Subsidy) session().createQuery(hql).setParameter(0,id).uniqueResult();
        return subsidy;
    }
}
