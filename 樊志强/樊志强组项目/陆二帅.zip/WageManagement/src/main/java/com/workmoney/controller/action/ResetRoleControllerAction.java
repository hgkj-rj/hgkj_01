package com.workmoney.controller.action;

import com.workmoney.model.entity.Role;
import com.workmoney.model.entity.Staff;
import com.workmoney.model.entity.StaffFuBen;
import com.workmoney.model.service.EmployeeService;
import com.workmoney.model.service.RoleService;
import com.workmoney.model.service.StaffService;
import com.workmoney.model.service.SubsidyLogService;
import org.apache.struts2.ServletActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import javax.servlet.http.HttpSession;
import java.util.List;

/**
 * user@Bright Rain .
 * 2019/6/28.
 */
@ParentPackage("struts-default")
@Namespace("/")
@Controller
public class ResetRoleControllerAction {

    @Autowired
    private RoleService service;

    @Autowired
    private StaffService staffService;

    @Autowired
    private EmployeeService employeeService;



    private StaffFuBen staff;

    private String name;

    @Action(value = "/updateRoleByIdAction",results = {@Result(name = "success",type = "redirectAction",location = "getAllRoleAction"),
            @Result(name = "error",type = "redirect",location = "error.jsp")})
    public String updateRoleByIdAction(){
        HttpSession session = ServletActionContext.getRequest().getSession();
        employeeService.updateRoleByIdService(staff);
        return "success";
    }


    /**
     * 获取当前角色的信息 去往修改页面
     */
    @Action(value = "/goStaffUpdateByRole",results = {@Result(name = "success",type = "redirect",location = "html/resetroleUpdate.jsp"),
            @Result(name = "error",type = "redirect",location = "error.jsp")})
    public String goStaffUpdateByRole(){
        HttpSession session = ServletActionContext.getRequest().getSession();
        StaffFuBen fuBen = employeeService.getEmpByIdService(staff);
        session.setAttribute("fuBen",fuBen);
        return "success";
    }
    /**
     * 模糊查询
     */
    @Action(value = "/serchRoleNameAction",results = {@Result(name = "success",type = "redirect",location = "html/resetrole.jsp"),
            @Result(name = "error",type = "redirect",location = "error.jsp")})
    public String serchRoleNameAction(){
        HttpSession session = ServletActionContext.getRequest().getSession();

        List<Staff> allRoll = service.serchNameAllowService(name);
        session.setAttribute("staffList",allRoll);
        return "success";
    }


    /**
     *获取所有的员工权限
     * @return
     */

    @Action(value = "/getAllRoleAction",results = {@Result(name = "success",type = "redirect",location = "html/resetrole.jsp"),
            @Result(name = "error",type = "redirect",location = "error.jsp")})
    public String getAllRoleAction(){
        HttpSession session = ServletActionContext.getRequest().getSession();
        List<Role> allRoll = service.getAllRoll();
        session.setAttribute("allRoll",allRoll);

        List<Staff> staffList = staffService.getStaffListSercharService();

        session.setAttribute("staffList",staffList);
        return "success";
    }

    public StaffFuBen getStaff() {
        return staff;
    }

    public void setStaff(StaffFuBen staff) {
        this.staff = staff;
    }
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
