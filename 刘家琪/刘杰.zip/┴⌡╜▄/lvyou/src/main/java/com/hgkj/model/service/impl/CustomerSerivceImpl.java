package com.hgkj.model.service.impl;

import com.hgkj.model.dao.CustomerDao;
import com.hgkj.model.entity.Customer;
import com.hgkj.model.service.CustomerSerivce;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CustomerSerivceImpl implements CustomerSerivce {
    @Autowired
    private CustomerDao customerDao;


    @Override
    public boolean addCustomerSerivce(Customer customer) {
        return customerDao.addCustomerDao(customer);
    }

    @Override
    public List<Customer> loginCustomerSerivce(Customer customer) {
        return customerDao.loginCustomerDao(customer);
    }


    public CustomerDao getCustomerDao() {
        return customerDao;
    }

    public void setCustomerDao(CustomerDao customerDao) {
        this.customerDao = customerDao;
    }
}
