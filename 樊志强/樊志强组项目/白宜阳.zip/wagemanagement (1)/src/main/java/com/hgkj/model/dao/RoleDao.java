package com.hgkj.model.dao;

import com.hgkj.model.entity.Role;

import java.util.List;

public interface RoleDao {
    List<Role> allRoleDao();
    boolean addRoleDao(Role role);
    boolean updateRoleDao(Role role);
    boolean deleteRoleDao(int roleId);
    Role getByIdRoleDao(int roleId);
}
