package com.tourism.controler.action;

import com.opensymphony.xwork2.ActionContext;
import com.tourism.model.entity.Car;
import com.tourism.model.entity.Customer;
import com.tourism.model.entity.Line;
import com.tourism.model.service.CarService;
import org.apache.struts2.ServletActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import javax.servlet.ServletContext;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

@Controller
@Namespace("/")
@ParentPackage("struts-default")
public class CarAction {
    @Autowired
    private CarService carService;

    private int pageindex;
    private int customerId;
    private Car car;

    public Car getCar() {
        return car;
    }

    public void setCar(Car car) {
        this.car = car;
    }

    public int getCustomerId() {
        return customerId;
    }

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    public int getPageindex() {
        return pageindex;
    }

    public void setPageindex(int pageindex) {
        this.pageindex = pageindex;
    }

    public CarService getCarService() {
        return carService;
    }

    public void setCarService(CarService carService) {
        this.carService = carService;
    }

    @Action(value = "toCart",results = @Result(name = "all",type = "redirect",location = "/cart.jsp"))
    public String toCart(){
        Customer customer = (Customer) ActionContext.getContext().getSession().get("customer");
        customerId = customer.getCustomerId();
        if (pageindex==0){
            pageindex=1;
        }
        int pagesize = 4;
        int totalpage = carService.gettotalpageService(pagesize,customerId);
        totalpage = (totalpage+pagesize-1)/pagesize;
        if (pageindex<1){
            pageindex = 1;
        }else if (pageindex>totalpage){
            pageindex = totalpage;
        }
        ActionContext.getContext().getSession().put("pageindex",pageindex);
        ActionContext.getContext().getSession().put("totalpage",totalpage);
        List<Car> carList =carService.allCarService(pageindex,pagesize,customerId);
        ActionContext.getContext().getSession().put("carList",carList);
        return "all";
    }

    @Action(value = "deleteCar",results = {@Result(name = "delete",type = "redirectAction",location = "toCart.action"),
            @Result(name = "error",type = "redirect",location = "/cart.jsp")})
    public String deleteCar(){
        boolean flag = false;
        flag = carService.deleteCarService(car);
        if (flag){
            return "delete";
        }
        return "error";
    }

    @Action(value = "addCar",results = {@Result(name = "add",type = "redirectAction",location = "toCart.action"),
            @Result(name = "error",type = "redirect",location = "/detail.jsp")})
    public String addCar(){
        Customer customer = (Customer) ActionContext.getContext().getSession().get("customer");
        boolean flag = false;
        Date date = new Date();
        SimpleDateFormat dateFormat= new SimpleDateFormat("yyyy-MM-dd :hh:mm:ss");
        car.setCustomer(customer);
        car.setTime(dateFormat.format(date));
        flag = carService.addCarService(car);
        if (!flag){
            return "error";
        }
        return "add";
    }
}
