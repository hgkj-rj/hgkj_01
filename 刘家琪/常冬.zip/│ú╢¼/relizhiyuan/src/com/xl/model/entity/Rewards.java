package com.xl.model.entity;

public class Rewards {
    private int cjId;
    private String cjZhuti;
    private String cjLeixin;
    private int cjJine;
    private String cjTime;
    public Rewards(){}
    public Rewards(String cjZhuti, String cjLeixin, int cjJine, String cjTime) {
        this.cjZhuti = cjZhuti;
        this.cjLeixin = cjLeixin;
        this.cjJine = cjJine;
        this.cjTime = cjTime;
    }

    public int getCjId() {
        return cjId;
    }

    public void setCjId(int cjId) {
        this.cjId = cjId;
    }

    public String getCjZhuti() {
        return cjZhuti;
    }

    public void setCjZhuti(String cjZhuti) {
        this.cjZhuti = cjZhuti;
    }

    public String getCjLeixin() {
        return cjLeixin;
    }

    public void setCjLeixin(String cjLeixin) {
        this.cjLeixin = cjLeixin;
    }

    public int getCjJine() {
        return cjJine;
    }

    public void setCjJine(int cjJine) {
        this.cjJine = cjJine;
    }

    public String getCjTime() {
        return cjTime;
    }

    public void setCjTime(String cjTime) {
        this.cjTime = cjTime;
    }
}
