package com.hgkj.model.service;

import com.hgkj.model.entity.Line;
import com.hgkj.model.entity.Picture;

import java.util.List;

public interface ImagesService {
    public List<Picture> imagesAllService();
    public boolean imagesInsertService(String lineID, String introduction, String name);
    public Picture imagesIdService(int pictureID);
    public boolean imagesUpdateService(int pictureID, String introduction, String name, String lineID);
    public boolean lineAddService(Line line);
    public List<Line> lineAllService();
    public boolean lineDeleteService(String lineID);
    public Line lineIdService(String lineID);
    public boolean lineUpdateService(Line line);
}
