/*
MySQL Data Transfer
Source Host: localhost
Source Database: lvwork
Target Host: localhost
Target Database: lvwork
Date: 2019/7/8 9:54:07
*/

SET FOREIGN_KEY_CHECKS=0;
-- ----------------------------
-- Table structure for car
-- ----------------------------
CREATE TABLE `car` (
  `carID` int(11) NOT NULL AUTO_INCREMENT,
  `customerID` int(11) NOT NULL,
  `lineID` int(11) NOT NULL,
  `time` datetime NOT NULL,
  PRIMARY KEY (`carID`),
  KEY `hg_02` (`customerID`),
  KEY `hg_03` (`lineID`),
  CONSTRAINT `hg_02` FOREIGN KEY (`customerID`) REFERENCES `customer` (`customerID`),
  CONSTRAINT `hg_03` FOREIGN KEY (`lineID`) REFERENCES `line` (`lineID`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for customer
-- ----------------------------
CREATE TABLE `customer` (
  `customerID` int(11) NOT NULL AUTO_INCREMENT,
  `account` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `gender` char(255) NOT NULL,
  `identityID` int(11) NOT NULL,
  `tel` int(11) NOT NULL,
  `type` int(11) NOT NULL,
  PRIMARY KEY (`customerID`),
  UNIQUE KEY `acnt` (`account`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for line
-- ----------------------------
CREATE TABLE `line` (
  `lineID` int(11) NOT NULL,
  `lineTypeID` int(11) NOT NULL,
  `lineName` varchar(255) NOT NULL,
  `days` int(11) NOT NULL,
  `vehicle` char(255) NOT NULL,
  `introduction` varchar(255) DEFAULT NULL,
  `reason` varchar(255) DEFAULT NULL,
  `arrange` varchar(255) DEFAULT NULL,
  `price` decimal(10,0) NOT NULL,
  `teamBuy` int(11) DEFAULT NULL,
  `teamBuyPrice` decimal(10,0) DEFAULT NULL,
  `beginTime` datetime DEFAULT NULL,
  `endTime` datetime DEFAULT NULL,
  `onTime` datetime NOT NULL,
  PRIMARY KEY (`lineID`),
  KEY `hg_01` (`lineTypeID`),
  CONSTRAINT `hg_01` FOREIGN KEY (`lineTypeID`) REFERENCES `linetype` (`lineTypeID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for linetype
-- ----------------------------
CREATE TABLE `linetype` (
  `lineTypeID` int(11) NOT NULL,
  `typeName` varchar(255) NOT NULL,
  `time` datetime NOT NULL,
  `icon` varchar(255) NOT NULL,
  PRIMARY KEY (`lineTypeID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for orderdetail
-- ----------------------------
CREATE TABLE `orderdetail` (
  `odID` int(11) NOT NULL,
  `customerID` int(11) NOT NULL,
  `lineName` varchar(255) NOT NULL,
  `price` decimal(10,0) NOT NULL,
  `orderDate` datetime NOT NULL,
  `travelDate` datetime NOT NULL,
  `total` decimal(10,0) NOT NULL,
  `lineID` int(11) NOT NULL,
  `state` int(11) NOT NULL,
  PRIMARY KEY (`odID`),
  KEY `hg_06` (`customerID`),
  KEY `hg_07` (`lineID`),
  KEY `odID` (`odID`),
  CONSTRAINT `hg_06` FOREIGN KEY (`customerID`) REFERENCES `customer` (`customerID`),
  CONSTRAINT `hg_07` FOREIGN KEY (`lineID`) REFERENCES `line` (`lineID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ot_detail
-- ----------------------------
CREATE TABLE `ot_detail` (
  `otID` int(11) NOT NULL AUTO_INCREMENT,
  `odID` int(11) NOT NULL,
  `touristID` int(11) NOT NULL,
  PRIMARY KEY (`otID`),
  KEY `hg_08` (`odID`),
  KEY `hg_09` (`touristID`),
  CONSTRAINT `hg_08` FOREIGN KEY (`odID`) REFERENCES `orderdetail` (`odID`),
  CONSTRAINT `hg_09` FOREIGN KEY (`touristID`) REFERENCES `tourist` (`touristID`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for picture
-- ----------------------------
CREATE TABLE `picture` (
  `pictureID` int(11) NOT NULL AUTO_INCREMENT,
  `introduction` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `lineID` int(11) NOT NULL,
  PRIMARY KEY (`pictureID`),
  KEY `hg_04` (`lineID`),
  CONSTRAINT `hg_04` FOREIGN KEY (`lineID`) REFERENCES `line` (`lineID`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for tourist
-- ----------------------------
CREATE TABLE `tourist` (
  `touristID` int(11) NOT NULL,
  `IDCard` int(11) NOT NULL,
  `tel` int(11) NOT NULL,
  `realName` decimal(10,0) NOT NULL,
  PRIMARY KEY (`touristID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records 
-- ----------------------------
INSERT INTO `car` VALUES ('10', '1', '11', '2019-06-25 14:29:13');
INSERT INTO `car` VALUES ('12', '2', '22', '2019-06-27 14:29:37');
INSERT INTO `customer` VALUES ('1', '123231213', '的法国队', '1323', '男', '3246546', '351351', '1');
INSERT INTO `customer` VALUES ('2', '132135544', '阿松大', '5646', '女', '65454654', '3123213', '2');
INSERT INTO `line` VALUES ('11', '1', '撒大苏打', '5', '汽车', '喜欢v比较好', '卡号抠脚大汉', '客户就会看见', '1321', '1', '54654', '2019-06-12 14:26:36', '2019-06-16 14:26:43', '2019-06-19 14:26:53');
INSERT INTO `line` VALUES ('22', '2', '看技能', '7', '飞机', '玫琳凯', 'i偶i解开了', '了集合框架', '6546', '2', '435435', '2019-06-14 14:27:36', '2019-07-20 14:27:29', '2019-06-21 14:27:24');
INSERT INTO `linetype` VALUES ('1', '阿三大苏打', '2019-07-02 14:24:26', '啊实打实');
INSERT INTO `linetype` VALUES ('2', '肺结核', '2019-07-01 14:24:55', '是v你');
INSERT INTO `orderdetail` VALUES ('123', '1', '阿法狗', '213123', '2019-06-17 14:31:21', '2019-07-24 14:31:27', '3213213', '11', '0');
INSERT INTO `orderdetail` VALUES ('321', '2', '看就看', '564654', '2019-06-27 14:32:22', '2019-06-29 14:32:28', '6456446', '22', '1');
INSERT INTO `ot_detail` VALUES ('12', '123', '656516');
INSERT INTO `ot_detail` VALUES ('45', '321', '8798798');
INSERT INTO `picture` VALUES ('1', '撒大苏打实打实', '电饭煲', '11');
INSERT INTO `picture` VALUES ('34', '撒大三政策宣传', '是飒飒', '22');
INSERT INTO `tourist` VALUES ('656516', '1321346465', '131231321', '4645646');
INSERT INTO `tourist` VALUES ('8798798', '79879465', '12456465', '9787946');
