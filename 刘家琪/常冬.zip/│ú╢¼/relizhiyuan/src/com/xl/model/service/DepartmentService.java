package com.xl.model.service;

import com.xl.model.entity.Department;

import java.util.List;

public interface DepartmentService {
public int departmentService(int pageSize);
public List<Department>allDepartmentService(int pageIndex,int pageSize);
    public boolean addDepartmentService(Department department);
    public boolean deleteDepartmentService(int department);
    public boolean updateDepartmentService(Department department);
   public int getDepartmentByIdService(int departmentId);
}
