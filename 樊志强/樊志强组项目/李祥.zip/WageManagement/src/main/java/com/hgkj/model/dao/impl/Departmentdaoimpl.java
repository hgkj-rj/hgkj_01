package com.hgkj.model.dao.impl;

import com.hgkj.model.dao.Departmentdao;
import com.hgkj.model.entity.Department;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
@Transactional
public class Departmentdaoimpl implements Departmentdao {

    @Autowired
    public SessionFactory sessionFactory;

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    private Session session(){
       return sessionFactory.getCurrentSession();
    }

    @Override
    public List<Department> allDepartmentdao() {
        Query query = session().createQuery("from Department ");
        return query.list();
    }

    @Override
    public boolean addDepartmentdao(Department department) {
        session().save(department);
        return false;
    }

    @Override
    public boolean deleteDepartmentdao(int depId) {
    Department department = session().get(Department.class,depId);
    session().delete(department);
        return false;
    }

    @Override
    public boolean updateDepartmentdao(Department department) {
        session().update(department);
        return false;
    }

    @Override
    public Department department(int depId) {
        Department department = session().get(Department.class,depId);
        return department;
    }
}
