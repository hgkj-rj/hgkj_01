package com.hgkj.contrloer.action;

import com.hgkj.model.entity.Level;
import com.hgkj.model.entity.Role;
import com.hgkj.model.service.RoleService;
import org.apache.struts2.ServletActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import java.util.List;

@Controller
@Namespace("/")
@ParentPackage("struts-default")
public class RoleAction {
    @Autowired
    private RoleService roleService;
    private Role role;

    public Role getRole() {
        return role;
    }

    public void setRole(Role role) {
        this.role = role;
    }

    public void setRoleService(RoleService roleService) {
        this.roleService = roleService;
    }

    @Action(value = "allrole",results = @Result(name = "all",type = "redirect",location = "/html/roleList.jsp"))
    public String allrole(){
        List<Role> roleList=roleService.allRoleService();
        ServletActionContext.getRequest().getSession().setAttribute("roleList",roleList);
        return "all";
    }

    @Action(value = "addrole",results = @Result(name = "adds",type = "redirectAction",params = {"actionName","allrole"}))
    public String addrole(){
        boolean r=roleService.addRoleService(role);
        if (r==true){
            return "adds";
        }else {
            return "adde";
        }
    }

    @Action(value = "delrole",results = @Result(name = "dels",type = "redirectAction",params = {"actionName","allrole"}))
    public String deleterole(){
        boolean r=roleService.deleteRoleService(role.getRoleId());
        if (r==true){
            return "dels";
        }else {
            return "dele";
        }
    }

    @Action(value = "updrole",results = @Result(name = "upds",type = "redirectAction",params = {"actionName","allrole"}))
    public String Updrole(){
        boolean r=roleService.updateRoleService(role);
        if (r==true){
            return "upds";
        }else {
            return "upde";
        }
    }

    @Action(value = "getByIdroles",results = {@Result(name = "getByIds",type = "redirect",location = "/html/roleUpdate.jsp")})
    public String getByIdrole(){
        Role role1=roleService.getByIdRoleService(role.getRoleId());
        ServletActionContext.getRequest().getSession().setAttribute("role1",role1);
        return "getByIds";
    }
}
