package com.hgkj.model.dao;

import com.hgkj.model.entity.Staff;

import java.util.List;

public interface StaffUserdao {
    /**
     * 管理员用户登录
     * 修改密码
     * @param staff
     * @return
     */
    List<Staff> loginUserDao(Staff staff);
    public boolean updateResetpassdao(Staff staff);
}
