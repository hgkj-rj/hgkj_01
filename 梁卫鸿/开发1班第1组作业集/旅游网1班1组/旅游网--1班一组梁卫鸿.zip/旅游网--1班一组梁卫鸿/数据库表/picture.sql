/*
 Navicat Premium Data Transfer

 Source Server         : shopcar
 Source Server Type    : MySQL
 Source Server Version : 50720
 Source Host           : localhost:3306
 Source Schema         : travelnetwork

 Target Server Type    : MySQL
 Target Server Version : 50720
 File Encoding         : 65001

 Date: 07/07/2019 21:21:10
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for picture
-- ----------------------------
DROP TABLE IF EXISTS `picture`;
CREATE TABLE `picture`  (
  `pictureID` int(11) NOT NULL AUTO_INCREMENT,
  `introduction` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `lineID` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`pictureID`) USING BTREE,
  INDEX `FKfawrfkab2v4n4xum1frvd5w3p`(`lineID`) USING BTREE,
  CONSTRAINT `FK_Picture_LIne_lineID` FOREIGN KEY (`lineID`) REFERENCES `line` (`lineID`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `FKfawrfkab2v4n4xum1frvd5w3p` FOREIGN KEY (`lineID`) REFERENCES `line` (`lineID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 55 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of picture
-- ----------------------------
INSERT INTO `picture` VALUES (2, '9', 'images/alter.jpg', '1');
INSERT INTO `picture` VALUES (3, '77', 'images/alter.jpg', '2');
INSERT INTO `picture` VALUES (4, '4', 'images/close.png', '3');
INSERT INTO `picture` VALUES (47, '7', 'images/btm_next.gif', '4');
INSERT INTO `picture` VALUES (51, '5', 'images/alter.jpg', '5');
INSERT INTO `picture` VALUES (52, '6', 'images/alter.jpg', '6');
INSERT INTO `picture` VALUES (54, '888', 'images/alter.jpg', '8');

SET FOREIGN_KEY_CHECKS = 1;
