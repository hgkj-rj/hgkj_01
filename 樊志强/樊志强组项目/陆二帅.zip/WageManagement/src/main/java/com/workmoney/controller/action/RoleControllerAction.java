package com.workmoney.controller.action;

import com.workmoney.model.entity.Role;
import com.workmoney.model.service.RoleService;
import org.apache.struts2.ServletActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import javax.servlet.http.HttpSession;
import java.util.List;

/**
 * user@Bright Rain .
 * 2019/6/27.
 */
@ParentPackage("struts-default")
@Namespace("/")
@Controller
public class RoleControllerAction {

    @Autowired
    private RoleService service;

    private Role role;

    @Action(value = "/addRoleAction",results = {@Result(name = "success",type = "redirectAction",location = "getRoleAllAction")})

    public String addRoleAction(){
        service.addRoleService(role);
        return "success";
    }

    /**
     * 删除角色
     * @return
     */
    @Action(value = "/delRoleById",results = {@Result(name = "success",type = "redirectAction",location = "getRoleAllAction")})
    public String delRoleById(){
        service.delRoleByIdService(role);
        return "success";
    }

    /**
     * 获取所有的角色
     * @return
     */
    @Action(value = "/getRoleAllAction",results = {@Result(name = "success",type = "redirect",location = "html/roleList.jsp")})
    public String getRoleAllAction(){
        HttpSession session = ServletActionContext.getRequest().getSession();
        List<Role> allRoll = service.getAllRoll();
        session.setAttribute("allRoll",allRoll);
        return "success";
    }

    public Role getRole() {
        return role;
    }

    public void setRole(Role role) {
        this.role = role;
    }
}
