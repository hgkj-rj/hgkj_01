package com.hgkj.controler.action;

import com.hgkj.model.entity.Line;
import com.hgkj.model.entity.Picture;
import com.hgkj.model.service.LineService;
import com.opensymphony.xwork2.ActionContext;
import org.apache.commons.io.FileUtils;
import org.apache.struts2.ServletActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.aop.IntroductionInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import java.io.File;
import java.io.IOException;
import java.util.List;

@Controller
@Namespace("/ht")
@ParentPackage("json-default")
public class lluxianAction {
    @Autowired
    private LineService lineService;
    private Line line;
    private String message;
    private File file[];
    private String fileFileName[];
    private String introduction[];
    private Picture picture;

    public Picture getPicture() {
        return picture;
    }

    public void setPicture(Picture picture) {
        this.picture = picture;
    }

    public String[] getIntroduction() {
        return introduction;
    }

    public void setIntroduction(String[] introduction) {
        this.introduction = introduction;
    }

    public File[] getFile() {
        return file;
    }

    public void setFile(File[] file) {
        this.file = file;
    }

    public String[] getFileFileName() {
        return fileFileName;
    }

    public void setFileFileName(String[] fileFileName) {
        this.fileFileName = fileFileName;
    }

    public LineService getLineService() {
        return lineService;
    }

    public void setLineService(LineService lineService) {
        this.lineService = lineService;
    }

    public Line getLine() {
        return line;
    }

    public void setLine(Line line) {
        this.line = line;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
    @Action(value ="addLineAction" ,results = {@Result(name = "insert",type = "redirectAction",params = {"actionName","allLineAction"}),
            @Result(name = "inserror",type = "redirect",location = "addLine.jsp")})
    public String addLineAction(){
        for (int i=0;i<file.length;i++){
            String path=ServletActionContext.getServletContext().getRealPath("ht/images/"+fileFileName[i]);
            File files=new File(path);
            try {
                FileUtils.copyFile(file[i],files);
            } catch (IOException e) {
                e.printStackTrace();
            }
            Picture picture=new Picture();
          //  picture.setIntroduction(introduction[i]);
            picture.setName("ht/images/"+fileFileName[i]);
            picture.setLine(line);
            line.getPictureSet().add(picture);
        }

        boolean rs=lineService.insertLineService(line);
        if (rs){
            return "insert";
        }
        return "inserror";
    }
    @Action(value = "allLineAction",results = @Result(name = "all",type = "redirect",location = "seeLine.jsp"))
    public String allLineAction(){
        System.out.println("11111111111111");
        List<Line> allLineList=lineService.allLineService();
        /*System.out.println(line.getDays()+line.getVehicle()+"2222222222222");*/
        ActionContext.getContext().getSession().put("allLineList",allLineList);
        return "all";
    }

    @Action(value = "updLineAction",results = @Result(name = "update",type = "redirectAction",params = {"actionName","allLineAction"}))
    public String updLineAction(){
        boolean rs=lineService.updLineService(line);
        if (rs){
            return "update";
        }
        return "error";
    }
   @Action(value = "lineByIdAction",results = @Result(name = "find",type = "redirect",location = "updateLine.jsp"))
    public String lineByIdAction(){
        Line line1=lineService.lineByIdService(line.getLineId());
        ServletActionContext.getRequest().getSession().setAttribute("line",line1);
        return "find";
    }
    @Action(value = "delLineAction",results ={ @Result(name = "del",type = "redirectAction",params = {"actionName","allLineAction"}),
    @Result(name = "error",type = "redirect",location = "seeLine.jsp")})
    public String delLineAction(){
        boolean rs=lineService.delLineService(line.getLineId());
        System.out.println(rs);
       if(rs){
           return "del";
       }
       return "error";
    }



    /**
     * 设置团购信息
     * @return
     */
    @Action(value = "SetTeamByIdAction",results = @Result(name = "find",type = "redirect",location = "setTeammes.jsp"))
    public String SetTeamByIdAction(){
        Line line1=lineService.SetTeamByIdService(line.getLineId());
        ServletActionContext.getRequest().getSession().setAttribute("line",line1);
        return "find";
    }

    public String setTeamMsgAction(){
        boolean rs=lineService.setTeamMsgService(line);
        if (rs){
            return "set";
        }else {
            return "error";
        }
    }
}
