package com.hgkj.controller.action;

import com.hgkj.model.entity.Staff;
import com.hgkj.model.service.StaffUserService;
import org.apache.struts2.ServletActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import java.util.List;

@Controller
@Namespace("/")
@ParentPackage("struts-default")
public class StaffloginAction {
    @Autowired
    private StaffUserService staffUserService;
    private String message;
    private Staff staff;

    public void setStaffUserService(StaffUserService staffUserService) {
        this.staffUserService = staffUserService;
    }

    @Action(value = "slogin",results={@Result(name="login",type = "redirect",location = "/main.jsp"),
          @Result(name = "logine",type = "redirect",location = "/login.jsp")})
    public String StraffLogin(){
        List<Staff>staffList=staffUserService.loginUserService(staff);
        if(staffList.size()>0){
            ServletActionContext.getRequest().getSession().setAttribute("staffList",staffList);
        return "login";
        }else {
            message = "登录失败";
            return "logine";
        }
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Staff getStaff() {
        return staff;
    }

    public void setStaff(Staff staff) {
        this.staff = staff;
    }
}
