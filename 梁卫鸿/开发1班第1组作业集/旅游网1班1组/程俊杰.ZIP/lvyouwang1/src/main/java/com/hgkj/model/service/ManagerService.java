package com.hgkj.model.service;

import com.hgkj.model.entity.Customer;

public interface ManagerService {
    public boolean managerloginService(Customer customer);
}
