package com.tourism.model.service;

import com.tourism.model.entity.Line;
import com.tourism.model.entity.Picture;

import java.util.List;

public interface PictureService {
    public boolean addPictureService(Picture picture);
    public boolean updatePictureService(Picture picture);
    public List<Picture> findPictureService(String lineId);

}
