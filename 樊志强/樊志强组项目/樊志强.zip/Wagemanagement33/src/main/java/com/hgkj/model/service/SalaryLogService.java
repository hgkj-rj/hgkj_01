package com.hgkj.model.service;

import com.hgkj.model.entity.AttendanceLog;
import com.hgkj.model.entity.SalaryLog;

import java.util.List;

public interface SalaryLogService {
    //根据员工id显示工资记录
    public List<SalaryLog> getsubsidyService(int id);
    //显示所有工资记录
    public List<SalaryLog> allsubsidyService();
    //根据Id查询考勤详情
    public List<AttendanceLog> allAttendanceLogService(int id);
}
