package com.mqy.model.dao;

import com.mqy.model.entity.Customer;

import java.util.List;

public interface CustomerDao {
    /**
     *
     * @param customer
     * @return 登录
     */
    public Customer LoginDao(Customer customer);

    /**
     * 查询所有用户
     * @return
     */
   public List<Customer> allCustomerDao();

    /**
     * 注册用户
     * @param customer
     * @return
     */
    public void registerCustomerDao(Customer customer);
}
