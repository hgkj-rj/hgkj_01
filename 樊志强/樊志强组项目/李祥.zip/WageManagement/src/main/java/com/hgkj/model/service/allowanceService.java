package com.hgkj.model.service;

import com.hgkj.model.entity.Reward;

import java.util.List;

public interface allowanceService {
    public List<Reward> allRewardService();
    public boolean addRewardService(Reward reward);
    public boolean deleteRewardService(int rewId);
    public boolean updateRewardService(Reward reward);
    public Reward reward(int rewId);
}
