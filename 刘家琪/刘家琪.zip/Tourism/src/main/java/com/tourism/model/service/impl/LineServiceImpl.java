package com.tourism.model.service.impl;

import com.tourism.model.dao.LineDao;
import com.tourism.model.entity.Line;
import com.tourism.model.service.LineService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class LineServiceImpl implements LineService {
    @Autowired
    private LineDao lineDao;

    public LineDao getLineDao() {
        return lineDao;
    }

    public void setLineDao(LineDao lineDao) {
        this.lineDao = lineDao;
    }

    @Override
    public int gettotalpageService(int pagesize,String time) {
        return lineDao.gettotalpageDao(pagesize,time);
    }

    @Override
    public List<Line> allLineService(int pageindex, int pagesize,String time) {
        return lineDao.allLineDao(pageindex,pagesize,time);
    }

    @Override
    public List<Line> allLineService() {
        return lineDao.allLineDao();
    }

    @Override
    public List<Line> allTuanGouLineService() {
        return lineDao.allTuanGouLineDao();
    }

    @Override
    public List<Line> toIndexLineService(String lineTypeId) {
        return lineDao.toIndexLineDao(lineTypeId);
    }

    @Override
    public List<Line> yiLineService() {
        return lineDao.yiLineDao();
    }

    @Override
    public List<Line> erLineService() {
        return lineDao.erLineDao();
    }

    @Override
    public List<Line> duoLineService() {
        return lineDao.duoLineDao();
    }

    @Override
    public boolean addLineService(Line line) {
        return lineDao.addLineDao(line);
    }

    @Override
    public boolean updateLineService(Line line) {
        return lineDao.updateLineDao(line);
    }

    @Override
    public Line getLineByIdService(String lineId) {
        return lineDao.getLineByIdDao(lineId);
    }
}
