package com.hgkj.model.dao.impl;

import com.hgkj.model.dao.Staffinformationdao;
import com.hgkj.model.entity.Staff;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
@Transactional
public class Staffinformationdaoimpl implements Staffinformationdao {
    @Autowired
    private SessionFactory sessionFactory;

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    public Session session(){
        return sessionFactory.getCurrentSession();
    }
    //Id查询
    @Override
    public Staff getByIdDao(int staffId) {
        Staff staff = session().get(Staff.class,staffId);
        return staff;
    }
    //查询所有
    @Override
    public List<Staff> allStaffdao() {
        Query query = session().createQuery("from   Staff ");
        return query.list();
    }
    //增加
    @Override
    public boolean addStaffdao(Staff staff) {
        session().save(staff);
        return false;
    }
    //删除
    @Override
    public boolean deleteStaffdao(int staffId) {
        Staff staff = session().get(Staff.class,staffId);
        session().delete(staff);
        return false;
    }
    //修改
    @Override
    public boolean updateStaffdao(Staff staff) {
        session().update(staff);
        return false;
    }
}
