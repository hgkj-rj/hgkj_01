package com.xl.servlet;

import com.xl.model.entity.Employee;
import com.xl.model.entity.Rewards;
import com.xl.model.service.EmployeeService;
import com.xl.model.service.RewardsService;
import com.xl.model.service.impl.EmployeeServiceImpl;
import com.xl.model.service.impl.RewardsServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet(name = "RewardsServlet",value = "/RewardsServlet")
public class RewardsServlet extends HttpServlet {
    RewardsService rewardsService=new RewardsServiceImpl();
    private int pageSize=2;
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");
        String action = request.getParameter("action");
        if ("all".equals(action)) {
            int pageIndex = request.getParameter("pageIndex") == null ? 1 : Integer.parseInt(request.getParameter("pageIndex"));
            int totalPage = rewardsService.RewardsService(pageSize);
            if (pageIndex < 1) {
                pageIndex = 1;
            } else if (pageIndex > totalPage) {
                pageIndex = totalPage;
            }
            request.getSession().setAttribute("pageIndex", pageIndex);
            request.getSession().setAttribute("totalPage", totalPage);
            List<Rewards> rewardsList = rewardsService.allRewardsService(pageIndex, pageSize);
            request.getSession().setAttribute("rewardsList", rewardsList);
            response.sendRedirect("rewardsMgr.jsp");
        }
    }
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
doPost(request,response);
    }
}
