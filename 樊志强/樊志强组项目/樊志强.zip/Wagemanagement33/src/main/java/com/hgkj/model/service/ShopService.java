package com.hgkj.model.service;

import com.hgkj.model.entity.Shop;

import java.util.List;

public interface ShopService {
    //查询所有店铺类别
    public List<Shop> allshopService();
    //添加店铺类别
    public boolean insertshopService(Shop shop);
    //删除店铺类别
    public boolean deleteshopService(int id);
    //修改店铺类别
    public boolean updateshopService(Shop shop);
    //根据Id获取店铺信息
    public Shop getshopByIdService(int id);
}
