package com.hgkj.model.dao;

import com.hgkj.model.entity.Attendance;

import java.util.List;

public interface Attendancedao {
    public List<Attendance> allAttendancedao();
    public boolean addAttendancedao(Attendance attendance);
    public boolean deleteAttendancedao(int attId);
    public boolean updateAttendancedao(Attendance attendance);
    public Attendance attendance(int attId);
}
