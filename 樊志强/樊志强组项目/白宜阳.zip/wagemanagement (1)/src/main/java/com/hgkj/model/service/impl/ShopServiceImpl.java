package com.hgkj.model.service.impl;

import com.hgkj.model.dao.ShopDao;
import com.hgkj.model.entity.Shop;
import com.hgkj.model.service.ShopService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ShopServiceImpl implements ShopService {
    @Autowired
    private ShopDao shopDao;

    public void setShopDao(ShopDao shopDao) {
        this.shopDao = shopDao;
    }

    @Override
    public List<Shop> allShopService() {
        return shopDao.allShopDao();
    }

    @Override
    public boolean addShopService(Shop shop) {
        return shopDao.addShopDao(shop);
    }

    @Override
    public boolean updateShopService(Shop shop) {
        return shopDao.updateShopDao(shop);
    }

    @Override
    public boolean deleteShopService(int shopId) {
        return shopDao.deleteShopDao(shopId);
    }

    @Override
    public Shop getByIdShopService(int shopId) {
        return shopDao.getByIdShopDao(shopId);
    }
}
