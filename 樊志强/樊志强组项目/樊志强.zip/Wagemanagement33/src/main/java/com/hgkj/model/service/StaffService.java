package com.hgkj.model.service;

import com.hgkj.model.entity.Staff;

import java.util.List;

public interface StaffService {
    //登录验证
    public Staff loginStaffService(Staff staff);
    //修改密码
    public boolean updPwdStaffService(Staff staff);
    //查询所有信息
    public List<Staff> allstaffService();
    //添加员工
    public boolean insertstaffService(Staff staff);
    //删除员工
    public boolean deletestaffService(int id);
    //修改员工信息
    public boolean updatestaffService(Staff staff);
    //根据Id获取员工信息
    public Staff getstaffByIdService(int id);
}
