package com.hgkj.model.dao.impl;

import com.hgkj.model.dao.AwardDao;
import com.hgkj.model.entity.RewardLog;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;


@Repository
@Transactional
public class AwardDaoImpl implements AwardDao {
    @Autowired
    private SessionFactory sessionFactory;

    @Override
    public List<RewardLog> allRewardLogList() {
        String hql="from RewardLog";
        List<RewardLog> list = getSession().createQuery(hql).list();
        return list;
    }

    @Override
    public boolean addRewardList(RewardLog rewardLog) {
        getSession().save(rewardLog);
        return true;
    }

    @Override
    public boolean delRewardList(RewardLog rewardLog) {
        getSession().delete(rewardLog);
        return true;
    }

    @Override
    public boolean updRewardList(RewardLog rewardLog) {
        getSession().update(rewardLog);
        return true;
    }

    @Override
    public RewardLog onlyRewardList(RewardLog rewardLog) {
        String hql="from  RewardLog  where rewlogId=?";
        RewardLog rewardLog1 = (RewardLog) getSession().createQuery(hql).setParameter(0, rewardLog.getRewlogId()).uniqueResult();
        return rewardLog1;
    }

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    public Session getSession(){
        return sessionFactory.getCurrentSession();
    }

}
