/*
Navicat MySQL Data Transfer

Source Server         : 1111111
Source Server Version : 50720
Source Host           : localhost:3306
Source Database       : tourism

Target Server Type    : MYSQL
Target Server Version : 50720
File Encoding         : 65001

Date: 2019-07-08 12:46:00
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `car`
-- ----------------------------
DROP TABLE IF EXISTS `car`;
CREATE TABLE `car` (
  `carId` int(10) NOT NULL AUTO_INCREMENT,
  `customerId` int(10) NOT NULL,
  `lineId` varchar(36) NOT NULL,
  `time` datetime DEFAULT NULL,
  PRIMARY KEY (`carId`),
  KEY `w1` (`customerId`),
  KEY `w2` (`lineId`),
  CONSTRAINT `w1` FOREIGN KEY (`customerId`) REFERENCES `customer` (`customerId`),
  CONSTRAINT `w2` FOREIGN KEY (`lineId`) REFERENCES `line` (`lineId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of car
-- ----------------------------

-- ----------------------------
-- Table structure for `customer`
-- ----------------------------
DROP TABLE IF EXISTS `customer`;
CREATE TABLE `customer` (
  `customerId` int(10) NOT NULL AUTO_INCREMENT,
  `account` varchar(12) NOT NULL,
  `name` varchar(12) NOT NULL,
  `password` varchar(12) NOT NULL,
  `gender` char(2) NOT NULL,
  `identityId` varchar(18) NOT NULL,
  `tel` varchar(11) NOT NULL,
  `type` int(1) DEFAULT NULL,
  PRIMARY KEY (`customerId`),
  UNIQUE KEY `s1` (`account`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of customer
-- ----------------------------
INSERT INTO `customer` VALUES ('1', 'zsl', '张绍龄', '0223', '男', '123456789', '1592626', '1');
INSERT INTO `customer` VALUES ('2', 'zyzyzy', 'yy', '20000226', '男', '123456789123456789', '15926711910', null);

-- ----------------------------
-- Table structure for `line`
-- ----------------------------
DROP TABLE IF EXISTS `line`;
CREATE TABLE `line` (
  `lineId` varchar(12) NOT NULL,
  `lineTypeId` varchar(36) NOT NULL,
  `lineName` varchar(15) NOT NULL,
  `days` varchar(12) NOT NULL,
  `vehicle` char(2) NOT NULL,
  `introduction` varchar(400) DEFAULT NULL,
  `reason` varchar(100) DEFAULT NULL,
  `arrange` varchar(100) DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  `teamBuy` int(11) DEFAULT NULL,
  `teamBuyPrice` decimal(10,2) DEFAULT NULL,
  `beginTime` datetime DEFAULT NULL,
  `endTime` datetime DEFAULT NULL,
  `onTime` datetime NOT NULL,
  PRIMARY KEY (`lineId`),
  KEY `FKd7h38nar3c77x5uw44ddn6nyf` (`lineTypeId`),
  CONSTRAINT `FKd7h38nar3c77x5uw44ddn6nyf` FOREIGN KEY (`lineTypeId`) REFERENCES `linetype` (`lineTypeId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of line
-- ----------------------------
INSERT INTO `line` VALUES ('4zU', 'CZ89en', 'x2', '2天', '轮船', '2', '2', '22', '1235.20', null, null, null, null, '2019-07-07 11:07:20');
INSERT INTO `line` VALUES ('78Q', '12Z1pE', '线路6', '6天', '飞机', '3', '1', '2', '111.20', '1', null, '2019-07-10 08:59:28', '2019-07-26 08:59:31', '2019-07-02 05:13:38');
INSERT INTO `line` VALUES ('816', 'CZ89en', '2222', '2天', '火车', '没有简介', '环游世界，你的梦想', '美国》英国》法国》太平洋》黄冈', '123.30', null, '10.00', '2019-06-17 23:59:37', '2019-06-21 23:59:41', '2019-06-28 04:05:10');
INSERT INTO `line` VALUES ('F4k', 'x67510', 'x1', '1天', '飞机', '1', '1', '11', '111.20', null, null, null, null, '2019-07-07 11:06:20');
INSERT INTO `line` VALUES ('Yvv', '12Z1pE', '神户6日游', '计划', '飞机', '3', '1', '2', '1235.20', '1', null, '2019-07-08 08:59:37', '2019-07-17 08:59:42', '2019-07-02 05:57:54');

-- ----------------------------
-- Table structure for `linetype`
-- ----------------------------
DROP TABLE IF EXISTS `linetype`;
CREATE TABLE `linetype` (
  `lineTypeId` varchar(36) NOT NULL,
  `typeName` varchar(10) NOT NULL,
  `time` datetime NOT NULL,
  `icon` varchar(20) NOT NULL,
  PRIMARY KEY (`lineTypeId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of linetype
-- ----------------------------
INSERT INTO `linetype` VALUES ('12Z1pE', '欧洲游', '2019-06-26 04:03:47', 'upload/6.jpeg');
INSERT INTO `linetype` VALUES ('70nw8j', '自驾游', '2019-07-07 11:11:56', 'upload/6.jpeg');
INSERT INTO `linetype` VALUES ('a6950c', '世界游', '2019-07-10 00:00:00', 'upload/4.jpg');
INSERT INTO `linetype` VALUES ('CZ89en', '境内游', '2019-06-26 04:03:29', 'upload/1.jpg');
INSERT INTO `linetype` VALUES ('JC1F26', '境外游', '2019-06-28 09:48:07', 'upload/杀生丸.jpg');
INSERT INTO `linetype` VALUES ('x67510', '热门游', '2019-07-02 05:58:05', 'upload/aa.jpg');

-- ----------------------------
-- Table structure for `orderdetail`
-- ----------------------------
DROP TABLE IF EXISTS `orderdetail`;
CREATE TABLE `orderdetail` (
  `odId` varchar(36) NOT NULL,
  `customerId` int(10) NOT NULL,
  `lineName` varchar(15) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `orderDate` datetime NOT NULL,
  `travelDate` datetime NOT NULL,
  `total` decimal(10,2) NOT NULL,
  `lineId` varchar(36) NOT NULL,
  `state` int(10) NOT NULL,
  PRIMARY KEY (`odId`),
  KEY `w4` (`customerId`),
  KEY `w5` (`lineId`),
  CONSTRAINT `w4` FOREIGN KEY (`customerId`) REFERENCES `customer` (`customerId`),
  CONSTRAINT `w5` FOREIGN KEY (`lineId`) REFERENCES `line` (`lineId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of orderdetail
-- ----------------------------

-- ----------------------------
-- Table structure for `picture`
-- ----------------------------
DROP TABLE IF EXISTS `picture`;
CREATE TABLE `picture` (
  `pictureId` int(15) NOT NULL AUTO_INCREMENT,
  `introduction` varchar(20) NOT NULL,
  `name` varchar(20) NOT NULL,
  `lineId` varchar(36) NOT NULL,
  PRIMARY KEY (`pictureId`),
  KEY `FKajxrh3n0rdhg235h7vf6r64l` (`lineId`),
  CONSTRAINT `FKajxrh3n0rdhg235h7vf6r64l` FOREIGN KEY (`lineId`) REFERENCES `line` (`lineId`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of picture
-- ----------------------------
INSERT INTO `picture` VALUES ('1', '1', 'upload/4.jpg', '816');
INSERT INTO `picture` VALUES ('2', '2', 'upload/2.jpg', '816');
INSERT INTO `picture` VALUES ('3', '3', 'upload/3.jpg', '816');
INSERT INTO `picture` VALUES ('4', '4', 'upload/4.jpg', '816');
INSERT INTO `picture` VALUES ('5', '2', 'upload/l4.jpg', '78Q');
INSERT INTO `picture` VALUES ('6', '3', 'upload/l2.jpg', '78Q');
INSERT INTO `picture` VALUES ('7', '4', 'upload/l3.jpg', '78Q');
INSERT INTO `picture` VALUES ('8', '5', 'upload/l4.jpg', '78Q');
INSERT INTO `picture` VALUES ('9', '5', 'upload/l8.jpg', 'Yvv');
INSERT INTO `picture` VALUES ('10', '6', 'upload/l6.jpg', 'Yvv');
INSERT INTO `picture` VALUES ('11', '7', 'upload/l7.jpg', 'Yvv');
INSERT INTO `picture` VALUES ('12', '8', 'upload/l8.jpg', 'Yvv');
INSERT INTO `picture` VALUES ('13', '1', 'upload/l1.jpg', 'F4k');
INSERT INTO `picture` VALUES ('14', '2', 'upload/l2.jpg', 'F4k');
INSERT INTO `picture` VALUES ('15', '3', 'upload/l3.jpg', 'F4k');
INSERT INTO `picture` VALUES ('16', '4', 'upload/l4.jpg', 'F4k');
INSERT INTO `picture` VALUES ('17', '5', 'upload/l5.jpg', '4zU');
INSERT INTO `picture` VALUES ('18', '6', 'upload/l6.jpg', '4zU');
INSERT INTO `picture` VALUES ('19', '7', 'upload/l7.jpg', '4zU');
INSERT INTO `picture` VALUES ('20', '8', 'upload/l8.jpg', '4zU');

-- ----------------------------
-- Table structure for `tourist`
-- ----------------------------
DROP TABLE IF EXISTS `tourist`;
CREATE TABLE `tourist` (
  `touristId` varchar(36) NOT NULL,
  `Idcard` varchar(36) NOT NULL,
  `tel` varchar(15) NOT NULL,
  `realName` varchar(15) NOT NULL,
  `odId` varchar(36) NOT NULL,
  PRIMARY KEY (`touristId`),
  KEY `w8` (`odId`),
  CONSTRAINT `w8` FOREIGN KEY (`odId`) REFERENCES `orderdetail` (`odId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tourist
-- ----------------------------
