/*
 Navicat Premium Data Transfer

 Source Server         : localhost
 Source Server Type    : MySQL
 Source Server Version : 50724
 Source Host           : localhost:3306
 Source Schema         : wagemanagement

 Target Server Type    : MySQL
 Target Server Version : 50724
 File Encoding         : 65001

 Date: 08/07/2019 21:37:52
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for attendance
-- ----------------------------
DROP TABLE IF EXISTS `attendance`;
CREATE TABLE `attendance`  (
  `att_Id` int(11) NOT NULL AUTO_INCREMENT,
  `att_Name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `att_Percent` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`att_Id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of attendance
-- ----------------------------
INSERT INTO `attendance` VALUES (1, '迟到', '50');
INSERT INTO `attendance` VALUES (2, '早退', '30');
INSERT INTO `attendance` VALUES (3, '旷工', '10');

-- ----------------------------
-- Table structure for attendance_log
-- ----------------------------
DROP TABLE IF EXISTS `attendance_log`;
CREATE TABLE `attendance_log`  (
  `attenlog_Id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_Id` int(11) NULL DEFAULT NULL,
  `att_Id` int(11) NULL DEFAULT NULL,
  `attlog_Count` int(11) NOT NULL,
  `attlog_Time` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`attenlog_Id`) USING BTREE,
  INDEX `att_Id`(`att_Id`) USING BTREE,
  INDEX `staff_Id`(`staff_Id`) USING BTREE,
  CONSTRAINT `FK1fk2eaal2bns1kxyanw48xkjc` FOREIGN KEY (`staff_Id`) REFERENCES `staff` (`staffId`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `FK6rwwqs7caervlmokymw8ijihn` FOREIGN KEY (`att_Id`) REFERENCES `attendance` (`att_Id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of attendance_log
-- ----------------------------
INSERT INTO `attendance_log` VALUES (1, 1, 1, 1, '2019.6');
INSERT INTO `attendance_log` VALUES (2, 4, 2, 2, '2019.7');

-- ----------------------------
-- Table structure for department
-- ----------------------------
DROP TABLE IF EXISTS `department`;
CREATE TABLE `department`  (
  `dep_Id` int(10) NOT NULL AUTO_INCREMENT,
  `dep_Name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`dep_Id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of department
-- ----------------------------
INSERT INTO `department` VALUES (1, '人事部');
INSERT INTO `department` VALUES (2, '财务部');

-- ----------------------------
-- Table structure for level
-- ----------------------------
DROP TABLE IF EXISTS `level`;
CREATE TABLE `level`  (
  `level_Id` int(11) NOT NULL AUTO_INCREMENT,
  `level_Name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `level_Price` decimal(10, 2) NOT NULL,
  PRIMARY KEY (`level_Id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of level
-- ----------------------------
INSERT INTO `level` VALUES (1, '门店-实习生', 5000.00);
INSERT INTO `level` VALUES (2, '门店-专一级', 6000.00);
INSERT INTO `level` VALUES (3, '门店-专二级', 7000.00);

-- ----------------------------
-- Table structure for reward
-- ----------------------------
DROP TABLE IF EXISTS `reward`;
CREATE TABLE `reward`  (
  `rew_Id` int(11) NOT NULL AUTO_INCREMENT,
  `rew_Name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `rew_Price` decimal(10, 2) NOT NULL,
  PRIMARY KEY (`rew_Id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 7 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of reward
-- ----------------------------
INSERT INTO `reward` VALUES (1, '全勤奖', 200.00);
INSERT INTO `reward` VALUES (2, '年终奖', 5000.00);
INSERT INTO `reward` VALUES (3, '效绩奖', 800.00);
INSERT INTO `reward` VALUES (6, '功绩奖', 600.00);

-- ----------------------------
-- Table structure for reward_log
-- ----------------------------
DROP TABLE IF EXISTS `reward_log`;
CREATE TABLE `reward_log`  (
  `rewlog_Id` int(10) NOT NULL AUTO_INCREMENT,
  `staff_Id` int(11) NULL DEFAULT NULL,
  `rew_Id` int(11) NULL DEFAULT NULL,
  `rew_price` decimal(10, 2) NOT NULL,
  `rewlog_Time` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`rewlog_Id`) USING BTREE,
  INDEX `reward_staff`(`staff_Id`) USING BTREE,
  INDEX `reward_rew`(`rew_Id`) USING BTREE,
  CONSTRAINT `FK1lsdusbli368y9oeftprw4kw6` FOREIGN KEY (`staff_Id`) REFERENCES `staff` (`staffId`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `FK5snrol82613adyasla3yb3fdx` FOREIGN KEY (`rew_Id`) REFERENCES `reward` (`rew_Id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of reward_log
-- ----------------------------
INSERT INTO `reward_log` VALUES (1, 1, 2, 5000.00, '2019.6');
INSERT INTO `reward_log` VALUES (2, 2, 2, 5000.00, '2019.7');

-- ----------------------------
-- Table structure for role
-- ----------------------------
DROP TABLE IF EXISTS `role`;
CREATE TABLE `role`  (
  `Role_Id` int(11) NOT NULL AUTO_INCREMENT,
  `role_Name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `roles_Id` int(11) NOT NULL,
  PRIMARY KEY (`Role_Id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of role
-- ----------------------------
INSERT INTO `role` VALUES (1, '员工', 0);
INSERT INTO `role` VALUES (2, '店长', 0);
INSERT INTO `role` VALUES (3, '管理员', 0);

-- ----------------------------
-- Table structure for salary_log
-- ----------------------------
DROP TABLE IF EXISTS `salary_log`;
CREATE TABLE `salary_log`  (
  `sallog_Id` int(11) NOT NULL,
  `staff_Id` int(11) NULL DEFAULT NULL,
  `staff_Name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `shop_Name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `level_Name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `sal_Time` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `level_Price` decimal(10, 2) NOT NULL,
  `att_Percent` decimal(10, 2) NOT NULL,
  `total_Subsidy` decimal(10, 2) NOT NULL,
  `total_reward` decimal(10, 2) NOT NULL,
  `salary_Old` decimal(10, 2) NOT NULL,
  `salary_True` decimal(10, 2) NOT NULL,
  `sallog_Remark` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`sallog_Id`) USING BTREE,
  INDEX `staff_log_Id`(`staff_Id`) USING BTREE,
  CONSTRAINT `FKnurxdm7n3lqnjgbe3r8uw9340` FOREIGN KEY (`staff_Id`) REFERENCES `staff` (`staffId`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of salary_log
-- ----------------------------
INSERT INTO `salary_log` VALUES (1, 1, 'byy', '派乐汉堡', '门店-实习生', '2019.6', 5000.00, 0.00, 0.00, 400.00, 5400.00, 5400.00, '5400');
INSERT INTO `salary_log` VALUES (2, 2, 'bxx', '派乐汉堡', '门店-专一级', '2019.6', 6000.00, 0.00, 0.00, 500.00, 6500.00, 6500.00, '6500');
INSERT INTO `salary_log` VALUES (3, 3, 'bwd', '派乐汉堡', '门店-专二级', '2019.7', 7000.00, 0.00, 0.00, 600.00, 7600.00, 7600.00, '7600');

-- ----------------------------
-- Table structure for shop
-- ----------------------------
DROP TABLE IF EXISTS `shop`;
CREATE TABLE `shop`  (
  `shop_Id` int(11) NOT NULL AUTO_INCREMENT,
  `shop_Name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `shop_Address` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `shop_state` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `shop_supervisor` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `shop_remark` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`shop_Id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of shop
-- ----------------------------
INSERT INTO `shop` VALUES (1, '派乐汉堡', '黄冈科技', '1', '张三', '');
INSERT INTO `shop` VALUES (2, '周黑鸭', '黄冈科技', '1', '王五', '优');

-- ----------------------------
-- Table structure for staff
-- ----------------------------
DROP TABLE IF EXISTS `staff`;
CREATE TABLE `staff`  (
  `staffId` int(10) NOT NULL AUTO_INCREMENT,
  `staffName` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `staffPwd` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `staffSex` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `staffAddress` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `staffTel` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `staffEmail` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `staffState` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `level_Id` int(11) NULL DEFAULT NULL,
  `roles_Id` int(11) NULL DEFAULT NULL,
  `dep_Id` int(11) NULL DEFAULT NULL,
  `shop_Id` int(11) NULL DEFAULT NULL,
  `staff_Id` int(11) NOT NULL,
  `staff_Name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `staff_Pwd` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `staff_Sex` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `staff_Address` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `staff_Tel` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `staff_Email` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `staff_State` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`staffId`) USING BTREE,
  INDEX `staff_shop`(`shop_Id`) USING BTREE,
  INDEX `staff_level`(`level_Id`) USING BTREE,
  INDEX `staff_dep`(`dep_Id`) USING BTREE,
  INDEX `staff_roles`(`roles_Id`) USING BTREE,
  CONSTRAINT `FK5m13xmclav0pt1k5chxkdwex3` FOREIGN KEY (`level_Id`) REFERENCES `level` (`level_Id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `FKistssg7jbq1b2pcdlug7hobiq` FOREIGN KEY (`roles_Id`) REFERENCES `role` (`Role_Id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `FKk4xhi49ywxwh6kivmp8ux9yfr` FOREIGN KEY (`dep_Id`) REFERENCES `department` (`dep_Id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `FKrcydhvn6wbiouophxxh7iiosn` FOREIGN KEY (`shop_Id`) REFERENCES `shop` (`shop_Id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of staff
-- ----------------------------
INSERT INTO `staff` VALUES (1, 'byy', '111', '男', '黄冈科技', '18727284600', '1123876228@qq.com', '0', 1, 1, 1, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `staff` VALUES (2, 'bxx', '1111', '女', '黄冈科技', '123456', '123@qq.com', '0', 2, 2, 2, 2, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `staff` VALUES (3, 'bwd', '000', '男', '黄冈科技', '000', '000@qq.com', '0', 3, 3, 1, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `staff` VALUES (4, 'xxx', '000', '男', '黄冈科技', '123456', '111@qq.com', '0', 1, 1, 1, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- ----------------------------
-- Table structure for subsidy
-- ----------------------------
DROP TABLE IF EXISTS `subsidy`;
CREATE TABLE `subsidy`  (
  `subsidy_Id` int(11) NOT NULL AUTO_INCREMENT,
  `subsidy_Name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `subsidy_Money` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`subsidy_Id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of subsidy
-- ----------------------------
INSERT INTO `subsidy` VALUES (1, '加班费', '500');
INSERT INTO `subsidy` VALUES (2, '高温补贴', '350');

-- ----------------------------
-- Table structure for subsidy_log
-- ----------------------------
DROP TABLE IF EXISTS `subsidy_log`;
CREATE TABLE `subsidy_log`  (
  `stblog_Id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_Id` int(11) NULL DEFAULT NULL,
  `sunsidy_Id` int(11) NULL DEFAULT NULL,
  `subsidy_Money` decimal(10, 2) NOT NULL,
  `sublog_Time` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`stblog_Id`) USING BTREE,
  INDEX `sunsidy_Id`(`sunsidy_Id`) USING BTREE,
  INDEX `subsidy_staff`(`staff_Id`) USING BTREE,
  CONSTRAINT `FKbmijdonnn9uy49oequ25w2lel` FOREIGN KEY (`staff_Id`) REFERENCES `staff` (`staffId`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `FKy7pf4vowqnyis0sbxd96yey` FOREIGN KEY (`sunsidy_Id`) REFERENCES `subsidy` (`subsidy_Id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of subsidy_log
-- ----------------------------
INSERT INTO `subsidy_log` VALUES (1, 1, 1, 500.00, '2019.7');
INSERT INTO `subsidy_log` VALUES (2, 2, 2, 350.00, '2019.7');

SET FOREIGN_KEY_CHECKS = 1;
