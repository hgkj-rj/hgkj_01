package com.hgkj.controler.action;


import com.hgkj.model.service.OrderdetailService;
import com.hgkj.model.entity.Orderdetail;
import com.opensymphony.xwork2.ActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import java.util.List;

@Controller
@Namespace("/")
@ParentPackage("struts-default")
public class OrderDetailAction {
    @Autowired
    private OrderdetailService orderDetailService;
    private Orderdetail orderdetail;
    public void setOrderDetailService(OrderdetailService orderDetailService) {
        this.orderDetailService = orderDetailService;
    }
    public Orderdetail getOrderdetail() {
        return orderdetail;
    }
    public void setOrderdetail(Orderdetail orderDetail) {
        this.orderdetail = orderdetail;
    }

    @Action(value = "allOrderdetail",results = {@Result(name = "all",type = "redirect",location = "")})
    public String allOrderdetail(){
       List<Orderdetail> orderdetailList=orderDetailService.allOrderdetailService();
        ActionContext.getContext().getSession().put("orderdetailList",orderdetailList);
        return "all";
    }

    @Action(value = "addOrderdetail",results = {@Result(name = "add",type = "redirectAction",location = ""),
            @Result(name = "error",type = "redirect",location = "")})
    public String addOrderdetail(){
        boolean f=orderDetailService.addOrderdetailService(orderdetail);
        if (f){
            return "add";
        }
        return "error";
    }

    @Action(value = "deleteOrderdetail",results = {@Result(name = "delete",type = "redirectAction",location = ""),
            @Result(name = "error",type = "redirect",location = "")})
    public String deleteOrderdetail(){
        boolean f=orderDetailService.deleteOrderdetailService(orderdetail);
        if (f){
            return "add";
        }
        return "error";
    }

    @Action(value = "updateOrderdetail",results = {@Result(name = "update",type = "redirectAction",location = ""),
            @Result(name = "error",type = "redirect",location = "")})
    public String updateOrderdetail(){
        boolean f=orderDetailService.updateOrderdetailService(orderdetail);
        if (f){
            return "add";
        }
        return "error";
    }


    public String findOrderdetail(){
        orderdetail = orderDetailService.getOrderdetailByIdService(orderdetail.getOdId());
        ActionContext.getContext().getSession().put("orderdetail",orderdetail);
        return "orderdetail";
    }
}
