package com.hgkj.model.dao.impl;

import com.hgkj.model.dao.CustomerDao;
import com.hgkj.model.entity.Customer;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
@Repository
@Transactional
public class CustomerDaoImpl implements CustomerDao {
    @Autowired
    private SessionFactory sessionFactory;

    public SessionFactory getSessionFactory() {
        return sessionFactory;
    }

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }
    public Session getsession(){
        return sessionFactory.getCurrentSession();
    }
    @Override
    public List<Customer> CustomerLoginDao(Customer customer) {
        String hql="from Customer where account='"+customer.getAccount()+"' and password='"+customer.getPassword()+"'";
        List<Customer> customerList=getsession().createQuery(hql).list();
        return customerList;

    }

    @Override
    public boolean CustomerAddDao(Customer customer) {
        boolean result=false;
        Customer customer1=new Customer(customer.getAccount(),customer.getPassword(),customer.getName(),customer.getGender(),customer.getIdentityID(),customer.getTel());
        try {
            getsession().save(customer1);
            result=true;
        }catch (Exception e){
            e.printStackTrace();
        }finally {
        }
        return result;
    }

}
