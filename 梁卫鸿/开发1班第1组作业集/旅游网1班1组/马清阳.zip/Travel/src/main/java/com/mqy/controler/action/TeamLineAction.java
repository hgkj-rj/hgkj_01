package com.mqy.controler.action;

import com.mqy.model.entity.Line;
import com.mqy.model.service.LineService;
import com.opensymphony.xwork2.ActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

public class TeamLineAction {
    private Line line;
    private int pageIndex;
    private int pageSize=2;
    private String message;

    @Autowired
    private LineService lineService;

    public void setLineService(LineService lineService) {
        this.lineService = lineService;
    }

    /**
     * ��ѯ�����Ź���·
     * @return
     */
    @Action(value = "allTeamLineAction", results = {
       @Result(name = "all", type = "redirect", location = "ht/seeTeamLine.jsp")
    })
    public String allTeamBuyLine() {
        int totalPage = lineService.getTotalPageService(pageSize);
        if (pageIndex < 1) {
            pageIndex=1;
        }else if (pageIndex> totalPage) {
            pageIndex = totalPage;
        }
        ActionContext.getContext().getSession().put("pageIndex",pageIndex);
        ActionContext.getContext().getSession().put("totalPage",totalPage);
        List<Line> allTeamLineList = lineService.teamLineService(
                pageIndex,pageSize);
        ActionContext.getContext().getSession().put("allTeamLineList",
              allTeamLineList);
        return "all";
    }

    /**
     * �޸��Ź���·
     * @return
     */
    @Action(value = "updateTeamLineAction", results = {
       @Result(name = "updateTeam", type = "redirectAction",params = {
               "actionName","allTeamLineAction"})
    })
    public String updateTeamLineBuyType() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss");
        line.setOnTime(sdf.format(new Date()));
        lineService.updateLineService(line);
        return "updateTeam";
    }

    /**
     * ��ȡ�Ź���·����
     * @return
     */
    @Action(value = "findTeamLineAction",results = {
       @Result(name = "findTeam",type = "redirect",
               location = "ht/setTeamLine.jsp")
    })
    public String findBuyLine(){
        line = lineService.getLineService(line.getLineId());
        ActionContext.getContext().getSession().put("line", line);
        return "findTeam";
    }

    public int getPageIndex() {
        return pageIndex;
    }

    public void setPageIndex(int pageIndex) {
        this.pageIndex = pageIndex;
    }

    public Line getLine() {
        return line;
    }

    public void setLine(Line line) {
        this.line = line;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
