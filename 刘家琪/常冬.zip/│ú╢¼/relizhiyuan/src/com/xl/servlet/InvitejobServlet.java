package com.xl.servlet;

import com.xl.model.entity.Department;
import com.xl.model.entity.Invitejob;
import com.xl.model.service.InvitejobService;
import com.xl.model.service.impl.InvitejobServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet(name = "InvitejobServlet",value = "/InvitejobServlet")
public class InvitejobServlet extends HttpServlet {
    InvitejobService invitejobService=new InvitejobServiceImpl();
private int pageSize=2;
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");
        String action = request.getParameter("action");
        if ("all".equals(action)) {
            int pageIndex = request.getParameter("pageIndex") == null ? 1 : Integer.parseInt(request.getParameter("pageIndex"));
            int totalPage = invitejobService.invitejobService(pageSize);
            if (pageIndex < 1) {
                pageIndex = 1;
            } else if (pageIndex > totalPage) {
                pageIndex = totalPage;
            }
            request.getSession().setAttribute("pageIndex", pageIndex);
            request.getSession().setAttribute("totalPage", totalPage);
            List<Invitejob> invitejobList = invitejobService.allInvitejobService(pageIndex, pageSize);
            request.getSession().setAttribute("invitejobList", invitejobList);
            response.sendRedirect("invitejobMgr.jsp");

        }else if ("add".equals(action)){
            String invitejobName=request.getParameter("invitejobName");
            String invitejobPost=request.getParameter("invitejobPost");
            String invitejobSex=request.getParameter("invitejobSex");
            String invitejobEd=request.getParameter("invitejobEd");
            String invitejobEx=request.getParameter("invitejobEx");
            Invitejob invitejob=new Invitejob(invitejobName,invitejobPost,invitejobSex,invitejobEd,invitejobEx);
            boolean result=invitejobService.addInvitejobService(invitejob);
            if (result){

                response.sendRedirect("InvitejobServlet?action=all");
            }else {

                request.getRequestDispatcher("invitejobAdd.jsp");
            }
        }
    }
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
doPost(request,response);
    }
}
