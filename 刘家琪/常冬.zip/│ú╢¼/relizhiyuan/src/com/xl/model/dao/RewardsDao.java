package com.xl.model.dao;

import com.xl.model.entity.Rewards;

import java.util.List;

public interface RewardsDao {
    public int RewardsDao(int pageSize);
    public List<Rewards> allRewardsDao(int pageIndex, int pageSize);
    public Rewards getRewardsByIdDao(int cjId);
    public boolean addRewardsDao(Rewards rewards);
    public boolean deleteRewardsDao(int rewards);
    public boolean updateRewardsDao(Rewards rewards);
}
