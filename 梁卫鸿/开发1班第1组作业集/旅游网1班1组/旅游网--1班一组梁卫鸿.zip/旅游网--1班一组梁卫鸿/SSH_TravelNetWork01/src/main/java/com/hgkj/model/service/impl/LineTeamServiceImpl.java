package com.hgkj.model.service.impl;

import com.hgkj.model.dao.LineTeamDao;
        import com.hgkj.model.entity.Line;
        import com.hgkj.model.service.LineTeamService;
        import org.springframework.beans.factory.annotation.Autowired;
        import org.springframework.stereotype.Service;

        import java.util.List;
@Service
public class LineTeamServiceImpl implements LineTeamService {
    @Autowired
    private LineTeamDao lineTeamDao;

    public void setLineTeamDao(LineTeamDao lineTeamDao) {
        this.lineTeamDao = lineTeamDao;
    }

    @Override
    public boolean lineTeamAddService(Line line) {
        return lineTeamDao.lineTeamAddDao(line);
    }

    @Override
    public List<Line> lineTeamAllService() {
        return lineTeamDao.lineTeamAllDao();
    }

    @Override
    public boolean lineTeamDeleteService(String lineId) {
        return lineTeamDao.lineTeamDeleteDao(lineId);
    }

    @Override
    public Line lineTeamIdService(String lineId) {
        return lineTeamDao.lineTeamIdDao(lineId);
    }

    @Override
    public boolean lineTeamUpdateService(Line line) {
        return lineTeamDao.lineTeamUpdateDao(line);
    }
}
