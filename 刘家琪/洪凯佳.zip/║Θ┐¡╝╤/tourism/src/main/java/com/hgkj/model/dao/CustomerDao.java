package com.hgkj.model.dao;

import com.hgkj.model.entity.Customer;

public interface CustomerDao {
       public Customer CustomerLoginDao(Customer customer);
       public boolean addCustomerDao(Customer customer);
}
