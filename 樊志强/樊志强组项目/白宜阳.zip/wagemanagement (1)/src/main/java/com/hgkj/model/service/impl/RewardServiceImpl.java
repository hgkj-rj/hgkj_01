package com.hgkj.model.service.impl;

import com.hgkj.model.dao.RewardDao;
import com.hgkj.model.entity.Reward;
import com.hgkj.model.service.RewardService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RewardServiceImpl implements RewardService {
    @Autowired
    private RewardDao rewardDao;

    public void setRewardDao(RewardDao rewardDao) {
        this.rewardDao = rewardDao;
    }

    @Override
    public List<Reward> allRewardService() {
        return rewardDao.allRewardDao();
    }

    @Override
    public boolean addRewardService(Reward reward) {
        return rewardDao.addRewardDao(reward);
    }

    @Override
    public boolean updateRewardService(Reward reward) {
        return rewardDao.updateRewardDao(reward);
    }

    @Override
    public boolean deleteRewardService(int rewId) {
        return rewardDao.deleteRewardDao(rewId);
    }

    @Override
    public Reward getByIdRewardService(int reWId) {
        return rewardDao.getByIdRewardDao(reWId);
    }
}
