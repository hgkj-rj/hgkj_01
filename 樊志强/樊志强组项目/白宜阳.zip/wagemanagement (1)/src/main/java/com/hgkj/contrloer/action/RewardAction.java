package com.hgkj.contrloer.action;

import com.hgkj.model.entity.Reward;
import com.hgkj.model.service.RewardService;
import org.apache.struts2.ServletActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import java.util.List;

@Controller
@Namespace("/")
@ParentPackage("struts-default")
public class RewardAction {
    @Autowired
    private RewardService rewardService;
    private String message;

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    private Reward reward;

    @Action(value = "allReward",results = @Result(name = "all",type = "redirect",location = "/html/bonusList.jsp"))
    public String allReward(){
        List<Reward>rewardList=rewardService.allRewardService();
        ServletActionContext.getRequest().getSession().setAttribute("rewardList",rewardList);
        return "all";
    }

    @Action(value = "addReward",results = @Result(name = "adds",type = "redirectAction",params = {"actionName","allReward"}))
    public String addReward(){
        boolean r=rewardService.addRewardService(reward);
        if (r==true){
            return "adds";
        }else {
            return "adde";
        }
    }

    @Action(value = "delReward",results = @Result(name = "dels",type = "redirectAction",params = {"actionName","allReward"}))
    public String deleteReward(){
        boolean r=rewardService.deleteRewardService(reward.getRewId());
        if (r==true){
            return "dels";
        }else {
            return "dele";
        }
    }

    @Action(value = "updReward",results = @Result(name = "upds",type = "redirectAction",params = {"actionName","allReward"}))
    public String UpdReward(){
        boolean r=rewardService.updateRewardService(reward);
        if (r==true){
            return "upds";
        }else {
            return "upde";
        }
    }

    @Action(value = "getByIdRews",results = {@Result(name = "getByIds",type = "redirect",location = "/html/bonusUpdate.jsp")})
    public String getByIdReward(){
        Reward reward1=rewardService.getByIdRewardService(reward.getRewId());
        ServletActionContext.getRequest().getSession().setAttribute("reward1",reward1);
        return "getByIds";
    }

    public Reward getReward() {
        return reward;
    }

    public void setReward(Reward reward) {
        this.reward = reward;
    }

    public void setRewardService(RewardService rewardService) {
        this.rewardService = rewardService;
    }
}
