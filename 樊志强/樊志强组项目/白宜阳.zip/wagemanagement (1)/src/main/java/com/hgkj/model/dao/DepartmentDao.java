package com.hgkj.model.dao;

import com.hgkj.model.entity.Department;

import java.util.List;

public interface DepartmentDao {
    List<Department> allDepartmentDao();
    boolean addDepartmentDao(Department department);
    boolean updateDepartmentDao(Department department);
    boolean deleteDepartmentDao(int depId);
    Department getByIdDepartmentDao(int depId);
}
