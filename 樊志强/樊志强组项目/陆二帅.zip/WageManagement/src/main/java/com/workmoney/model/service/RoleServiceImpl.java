package com.workmoney.model.service;

import com.workmoney.model.dao.RoleDao;
import com.workmoney.model.entity.Role;
import com.workmoney.model.entity.Staff;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * user@Bright Rain .
 * 2019/6/27.
 */
@Service
public class RoleServiceImpl implements RoleService{

    @Autowired
    private RoleDao dao;

    @Override
    public List<Role> getAllRoll() {
        return dao.getAllRole();
    }

    @Override
    public void delRoleByIdService(Role role) {
        dao.delRoleByIdDao( role);
    }

    @Override
    public void addRoleService(Role role) {
        dao.addRoleDao( role);
    }

    @Override
    public List<Staff> serchNameAllowService(String name) {
        return dao.serchNameAllowDao(name);
    }
}
