package com.hgkj.model.service;

import com.hgkj.model.entity.Customer;

public interface CustLoginService {
    public Customer custLoginService(Customer customer);
    public boolean custRegisterService(Customer customer);
}
