package com.hgkj.model.Service.impl;

import com.hgkj.model.Dao.LineTypeDao;
import com.hgkj.model.Service.LineTypeService;
import com.hgkj.model.entity.Linetype;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class LineTypeServiceimpl implements LineTypeService {
    @Autowired
    private LineTypeDao lineTypeDao;
    public void setLineTypeDao(LineTypeDao lineTypeDao) {
        this.lineTypeDao = lineTypeDao;
    }

    public LineTypeDao getLineTypeDao() {
        return lineTypeDao;
    }

    @Override
    public List<Linetype> allLineTypeService() {
        return lineTypeDao.allLineTypeDao();
    }

    @Override
    public List<Linetype> fourLineService() {
        return lineTypeDao.fourLineDao();
    }

    @Override
    public boolean addLineTypeService(Linetype linetype) {
        return lineTypeDao.addLineTypeDao(linetype);
    }

    @Override
    public boolean updateLineTypeService(Linetype linetype) {
        return lineTypeDao.updateLineTypeDao(linetype);
    }

    @Override
    public Linetype getLineByIdService(String lineTypeId) {
        return lineTypeDao.getLineByIdDao(lineTypeId);
    }

    @Override
    public Linetype getLastService() {
        return lineTypeDao.getLastDao();
    }
}
