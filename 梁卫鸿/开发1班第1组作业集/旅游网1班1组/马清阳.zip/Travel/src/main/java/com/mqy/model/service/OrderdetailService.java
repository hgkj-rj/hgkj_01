package com.mqy.model.service;

/**
 * @Author:马清阳
 * @Date:2019/6/26 22:36
 * InteliJ IDEA 1.8
 */
public interface OrderdetailService {
}
