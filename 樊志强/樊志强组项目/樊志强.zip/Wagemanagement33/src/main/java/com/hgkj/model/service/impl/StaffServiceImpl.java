package com.hgkj.model.service.impl;

import com.hgkj.model.dao.StaffDao;
import com.hgkj.model.entity.Staff;
import com.hgkj.model.service.StaffService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class StaffServiceImpl implements StaffService {
    @Autowired
    private StaffDao staffDao;

    @Override
    public Staff loginStaffService(Staff staff) {
        return staffDao.loginStaffDao(staff);
    }

    @Override
    public boolean updPwdStaffService(Staff staff) {
        return staffDao.updPwdStaffDao(staff);
    }

    @Override
    public List<Staff> allstaffService() {
        return staffDao.allstaffDao();
    }

    @Override
    public boolean insertstaffService(Staff staff) {
        return staffDao.insertstaffDao(staff);
    }

    @Override
    public boolean deletestaffService(int id) {
        return staffDao.deletestaffDao(id);
    }

    @Override
    public boolean updatestaffService(Staff staff) {
        return staffDao.updPwdStaffDao(staff);
    }

    @Override
    public Staff getstaffByIdService(int id) {
        return staffDao.getstaffByIdDao(id);
    }

    public void setStaffDao(StaffDao staffDao) {
        this.staffDao = staffDao;
    }


}
