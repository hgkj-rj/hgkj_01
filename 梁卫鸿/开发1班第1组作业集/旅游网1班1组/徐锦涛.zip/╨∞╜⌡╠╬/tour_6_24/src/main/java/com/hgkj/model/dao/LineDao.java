package com.hgkj.model.dao;

import com.hgkj.model.entity.Line;

import java.util.List;

public interface LineDao {
    public List<Line> allLineDao();
    public Line lineByIdDao(String lineID);
    public boolean linedeleteDao(String lineID);
    public boolean lineAddDao(Line line);
}
