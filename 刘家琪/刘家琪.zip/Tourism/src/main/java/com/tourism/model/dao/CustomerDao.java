package com.tourism.model.dao;

import com.tourism.model.entity.Customer;

public interface CustomerDao {
    public Customer loginDao(Customer customer);
    public boolean addCustomerDao(Customer customer);
}
