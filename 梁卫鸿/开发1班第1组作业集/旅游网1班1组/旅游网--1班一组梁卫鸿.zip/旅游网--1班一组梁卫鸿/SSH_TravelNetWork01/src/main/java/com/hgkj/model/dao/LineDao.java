package com.hgkj.model.dao;

import com.hgkj.model.entity.Customer;
import com.hgkj.model.entity.Line;
import com.hgkj.model.entity.Picture;

import java.util.List;

public interface LineDao {
    public List<Line> lineAllDao();
    public List<Picture> imagesAllDao();
    public boolean lineAddDao(Line line);
    public Line lineIdDao(String lineId);
}
