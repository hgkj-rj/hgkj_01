/*
 Navicat Premium Data Transfer

 Source Server         : shopcar
 Source Server Type    : MySQL
 Source Server Version : 50720
 Source Host           : localhost:3306
 Source Schema         : travelnetwork

 Target Server Type    : MySQL
 Target Server Version : 50720
 File Encoding         : 65001

 Date: 07/07/2019 21:20:26
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for line
-- ----------------------------
DROP TABLE IF EXISTS `line`;
CREATE TABLE `line`  (
  `lineID` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `lineTypeID` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `lineName` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `days` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `vehicle` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `introduction` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `reason` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `arrange` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `price` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `teamBuy` int(10) NULL DEFAULT NULL,
  `teamBuyPrice` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `beginTime` datetime(0) NULL DEFAULT NULL,
  `endTime` datetime(0) NULL DEFAULT NULL,
  `onTime` datetime(0) NULL DEFAULT NULL,
  PRIMARY KEY (`lineID`) USING BTREE,
  INDEX `FKmjcgyxrw5nra0fu5p55q3lv7v`(`lineTypeID`) USING BTREE,
  CONSTRAINT `FK_line_lineType_typeId` FOREIGN KEY (`lineTypeID`) REFERENCES `linetype` (`lineTypeID`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `FKmjcgyxrw5nra0fu5p55q3lv7v` FOREIGN KEY (`lineTypeID`) REFERENCES `linetype` (`lineTypeID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of line
-- ----------------------------
INSERT INTO `line` VALUES ('1', '1', '凤凰古城', '5', '飞机', 'asda8888888888888888888888888888888', 'asd54648645623', '[多重优惠+超值赠送]品质全景，张家界、凤凰、天门山、宝峰湖纯玩双飞5日游', '2000.00', 1, '1500.00', NULL, NULL, NULL);
INSERT INTO `line` VALUES ('2', '2', '婺源', '3', '火车', 'ads', 'ww', '[多重优惠+超值赠送]品质全景，张家界、凤凰、天门山、宝峰湖纯玩双飞5日游', '2552.00', 2, '2133.00', '2019-06-26 18:56:45', '2019-07-04 18:56:48', '2019-07-02 18:56:53');
INSERT INTO `line` VALUES ('3', '3', '99', '99', '飞机', '99', '99', '[三重优惠+超亏赠送]品质全景，石家庄、婺源、天门山、宝峰湖纯玩双飞44日游', '99.00', 3, '55.00', NULL, NULL, NULL);
INSERT INTO `line` VALUES ('4', '4', '44', '44', '飞机', '4', '4', '[三重优惠+超亏赠送]品质全景，石家庄、婺源、天门山、宝峰湖纯玩双飞44日游', '44.00', 4, '22.00', NULL, NULL, NULL);
INSERT INTO `line` VALUES ('5', '1', '5', '5', '飞机', '5', '5', '[三重优惠+超亏赠送]品质全景，石家庄、婺源、天门山、宝峰湖纯玩双飞44日游', '5.00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `line` VALUES ('6', '1', '6', '6', '飞机', '6', '6', '[三重优惠+超亏赠送]品质全景，石家庄、婺源、天门山、宝峰湖纯玩双飞44日游', '6.00', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `line` VALUES ('8', '1', '8', '8', '飞机', '8', '8', '8', '888', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `line` VALUES ('9', '3', '富士山', '5', '客车', '富士山三大殿的撒到我的撒大网哇塞的', '活火山，四季被雪覆盖', '无常以后大师大卫', '55', NULL, NULL, NULL, NULL, NULL);

SET FOREIGN_KEY_CHECKS = 1;
