package com.hgkj.contrloer.action;

import com.hgkj.model.entity.Department;
import com.hgkj.model.entity.Reward;
import com.hgkj.model.service.DepartmentService;
import com.opensymphony.xwork2.ActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import java.util.List;

@Controller
@Namespace("/")
@ParentPackage("json-default")
public class DepartmentAction {
    @Autowired
    private DepartmentService departmentService;
    private Department  department;
    private int id;
    @Action(value = "alldepartment",results = {@Result(name = "all",type = "redirect",location = "html/departmentList.jsp")})
    public String allreward(){
        List<Department> departmentList=departmentService.alldepartmentService();
        ActionContext.getContext().getSession().put("departmentList",departmentList);
        return "all";
    }
    @Action(value = "insertdepartment",results = {@Result(name = "insert",type = "redirect",location = "alldepartment")})
    public String insert(){
        departmentService.insertdepartmentService(department);
            return "insert";
    }
    @Action(value = "deletedepartment",results = {@Result(name = "delete",type = "json",params = {"root","delete"})})
    public String delete(){
        departmentService.deletedepartmentService(id);
        return "delete";
    }
    @Action(value = "updatedepartment",results = {@Result(name = "update",type = "redirectAction",location = "alldepartment"),@Result(name = "noupdate",type = "redirect",location = "../departmentList.jsp")})
    public String update(){
        if (departmentService.updatedepartmentService(department)){
            return "update";
        }else {
            return "noupdate";
        }
    }
    @Action(value = "getdepartment",results = {@Result(name = "get",type = "redirect",location = "html/departmentupdate.jsp")})
    public String getrewardmanage(){
        department=departmentService.getdepartmentByIdService(id);
        ActionContext.getContext().getSession().put("department",department);
        return "get";
    }
    public void setDepartmentService(DepartmentService departmentService) {
        this.departmentService = departmentService;
    }

    public void setDepartment(Department department) {
        this.department = department;
    }

    public Department getDepartment() {
        return department;
    }

    public void setId(int id) {
        this.id = id;
    }
}
