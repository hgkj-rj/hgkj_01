package com.hgkj.model.dao;

public interface PictureDao {
}
