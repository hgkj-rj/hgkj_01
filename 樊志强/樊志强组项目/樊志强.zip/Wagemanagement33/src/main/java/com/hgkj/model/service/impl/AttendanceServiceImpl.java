package com.hgkj.model.service.impl;

import com.hgkj.model.dao.AttendanceDao;
import com.hgkj.model.entity.Attendance;
import com.hgkj.model.service.AttendanceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class AttendanceServiceImpl implements AttendanceService {
    @Autowired
   private AttendanceDao attendanceDao;

    public void setAttendanceDao(AttendanceDao attendanceDao) {
        this.attendanceDao = attendanceDao;
    }

    @Override
    public List<Attendance> allattendanceService() {
        return attendanceDao.allattendanceDao();
    }

    @Override
    public boolean insertattendanceService(Attendance attendance) {
        return attendanceDao.insertattendanceDao(attendance);
    }

    @Override
    public boolean deleteattendanceService(int id) {
        return attendanceDao.deleteattendanceDao(id);
    }

    @Override
    public boolean updateattendanceService(Attendance attendance) {
        return attendanceDao.updateattendanceDao(attendance);
    }

    @Override
    public Attendance getattendanceByIdService(int id) {
        return attendanceDao.getattendanceByIdDao(id);
    }
}
