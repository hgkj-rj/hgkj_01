package com.hgkj.conteltor.action;

import com.hgkj.model.entity.Tourist;
import com.hgkj.model.service.TouristService;
import com.opensymphony.xwork2.ActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import java.util.List;

@Controller
@Namespace("/")
@ParentPackage("struts-default")
public class TouristAction {
    @Autowired
    private TouristService touristService;
    private Tourist tourist;
    private String message;

    public TouristService getTouristService() {
        return touristService;
    }

    public void setTouristService(TouristService touristService) {
        this.touristService = touristService;
    }

    public Tourist getTourist() {
        return tourist;
    }

    public void setTourist(Tourist tourist) {
        this.tourist = tourist;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
    @Action(value = "allTourist",results = @Result(name = "all", type = "redirect", location = "/qt/order1.jsp"))
    public String allTourist(){
        List<Tourist> touristList=touristService.allTouristService();
        ActionContext.getContext().getSession().put("touristList",touristList);
        return "all";
    }
    @Action(value = "addTourist",results = @Result(name = "add",type = "redirectAction",params = {"actionName","allTourist"}))
    public String addTourist(){
        boolean addtour=touristService.addTouristService(tourist);
        if (addtour){
        return "add";
        }else {
            return "addError";
        }
    }
}
