package com.hgkj.model.dao.impl;

import com.hgkj.model.dao.ImagesDao;
import com.hgkj.model.entity.Line;
import com.hgkj.model.entity.Picture;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
@Repository
@Transactional
public class ImagesDaoImpl implements ImagesDao {
    @Autowired
    private SessionFactory sessionFactory;
    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }
    public Session getSession(){
        return sessionFactory.getCurrentSession();
    }
    @Override
    public List<Picture> imagesAllDao() {
        String hql="from Picture ";
        Query query=getSession().createQuery(hql);
        return query.list();
    }
    @Override
    public boolean imagesInsertDao(String lineID,String introduction,String name) {
        boolean result=false;
        Picture picture1=new Picture(lineID,introduction,name);
        try {
            getSession().save(picture1);
            result=true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

    @Override
    public Picture imagesIdDao(int pictureID) {
        Picture picture=getSession().get(Picture.class,pictureID);
        return picture;
    }

    @Override
    public boolean imagesUpdateService(int pictureID,String introduction,String name,String lineID) {
        boolean resoult=false;
        Picture picture1=new Picture(pictureID,introduction,name,lineID);
        try {
            getSession().update(picture1);
            resoult=true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return resoult;
    }

    @Override
    public boolean lineAddDao(Line line) {
        boolean result=false;
        try {
            getSession().save(line);
            result=true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }
    @Override
    public List<Line> lineAllDao() {
        String hql="from Line ";
        Query query=getSession().createQuery(hql);
        return query.list();
    }
    @Override
    public boolean lineDeleteDao(String lineID) {
        boolean resoult=false;
        Line line=getSession().get(Line.class,lineID);
        try {
            getSession().delete(line);
            resoult=true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return resoult;
    }
    @Override
    public Line lineIdDao(String lineID) {
        Line line=getSession().get(Line.class,lineID);
        return line;
    }
    @Override
    public boolean lineUpdateDao(Line line) {
        boolean resoult=false;
        try {
            getSession().update(line);
            resoult=true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return resoult;
    }


}