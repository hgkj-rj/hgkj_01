package com.hgkj.model.dao;

import com.hgkj.model.entity.Attendance;
import com.hgkj.model.entity.AttendanceLog;
import com.hgkj.model.entity.Staff;

import java.util.List;

public interface AttendanceDao {
    /**
     * 查询员工考勤
     * @return
     */
    List<AttendanceLog>allAttendanceLogDao();

    /**
     * 添加考勤管理
     * @param attendanceLog
     * @return
     */
    boolean addAttendanceLogDao(AttendanceLog attendanceLog);

    /**
     * 删除考勤
     * @param attenlogId
     * @return
     */
    boolean deleteAttendanceLogDao(int attenlogId);

    /**
     * 修改考勤
     * @param attendanceLog
     * @return
     */
    boolean updateAttendanceLogDao(AttendanceLog attendanceLog);

    /**
     * 根据Id查考勤
     * @param attenlogId
     * @return
     */
    AttendanceLog getByIdAttendanceDao(int attenlogId);

    /**
     * 查询所有员工信息
     * @return
     */
    List<Staff>allStaffDao();

    /**
     * 查询考勤类型信息
     * @return
     */
    List<Attendance>allAttendanceDao();

    List<AttendanceLog> AttendanceLogDao(AttendanceLog attendanceLog);
}
