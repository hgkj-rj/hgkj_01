package com.hgkj.controler.action;

import com.hgkj.model.entity.Customer;
import com.hgkj.model.service.CusregisterService;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

@Controller
@Namespace("/qt")
@ParentPackage("struts-default")
public class RegisterAction {
@Autowired
    private CusregisterService cusregisterService;
private String message;

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public CusregisterService getCusregisterService() {
        return cusregisterService;
    }

    public void setCusregisterService(CusregisterService cusregisterService) {
        this.cusregisterService = cusregisterService;
    }

    private Customer customer;



    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    @Action(value = "insertCus",results = {@Result(name = "add",type = "redirect",
            location = "index.jsp"),@Result(name="adderror",type = "redirect",location = "regist.jsp")})
    public String insertCus() {
        boolean rs=cusregisterService.insertcusService(customer);
        if (rs){
            return "add";
        }else {
            return"adderror";
        }
    }


    @Action(value = "denglu", results ={@Result(name = "denglu", type = "redirect", location = "index.jsp"),
            @Result(name ="dengluError",type = "redirect",location = "login.jsp" )})
    public String denglu(){
        boolean result=cusregisterService.logincusService(customer);
        if (result){

            return "denglu";
        }else {
            message="账号密码不正确!";
            return "dengluError";
        }
    }
//    @Action(value = "htdenglu", results = {@Result(name = "denglucg", type = "redirect", location = "ht/index.jsp"), @Result(
//            name = "dlerror", type = "redirect", location = "ht/adminLogin.jsp")})
//    public String htdenglu(){
//        boolean rs=cusregisterService.logincusService(customer);
//        if (rs){
//            return "denglucg";
//        } else {
//            return "dlerror";
//        }
    }



