/*
Navicat MySQL Data Transfer

Source Server         : ojj
Source Server Version : 50644
Source Host           : localhost:3306
Source Database       : lvyou

Target Server Type    : MYSQL
Target Server Version : 50644
File Encoding         : 65001

Date: 2019-07-08 11:49:36
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for car
-- ----------------------------
DROP TABLE IF EXISTS `car`;
CREATE TABLE `car` (
  `carID` int(11) NOT NULL AUTO_INCREMENT,
  `customerID` int(11) NOT NULL,
  `lineID` varchar(36) NOT NULL,
  `time` datetime NOT NULL,
  PRIMARY KEY (`carID`) USING BTREE,
  KEY `FK_2` (`customerID`) USING BTREE,
  KEY `FK_3` (`lineID`) USING BTREE,
  CONSTRAINT `FK_2` FOREIGN KEY (`customerID`) REFERENCES `customer` (`customerID`),
  CONSTRAINT `FK_3` FOREIGN KEY (`lineID`) REFERENCES `line` (`lineID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- ----------------------------
-- Records of car
-- ----------------------------

-- ----------------------------
-- Table structure for customer
-- ----------------------------
DROP TABLE IF EXISTS `customer`;
CREATE TABLE `customer` (
  `customerID` int(11) NOT NULL AUTO_INCREMENT,
  `account` varchar(12) NOT NULL,
  `name` varchar(6) NOT NULL,
  `password` varchar(12) NOT NULL,
  `gender` char(8) NOT NULL,
  `identityID` varchar(18) NOT NULL,
  `tel` varchar(11) NOT NULL,
  `type` int(255) DEFAULT NULL,
  `custAccount` varchar(255) DEFAULT NULL,
  `custName` varchar(255) DEFAULT NULL,
  `custPassWord` varchar(255) DEFAULT NULL,
  `custSex` varchar(255) DEFAULT NULL,
  `custIdentityId` varchar(255) DEFAULT NULL,
  `custTel` varchar(255) DEFAULT NULL,
  `custType` int(11) DEFAULT NULL,
  PRIMARY KEY (`customerID`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- ----------------------------
-- Records of customer
-- ----------------------------
INSERT INTO `customer` VALUES ('1', '144110', 'ojj', '111', '男', '360', '176', '1', null, null, null, null, null, null, null);
INSERT INTO `customer` VALUES ('2', '144110', '11111', '1', 'radio', '1', '13689754698', null, null, null, null, null, null, null, null);
INSERT INTO `customer` VALUES ('22', '144110', '111', '111111', '男', '360281199803271413', '13689754698', null, null, null, null, null, null, null, null);

-- ----------------------------
-- Table structure for line
-- ----------------------------
DROP TABLE IF EXISTS `line`;
CREATE TABLE `line` (
  `lineID` varchar(12) NOT NULL,
  `lineTypeID` varchar(12) NOT NULL,
  `lineName` varchar(15) NOT NULL,
  `days` varchar(12) NOT NULL,
  `vehicle` char(2) NOT NULL,
  `introduction` varchar(400) DEFAULT NULL,
  `reason` varchar(100) DEFAULT NULL,
  `arrange` varchar(100) DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  `teamBuy` int(255) DEFAULT NULL,
  `teamBuyPrice` decimal(10,2) DEFAULT NULL,
  `beginTime` datetime DEFAULT NULL,
  `endTime` datetime DEFAULT NULL,
  `onTime` datetime NOT NULL,
  `lineDays` varchar(255) DEFAULT NULL,
  `lineVehicle` varchar(255) DEFAULT NULL,
  `lineIntroduction` varchar(255) DEFAULT NULL,
  `lineReason` varchar(255) DEFAULT NULL,
  `lineArrange` varchar(255) DEFAULT NULL,
  `linePrice` decimal(19,2) DEFAULT NULL,
  `lineTeamBuy` int(11) DEFAULT NULL,
  `lineTeamBuyPrice` decimal(19,2) DEFAULT NULL,
  `lineBeginTime` datetime DEFAULT NULL,
  `lineEndTime` datetime DEFAULT NULL,
  `lineOnTime` datetime DEFAULT NULL,
  PRIMARY KEY (`lineID`) USING BTREE,
  KEY `FK_1` (`lineTypeID`) USING BTREE,
  CONSTRAINT `FKd7h38nar3c77x5uw44ddn6nyf` FOREIGN KEY (`lineTypeID`) REFERENCES `linetype` (`lineTypeID`),
  CONSTRAINT `line_ibfk_4` FOREIGN KEY (`lineTypeID`) REFERENCES `linetype` (`lineTypeID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- ----------------------------
-- Records of line
-- ----------------------------
INSERT INTO `line` VALUES ('21', '1', '31', '231', '32', '213', '321', '312', '12.00', '1', '1.00', null, null, '2019-07-19 13:38:48', null, null, null, null, null, null, null, null, null, null, null);

-- ----------------------------
-- Table structure for linetype
-- ----------------------------
DROP TABLE IF EXISTS `linetype`;
CREATE TABLE `linetype` (
  `lineTypeID` varchar(36) NOT NULL,
  `typeName` varchar(10) NOT NULL,
  `time` datetime NOT NULL,
  `icon` varchar(20) NOT NULL,
  `lineTypeName` varchar(255) DEFAULT NULL,
  `lineTypeTime` datetime DEFAULT NULL,
  `lineTypeIcon` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`lineTypeID`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- ----------------------------
-- Records of linetype
-- ----------------------------
INSERT INTO `linetype` VALUES ('1', '哈哈12', '2019-07-07 12:51:01', 'ht/images/noprv.gif', null, null, null);
INSERT INTO `linetype` VALUES ('2', '哈哈', '2019-07-05 16:47:43', 'ht/images/alter.jpg', null, null, null);

-- ----------------------------
-- Table structure for orderdetail
-- ----------------------------
DROP TABLE IF EXISTS `orderdetail`;
CREATE TABLE `orderdetail` (
  `odID` varchar(36) NOT NULL,
  `customerID` int(11) NOT NULL,
  `lineName` varchar(15) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `orderDate` datetime NOT NULL,
  `travelDate` datetime NOT NULL,
  `total` decimal(10,2) NOT NULL,
  `lineID` varchar(36) NOT NULL,
  `state` int(255) NOT NULL,
  PRIMARY KEY (`odID`) USING BTREE,
  KEY `FK_5` (`customerID`) USING BTREE,
  KEY `FK_6` (`lineID`) USING BTREE,
  CONSTRAINT `FK_5` FOREIGN KEY (`customerID`) REFERENCES `customer` (`customerID`),
  CONSTRAINT `FK_6` FOREIGN KEY (`lineID`) REFERENCES `line` (`lineID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- ----------------------------
-- Records of orderdetail
-- ----------------------------

-- ----------------------------
-- Table structure for ot_detail
-- ----------------------------
DROP TABLE IF EXISTS `ot_detail`;
CREATE TABLE `ot_detail` (
  `otID` int(255) NOT NULL AUTO_INCREMENT,
  `odID` varchar(36) NOT NULL,
  `touristID` varchar(36) NOT NULL,
  PRIMARY KEY (`otID`) USING BTREE,
  KEY `FK_7` (`odID`) USING BTREE,
  KEY `FK_8` (`touristID`) USING BTREE,
  CONSTRAINT `FK_7` FOREIGN KEY (`odID`) REFERENCES `orderdetail` (`odID`),
  CONSTRAINT `FK_8` FOREIGN KEY (`touristID`) REFERENCES `tourist` (`touristID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- ----------------------------
-- Records of ot_detail
-- ----------------------------

-- ----------------------------
-- Table structure for picture
-- ----------------------------
DROP TABLE IF EXISTS `picture`;
CREATE TABLE `picture` (
  `pictureID` int(36) NOT NULL AUTO_INCREMENT,
  `introduction` varchar(20) DEFAULT NULL,
  `name` varchar(20) NOT NULL,
  `lineID` varchar(36) NOT NULL,
  PRIMARY KEY (`pictureID`) USING BTREE,
  KEY `FK_4` (`lineID`) USING BTREE,
  CONSTRAINT `FK_4` FOREIGN KEY (`lineID`) REFERENCES `line` (`lineID`),
  CONSTRAINT `FKajxrh3n0rdhg235h7vf6r64l` FOREIGN KEY (`lineID`) REFERENCES `line` (`lineID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- ----------------------------
-- Records of picture
-- ----------------------------

-- ----------------------------
-- Table structure for tourist
-- ----------------------------
DROP TABLE IF EXISTS `tourist`;
CREATE TABLE `tourist` (
  `touristID` varchar(36) NOT NULL,
  `IDCard` varchar(36) NOT NULL,
  `tel` varchar(15) NOT NULL,
  `realName` decimal(10,2) NOT NULL,
  PRIMARY KEY (`touristID`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- ----------------------------
-- Records of tourist
-- ----------------------------
