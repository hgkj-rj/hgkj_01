package com.workmoney.model.dao;

import com.workmoney.model.entity.Attendance;

import java.util.List;

/**
 * user@Bright Rain .
 * 2019/6/29.
 */
public interface KaoQinDao {
    /**
     * 获取所有考勤
     * @return
     */
    List<Attendance> getAllAttendanceDao();
    /**
     * 添加考勤
     * @return
     */
    void addAttendanceDao(Attendance Attendance);
    /**
     * 删除考勤
     * @return
     */
    void delAttendanceDao(Attendance Attendance);
    /**
     * 获取考勤
     * @return
     */
    Attendance getAttendanceDao(Attendance Attendance);
    /**
     * 修改考勤
     * @return
     */
    void updateAttendance(Attendance Attendance);
}
