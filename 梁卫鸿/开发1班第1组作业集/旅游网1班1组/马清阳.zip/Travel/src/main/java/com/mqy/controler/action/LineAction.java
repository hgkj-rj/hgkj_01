package com.mqy.controler.action;

import com.mqy.model.entity.Line;
import com.mqy.model.entity.Linetype;
import com.mqy.model.entity.Picture;
import com.mqy.model.service.LineService;
import com.mqy.model.service.LineTypeService;
import com.opensymphony.xwork2.ActionContext;
import org.apache.commons.io.FileUtils;
import org.apache.struts2.ServletActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

@Controller
@Namespace("/")
@ParentPackage("json-default")
public class LineAction {
    private int pageSize=2;
    private int pageIndex;
    private Line line;
    private String message;
    private File[] file;
    private String[] fileContentType;
    private String[] fileFileName;
    private String[] introduction;
    private int[] pictureId;
    private Linetype linetype;

    @Autowired
    private LineService lineService;

    @Autowired
    private LineTypeService lineTypeService;

    public void setLineTypeService(LineTypeService lineTypeService) {
        this.lineTypeService = lineTypeService;
    }

    public void setLineService(LineService lineService) {
        this.lineService = lineService;
    }

    /**
     * 查找全部线路
     * @return
     */
    @Action(value = "allLineAction", results = {
       @Result(name = "all", type = "redirect", location = "ht/seeLine.jsp")
    })
    public String allLine() {
        System.out.println("----全部线路查询----");
        int totalPage = lineService.getTotalPageService(pageSize);
        if (pageIndex < 1) {
            pageIndex=1;
        }else if (pageIndex> totalPage) {
            pageIndex = totalPage;
        }
        ActionContext.getContext().getSession().put("pageIndex",pageIndex);
        ActionContext.getContext().getSession().put("totalPage",totalPage);
        List<Line> allLineList = lineService.allLineService(pageIndex,pageSize);
        ActionContext.getContext().getSession().put("allLineList", allLineList);
        return "all";
    }

    /**
     * 查询全部团购
     * @return
     */
    @Action(value = "allTeamAction", results = {
            @Result(name = "all", type = "redirect", location = "ht/seeTeam.jsp")
    })
    public String allTeamLine() {
        System.out.println("---查询全部团购---");
        int totalPage = lineService.getTotalPageService(pageSize);
        if (pageIndex < 1) {
            pageIndex=1;
        }else if (pageIndex> totalPage) {
            pageIndex = totalPage;
        }
        ActionContext.getContext().getSession().put("pageIndex",pageIndex);
        ActionContext.getContext().getSession().put("totalPage",totalPage);
        List<Line> allLineList = lineService.allLineService(
                pageIndex,pageSize);
        ActionContext.getContext().getSession().put("allLineList",
                allLineList);
        return "all";
    }

    /**
     * 添加线路
     * @return
     */
    @Action(value = "addLineAction", results = {
       @Result(name = "add", type = "redirectAction", params = {
               "actionName", "allLineAction"})
    })
    public String addLine() {
        System.out.println("---添加线路---");
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss");
        line.setOnTime(sdf.format(new Date()));
        for(int i=0;i<file.length;i++){
            String  path= ServletActionContext.getServletContext().getRealPath
                    ("img/"+fileFileName[i]);
            File dest=new File(path);
            try {
                FileUtils.copyFile(file[i], dest);
            } catch (IOException e) {
                e.printStackTrace();
            }
            Picture picture=new Picture();
            picture.setName("img/"+fileFileName[i]);
            picture.setIntroduction(introduction[i]);
            picture.setLine(line);
            line.getPictureSet().add(picture);
        }
        lineService.addLineService(line);
        return "add";
    }

    /**
     * 删除线路
     * @return
     */
    @Action(value = "deleteLineAction",results = {
       @Result(name = "delete",type = "json", params = {"root", "message"})
    })
    public String deleteLine() {
        System.out.println("---删除线路---");
        lineService.deleteLineService(line.getLineId());
        message = "ok";
        return "delete";
    }

    /**
     * 获取线路对象
     * @return
     */
    @Action(value = "findLineAction",results = {
            @Result(name = "find",type = "redirect",location = "ht/updateLine.jsp")
    })
    public String findLine() {
        System.out.println("---获取线路对象---");
        line = lineService.getLineService(line.getLineId());
        ServletActionContext.getRequest().getSession().setAttribute("line", line);
        return "find";
    }

    /**
     * 获取团购对象
     * @return
     */
    @Action(value = "findTeamAction",results = {
            @Result(name = "findTeam",type = "redirect", location = "ht/setTeam.jsp")
    })
    public String findTeamBuyLine(){
        line = lineService.getLineService(line.getLineId());
        ServletActionContext.getRequest().getSession().setAttribute("line", line);
        return "findTeam";
    }

    /**
     * 修改线路
     * @return
     */
    @Action(value = "updateLineAction", results = {
       @Result(name = "update",type = "redirectAction", params = {
               "actionName", "allLineAction"})
    })
    public String updateLineType() {
        System.out.println("---修改线路---");
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss");
        line.setOnTime(sdf.format(new Date()));
        for(int i=0;i<file.length;i++){
            String  path=ServletActionContext.getServletContext().getRealPath
                    ("img/"+fileFileName[i]);
            File dest=new File(path);
            try {
                FileUtils.copyFile(file[i], dest);
            } catch (IOException e) {
                e.printStackTrace();
            }
            Picture picture=new Picture();
            picture.setName("img/"+fileFileName[i]);
            picture.setPictureId(pictureId[i]);
            picture.setIntroduction(introduction[i]);
            picture.setLine(line);
            line.getPictureSet().add(picture);
        }
        lineService.updateLineService(line);
        return "update";
    }

    /**
     * 修改团购信息
     * @return
     */
    @Action(value = "updateTeamAction", results = {
            @Result(name = "updateTeam", type = "redirectAction",params = {
                    "actionName","allTeamAction"})
    })
    public String updateTeam() {
        System.out.println("---修改团购---");
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss");
        line.setOnTime(sdf.format(new Date()));
        lineService.updateLineService(line);
        return "updateTeam";
    }

    public int getPageIndex() {
        return pageIndex;
    }

    public void setPageIndex(int pageIndex) {
        this.pageIndex = pageIndex;
    }

    public File[] getFile() {
        return file;
    }

    public int[] getPictureId() {
        return pictureId;
    }

    public void setPictureId(int[] pictureId) {
        this.pictureId = pictureId;
    }

    public Linetype getLinetype() {
        return linetype;
    }

    public void setLinetype(Linetype linetype) {
        this.linetype = linetype;
    }

    public void setFile(File[] file) {
        this.file = file;
    }

    public String[] getFileContentType() {
        return fileContentType;
    }

    public void setFileContentType(String[] fileContentType) {
        this.fileContentType = fileContentType;
    }

    public String[] getFileFileName() {
        return fileFileName;
    }

    public void setFileFileName(String[] fileFileName) {
        this.fileFileName = fileFileName;
    }

    public String[] getIntroduction() {
        return introduction;
    }

    public void setIntroduction(String[] introduction) {
        this.introduction = introduction;
    }

    public Line getLine() {
        return line;
    }

    public void setLine(Line line) {
        this.line = line;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
