/*
 Navicat Premium Data Transfer

 Source Server         : localhost
 Source Server Type    : MySQL
 Source Server Version : 50162
 Source Host           : localhost:3306
 Source Schema         : management

 Target Server Type    : MySQL
 Target Server Version : 50162
 File Encoding         : 65001

 Date: 08/07/2019 11:50:03
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for attendance
-- ----------------------------
DROP TABLE IF EXISTS `attendance`;
CREATE TABLE `attendance`  (
  `att_Id` int(11) NOT NULL AUTO_INCREMENT,
  `att_Name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `att_Percent` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`att_Id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of attendance
-- ----------------------------
INSERT INTO `attendance` VALUES (1, '迟到', '0.3');
INSERT INTO `attendance` VALUES (2, '旷工', '0.5');
INSERT INTO `attendance` VALUES (3, '早退', '0.4');

-- ----------------------------
-- Table structure for attendance_log
-- ----------------------------
DROP TABLE IF EXISTS `attendance_log`;
CREATE TABLE `attendance_log`  (
  `attenlog_Id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_Id` int(11) NULL DEFAULT NULL,
  `att_Id` int(11) NULL DEFAULT NULL,
  `attlog_Count` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `attlog_Time` datetime NULL DEFAULT NULL,
  `attendance` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`attenlog_Id`) USING BTREE,
  INDEX `FK1fk2eaal2bns1kxyanw48xkjc`(`staff_Id`) USING BTREE,
  INDEX `FKbheo5lhw8xjphy3298l1as6nn`(`attendance`) USING BTREE,
  INDEX `FK6rwwqs7caervlmokymw8ijihn`(`att_Id`) USING BTREE,
  CONSTRAINT `FK6rwwqs7caervlmokymw8ijihn` FOREIGN KEY (`att_Id`) REFERENCES `attendance` (`att_Id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `att_Id` FOREIGN KEY (`att_Id`) REFERENCES `attendance` (`att_Id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `FK1fk2eaal2bns1kxyanw48xkjc` FOREIGN KEY (`staff_Id`) REFERENCES `staff` (`staffId`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `FKbheo5lhw8xjphy3298l1as6nn` FOREIGN KEY (`attendance`) REFERENCES `attendance` (`att_Id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `staff_Id` FOREIGN KEY (`staff_Id`) REFERENCES `staff` (`staffId`) ON DELETE RESTRICT ON UPDATE NO ACTION
) ENGINE = InnoDB AUTO_INCREMENT = 18 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of attendance_log
-- ----------------------------
INSERT INTO `attendance_log` VALUES (3, 3, 2, '3', '2019-06-21 19:16:44', NULL);
INSERT INTO `attendance_log` VALUES (15, 4, 2, '2', '2019-06-21 15:29:58', NULL);
INSERT INTO `attendance_log` VALUES (16, 3, 3, '1', '2019-06-14 14:25:49', NULL);

-- ----------------------------
-- Table structure for department
-- ----------------------------
DROP TABLE IF EXISTS `department`;
CREATE TABLE `department`  (
  `dep_Id` int(10) NOT NULL AUTO_INCREMENT,
  `dep_Name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`dep_Id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of department
-- ----------------------------
INSERT INTO `department` VALUES (1, '管理');
INSERT INTO `department` VALUES (2, '店面');

-- ----------------------------
-- Table structure for level
-- ----------------------------
DROP TABLE IF EXISTS `level`;
CREATE TABLE `level`  (
  `level_Id` int(11) NOT NULL AUTO_INCREMENT,
  `level_Name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `level_Price` decimal(10, 2) NOT NULL,
  PRIMARY KEY (`level_Id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 6 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of level
-- ----------------------------
INSERT INTO `level` VALUES (1, '超级管理员', 100.00);
INSERT INTO `level` VALUES (2, '管理员', 50.00);
INSERT INTO `level` VALUES (3, '员工', 10.00);
INSERT INTO `level` VALUES (4, '店长', 1.00);

-- ----------------------------
-- Table structure for reward
-- ----------------------------
DROP TABLE IF EXISTS `reward`;
CREATE TABLE `reward`  (
  `rew_Id` int(11) NOT NULL AUTO_INCREMENT,
  `rew_Name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `rew_Price` decimal(10, 2) NOT NULL,
  PRIMARY KEY (`rew_Id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of reward
-- ----------------------------
INSERT INTO `reward` VALUES (1, '勤奋奖', 256.00);
INSERT INTO `reward` VALUES (2, '突出奖', 269.00);
INSERT INTO `reward` VALUES (3, '业绩奖', 298.00);

-- ----------------------------
-- Table structure for reward_log
-- ----------------------------
DROP TABLE IF EXISTS `reward_log`;
CREATE TABLE `reward_log`  (
  `rewlog_Id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_Id` int(11) NULL DEFAULT NULL,
  `rew_Id` int(11) NULL DEFAULT NULL,
  `rew_price` decimal(10, 2) NULL DEFAULT NULL,
  `rewlog_Time` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`rewlog_Id`) USING BTREE,
  INDEX `FK1lsdusbli368y9oeftprw4kw6`(`staff_Id`) USING BTREE,
  INDEX `FK5snrol82613adyasla3yb3fdx`(`rew_Id`) USING BTREE,
  CONSTRAINT `FK5snrol82613adyasla3yb3fdx` FOREIGN KEY (`rew_Id`) REFERENCES `reward` (`rew_Id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `FK1lsdusbli368y9oeftprw4kw6` FOREIGN KEY (`staff_Id`) REFERENCES `staff` (`staffId`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `reward_rew` FOREIGN KEY (`rew_Id`) REFERENCES `reward` (`rew_Id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `reward_staff` FOREIGN KEY (`staff_Id`) REFERENCES `staff` (`staffId`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 8 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of reward_log
-- ----------------------------
INSERT INTO `reward_log` VALUES (1, 3, 2, NULL, '2019-4-25');
INSERT INTO `reward_log` VALUES (2, 2, 3, NULL, '2019-1-5');
INSERT INTO `reward_log` VALUES (6, 3, 2, NULL, '2019-06-29');

-- ----------------------------
-- Table structure for role
-- ----------------------------
DROP TABLE IF EXISTS `role`;
CREATE TABLE `role`  (
  `Role_Id` int(11) NOT NULL AUTO_INCREMENT,
  `role_Name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`Role_Id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 6 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of role
-- ----------------------------
INSERT INTO `role` VALUES (1, '超级管理员');
INSERT INTO `role` VALUES (2, '管理员');
INSERT INTO `role` VALUES (3, '员工');
INSERT INTO `role` VALUES (4, '店长');

-- ----------------------------
-- Table structure for salary_log
-- ----------------------------
DROP TABLE IF EXISTS `salary_log`;
CREATE TABLE `salary_log`  (
  `sallog_Id` int(11) NOT NULL,
  `staff_Id` int(11) NULL DEFAULT NULL,
  `staff_Name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `shop_Name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `level_Name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `sal_Time` datetime NULL DEFAULT NULL,
  `level_Price` decimal(10, 2) NULL DEFAULT NULL,
  `att_Percent` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `total_Subsidy` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `total_reward` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `salary_Old` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `salary_True` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `sallog_Remark` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`sallog_Id`) USING BTREE,
  INDEX `staff_log_Id`(`staff_Id`) USING BTREE,
  CONSTRAINT `staff_log_Id` FOREIGN KEY (`staff_Id`) REFERENCES `staff` (`staffId`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of salary_log
-- ----------------------------
INSERT INTO `salary_log` VALUES (1, 1, 'root', '甜品店', '超级管理员', '2019-06-20 00:00:00', 100000.00, '0', '1000', '10000', '16516516', '16516516', '加油55');
INSERT INTO `salary_log` VALUES (2, 2, 'admin', '咖啡店', '管理员', '2019-04-05 00:00:00', 55.00, '0', '2112.', '10.21', '42', '42', '你要');
INSERT INTO `salary_log` VALUES (3, 3, 'emp', '甜店', '员工', '2019-06-01 00:00:00', 45345.00, '0', '24537', '5434753', '37583', '75837', '666');
INSERT INTO `salary_log` VALUES (4, 4, 'les', '甜店', '店长', '2019-06-21 00:00:00', 16516516.00, '100', '5', '838', '3883', '333', '333');

-- ----------------------------
-- Table structure for shop
-- ----------------------------
DROP TABLE IF EXISTS `shop`;
CREATE TABLE `shop`  (
  `shop_Id` int(11) NOT NULL AUTO_INCREMENT,
  `shop_Name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `shop_Address` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `shop_state` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '1',
  `shop_supervisor` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '20',
  `shop_remark` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '20',
  PRIMARY KEY (`shop_Id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 6 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of shop
-- ----------------------------
INSERT INTO `shop` VALUES (1, '甜品店', '不知道那里的店', '1', '52', '36');
INSERT INTO `shop` VALUES (2, '咖啡店', '时代的', '1', '2', '55');
INSERT INTO `shop` VALUES (3, '甜店', 'dd', '1', '11', '11');
INSERT INTO `shop` VALUES (4, '玩具店', '顶顶顶', '1', '33', '55');

-- ----------------------------
-- Table structure for staff
-- ----------------------------
DROP TABLE IF EXISTS `staff`;
CREATE TABLE `staff`  (
  `staffId` int(10) NOT NULL AUTO_INCREMENT,
  `staffName` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `staffPwd` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `staffSex` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `staffAddress` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `staffTel` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `staffEmail` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `staffState` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `level_Id` int(11) NULL DEFAULT 3,
  `roles_Id` int(11) NULL DEFAULT 4,
  `dep_Id` int(11) NULL DEFAULT 1,
  `shop_Id` int(11) NULL DEFAULT 2,
  `level` int(11) NULL DEFAULT NULL,
  `role` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`staffId`) USING BTREE,
  INDEX `staff_shop`(`shop_Id`) USING BTREE,
  INDEX `staff_level`(`level_Id`) USING BTREE,
  INDEX `staff_dep`(`dep_Id`) USING BTREE,
  INDEX `staff_roles`(`roles_Id`) USING BTREE,
  INDEX `FK1jgn46nb8wqtylmrtk5k3yumm`(`level`) USING BTREE,
  INDEX `FKh3gguv9i8qnualo6wiyf8xvbd`(`role`) USING BTREE,
  CONSTRAINT `FKistssg7jbq1b2pcdlug7hobiq` FOREIGN KEY (`roles_Id`) REFERENCES `role` (`Role_Id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `FK1jgn46nb8wqtylmrtk5k3yumm` FOREIGN KEY (`level`) REFERENCES `level` (`level_Id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `FKh3gguv9i8qnualo6wiyf8xvbd` FOREIGN KEY (`role`) REFERENCES `role` (`Role_Id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `FKk4xhi49ywxwh6kivmp8ux9yfr` FOREIGN KEY (`dep_Id`) REFERENCES `department` (`dep_Id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `staff_dep` FOREIGN KEY (`dep_Id`) REFERENCES `department` (`dep_Id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `staff_level` FOREIGN KEY (`level_Id`) REFERENCES `level` (`level_Id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `staff_roles` FOREIGN KEY (`roles_Id`) REFERENCES `role` (`Role_Id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `staff_shop` FOREIGN KEY (`shop_Id`) REFERENCES `shop` (`shop_Id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 10 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of staff
-- ----------------------------
INSERT INTO `staff` VALUES (1, 'root', '123456', '男', '别墅', '165465651', '17745277963@qq.com', '1', 1, 1, 1, 4, NULL, NULL);
INSERT INTO `staff` VALUES (2, 'admin', '123', '男', '订单', '15056332579', '5455@', '1', 2, 2, 1, 2, NULL, NULL);
INSERT INTO `staff` VALUES (3, 'emp', '123456', '男', '方方法', '16516516', '16516@qq.com', '1', 3, 3, 1, 4, NULL, NULL);
INSERT INTO `staff` VALUES (4, 'les', '123456', '男', '典型的', '51651', '165165', '1', 4, 4, 2, 4, NULL, NULL);

-- ----------------------------
-- Table structure for subsidy
-- ----------------------------
DROP TABLE IF EXISTS `subsidy`;
CREATE TABLE `subsidy`  (
  `subsidy_Id` int(11) NOT NULL AUTO_INCREMENT,
  `subsidy_Name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `subsidy_Money` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`subsidy_Id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 6 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of subsidy
-- ----------------------------
INSERT INTO `subsidy` VALUES (1, '交通补助', '150');
INSERT INTO `subsidy` VALUES (2, '午餐补助', '150');
INSERT INTO `subsidy` VALUES (3, '社保补助', '500');

-- ----------------------------
-- Table structure for subsidy_log
-- ----------------------------
DROP TABLE IF EXISTS `subsidy_log`;
CREATE TABLE `subsidy_log`  (
  `stblog_Id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_Id` int(11) NULL DEFAULT NULL,
  `sunsidy_Id` int(11) NULL DEFAULT NULL,
  `subsidy_Money` decimal(10, 2) NULL DEFAULT NULL,
  `sublog_Time` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`stblog_Id`) USING BTREE,
  INDEX `sunsidy_Id`(`sunsidy_Id`) USING BTREE,
  INDEX `subsidy_staff`(`staff_Id`) USING BTREE,
  CONSTRAINT `subsidy_staff` FOREIGN KEY (`staff_Id`) REFERENCES `staff` (`staffId`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `FKbmijdonnn9uy49oequ25w2lel` FOREIGN KEY (`staff_Id`) REFERENCES `staff` (`staffId`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `FKy7pf4vowqnyis0sbxd96yey` FOREIGN KEY (`sunsidy_Id`) REFERENCES `subsidy` (`subsidy_Id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `sunsidy_Id` FOREIGN KEY (`sunsidy_Id`) REFERENCES `subsidy` (`subsidy_Id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 13 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of subsidy_log
-- ----------------------------
INSERT INTO `subsidy_log` VALUES (1, 3, 1, 150.00, '2019-6-8');
INSERT INTO `subsidy_log` VALUES (2, 3, 2, 150.00, '2019-6-8');
INSERT INTO `subsidy_log` VALUES (3, 2, 3, 500.00, '2019-6-8');
INSERT INTO `subsidy_log` VALUES (12, 4, 3, 50.00, '2019-06-27 18:01:44.373');

SET FOREIGN_KEY_CHECKS = 1;
