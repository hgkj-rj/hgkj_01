package com.hgkj.model.dao;

import com.hgkj.model.entity.Line;


import java.util.List;

public interface LineDao {
    public List<Line> allLineDao();
    public boolean addLineDao(Line line);
    public boolean deleteLineDao(Line line);
    public boolean updateLineDao(Line line);
    public Line getLineByIdDao(String lineId);
}
