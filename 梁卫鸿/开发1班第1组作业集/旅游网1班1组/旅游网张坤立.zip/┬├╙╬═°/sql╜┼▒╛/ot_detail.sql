/*
 Navicat Premium Data Transfer

 Source Server         : Mysql
 Source Server Type    : MySQL
 Source Server Version : 50724
 Source Host           : localhost:3306
 Source Schema         : travel

 Target Server Type    : MySQL
 Target Server Version : 50724
 File Encoding         : 65001

 Date: 08/07/2019 09:54:18
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for ot_detail
-- ----------------------------
DROP TABLE IF EXISTS `ot_detail`;
CREATE TABLE `ot_detail`  (
  `otID` int(11) NOT NULL AUTO_INCREMENT COMMENT '订单游客信息编号，主键自增长',
  `odID` int(255) NULL DEFAULT NULL COMMENT '订单编号，外键',
  `touristID` int(255) NULL DEFAULT NULL COMMENT '游客信息编号，外键',
  PRIMARY KEY (`otID`) USING BTREE,
  INDEX `FK_OT_TOURIST`(`touristID`) USING BTREE,
  INDEX `FK_OT_OD`(`odID`) USING BTREE,
  CONSTRAINT `FK_OT_OD` FOREIGN KEY (`odID`) REFERENCES `orderdetail` (`odID`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `FK_OT_TOURIST` FOREIGN KEY (`touristID`) REFERENCES `tourist` (`touristID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

SET FOREIGN_KEY_CHECKS = 1;
