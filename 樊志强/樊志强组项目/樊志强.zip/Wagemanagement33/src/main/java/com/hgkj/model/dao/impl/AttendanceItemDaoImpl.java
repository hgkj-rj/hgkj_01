package com.hgkj.model.dao.impl;

import com.hgkj.model.dao.AttendanceItemDao;
import com.hgkj.model.entity.Attendance;
import com.hgkj.model.entity.Department;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

@Repository
@Transactional
public class AttendanceItemDaoImpl implements AttendanceItemDao {
    @Autowired
    private SessionFactory sessionFactory;


    @Override
    public List<Attendance> allAttendance() {
        String hql="from Attendance ";
        List<Attendance> attendanceList=getSession().createQuery(hql).list();
        return attendanceList;
    }

    @Override
    public boolean addAttendance(Attendance Attendance) {
        getSession().save(Attendance);
        return true;
    }

    @Override
    public boolean delAttendance(Attendance Attendance) {
        getSession().delete(Attendance);
        return true;
    }

    @Override
    public boolean updAttendance(Attendance Attendance) {
        getSession().update(Attendance);
        return true;
    }

    @Override
    public Attendance queryAttendance(Attendance Attendance) {
        String hql="from Attendance where attId=?";
        Attendance attendance = (Attendance) getSession().createQuery(hql).setParameter(0, Attendance.getAttId()).uniqueResult();
        return attendance;
    }

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    public Session getSession(){
        return sessionFactory.getCurrentSession();
    }

}
