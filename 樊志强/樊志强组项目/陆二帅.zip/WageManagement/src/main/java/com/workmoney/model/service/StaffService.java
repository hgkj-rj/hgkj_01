package com.workmoney.model.service;

import com.workmoney.model.entity.Staff;
import com.workmoney.util.SercharStaff;
import com.workmoney.util.SercharStaffUpload;

import java.util.List;

/**
 * user@Bright Rain .
 * 2019/6/24.
 */
public interface StaffService {

    /**
     * 登陆
     * @param staff
     * @return
     */
    Staff staffLoginService(Staff staff);
    /**
     * 修改密码
     * @param staff
     * @return
     */
    Staff updateStaffPwdByIdService(Staff staff);
    /**
     * 查询所有员工
     * @return
     */
    List<Staff> getStaffListSercharService();

    /**
     * 根据月份和名字进行模糊查询
     * @param sercharStaff
     * @return
     */
    List<Staff> sercharStaffByNameAndMonth(SercharStaff sercharStaff);

    /**
     * 修改备注
     * @param staffId
     * @param remark
     * @return
     */
    boolean updateStaffRemarkByIdService(int staffId, String remark);
}
