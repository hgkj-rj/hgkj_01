package com.hgkj.model.service.impl;

import com.hgkj.model.entity.Role;
import com.hgkj.model.service.RoleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RoleServiceimpl implements RoleService {
    @Autowired
    private RoleService roleService;

    public void setRoleService(RoleService roleService) {
        this.roleService = roleService;
    }

    @Override
    public List<Role> roleService() {
        return roleService.roleService();
    }
}
