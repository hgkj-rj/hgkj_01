package com.workmoney.controller.action;

import com.workmoney.model.entity.Reward;
import com.workmoney.model.entity.RewardLog;
import com.workmoney.model.entity.Staff;
import com.workmoney.model.entity.StaffFuBen;
import com.workmoney.model.service.EmployeeService;
import com.workmoney.model.service.RewardService;
import com.workmoney.model.service.StaffService;
import org.apache.struts2.ServletActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import javax.servlet.http.HttpSession;
import java.util.List;

/**
 * user@Bright Rain .
 * 2019/6/29.
 */
@ParentPackage("struts-default")
@Namespace("/")
@Controller
public class RewardControllerAction {

    @Autowired
    private StaffService staffService;

    @Autowired
    private RewardService service;
    @Autowired
    private EmployeeService employeeService;
    private RewardLog rewardLog;
    private StaffFuBen staffFuBen;

    /**
     * 保存添加
     */
    @Action(value = "/addEmpRewardAction",results = {@Result(name = "success",type = "redirectAction",location = "getAllReward")})
    public String addEmpRewardAction(){
        service.addEmpRewardService(rewardLog);
        return "success";
    }

    /**
     * 去往添加页面
     */
    @Action(value = "/toAddRewardAction",results = {@Result(name = "success",type = "redirect",location = "rewardEmpAdd.jsp")})
    public String toAddRewardAction(){
        HttpSession session = ServletActionContext.getRequest().getSession();
        StaffFuBen fuBen = employeeService.getEmpByIdService(staffFuBen);
        List<Reward> rewardType = service.getAllRewardType();
        session.setAttribute("rewardType",rewardType);
        session.setAttribute("fuBen",fuBen);
        return "success";
    }

    /**
     * 查询所有员工
     */
    @Action(value = "/goRewardEmpListAction",results = {@Result(name = "success",type = "redirect",location = "html/rewardStaffList.jsp")})
    public String goRewardEmpListAction(){
        HttpSession session = ServletActionContext.getRequest().getSession();


        List<Staff> staffList = staffService.getStaffListSercharService();
        session.setAttribute("staffList",staffList);
        return "success";
    }


    /**
     * 删除奖金补贴
     * @return
     */

    @Action(value = "/delrewardById",results = {@Result(name = "success",type = "redirectAction",location = "getAllReward")})
    public String delrewardById(){

        service.delrewardByIdService(rewardLog);

        return "success";
    }


    /**
     * 查询所有获奖信息
     * @return
     */

    @Action(value = "/getAllReward",results = {@Result(name = "success",type = "redirect",location = "html/rewardList.jsp")})
    public String getAllReward(){

        HttpSession session = ServletActionContext.getRequest().getSession();

        List<RewardLog> rewardLogList = service.getAllRewardService();

        session.setAttribute("rewardLogList",rewardLogList);
        return "success";
    }

    public RewardLog getRewardLog() {
        return rewardLog;
    }

    public void setRewardLog(RewardLog rewardLog) {
        this.rewardLog = rewardLog;
    }

    public StaffFuBen getStaffFuBen() {
        return staffFuBen;
    }

    public void setStaffFuBen(StaffFuBen staffFuBen) {
        this.staffFuBen = staffFuBen;
    }
}
