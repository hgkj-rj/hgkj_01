package com.mqy.controler.action;

import com.mqy.model.entity.Customer;
import com.mqy.model.service.CustomerService;
import com.opensymphony.xwork2.ActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

@Controller
@Namespace("/")
@ParentPackage("struts-default")
public class CustomerAction {
    private Customer customer;
    private HttpServletRequest request;

    @Autowired
    private CustomerService customerService;

    public void setCustomerService(CustomerService customerService) {
        this.customerService = customerService;
    }

    /**
     * ��ͨ�û���¼
     * @return
     */
    @Action(value = "LoginAction",results = {
        @Result(name = "login",type = "redirect",location = "qt/index.jsp"),
        @Result(name = "error",type="redirect",location = "qt/login.jsp")
    })
    public String customerLogin(){
        System.out.println("----��ͨ��Ա��¼----");
        Customer cus=customerService.LoginService(customer);
        if(cus!=null && cus.getCustomerId()>0){
            ActionContext.getContext().getSession().put("customer",customer);
            return "login";
        }else{
            return "error";
        }
    }

    /**
     * ����Ա��¼
     * @return
     */
    @Action(value = "adminLoginAction", results = {
       @Result(name = "admin", type = "redirect", location = "ht/index.jsp"),
       @Result(name = "adminError", type = "redirect", location = "ht/adminLogin.jsp")
    })
    public String adminLogin() {
        System.out.println("-----����Ա��¼------");
        Customer cus = customerService.LoginService(customer);
        if (cus!=null && cus.getType()==1) {
            return "admin";
        }else {
            return "adminError";
        }
    }

    /**
     * ��ѯ������ͨ��Ա
     * @return
     */
    @Action(value = "allCustomerAction",results = {
        @Result(name = "all",type = "redirect",location = "qt/showCustomer.jsp")
    })
    public String allCustomer(){
        List<Customer> customerList=customerService.allCustomerService();
        ActionContext.getContext().getSession().put("customerList",
            customerList);
        return "all";
    }

    /**
     * ע����ͨ��Ա
     * @return
     */
    @Action(value = "registerCustomerAction",results = {
        @Result(name = "register",type = "redirect",location = "/qt/login.jsp")
    })
    public String registerCustomer(){
        customerService.registerCustomerService(customer);
        return "register";
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public HttpServletRequest getRequest() {
        return request;
    }

    public void setRequest(HttpServletRequest request) {
        this.request = request;
    }
}
