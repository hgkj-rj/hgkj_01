package com.xl.model.dao.impl;

import com.xl.model.dao.InvitejobDao;
import com.xl.model.entity.Employee;
import com.xl.model.entity.Invitejob;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class InvitejobDaoImpl implements InvitejobDao {
    @Override
    public int invitejobDao(int pageSize) {
        int totalPage=0;
        Connection connection=DBManager.getConnection();
        PreparedStatement preparedStatement=null;
        ResultSet resultSet=null;
        String sql="select count(*) from invitejob";
        try {
            preparedStatement=connection.prepareStatement(sql);
            resultSet=preparedStatement.executeQuery();
            if (resultSet.next()){
                totalPage=(resultSet.getInt(1)-1)/pageSize+1;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            DBManager.closeAll(connection,preparedStatement,resultSet);
        }
        return totalPage;
    }


    @Override
    public List<Invitejob> allInvitejobDao(int pageIndex, int pageSize) {
        List<Invitejob> invitejobList=new ArrayList<>();
        Connection connection=DBManager.getConnection();
        PreparedStatement preparedStatement=null;
        ResultSet resultSet=null;
        String sql="select * from invitejob limit  ?,?";
        try {
            preparedStatement=connection.prepareStatement(sql);
            preparedStatement.setInt(1,(pageIndex-1)*pageSize);
            preparedStatement.setInt(2,pageSize);
            resultSet=preparedStatement.executeQuery();
            while (resultSet.next()){
                Invitejob invitejob=new Invitejob();
                invitejob.setInvitejobId(resultSet.getInt("InvitejobId"));
                invitejob.setInvitejobName(resultSet.getString("invitejobName"));
                invitejob.setInvitejobPost(resultSet.getString("invitejobPost"));
                invitejob.setInvitejobSex(resultSet.getString("invitejobSex"));
                invitejob.setInvitejobEd(resultSet.getString("invitejobEd"));
                invitejob.setInvitejobEx(resultSet.getInt("invitejobEx"));

                invitejobList.add(invitejob);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            DBManager.closeAll(connection,preparedStatement,resultSet);
        }
        return invitejobList;
    }


    @Override
    public Invitejob getInvitejobByIdDao(int invitejobId) {

        return null;
    }

    @Override
    public boolean addInvitejobDao(Invitejob invitejob) {

        String sql = "insert into invitejob(invitejobName,invitejobPost,invitejobSex,invitejobEd,invitejobEx) values(?,?,?,?,?)";
        Object[] objects = {invitejob.getInvitejobName(),invitejob.getInvitejobPost(), invitejob.getInvitejobSex(),invitejob.getInvitejobEd(),invitejob.getInvitejobEx(),invitejob.getInvitejobId()};
        return DBManager.executeUpdate(sql,objects);
    }

    @Override
    public boolean deleteInvitejobDao(Invitejob invitejob) {

        String sql = "delete from invitejob where invitejobId=?";
        Object[] objects = {invitejob};
        return DBManager.executeUpdate(sql,objects);
    }

    @Override
    public boolean updateInvitejobDao(Invitejob invitejob) {
        String sql = "update invitejob set invitejobName=?,invitejobPost=?,invitejobSex=? ,invitejobEd=?,invitejobEx=?where employeeId=?";
        Object[] objects = {invitejob.getInvitejobName(),invitejob.getInvitejobPost(), invitejob.getInvitejobSex(),invitejob.getInvitejobEd(),invitejob.getInvitejobEx(),invitejob.getInvitejobId()};
        return DBManager.executeUpdate(sql,objects);
    }
}
