package com.hgkj.contrloer.action;

import com.hgkj.model.entity.Subsidy;
import com.hgkj.model.service.SubsidyService;
import com.opensymphony.xwork2.ActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import java.util.List;

@Controller
@Namespace("/")
@ParentPackage("json-default")
public class SubsidyAction {
    @Autowired
    private SubsidyService subsidyService;
    private Subsidy subsidy;
    private int id;
    @Action(value = "allsubsidy",results = {@Result(name = "all",type = "redirect",location = "html/subsidyList.jsp")})
    public String allreward(){
        List<Subsidy> subsidyList=subsidyService.allsubsidyService();
        ActionContext.getContext().getSession().put("subsidyList",subsidyList);
        return "all";
    }
    @Action(value = "insertsubsidy",results = {@Result(name = "insert",type = "redirect",location = "allsubsidy")})
    public String insert(){
        System.out.println(subsidy.getSubsidyMoney()+"：我是钱！！！！！！！！！！"+subsidy.getSubsidyName()+"：我是名字");
        if(subsidyService.insertsubsidyService(subsidy)){
            return "insert";
        }else {
            return "noinsert";
        }

    }
    @Action(value = "deletesubsidy",results = {@Result(name = "delete",type = "json",params = {"root","delete"}),@Result(name = "nodelete",type = "redirect",location = "../subsidyList.jsp")})
    public String delete(){
        if (subsidyService.deletesubsidyService(id)){
            return "delete";
        }else {
            return "nodelete";
        }

    }
    @Action(value = "updatesubsidy",results = {@Result(name = "update",type = "redirectAction",location = "allsubsidy"),@Result(name = "noupdate",type = "redirect",location = "../subsidyList.jsp")})
    public String update(){
        System.out.println(subsidy.getSubsidyId()+"+"+subsidy.getSubsidyName()+"+"+subsidy.getSubsidyMoney());
        if (subsidyService.updatesubsidyService(subsidy)){
            return "update";
        }else {
            return "noupdate";
        }

    }
    @Action(value = "getsubsidy",results = {@Result(name = "get",type = "redirect",location = "html/subsidyupdate.jsp")})
    public String getrewardmanage(){
        subsidy=subsidyService.getsubsidyByIdService(id);
        ActionContext.getContext().getSession().put("subsidy",subsidy);
        return "get";
    }
    public void setSubsidyService(SubsidyService subsidyService) {
        this.subsidyService = subsidyService;
    }

    public void setSubsidy(Subsidy subsidy) {
        this.subsidy = subsidy;
    }

    public Subsidy getSubsidy() {
        return subsidy;
    }

    public void setId(int id) {
        this.id = id;
    }
}
