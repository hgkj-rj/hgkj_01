package com.hgkj.model.entity;

import java.math.BigDecimal;

public class RewardLog {
    private int rewlogId;
    private BigDecimal rewPrice;
    private String rewlogTime;
    private Staff staff;
    private Reward reward;
    public int getRewlogId() {
        return rewlogId;
    }

    public void setRewlogId(int rewlogId) {
        this.rewlogId = rewlogId;
    }

    public BigDecimal getRewPrice() {
        return rewPrice;
    }

    public void setRewPrice(BigDecimal rewPrice) {
        this.rewPrice = rewPrice;
    }

    public String getRewlogTime() {
        return rewlogTime;
    }

    public void setRewlogTime(String rewlogTime) {
        this.rewlogTime = rewlogTime;
    }

    public Staff getStaff() {
        return staff;
    }

    public void setStaff(Staff staff) {
        this.staff = staff;
    }

    public Reward getReward() {
        return reward;
    }

    public void setReward(Reward reward) {
        this.reward = reward;
    }

    @Override
    public String toString() {
        return "RewardLog{" +
                "rewlogId=" + rewlogId +
                ", rewPrice=" + rewPrice +
                ", rewlogTime='" + rewlogTime + '\'' +
                ", staff=" + staff +
                ", reward=" + reward +
                '}';
    }
}
