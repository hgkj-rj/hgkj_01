package com.hgkj.contrloer.action;

import com.hgkj.model.entity.AttendanceLog;
import com.hgkj.model.entity.SalaryLog;
import com.hgkj.model.service.SalaryLogService;
import com.opensymphony.xwork2.ActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import java.util.List;

@Controller
@Namespace("/")
@ParentPackage("struts-default")
public class SalaryLogAction {
    @Autowired
    private SalaryLogService salaryLogService;
    private SalaryLog salaryLog;
    private int staffId;
    private int numberZ;
    private int numberK;
    private int numberC;
    private double priceZ;
    private double priceK;
    private double priceC;
    @Action(value = "all",results = {@Result(name = "all1",type = "redirect",location = "html/salarySearch.jsp"),@Result(name = "all2",type = "redirect",location = "html/salarySearch.jsp"),@Result(name = "all3",type = "redirect",location = "html/salarySearch.jsp")})
    public String allSalaryLog(){
        staffId= (Integer) ActionContext.getContext().getSession().get("staffId");
        List<SalaryLog> list=salaryLogService.getsubsidyService(staffId);
        SalaryLog salaryLog=list.get(0);
        if (salaryLog.getStaff().getLevel().getLevelId()==1){
            ActionContext.getContext().getSession().put("list",list);
            return "all1";
        }else if (salaryLog.getStaff().getLevel().getLevelId()==3){
            ActionContext.getContext().getSession().put("list",list);
            return "all2";
        }else {
            List<SalaryLog> list2=salaryLogService.allsubsidyService();
            ActionContext.getContext().getSession().put("list",list);
            return "all3";
        }

    }
    @Action(value = "allattendance",results = {@Result(name = "allatt",type = "redirect",location = "html/salaryAttendanceInfo.jsp")})
    public String allAttendanceLog(){
        staffId= (Integer) ActionContext.getContext().getSession().get("staffId");
        List<SalaryLog> salaryLogs=salaryLogService.getsubsidyService(staffId);
        double levelPrice=Double.parseDouble(salaryLogs.get(0).getLevelPrice().toString());
        List<AttendanceLog> attendanceLogList=salaryLogService.allAttendanceLogService(staffId);
        for (AttendanceLog attendanceLog:attendanceLogList){
            if (attendanceLog.getAttenlogId()==1){
                numberC++;
                priceC=levelPrice*Double.parseDouble(attendanceLog.getAttendance().getAttPercent())*numberC;
            }else if (attendanceLog.getAttenlogId()==2){
                numberK++;
                priceK=levelPrice*Double.parseDouble(attendanceLog.getAttendance().getAttPercent())*numberK;
            }else if (attendanceLog.getAttenlogId()==3){
                numberK++;
                priceK=levelPrice*Double.parseDouble(attendanceLog.getAttendance().getAttPercent())*numberK;
            }
            ActionContext.getContext().getSession().put("priceC",priceC);
            ActionContext.getContext().getSession().put("priceK",priceK);
            ActionContext.getContext().getSession().put("priceZ",priceZ);
            ActionContext.getContext().getSession().put("numberC",numberC);
            ActionContext.getContext().getSession().put("numberK",numberK);
            ActionContext.getContext().getSession().put("numberZ",numberZ);
        }
//        List<AttendanceLog> listatt=salaryLogService.allAttendanceLogService(staffId);
//        List<SalaryLog> list=salaryLogService.getsubsidyService(staffId);
//        for (AttendanceLog attendanceLog:listatt){
//            if (attendanceLog.getAttendance().getAttId()==1){
//                numberC++;
//                System.out.println(numberC+"+++++++++++++++++++++");
//                double point=Double.parseDouble(attendanceLog.getAttendance().getAttPercent());
//                double price=Double.parseDouble(salaryLog.getLevelPrice().toString());
//                priceC=numberC*(point*price);
//            }else if (attendanceLog.getAttendance().getAttId()==2){
//                numberK++;
//                double point= 0;
//                double price= 0;
//                try {
//                    point = Double.parseDouble(attendanceLog.getAttendance().getAttPercent());
//                    price = Double.parseDouble(salaryLog.getLevelPrice().toString());
//                } catch (NumberFormatException e) {
//                    System.out.println("异常处理");
//                    e.printStackTrace();
//                }
//                priceK=numberK*(point*price);
//            }else{
//                numberZ++;
//                double point=Double.parseDouble(attendanceLog.getAttendance().getAttPercent());
//                double price=Double.parseDouble(salaryLog.getLevelPrice().toString());
//                priceZ=numberZ*(point*price);
//            }
//        }
//        ActionContext.getContext().getSession().put("priceC",priceC);
//        ActionContext.getContext().getSession().put("priceK",priceK);
//        ActionContext.getContext().getSession().put("priceZ",priceZ);
//        ActionContext.getContext().getSession().put("numberC",numberC);
//        ActionContext.getContext().getSession().put("numberK",numberK);
//        ActionContext.getContext().getSession().put("numberZ",numberZ);
        return "allatt";
    }

    public double getPriceZ() {
        return priceZ;
    }

    public void setPriceZ(double priceZ) {
        this.priceZ = priceZ;
    }

    public double getPriceK() {
        return priceK;
    }

    public void setPriceK(double priceK) {
        this.priceK = priceK;
    }

    public double getPriceC() {
        return priceC;
    }

    public void setPriceC(double priceC) {
        this.priceC = priceC;
    }

    public int getNumberZ() {
        return numberZ;
    }

    public void setNumberZ(int numberZ) {
        this.numberZ = numberZ;
    }

    public int getNumberK() {
        return numberK;
    }

    public void setNumberK(int numberK) {
        this.numberK = numberK;
    }

    public int getNumberC() {
        return numberC;
    }

    public void setNumberC(int numberC) {
        this.numberC = numberC;
    }

    public int getStaffId() {
        return staffId;
    }

    public void setStaffId(int staffId) {
        this.staffId = staffId;
    }

    public SalaryLogService getSalaryLogService() {
        return salaryLogService;
    }

    public void setSalaryLogService(SalaryLogService salaryLogService) {
        this.salaryLogService = salaryLogService;
    }

    public SalaryLog getSalaryLog() {
        return salaryLog;
    }

    public void setSalaryLog(SalaryLog salaryLog) {
        this.salaryLog = salaryLog;
    }
}
