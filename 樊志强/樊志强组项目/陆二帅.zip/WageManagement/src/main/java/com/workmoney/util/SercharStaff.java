package com.workmoney.util;

/**
 * user@Bright Rain .
 * 2019/6/24.
 */
public class SercharStaff {
   private String name;
    private String month;

    @Override
    public String toString() {
        return "SercharStaff{" +
                "name='" + name + '\'' +
                ", month='" + month + '\'' +
                '}';
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMonth() {
        return month;
    }

    public void setMonth(String month) {
        this.month = month;
    }
}
