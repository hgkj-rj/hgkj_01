package com.hgkj.model.dao;

import com.hgkj.model.entity.Line;
import com.hgkj.model.entity.Picture;

import java.util.List;

public interface ImagesDao {
    public List<Picture> imagesAllDao();
    public boolean imagesInsertDao(String lineID, String introduction, String name);
    public Picture imagesIdDao(int pictureID);
    public boolean imagesUpdateService(int pictureID, String introduction, String name, String lineID);
    public boolean lineAddDao(Line line);
    public List<Line> lineAllDao();
    public boolean lineDeleteDao(String lineID);
    public Line lineIdDao(String lineID);
    public boolean lineUpdateDao(Line line);


}
