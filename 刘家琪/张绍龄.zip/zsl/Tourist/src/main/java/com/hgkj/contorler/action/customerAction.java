package com.hgkj.contorler.action;

import com.hgkj.model.Service.CustomerService;
import com.hgkj.model.entity.Customer;
import com.opensymphony.xwork2.ActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

@Controller
@Namespace("/")
@ParentPackage("struts-default")
public class customerAction {
    @Autowired
    private CustomerService customerService;
    private Customer customer;
    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public CustomerService getCustomerService() {
        return customerService;
    }
    public void setCustomerService(CustomerService customerService) {
        this.customerService = customerService;
    }

    @Action(value = "qlogin" ,results = {@Result(name = "login",type = "redirectAction",location = "toIndex.action"),
            @Result(name = "error",type = "redirect",location = "/login.jsp")})
    public  String  qLogin(){
        customer = customerService.qCustomerService(customer);
        if(customer!=null){
            return  "login";
        }else {
            return  "error";
        }
    }
    @Action(value = "hlogin" ,results = {@Result(name = "login",type = "redirect",location = "/htindex.jsp"),
            @Result(name = "error",type = "redirect",location = "/adminLogin.jsp")})
    public  String  hlogin(){
        customer = customerService.qCustomerService(customer);
        if(customer!=null){
            if(customer.getType()==1){
                return  "login";
            }
            return  "error";
        }else {
            return  "error";
        }
    }
    @Action(value = "addCustomer" ,results = {@Result(name = "add",type = "redirect",location = "/login.jsp"),
            @Result(name = "error",type = "redirect",location = "/regist.jsp")})
    public String  addCustomer(){
        boolean flag =customerService.addCustomerService(customer);
        if(flag) {
            return "add";
        }else
            return "error";
    }
    @Action(value = "qttuichu" ,results = {@Result(name = "tui",type = "redirect",location = "/index.jsp")})
    public  String qttuichu(){
        ActionContext.getContext().getSession().remove("customer");
        return "tui";
    }
}
