package com.hgkj.model.dao.impl;

import com.hgkj.model.dao.DetailLineDao;
import com.hgkj.model.entity.Line;
import com.hgkj.model.entity.Picture;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
@Transactional
public class DetailLineDaoImpl implements DetailLineDao {
    @Autowired
    private SessionFactory sessionFactory;
    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }
    public Session getSession(){
        return sessionFactory.getCurrentSession();
    }
    @Override
    public List<Line> lineAllDao() {
        String hql="from Line ";
        Query query=getSession().createQuery(hql);
        return query.list();
    }
    @Override
    public List<Picture> imagesAllDao() {
        String hql="from Picture ";
        Query query=getSession().createQuery(hql);
        return query.list();
    }
    @Override
    public Line lineIdDao(String lineId) {
        Line line=getSession().get(Line.class,lineId);
        return line;
    }
    @Override
    public Picture imagesIdDao(int pictureId) {
        Picture picture=getSession().get(Picture.class,pictureId);
        return picture;
    }
}
