package com.hgkj.model.dao;

import com.hgkj.model.entity.Linetype;


import java.util.List;

public interface LineTypeDao {
    public List<Linetype> lineTypeAllDao();
    public boolean lineTypeAddDao(String lineTypeId,String typeName,String icon);
    public boolean lineTypeDeleteDao(String lineTypeId);
    public Linetype lineTypeIdDao(String lineTypeId);
    public boolean lineTypeUpdateDao(String lineTypeId,String typeName,String icon);
}
