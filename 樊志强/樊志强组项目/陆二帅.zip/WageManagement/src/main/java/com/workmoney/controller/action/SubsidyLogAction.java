package com.workmoney.controller.action;

import com.workmoney.model.entity.Staff;
import com.workmoney.model.entity.StaffFuBen;
import com.workmoney.model.entity.Subsidy;
import com.workmoney.model.entity.SubsidyLog;
import com.workmoney.model.service.EmployeeService;
import com.workmoney.model.service.StaffService;
import com.workmoney.model.service.SubsidyLogService;
import org.apache.struts2.ServletActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import javax.servlet.http.HttpSession;
import java.util.List;

/**
 * user@Bright Rain .
 * 2019/6/27.
 */

@ParentPackage("struts-default")
@Namespace("/")
@Controller
public class SubsidyLogAction {

    @Autowired
    private SubsidyLogService service;

    @Autowired
    private StaffService staffService;

    @Autowired
    private EmployeeService employeeService;

    private SubsidyLog subsidyLog;

    private StaffFuBen staffFuBen;

    private String name;

    @Action(value = "/serchNameAllowAction",results = {@Result(name = "success",type = "redirect",location = "html/allowanceAdd.jsp")})
    public String serchNameAllowAction(){
        HttpSession session = ServletActionContext.getRequest().getSession();

        List<SubsidyLog> logList = service.serchNameAllowAction(name);

        session.setAttribute("logList",logList);
        return "success";
    }


    @Action(value = "/delAllowanceById",results = {@Result(name = "success",type = "redirectAction",location = "getAllSubsidyLog")})
    public String delAllowanceById(){
        service.delAllowanceById(subsidyLog);
        return "success";
    }

    /**
     * 添加补助
     * @return
     */
    @Action(value = "/addEmpAllowanceAction",results = {@Result(name = "success",type = "redirectAction",location = "getAllSubsidyLog")})
    public String addEmpAllowanceAction(){
        service.addEmpAllowanceService(subsidyLog);
        return "success";
    }

    /**
     * 去往补助页面
     * @return
     */
    @Action(value = "/toAddEmpBuAction",results = {@Result(name = "success",type = "redirect",location = "html/allowanceEmpAdd.jsp")})
    public String toAddEmpBuAction(){
        HttpSession session = ServletActionContext.getRequest().getSession();
        StaffFuBen fuBen = employeeService.getEmpByIdService(staffFuBen);
        //补助类别放入 subsidyTypeList
       List<Subsidy> subsidyTypeList =   service.getAllSubsidyService();
        session.setAttribute("fuBen",fuBen);
        session.setAttribute("subsidyTypeList",subsidyTypeList);
        return "success";
    }

    /**
     * 查询所有员工
     * @return
     */
    @Action(value = "/goAllowanceEmpListAction",results = {@Result(name = "success",type = "redirect",location = "html/allowanceEmpList.jsp")})
    public String goAllowanceEmpListAction(){
        HttpSession session = ServletActionContext.getRequest().getSession();
        List<Staff> staffList = staffService.getStaffListSercharService();
        session.setAttribute("staffList",staffList);
        return "success";
    }


    /**
     * 获取所有补助信息
     * @return
     */
    @Action(value = "/getAllSubsidyLog",results = {@Result(name = "success",type = "redirect",location = "html/allowanceAdd.jsp")})
    public String getAllSubsidyLog(){

        HttpSession session = ServletActionContext.getRequest().getSession();

        List<SubsidyLog> logList = service.getAllSubsidyLogService();

        session.setAttribute("logList",logList);

        return "success";
    }

    public StaffFuBen getStaffFuBen() {
        return staffFuBen;
    }

    public void setStaffFuBen(StaffFuBen staffFuBen) {
        this.staffFuBen = staffFuBen;
    }

    public SubsidyLog getSubsidyLog() {
        return subsidyLog;
    }

    public void setSubsidyLog(SubsidyLog subsidyLog) {
        this.subsidyLog = subsidyLog;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
