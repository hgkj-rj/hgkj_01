package com.xl.model.dao.impl;

import com.xl.model.dao.ManagDao;
import com.xl.model.entity.Manag;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ManagDaoImpl implements ManagDao {
    @Override
    public boolean managLoginDao(Manag manag) {
        boolean flag=false;
        Connection connection = DBManager.getConnection();
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        String sql = "select count(*) from manag where managName=? and managPwd=?";
        try {
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1,manag.getManagName());
            preparedStatement.setString(2,manag.getManagPwd());
            resultSet = preparedStatement.executeQuery();
            if (resultSet.next()){
             
                    flag = true;
                
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            DBManager.closeAll(connection,preparedStatement,resultSet);
        }
        return flag;
    }



    @Override
    public List<Manag> allManagDao() {
        List<Manag> managList=new ArrayList<>();
        Connection connection=DBManager.getConnection();
        PreparedStatement preparedStatement=null;
        ResultSet resultSet=null;
        String sql="select* from manag";

        try {
            preparedStatement=connection.prepareStatement(sql);
            resultSet=preparedStatement.executeQuery();
            while(resultSet.next()){
                Manag manag=new Manag();
                manag.setManagId(resultSet.getInt("managId"));
                manag.setManagName(resultSet.getString("managName"));
                manag.setManagPwd(resultSet.getString("managPwd"));
                managList.add(manag);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBManager.closeAll(connection,preparedStatement,resultSet);
        }
        return managList;
    }
}
