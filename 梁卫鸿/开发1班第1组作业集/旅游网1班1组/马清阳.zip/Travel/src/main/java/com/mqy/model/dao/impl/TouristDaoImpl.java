package com.mqy.model.dao.impl;

import com.mqy.model.dao.TouristDao;
import com.mqy.model.entity.Tourist;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * @Author:马清阳
 * @Date:2019/6/26 22:50
 * InteliJ IDEA 1.8
 */
@Repository
@Transactional
public class TouristDaoImpl implements TouristDao {
    @Autowired
    private SessionFactory sessionFactory;

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }
    public Session getSession(){
        return sessionFactory.getCurrentSession();
    }

    /**
     * 查询所有游客信息
     * @return
     */
    @Override
    public List<Tourist> allTouristDao() {
        Query query=getSession().createQuery("from Tourist");
        return query.list();
    }

    /**
     * 添加游客信息
     * @param tourist
     * @return
     */
    @Override
    public boolean addTouristDao(Tourist tourist) {
        boolean result=false;
        try {
            this.sessionFactory.getCurrentSession().save(tourist);
            result=true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

    /**
     * 删除游客信息
     * @param touristId
     * @return
     */
    @Override
    public boolean deleteTouristDao(String touristId) {
        boolean result=false;
        Tourist tourist=getSession().get(Tourist.class,touristId);
        try {
            this.sessionFactory.getCurrentSession().delete(tourist);
            result=true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

    /**
     * 修改游客信息
     * @param tourist
     * @return
     */
    @Override
    public boolean updateTouristDao(Tourist tourist) {
        boolean result=false;
        try {
            this.sessionFactory.getCurrentSession().update(tourist);
            result=true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

    /**
     * 获取游客对象信息
     * @param touristId
     * @return
     */
    @Override
    public Tourist getTouristDao(String touristId) {
        Tourist tourist=null;
        try {
            tourist=(Tourist) this.sessionFactory.getCurrentSession().get
                    (Tourist.class,touristId);
        }catch (Exception e){
            e.printStackTrace();
        }
        return tourist;
    }
}
