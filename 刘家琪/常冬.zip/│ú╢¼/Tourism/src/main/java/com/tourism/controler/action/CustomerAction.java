package com.tourism.controler.action;

import com.tourism.model.entity.Customer;
import com.tourism.model.service.CustomerService;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

@Controller
@Namespace("/")
@ParentPackage("struts-default")

public class CustomerAction {
    @Autowired
    private CustomerService customerService;
    private Customer customer;

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public CustomerService getCustomerService(){
        return customerService;
    }
    public void setCustomerService(CustomerService customerService){
        this.customerService=customerService;
    }

 @Action(value = "qtlogin",results = {@Result(name = "login",type = "redirect",location = "../qt/index.jsp"),
         @Result(name = "loginerror",type = "redirect",location = "../qt/login.jsp")})
    public String qtLogin(){
        customer=customerService.loginService(customer);
        if (customer!=null){
            return "login";
        }else {
            return "loginerror";
        }
 }
    @Action(value = "htlogin",results = {@Result(name = "login",type = "redirect",location = "../ht/htindex.jsp"),
            @Result(name = "loginerror",type = "redirect",location = "../ht/adminLogin.jsp")})
    public String htLogin() {
        customer = customerService.loginService(customer);
        if (customer != null) {
            if (customer.getType() == 1) {
                return "login";
            } else {
                return "loginerror";
            }
        } else {
            return "loginerror";
        }



    }
    @Action(value = "addCustomer", results = {@Result(name = "add", type = "redirect", location = "../qt/login.jsp"),
            @Result(name = "error", type = "redirect", location = "../qt/regist.jsp")})
    public String addCustomer () {
        boolean flag=customerService.addCustomerService(customer);
        if (flag){
            return "add";
        }
        return "error";
    }
}
