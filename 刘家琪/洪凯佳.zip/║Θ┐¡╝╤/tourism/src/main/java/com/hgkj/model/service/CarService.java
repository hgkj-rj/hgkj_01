package com.hgkj.model.service;

import com.hgkj.model.entity.Car;

import java.util.List;

public interface CarService {
    public List<Car> allCarService();
    public boolean addCarService(Car car);
    public boolean deleteCarService(Car car);
    public boolean updateCarService(Car car);
    public Car getCarByIdService(String carId);
}
