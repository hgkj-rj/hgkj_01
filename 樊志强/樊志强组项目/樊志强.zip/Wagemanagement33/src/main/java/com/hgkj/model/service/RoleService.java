package com.hgkj.model.service;

import com.hgkj.model.entity.Role;

import java.util.List;

public interface RoleService {
    //查询所有角色类别
    public List<Role> allroleService();
    //添加角色类别
    public boolean insertroleService(Role role);
    //删除角色类别
    public boolean deleteroleService(int id);
    //修改角色类别
    public boolean updateroleService(Role role);
    //根据Id获取角色信息
    public Role getroleByIdService(int id);
}
