package com.xl.model.dao;

import com.xl.model.entity.Department;
import com.xl.model.entity.Employee;

import java.util.List;

public interface EmployeeDao {
    public int EmployeeDao(int pageSize);
    public List<Employee>allEmployeeDao(int pageIndex,int pageSize);
    public boolean addEmployeeDao(Employee employee);
    public boolean deleteEmployeeDao(int employeeId);
    public boolean updateEmployeeDao(Employee employee);
}
