package com.hgkj.model.service;

import com.hgkj.model.entity.Customer;

public interface CusregisterService {
    public boolean insertcusService(Customer customer);
    public boolean logincusService(Customer customer);

}
