package com.hgkj.model.dao;

import com.hgkj.model.entity.Line;

import java.util.List;

public interface LineDao {
    public boolean insertLineDao(Line line);
    public List<Line> allLineDao();
    public boolean delLineDao(String lineId);
    public boolean updLineDao(Line line);
    public Line lineByIdDao(String lineId);
    public Line teamByIdDao(String lineId);
    public boolean updTeamDao(Line line);
    public Line SetTeamByIdDao(String lineId);
    public boolean setTeamMsgDao(Line line);

}
