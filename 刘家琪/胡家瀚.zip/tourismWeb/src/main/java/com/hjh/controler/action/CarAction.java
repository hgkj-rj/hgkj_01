package com.hjh.controler.action;

import com.hjh.model.entity.Car;
import com.hjh.model.service.CarService;
import com.opensymphony.xwork2.ActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import java.util.List;

@Controller
@Namespace("/")
@ParentPackage("struts-default")
public class CarAction {
@Autowired
private CarService carService;
private Car car;

    public CarService getCarService() {
        return carService;
    }

    public void setCarService(CarService carService) {
        this.carService = carService;
    }

    public Car getCar() {
        return car;
    }

    public void setCar(Car car) {
        this.car = car;
    }
    @Action(value = "AllCar",results = {@Result(name = "all",type = "redirect",location = "/qt/cart.jsp")})
    public String AllCar(){
        List<Car> carList = carService.AllCar();
        ActionContext.getContext().getSession().put("carList",carList);
        return "all";
    }
}
