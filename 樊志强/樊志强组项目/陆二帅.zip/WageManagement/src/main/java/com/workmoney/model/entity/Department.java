package com.workmoney.model.entity;

import java.util.Objects;

/**
 * user@Bright Rain .
 * 2019/6/21.
 */
public class Department {
    private int depId;
    private String depName;

    public int getDepId() {
        return depId;
    }

    public void setDepId(int depId) {
        this.depId = depId;
    }

    public String getDepName() {
        return depName;
    }

    public void setDepName(String depName) {
        this.depName = depName;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Department that = (Department) o;
        return depId == that.depId &&
                Objects.equals(depName, that.depName);
    }

    @Override
    public int hashCode() {
        return Objects.hash(depId, depName);
    }
}
