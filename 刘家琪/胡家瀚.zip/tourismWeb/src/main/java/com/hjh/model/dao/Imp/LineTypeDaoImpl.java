package com.hjh.model.dao.Imp;

import com.hjh.model.dao.LineTypeDao;
import com.hjh.model.entity.Linetype;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
@Repository
@Transactional
public class LineTypeDaoImpl implements LineTypeDao {

    @Autowired
    private SessionFactory sessionFactory;

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    public SessionFactory getSessionFactory() {
        return sessionFactory;
    }

    public Session getSession(){
        return sessionFactory.getCurrentSession();
    }
    @Override
    public List<Linetype> AllLineTypeDao() {
        String hql = "from Linetype";
        List<Linetype> linetypeList = getSession().createQuery(hql).list();
        return linetypeList;
    }

    @Override
    public boolean AddLine(Linetype linetype) {
        boolean flag = false;
        try {
            getSession().save(linetype);
            flag = true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return flag;
    }

    @Override
    public boolean UpingLineType(Linetype linetype) {
        boolean flag = false;
        try {
            getSession().update(linetype);
            flag = true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return flag;
    }

    @Override
    public Linetype GetLineType(String lineTypeid) {
        String hql = "from Linetype where lineTypeid=?";
        Linetype linetype = (Linetype) getSession().createQuery(hql).setParameter(0,lineTypeid).list().get(0);
        return linetype;
    }

    @Override
    public String GetRan() {
        String randomcode = "";
        String model = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        char[] m = model.toCharArray();
        for (int j = 0; j < 6; j++) {
            char c = m[(int) (Math.random() * 36)];
            if (randomcode.contains(String.valueOf(c))) {
                j--;
                continue;
            }
            randomcode = randomcode + c;
        }
        return randomcode;
    }
}
