package com.hgkj.model.dao.impl;

import com.hgkj.model.dao.StaffUserdao;
import com.hgkj.model.entity.Staff;

import org.hibernate.Session;
import org.hibernate.SessionFactory;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
@Transactional
public class StaffUserdaoimpl implements StaffUserdao {

    @Autowired
    private SessionFactory sessionFactory;

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }
    public Session getSession(){
        return sessionFactory.getCurrentSession();
    }

    @Override
    public List<Staff> loginUserDao(Staff staff) {
        String hql="from Staff where staffName=? and staffPwd=?";
        System.out.println("staffName="+staff.getStaffName());
        System.out.println("staffPwd="+staff.getStaffPwd());
        List<Staff> staff1 = getSession().createQuery(hql).setParameter(0,staff.getStaffName()).setParameter(1,staff.getStaffPwd()).list();
        return staff1;
    }

    @Override
    public boolean updateResetpassdao(Staff staff) {
       getSession().createQuery("update Staff set staffPwd=:pwd where staffId=:staffid").setParameter("pwd",staff.getStaffPwd()).setParameter("staffid",staff.getStaffId()).executeUpdate();
        return true;
    }

}
