package com.hgkj.model.dao;

import com.hgkj.model.entity.Staff;

import java.util.List;

public interface StaffDao {
        //登录验证
    public Staff loginStaffDao(Staff staff);
        //修改密码
    public boolean updPwdStaffDao(Staff staff);
    //查询所有信息
    public List<Staff> allstaffDao();
    //添加员工
    public boolean insertstaffDao(Staff staff);
    //删除员工
    public boolean deletestaffDao(int id);
    //修改员工信息
    public boolean updatestaffDao(Staff staff);
    //根据Id获取员工信息
    public Staff getstaffByIdDao(int id);
}
