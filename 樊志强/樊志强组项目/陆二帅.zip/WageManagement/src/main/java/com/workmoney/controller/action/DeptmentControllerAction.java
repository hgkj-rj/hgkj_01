package com.workmoney.controller.action;

import com.workmoney.model.entity.Department;
import com.workmoney.model.service.DepartmentService;
import org.apache.struts2.ServletActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import javax.servlet.http.HttpSession;
import java.util.List;

/**
 * user@Bright Rain .
 * 2019/6/29.
 */
@ParentPackage("struts-default")
@Namespace("/")
@Controller
public class DeptmentControllerAction {

    @Autowired
    private DepartmentService service;

    private Department department;


    @Action(value = "/addDeptAction",results = {@Result(name = "success",type = "redirectAction",location = "getAllDeptAction")})
    public String addDeptAction(){
        service.addDepartmentService(department);
        return "success";
    }

    /**
     * 删除
     * @return
     */
    @Action(value = "/delDeptByIdAction",results = {@Result(name = "success",type = "redirectAction",location = "getAllDeptAction")})
    public String delDeptByIdAction(){
        service.delDepartmentService(department);
        return "success";
    }


    /**
     * 修改
     * @return
     */
    @Action(value = "/editdeptAction",results = {@Result(name = "success",type = "redirectAction",location = "getAllDeptAction")})
    public String editdeptAction(){
        service.updateDepartment(department);
        return "success";
    }



    /**
     * 去往修改页面
     * @return
     */
    @Action(value = "/goEditDeptByIdAction",results = {@Result(name = "success",type = "redirect",location = "html/DeptEdit.jsp")})
    public String goEditDeptByIdAction(){
        HttpSession session = ServletActionContext.getRequest().getSession();

        Department departmentService = service.getDepartmentService(department);

        session.setAttribute("dept",departmentService);
        return "success";
    }

    /**
     * 获取所有部门
     * @return
     */
    @Action(value = "/getAllDeptAction",results = {@Result(name = "success",type = "redirect",location = "html/DeptList.jsp")})
    public String getAllDeptAction(){
        HttpSession session = ServletActionContext.getRequest().getSession();
        List<Department> departmentList = service.getAllDepartmentService();
        session.setAttribute("departmentList",departmentList);

        return "success";
    }

    public Department getDepartment() {
        return department;
    }

    public void setDepartment(Department department) {
        this.department = department;
    }
}
