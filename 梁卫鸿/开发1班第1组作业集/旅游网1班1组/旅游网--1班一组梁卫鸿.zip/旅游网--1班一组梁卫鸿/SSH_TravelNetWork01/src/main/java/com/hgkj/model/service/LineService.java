package com.hgkj.model.service;

import com.hgkj.model.entity.Line;
import com.hgkj.model.entity.Picture;

import java.util.List;

public interface LineService {
    public List<Line> lineAllService();
    public List<Picture> imagesAllService();
    public boolean lineAddService(Line line);
    public Line lineIdService(String lineId);
}
