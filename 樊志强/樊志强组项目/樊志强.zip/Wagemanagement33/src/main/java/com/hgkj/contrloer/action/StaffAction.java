package com.hgkj.contrloer.action;

import com.hgkj.model.entity.*;
import com.hgkj.model.service.*;
import com.opensymphony.xwork2.ActionContext;
import org.apache.struts2.ServletActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import javax.naming.Name;
import java.util.List;

@Controller
@Namespace("/")
@ParentPackage("json-default")
public class StaffAction {
    @Autowired
    private StaffService staffService;
    @Autowired
    private RoleService roleService;
    @Autowired
    private DepartmentService departmentService;
    @Autowired
    private LevelService levelService;
    @Autowired
    private ShopService shopService;
    private String message;
    private Staff staff;
    private String queren;
    private int id;

    public String getQueren() {
        return queren;
    }

    public void setQueren(String queren) {
        this.queren = queren;
    }

    //    登录
    @Action(value = "login",results = {
            @Result(name = "login",type = "redirect",location = "main.jsp"),
            @Result(name = "nologin",type = "redirect",location = "login.jsp")
    })
    public String StraffLogin(){
        System.out.println(staff.getStaffId()+staff.getStaffPwd());
        Staff staff1 = staffService.loginStaffService(this.staff);
        if(staff1==null){
            return "nologin";
        }else{
            ActionContext.getContext().getSession().put("staffUser",staff1);
            ActionContext.getContext().getSession().put("staffId",staff1.getStaffId());
            return "login";
        }

    }


    @Action(value = "staffupd",results = @Result(name = "true",type = "redirect",location = "main.jsp"))
    public String staffupd(){
    staffService.updPwdStaffService(staff);
    return "true";
    }

    @Action(value = "update",results = {@Result(name = "update",type = "redirect",location = "/main.jsp"),@Result(name = "noupdate",type = "redirect",location = "../resetpass.jsp")})
    public String updatepassword(){
        if (staff.getStaffPwd().equals(queren)){
            return "update";
        }else {
            return "noupdate";
        }

    }
    @Action(value = "allstaff",results = {@Result(name = "all",type = "redirect",location = "html/empList.jsp")})
    public String allStaff(){
        List<Staff> staffList=staffService.allstaffService();
        ActionContext.getContext().getSession().put("staffList",staffList);
        return "all";
    }
    @Action(value = "insertstaff",results = {@Result(name = "insert",type = "redirectAction",location = "allstaff"),@Result(name = "noinsert",type = "redirect",location = "../empAdd.jsp")})
    public String insertStaff(){
        if (staffService.insertstaffService(staff)){
            return "insert";
        }else {
            return "noinsert";
        }

    }
    @Action(value = "deletestaff",results = {@Result(name = "delete",type = "json",params = {"root","delete"})})
    public String delete(){
       staffService.deletestaffService(id);
        return "delete";
    }
    @Action(value = "updatestaff",results = {@Result(name = "update",type = "redirectAction",location = "allstaff"),@Result(name = "noupdate",type = "redirect",location = "../emList.jsp")})
    public String update(){
        System.out.println(staff);
        if (staffService.updatestaffService(staff)){
            return "update";
        }else {
            return "noupdate";
        }

    }
    @Action(value = "getstaff",results = {@Result(name = "get",type = "redirect",location = "html/empUpdate.jsp")})
    public String getrewardmanage(){
        staff=staffService.getstaffByIdService(id);
        List<Role> roles=roleService.allroleService();
        List<Department> departments=departmentService.alldepartmentService();
        List<Shop> shops=shopService.allshopService();
        List<Level> levels=levelService.alllevelService();
        ActionContext.getContext().getSession().put("roles",roles);
        ActionContext.getContext().getSession().put("departments",departments);
        ActionContext.getContext().getSession().put("shops",shops);
        ActionContext.getContext().getSession().put("levels",levels);
        ActionContext.getContext().getSession().put("staffs",staff);
        return "get";
    }
@Action(value = "allinput",results = {@Result(name = "all",type = "redirect",location = "html/empAdd.jsp")})
    public String allinput(){
        List<Role> roles=roleService.allroleService();
        List<Department> departments=departmentService.alldepartmentService();
        List<Shop> shops=shopService.allshopService();
        List<Level> levels=levelService.alllevelService();
        ActionContext.getContext().getSession().put("roles",roles);
        ActionContext.getContext().getSession().put("departments",departments);
        ActionContext.getContext().getSession().put("shops",shops);
        ActionContext.getContext().getSession().put("levels",levels);
        return "all";
    }

    public StaffService getStaffService() {
        return staffService;
    }

    public RoleService getRoleService() {
        return roleService;
    }

    public void setRoleService(RoleService roleService) {
        this.roleService = roleService;
    }

    public DepartmentService getDepartmentService() {
        return departmentService;
    }

    public void setDepartmentService(DepartmentService departmentService) {
        this.departmentService = departmentService;
    }

    public LevelService getLevelService() {
        return levelService;
    }

    public void setLevelService(LevelService levelService) {
        this.levelService = levelService;
    }

    public ShopService getShopService() {
        return shopService;
    }

    public void setShopService(ShopService shopService) {
        this.shopService = shopService;
    }

    public void setStaffService(StaffService staffService) {
        this.staffService = staffService;
    }

    public Staff getStaff() {
        return staff;
    }

    public void setStaff(Staff staff) {
        this.staff = staff;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}
