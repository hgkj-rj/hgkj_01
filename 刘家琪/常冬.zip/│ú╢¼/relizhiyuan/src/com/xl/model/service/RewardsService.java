package com.xl.model.service;

import com.xl.model.entity.Rewards;

import java.util.List;

public interface RewardsService {
    public int RewardsService(int pageSize);
    public List<Rewards> allRewardsService(int pageIndex, int pageSize);
    public Rewards getRewardsByIdService(int cjId);
    public boolean addRewardsService(Rewards rewards);
    public boolean deleteRewardsService(int rewards);
    public boolean updateRewardsService(Rewards rewards);
}
