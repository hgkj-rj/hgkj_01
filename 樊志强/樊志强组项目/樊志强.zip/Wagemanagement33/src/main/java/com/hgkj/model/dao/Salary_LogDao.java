package com.hgkj.model.dao;

import com.hgkj.model.entity.AttendanceLog;
import com.hgkj.model.entity.SalaryLog;
import com.hgkj.model.entity.Staff;

import java.util.List;

public interface Salary_LogDao {


    public List<SalaryLog> allSalaryList();


    /**
     * 查询所有的工资记录表
     * 里面写了权限
     * 1 2 直查自己的 员工和店长
     * 3是管理员  查询所有
     * @param staff
     * @return
     */

    public List<SalaryLog> querySalaryDao(Staff staff);


    /**
     * 从slaryLog中获取AttendanceLog表的信息
     * 因为三个表中都有staffId所以直接可以调用AttendanceLog表
     * @param staffId
     * @return
     */
    public List SalaryLog_AttendanceLog(int staffId);

    /**
     * 根据姓名模糊查询2
     * 模糊查询  返回一个工资数据的对象
     * @return
     */
    public  List<SalaryLog> dimquery(String name);





    /**
     * 进行排序 下一页 下一页
     * @param index
     * @return
     */
    public List<SalaryLog> Salary_Next(int index);


    /**
     * 尾页
     * @param staff
     * @return
     */
    public List<SalaryLog> Salary_End(Staff staff);

    /**
     * 查询总页数
     * @return
     */
    public int Salary_Pages();

    public boolean addSalaryDao(SalaryLog salaryLog);

    public boolean updSalaryDao(SalaryLog salaryLog);

    public boolean delSalaryDao(SalaryLog salaryLog);
}
