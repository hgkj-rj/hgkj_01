package com.mqy.model.dao.impl;

import com.mqy.model.dao.CarDao;
import com.mqy.model.entity.Car;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * @Author:马清阳
 * @Date:2019/6/26 22:23
 * InteliJ IDEA 1.8
 */
@Repository
@Transactional
public class CarDaoImpl implements CarDao {
    @Autowired
    private SessionFactory sessionFactory;

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }
    public Session getSession(){
        return sessionFactory.getCurrentSession();
    }

    /**
     * 查询所有购物信息
     * @return
     */
    @Override
    public List<Car> carListDao() {
        Query query=getSession().createQuery("from Car");
        return query.list();
    }

    /**
     * 添加购物信息
     * @param car
     * @return
     */
    @Override
    public boolean addCarDao(Car car) {
        boolean result=false;
        try {
            this.sessionFactory.getCurrentSession().save(car);
            result=true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

    /**
     * 删除购物信息
     * @param carId
     * @return
     */
    @Override
    public boolean deleteCarDao(int carId) {
        boolean result=false;
        Car car=getSession().get(Car.class,carId);
        try {
            this.sessionFactory.getCurrentSession().delete(car);
            result=true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }
}
