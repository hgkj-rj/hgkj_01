package com.workmoney.model.service;

import com.workmoney.model.entity.StaffFuBen;

import java.util.List;

/**
 * user@Bright Rain .
 * 2019/6/26.
 */
public interface EmployeeService {

    void addEmployee(StaffFuBen staffFuBen);

    void delEmpService(StaffFuBen staffFuBen);

    StaffFuBen getEmpByIdService(StaffFuBen staffFuBen);

    void updateEmployeeById(StaffFuBen staffFuBen);

    List<StaffFuBen> getAllStaffFuBenService();

    void updateRoleByIdService(StaffFuBen staff);
}
