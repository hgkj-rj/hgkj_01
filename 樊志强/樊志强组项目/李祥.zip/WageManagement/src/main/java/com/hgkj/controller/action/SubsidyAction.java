package com.hgkj.controller.action;

import com.hgkj.model.entity.Subsidy;
import com.hgkj.model.service.SubsidyService;
import com.opensymphony.xwork2.ActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import java.lang.reflect.Type;
import java.util.List;

@Controller
@Namespace("/")
@ParentPackage("struts-default")
public class SubsidyAction {
    public int subsidyId;
    private Subsidy subsidy;

    @Autowired
    private SubsidyService subsidyService;

    public void setSubsidyService(SubsidyService subsidyService) {
        this.subsidyService = subsidyService;
    }
    @Action(value = "allSubsidy",results =
            {@Result(name = "all",type = "redirect",location = "html/bonusList.jsp")})
    public String allSubsidy(){
        List<Subsidy> subsidyList = subsidyService.allSubsidyService();
        ActionContext.getContext().getSession().put("subsidyList",subsidyList);
        return "all";
    }
    @Action(value = "updateSubsidy",results =
            {@Result(name = "all" ,type = "redirectAction",location = "allSubsidy")})
    public String updateSubsidy(){
        subsidyService.updateSubsidyService(subsidy);
        return "all";
    }

    @Action(value = "deleteSubsidy",results =
            {@Result(name = "all",type ="redirectAction" ,location ="allSubsidy" )})
    public String deleteSubsidy(){
        subsidyService.deleteSubsidyService(subsidyId);
        return "all";
    }

    @Action(value = "addSubsidy",results =
            {@Result(name ="all", type="redirectAction",location = "allSubsidy")})
    public String addSubsidy(){
        subsidyService.addSubsidyService(subsidy);
        return  "all";
    }

    @Action(value = "subsidy",results =
            {@Result(name = "all",type = "redirect",location = "html/bonusEdit.jsp")})
    public String subsidy(){
        Subsidy subsidy=subsidyService.subsiService(subsidyId);
        ActionContext.getContext().getSession().put("subsidy",subsidy);
        return  "all";
    }

    public Subsidy getSubsidy() {
        return subsidy;
    }

    public void setSubsidy(Subsidy subsidy) {
        this.subsidy = subsidy;
    }

    public int getSubsidyId() {
        return subsidyId;
    }

    public void setSubsidyId(int subsidyId) {
        this.subsidyId = subsidyId;
    }

}
