package com.tourism.model.dao;

import com.tourism.model.entity.Line;
import com.tourism.model.entity.Linetype;

import java.util.List;

public interface LineDao {
    public int gettotalpageDao(int pagesize,String time);
    public List<Line> allLineDao(int pageindex, int pagesize,String time);
    public List<Line> allLineDao();
    public List<Line> allTuanGouLineDao();
    public List<Line> toIndexLineDao(String lineTypeId);
    public List<Line> yiLineDao();
    public List<Line> erLineDao();
    public List<Line> duoLineDao();
    public boolean addLineDao(Line line);
    public boolean updateLineDao(Line line);
    public Line getLineByIdDao(String lineId);
}
