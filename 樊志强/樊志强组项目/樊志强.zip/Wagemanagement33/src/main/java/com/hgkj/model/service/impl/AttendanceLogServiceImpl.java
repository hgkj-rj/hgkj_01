package com.hgkj.model.service.impl;

import com.hgkj.model.dao.AttendanceLogDao;
import com.hgkj.model.entity.Attendance;
import com.hgkj.model.entity.AttendanceLog;
import com.hgkj.model.service.AttendanceLogService;
import com.hgkj.model.service.AttendanceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class AttendanceLogServiceImpl implements AttendanceLogService {
    @Autowired
    private AttendanceLogDao attendanceLogDao;

    public AttendanceLogDao getAttendanceLogDao() {
        return attendanceLogDao;
    }

    public void setAttendanceLogDao(AttendanceLogDao attendanceLogDao) {
        this.attendanceLogDao = attendanceLogDao;
    }


    @Override
    public List<AttendanceLog> allAttendanceLogService() {
        return attendanceLogDao.allAttendanceLogDao();
    }

    @Override
    public boolean insertAttendanceLogService(AttendanceLog attendanceLog) {
        return attendanceLogDao.insertAttendanceLogDao(attendanceLog);
    }

    @Override
    public boolean deleteAttendanceLogService(int id) {
        return attendanceLogDao.deleteAttendanceLogDao(id);
    }

    @Override
    public boolean updateAttendanceLogService(AttendanceLog attendanceLog) {
        return attendanceLogDao.updateAttendanceLogDao(attendanceLog);
    }

    @Override
    public AttendanceLog getAttendanceLogByIdService(int id) {
        return attendanceLogDao.getAttendanceLogByIdDao(id);
    }
}
