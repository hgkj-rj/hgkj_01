package com.hgkj.contrloer.action;

import com.hgkj.model.entity.Role;
import com.hgkj.model.service.RoleService;
import com.opensymphony.xwork2.ActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import java.util.List;

@Controller
@Namespace("/")
@ParentPackage("json-default")
public class RoleAction {
    @Autowired
    private RoleService roleService;
    private Role role;
    private int id;
    @Action(value = "allrole",results = {@Result(name = "all",type = "redirect",location = "html/roleList.jsp")})
    public String allreward(){
        List<Role> roleList=roleService.allroleService();
        ActionContext.getContext().getSession().put("roleList",roleList);
        return "all";
    }
    @Action(value = "insertrole",results = {@Result(name = "insert",type = "redirectAction",location = "allrole")})
    public String insert(){
        if(roleService.insertroleService(role)){
            return "insert";
        }else {
            return "noinsert";
        }

    }
    @Action(value = "deleterole",results = {@Result(name = "delete",type = "json",params = {"root","delete"})})
    public String delete(){
        roleService.deleteroleService(id);
        return "delete";
    }
    @Action(value = "updaterole",results = {@Result(name = "update",type = "redirectAction",location = "allrole"),@Result(name = "noupdate",type = "redirect",location = "../roleList.jsp")})
    public String update(){
        if (roleService.updateroleService(role)){
            return "update";
        }else {
            return "noupdate";
        }

    }
    @Action(value = "getrole",results = {@Result(name = "get",type = "redirect",location = "html/roleupdate.jsp")})
    public String getrewardmanage(){
        role=roleService.getroleByIdService(id);
        ActionContext.getContext().getSession().put("role",role);
        return "get";
    }

    public RoleService getRoleService() {
        return roleService;
    }

    public void setRoleService(RoleService roleService) {
        this.roleService = roleService;
    }

    public Role getRole() {
        return role;
    }

    public void setRole(Role role) {
        this.role = role;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}

