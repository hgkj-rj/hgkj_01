package com.workmoney.model.dao.impl;

import com.workmoney.model.dao.DepartmentDao;
import com.workmoney.model.entity.Department;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * user@Bright Rain .
 * 2019/6/29.
 */
@Repository
@Transactional
public class DepartmentDaoImpl implements DepartmentDao {

    @Autowired
    private SessionFactory sessionFactory;

    @Override
    public List<Department> getAllDepartmentDao() {
        Session session = sessionFactory.getCurrentSession();
        String hql = "from Department ";
        List<Department> departmentList = session.createQuery(hql, Department.class).list();
        return departmentList;
    }

    @Override
    public void addDepartmentDao(Department department) {
        Session session = sessionFactory.getCurrentSession();
       session.save(department);
    }

    @Override
    public void delDepartmentDao(Department department) {
        Session session = sessionFactory.getCurrentSession();
        session.delete(department);
    }

    @Override
    public Department getDepartmentDao(Department department) {
        Session session = sessionFactory.getCurrentSession();
        Department department1 = session.get(Department.class, department.getDepId());
        return department1;
    }

    @Override
    public void updateDepartmentDao(Department department) {
        Session session = sessionFactory.getCurrentSession();
        session.update(department);
    }

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }
}
