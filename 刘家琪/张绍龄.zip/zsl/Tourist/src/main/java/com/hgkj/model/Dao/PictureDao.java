package com.hgkj.model.Dao;

import com.hgkj.model.entity.Picture;

import java.util.List;

public interface PictureDao {
    public  List<Picture>allPictureDao();
    public List<Picture> findPictureDao(String lineId);
    public List<Picture> findlineDao(String lineTypeId);
    public boolean  addPictureDao(Picture picture);
    public boolean  updatePictureDao(Picture picture);

}
