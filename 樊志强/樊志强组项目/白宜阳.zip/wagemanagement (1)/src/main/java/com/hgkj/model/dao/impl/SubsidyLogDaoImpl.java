package com.hgkj.model.dao.impl;

import com.hgkj.model.dao.SubsidyLogDao;
import com.hgkj.model.entity.Shop;
import com.hgkj.model.entity.SubsidyLog;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
@Transactional
public class SubsidyLogDaoImpl implements SubsidyLogDao {
    @Autowired
    private SessionFactory sessionFactory;
    private Transaction transaction;

    public Transaction getTransaction() {
        return transaction;
    }

    public void setTransaction(Transaction transaction) {
        this.transaction = transaction;
    }

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }
    public Session getSession(){
        return sessionFactory.getCurrentSession();
    }

    @Override
    public List<SubsidyLog> allSubsidyLogDao() {
        Query query=getSession().createQuery("from SubsidyLog");
        return query.list();
    }

    @Override
    public boolean addSubsidyLogDao(SubsidyLog subsidyLog) {
        boolean flag=false;
        try {
            getSession().save(subsidyLog);
            flag=true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return flag;
    }

    @Override
    public boolean updateSubsidyLogDao(SubsidyLog subsidyLog) {
        boolean flag=false;
        try {
            getSession().update(subsidyLog);
            flag=true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return flag;
    }

    @Override
    public boolean deleteSubsidyLogDao(int stblogId) {
        boolean flag=false;
        SubsidyLog subsidyLog=new SubsidyLog();
        subsidyLog.setStblogId(stblogId);
        try {
            getSession().delete(subsidyLog);
            flag=true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return flag;
    }

    @Override
    public SubsidyLog getByIdSubsidyLogDao(int stblogId) {
        SubsidyLog subsidyLog=getSession().get(SubsidyLog.class,stblogId);
        return subsidyLog;
    }
}
