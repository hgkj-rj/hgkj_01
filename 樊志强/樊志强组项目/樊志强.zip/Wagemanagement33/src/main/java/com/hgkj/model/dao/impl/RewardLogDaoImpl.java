package com.hgkj.model.dao.impl;

import com.hgkj.model.dao.RewardDao;
import com.hgkj.model.dao.RewardLogDao;
import com.hgkj.model.entity.Attendance;
import com.hgkj.model.entity.Reward;
import com.hgkj.model.entity.RewardLog;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
@Transactional
public class RewardLogDaoImpl implements RewardLogDao {
    @Autowired
    private SessionFactory sessionFactory;
    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }
    public Session session(){
        return sessionFactory.getCurrentSession();
    }

    @Override
    public List<RewardLog> allrewardLogDao() {
        String hql="from RewardLog ";
        List<RewardLog> list=session().createQuery(hql).list();
        return list;
    }

    @Override
    public boolean insertrewardLogDao(RewardLog rewardLog) {
        boolean b=false;
        session().save(rewardLog);
        b=true;
        return b;
    }

    @Override
    public boolean deleterewardLogDao(int id) {
        boolean a=false;
        String hql="delete RewardLog where rewlogId=?";
        int b=session().createQuery(hql).setParameter(0,id).executeUpdate();
        if (b!=0){
            a=true;
        }
        return a;
    }

    @Override
    public boolean updaterewardLogDao(RewardLog rewardLog) {
        boolean a=false;
        String hql="update RewardLog set staff.staffId=?,reward.rewId=?,rewPrice=?,rewlogTime=? where rewlogId=?";
        int b=session().createQuery(hql).setParameter(0,rewardLog.getStaff().getStaffId()).setParameter(1,rewardLog.getReward().getRewId()).setParameter(2,rewardLog.getRewPrice()).setParameter(3,rewardLog.getRewlogTime()).setParameter(4,rewardLog.getRewlogId()).executeUpdate();
        if (b!=0){
            a=true;
        }
        return a;
    }

    @Override
    public RewardLog getrewardLogByIdDao(int id) {
        String hql="from RewardLog where rewlogId=?";
        RewardLog rewardLog=(RewardLog) session().createQuery(hql).setParameter(0,id).uniqueResult();
        return rewardLog;
    }
}
