package com.xl.model.dao;

import com.xl.model.entity.Manag;

import java.util.List;

public interface ManagDao {
    public boolean managLoginDao(Manag manag);
    public List<Manag>allManagDao();
}
