package com.tourism.model.service.Impl;

import com.tourism.model.dao.LineDao;

import com.tourism.model.entity.Line;
import com.tourism.model.entity.Linetype;
import com.tourism.model.service.LineService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class LineServiceImpl implements LineService {
@Autowired
private LineDao lineDao;
    @Override
    public boolean addLineService(Line line) {
        return lineDao.addLineDao(line);
    }

    @Override
    public boolean updateLineService(Line line) {
        return lineDao.updateLineDao(line);
    }

    @Override
    public List<Line> toIndexLineService() {
        return lineDao.allLineDao();
    }

    @Override
    public Line getLineByIdService(String lineId) {
        return lineDao.getLineByIdDao(lineId);
    }
}
