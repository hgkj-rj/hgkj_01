/*
 Navicat Premium Data Transfer

 Source Server         : MySQL
 Source Server Type    : MySQL
 Source Server Version : 50720
 Source Host           : localhost:3306
 Source Schema         : travel

 Target Server Type    : MySQL
 Target Server Version : 50720
 File Encoding         : 65001

 Date: 08/07/2019 09:55:37
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for car
-- ----------------------------
DROP TABLE IF EXISTS `car`;
CREATE TABLE `car`  (
  `carID` int(255) NOT NULL AUTO_INCREMENT,
  `customerID` int(255) NOT NULL,
  `lineID` varchar(12) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `time` datetime(0) NOT NULL,
  PRIMARY KEY (`carID`) USING BTREE,
  INDEX `FKc6b6alxff72xk3ymm0uifq3id`(`lineID`) USING BTREE,
  INDEX `FKno1l94875exi2qlwvkxklg2o5`(`customerID`) USING BTREE,
  CONSTRAINT `FK_Car_Customer` FOREIGN KEY (`customerID`) REFERENCES `customer` (`customerID`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `FKc6b6alxff72xk3ymm0uifq3id` FOREIGN KEY (`lineID`) REFERENCES `line` (`lineID`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `FKno1l94875exi2qlwvkxklg2o5` FOREIGN KEY (`customerID`) REFERENCES `customer` (`customerID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 18 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of car
-- ----------------------------
INSERT INTO `car` VALUES (5, 6, 'l1002', '2019-07-21 16:55:02');
INSERT INTO `car` VALUES (6, 1, 'l1001', '2019-07-27 18:46:58');
INSERT INTO `car` VALUES (7, 4, 'l1003', '2019-07-28 18:47:14');
INSERT INTO `car` VALUES (8, 7, 'l1002', '2019-07-28 18:47:29');
INSERT INTO `car` VALUES (14, 5, 'l1001', '2019-07-04 15:15:03');
INSERT INTO `car` VALUES (15, 5, 'l1001', '2019-07-04 15:35:15');

SET FOREIGN_KEY_CHECKS = 1;
