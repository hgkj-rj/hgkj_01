package com.hgkj.model.dao;

import com.hgkj.model.entity.Customer;

public interface CusregisterDao {
    public boolean insertcusDao(Customer customer);
    public boolean logincusDao(Customer customer);
}
