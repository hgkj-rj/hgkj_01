package com.hgkj.model.dao.impl;

import com.hgkj.model.dao.StaffDao;
import com.hgkj.model.entity.Attendance;
import com.hgkj.model.entity.Staff;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
@Transactional
public class StaffDaoImpl implements StaffDao {
    @Autowired
    private SessionFactory sessionFactory;

    @Override
    public Staff loginStaffDao(Staff staff) {
        String hql="from Staff where staffName=? and staffPwd=?";
        Staff staff1=(Staff) getSession().createQuery(hql).setParameter(0,staff.getStaffName()).setParameter(1,staff.getStaffPwd()).uniqueResult();
        return staff1;
    }

    @Override
    public boolean updPwdStaffDao(Staff staff) {
        String hql="UPDATE Staff set staffPwd=? WHERE staffId=?";
        Query query = getSession().createQuery(hql);
        query.setParameter(0,staff.getStaffPwd()).setParameter(1,staff.getStaffId());
        query.executeUpdate();
        return true;
    }

    @Override
    public List<Staff> allstaffDao() {
        String hql="from Staff ";
        List<Staff> list=getSession().createQuery(hql).list();
        return list;
    }

    @Override
    public boolean insertstaffDao(Staff staff) {
        getSession().save(staff);
        return true;
    }

    @Override
    public boolean deletestaffDao(int id) {
        boolean a=false;
        String hql="delete Staff where staffId=?";
        int b=getSession().createQuery(hql).setParameter(0,id).executeUpdate();
        if (b!=0){
            a=true;
        }
        return a;
    }

    @Override
    public boolean updatestaffDao(Staff staff) {
        boolean a=false;
        String hql="update Staff set staffName=?,staffPwd=?,staffAddress=?,staffEmail=?,staffSex=?,staffState=?,staffTel=?,level.levelId=?,role.roleId=?,shop.shopId=?,department.depId=?where staffId=?";
        int b=getSession().createQuery(hql).setParameter(0,staff.getStaffName()).setParameter(1,staff.getStaffPwd()).setParameter(2,staff.getStaffAddress()).setParameter(3,staff.getStaffEmail())
                .setParameter(4,staff.getStaffSex()).setParameter(5,staff.getStaffState()).setParameter(6,staff.getStaffTel()).setParameter(7,staff.getLevel().getLevelId()).setParameter(8,staff.getRole().getRoleId()).setParameter(9,staff.getShop().getShopId()).setParameter(10,staff.getDepartment().getDepId()).setParameter(11,staff.getStaffId()).executeUpdate();
        if (b!=0){
            a=true;
        }
        return a;
    }

    @Override
    public Staff getstaffByIdDao(int id) {
        String hql="from Staff where staffId=?";
        Staff staff=(Staff) getSession().createQuery(hql).setParameter(0,id).uniqueResult();
        return staff;
    }


    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    public Session getSession(){
        return sessionFactory.getCurrentSession();
    }

}
