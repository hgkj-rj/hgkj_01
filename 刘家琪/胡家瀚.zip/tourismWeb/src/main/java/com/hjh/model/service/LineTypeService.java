package com.hjh.model.service;

import com.hjh.model.entity.Linetype;

import java.util.List;

public interface LineTypeService {
    public List<Linetype> AllLineTypeDao();
    public boolean AddLine(Linetype linetype);
    public boolean UpingLineType(Linetype linetype);
    public Linetype GetLineType(String lineTypeid);
    public String GetRan();
}
