package com.mqy.model.dao.impl;

import com.mqy.model.dao.LineTypeDao;
import com.mqy.model.entity.Linetype;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
@Repository
@Transactional
public class LineTypeDaoImpl implements LineTypeDao {
    @Autowired
    private SessionFactory sessionFactory;

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }
    public Session getSession(){
        return sessionFactory.getCurrentSession();
    }

    /**
     * ��ѯ������·����
     * @return
     */
    @Override
    public List<Linetype> allLineTypeDao() {
        Query query =getSession().createQuery("from Linetype");
        return query.list();
    }

    /**
     * ������·����
     * @param linetype
     * @return
     */
    @Override
    public void addLineTypeDao(Linetype linetype) {
        getSession().save(linetype);
    }

    /**
     * ɾ����·����
     * @param lineTypeId
     * @return
     */
    @Override
    public void deleteLineTypeDao(String lineTypeId) {
        getSession().delete(getSession().get(Linetype.class,lineTypeId));
    }

    /**
     * �޸���·����
     * @param linetype
     * @return
     */
    @Override
    public void updateLineTypeDao(Linetype linetype) {
        getSession().update(linetype);
    }

    /**
     * ��ȡ��·���Ͷ���
     * @param lineTypeId
     * @return
     */
    @Override
    public Linetype getLineTypeDao(String lineTypeId) {
        Linetype linetype=getSession().get(Linetype.class,lineTypeId);
        return linetype;
    }
}
