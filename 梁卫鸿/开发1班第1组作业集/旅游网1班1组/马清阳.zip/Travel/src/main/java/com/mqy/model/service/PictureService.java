package com.mqy.model.service;


import com.mqy.model.entity.Picture;

import java.util.List;

public interface PictureService {
    /**
     * 查询所有图片
     * @return
     */
    public List<Picture> allPictureService();

    /**
     * 添加图片
     * @param picture
     * @return
     */
    public void addPictureService(Picture picture);

    /**
     * 删除图片
     * @param pictureId
     * @return
     */
    public void deletePictureService(int pictureId);

    /**
     * 修改图片
     * @param picture
     */
    public void updatePictureService(Picture picture);

    /***
     * 获取图片对象
     * @param pictureId
     * @return
     */
    public Picture getPictureService(int pictureId);
}
