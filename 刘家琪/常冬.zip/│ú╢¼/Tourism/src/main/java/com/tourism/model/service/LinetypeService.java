package com.tourism.model.service;

import com.tourism.model.entity.Linetype;

import java.util.List;

public interface LinetypeService {
    public boolean addLinetypeService(Linetype linetype);
    public boolean updateLinetypeService(Linetype linetype);
    public List<Linetype> fourLinetypeService();
    public Linetype getLinetypeByIdService(String linetypeId);


    List<Linetype> allLinetypeService();
}
