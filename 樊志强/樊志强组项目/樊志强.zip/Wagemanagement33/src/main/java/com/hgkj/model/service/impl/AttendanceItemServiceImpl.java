package com.hgkj.model.service.impl;

import com.hgkj.model.dao.AttendanceItemDao;
import com.hgkj.model.entity.Attendance;
import com.hgkj.model.service.AttendanceItemService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class AttendanceItemServiceImpl implements AttendanceItemService {
    @Autowired
    private AttendanceItemDao attendanceItemDao;


    @Override
    public List<Attendance> allAttendance() {
        return attendanceItemDao.allAttendance();
    }

    @Override
    public boolean addAttendance(Attendance Attendance) {
        return attendanceItemDao.addAttendance(Attendance);
    }

    @Override
    public boolean delAttendance(Attendance Attendance) {
        return attendanceItemDao.delAttendance(Attendance);
    }

    @Override
    public boolean updAttendance(Attendance Attendance) {
        return attendanceItemDao.updAttendance(Attendance);
    }

    @Override
    public Attendance queryAttendance(Attendance Attendance) {
        return attendanceItemDao.queryAttendance(Attendance);
    }
}
