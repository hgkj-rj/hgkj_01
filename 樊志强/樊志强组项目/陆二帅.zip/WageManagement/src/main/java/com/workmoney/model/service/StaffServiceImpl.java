package com.workmoney.model.service;

import com.workmoney.model.dao.StaffDao;
import com.workmoney.model.entity.Staff;
import com.workmoney.util.SercharStaff;
import com.workmoney.util.SercharStaffUpload;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * user@Bright Rain .
 * 2019/6/24.
 */
@Service
public class StaffServiceImpl implements StaffService {

    @Autowired
    private StaffDao dao;

    @Override
    public Staff staffLoginService(Staff staff) {
        Staff loginDao = dao.getStaffLoginDao(staff);
        return loginDao;
    }

    @Override
    public Staff updateStaffPwdByIdService(Staff staff) {
        Staff staff1 = dao.updateStaffPwdByIdDao(staff);
        return staff1;
    }

    @Override
    public List<Staff> getStaffListSercharService() {
        return dao.getStaffListSercharDao();
    }

    @Override
    public List<Staff> sercharStaffByNameAndMonth(SercharStaff sercharStaff) {
        return dao.sercharStaffByNameAndMonthDao(sercharStaff);
    }

    @Override
    public boolean updateStaffRemarkByIdService(int staffId, String remark) {
        return   dao.updateStaffRemarkByIdDao(staffId,remark);

    }
}
