package com.hgkj.model.service.impl;

import com.hgkj.model.dao.StaffDao;
import com.hgkj.model.entity.*;
import com.hgkj.model.service.StaffService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class StaffServiceImpl implements StaffService {
    @Autowired
    private StaffDao staffDao;

    public void setStaffDao(StaffDao staffDao) {
        this.staffDao = staffDao;
    }

    @Override
    public List<Staff> loginStaffService(Staff staff) {
        return staffDao.loginStaffDao(staff);
    }

    @Override
    public Staff getByIdStaffService(int staffId) {
        return staffDao.getByIdStaffDao(staffId);
    }

    @Override
    public boolean updateStaffService(Staff staff) {
        return staffDao.updateStaffDao(staff);
    }

    @Override
    public boolean updateStaffXXService(Staff staff) {
        return staffDao.updateStaffXXDao(staff);
    }

    @Override
    public List<Staff> allStaffService() {
        return staffDao.allStaffDao();
    }

    @Override
    public boolean addStaffService(Staff staff) {
        return staffDao.addStaffDao(staff);
    }

    @Override
    public boolean deleteStaffService(int staffId) {
        return staffDao.deleteStaffDao(staffId);
    }

    @Override
    public List<Level> allLevelService() {
        return staffDao.allLevelDao();
    }

    @Override
    public List<Role> allRoleService() {
        return staffDao.allRoleDao();
    }

    @Override
    public List<Department> allDepartmentService() {
        return staffDao.allDepartmentDao();
    }

    @Override
    public List<Shop> allShopService() {
        return staffDao.allShopDao();
    }

}
