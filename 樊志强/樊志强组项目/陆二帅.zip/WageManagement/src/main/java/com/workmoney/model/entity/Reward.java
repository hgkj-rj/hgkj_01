package com.workmoney.model.entity;

import java.math.BigDecimal;
import java.util.Objects;

/**
 * user@Bright Rain .
 * 2019/6/21.
 */
public class Reward {
    private int rewId;
    private String rewName;
    private BigDecimal rewPrice;

    public int getRewId() {
        return rewId;
    }

    public void setRewId(int rewId) {
        this.rewId = rewId;
    }

    public String getRewName() {
        return rewName;
    }

    public void setRewName(String rewName) {
        this.rewName = rewName;
    }

    public BigDecimal getRewPrice() {
        return rewPrice;
    }

    public void setRewPrice(BigDecimal rewPrice) {
        this.rewPrice = rewPrice;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Reward reward = (Reward) o;
        return rewId == reward.rewId &&
                Objects.equals(rewName, reward.rewName) &&
                Objects.equals(rewPrice, reward.rewPrice);
    }

    @Override
    public int hashCode() {
        return Objects.hash(rewId, rewName, rewPrice);
    }
}
