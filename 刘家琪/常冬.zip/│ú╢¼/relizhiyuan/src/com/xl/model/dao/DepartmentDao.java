package com.xl.model.dao;

import com.xl.model.entity.Department;

import java.util.List;

public interface DepartmentDao {

    public int departmentDao(int pageSize);
    public List<Department> allDepartmentDao(int pageIndex,int pageSize);
    public int getDepartmentByIdDao(int departmentId);
    public boolean addDepartmentDao(Department department);
    public boolean deleteDepartmentDao(int department);
    public boolean updateDepartmentDao(Department department);


}
