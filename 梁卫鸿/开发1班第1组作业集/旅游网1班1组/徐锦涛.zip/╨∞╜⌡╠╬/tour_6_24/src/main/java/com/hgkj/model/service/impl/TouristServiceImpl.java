package com.hgkj.model.service.impl;

import com.hgkj.model.dao.TouristDao;
import com.hgkj.model.entity.Tourist;
import com.hgkj.model.service.TouristService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class TouristServiceImpl implements TouristService {
    @Autowired
    private TouristDao touristDao;
    public TouristDao getTouristDao() {
        return touristDao;
    }
    public void setTouristDao(TouristDao touristDao) {
        this.touristDao = touristDao;
    }

    @Override
    public List<Tourist> allTouristService() {
        return touristDao.allTouristDao();
    }

    @Override
    public boolean addTouristService(Tourist tourist) {
        return touristDao.addTouristDao(tourist);
    }
}
