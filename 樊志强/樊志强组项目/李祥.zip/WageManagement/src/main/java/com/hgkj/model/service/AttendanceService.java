package com.hgkj.model.service;

import com.hgkj.model.entity.Attendance;

import java.util.List;

public interface AttendanceService {
    public List<Attendance> allAttendanceService();
    public boolean addAttendanceService(Attendance attendance);
    public boolean deleteAttendanceService(int attId);
    public boolean updateAttendanceService(Attendance attendance);
    public Attendance attendance(int attId);
}
