package com.xl.model.service.impl;

import com.xl.model.dao.ManagDao;
import com.xl.model.dao.impl.ManagDaoImpl;
import com.xl.model.entity.Manag;
import com.xl.model.service.ManagService;

import java.util.List;

public class ManagServiceImpl  implements ManagService {
    private ManagDao ManagDao=new ManagDaoImpl();
    @Override
    public boolean managLoginService(Manag manag) {

        return ManagDao.managLoginDao(manag);
    }

    @Override
    public List<Manag> allManagService() {

        return ManagDao.allManagDao();
    }
}
