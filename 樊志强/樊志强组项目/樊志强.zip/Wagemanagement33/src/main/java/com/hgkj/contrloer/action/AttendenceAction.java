package com.hgkj.contrloer.action;

import com.hgkj.model.entity.Attendance;
import com.hgkj.model.entity.Reward;
import com.hgkj.model.service.AttendanceService;
import com.opensymphony.xwork2.ActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import java.util.List;

@Controller
@Namespace("/")
@ParentPackage("json-default")
public class AttendenceAction {
    @Autowired
    private AttendanceService attendanceService;
    private Attendance attendance;
    private int id;
    @Action(value = "allattendence",results = {@Result(name = "all",type = "redirect",location = "html/attendenceList.jsp")})
    public String allreward(){
        List<Attendance> attendanceList=attendanceService.allattendanceService();
        ActionContext.getContext().getSession().put("attendanceList",attendanceList);
        return "all";
    }
    @Action(value = "insertattendence",results = {@Result(name = "insert",type = "redirectAction",location = "allattendence")})
    public String insert(){
        if(attendanceService.insertattendanceService(attendance)){
            return "insert";
        }else {
            return "noinsert";
        }

    }
    @Action(value = "deleteattendence",results = {@Result(name = "delete",type = "json",params = {"root","delete"})})
    public String delete(){
        attendanceService.deleteattendanceService(id);
        return "delete";
    }
    @Action(value = "updateattendence",results = {@Result(name = "update",type = "redirectAction",location = "allattendence"),@Result(name = "noupdate",type = "redirect",location = "../attendenceList.jsp")})
    public String update(){
        if (attendanceService.updateattendanceService(attendance)){
            return "update";
        }else {
            return "noupdate";
        }

    }
    @Action(value = "getattendence",results = {@Result(name = "get",type = "redirect",location = "html/attendenceupdate.jsp")})
    public String getrewardmanage(){
        attendance=attendanceService.getattendanceByIdService(id);
        ActionContext.getContext().getSession().put("attendance",attendance);
        return "get";
    }
    public void setAttendanceService(AttendanceService attendanceService) {
        this.attendanceService = attendanceService;
    }

    public Attendance getAttendance() {
        return attendance;
    }

    public void setAttendance(Attendance attendance) {
        this.attendance = attendance;
    }

    public void setId(int id) {
        this.id = id;
    }
}
