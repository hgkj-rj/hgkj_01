package com.workmoney.model.service;

import com.workmoney.model.dao.SubsidyLogDao;
import com.workmoney.model.entity.Subsidy;
import com.workmoney.model.entity.SubsidyLog;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * user@Bright Rain .
 * 2019/6/27.
 */
@Service
public class SubsidyLogServiceImpl  implements SubsidyLogService {

    @Autowired
    private SubsidyLogDao dao;

    @Override
    public List<SubsidyLog> getAllSubsidyLogService() {
        List<SubsidyLog> logList = dao.getAllSubsidyLogDao();
        return logList;
    }

    @Override
    public List<Subsidy> getAllSubsidyService() {
        return dao.getAllSubsidyDao();
    }

    @Override
    public void addEmpAllowanceService(SubsidyLog subsidyLog) {
        dao.addEmpAllowanceDao(subsidyLog);
    }

    @Override
    public void delAllowanceById(SubsidyLog subsidyLog) {
        dao.delAllowanceByIdDao(subsidyLog);
    }

    @Override
    public List<SubsidyLog> serchNameAllowAction(String name) {
        return dao.serchNameAllowAction(name);
    }

    @Override
    public void delSubsidyByIdService(Subsidy subsidy) {
        dao.delSubsidyByIdDao(subsidy);
    }

    @Override
    public Subsidy getSubsidyByIdService(Subsidy subsidy) {
      return   dao.getSubsidyByIdService(subsidy);
    }

    @Override
    public void editSubsidyService(Subsidy subsidy) {
        dao.editSubsidyDao(subsidy);
    }

    @Override
    public void addSubSidyService(Subsidy subsidy) {
        dao.addSubSidyDao(subsidy);
    }
}
