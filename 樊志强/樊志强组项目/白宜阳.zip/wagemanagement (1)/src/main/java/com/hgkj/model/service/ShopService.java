package com.hgkj.model.service;

import com.hgkj.model.entity.Shop;

import java.util.List;

public interface ShopService {
    List<Shop> allShopService();
    boolean addShopService(Shop shop);
    boolean updateShopService(Shop shop);
    boolean deleteShopService(int shopId);
    Shop getByIdShopService(int shopId);
}
