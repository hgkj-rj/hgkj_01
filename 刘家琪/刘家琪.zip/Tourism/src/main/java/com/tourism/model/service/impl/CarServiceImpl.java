package com.tourism.model.service.impl;

import com.tourism.model.dao.CarDao;
import com.tourism.model.entity.Car;
import com.tourism.model.entity.Orderdetail;
import com.tourism.model.service.CarService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CarServiceImpl implements CarService {
    @Autowired
    private CarDao carDao;

    @Override
    public int gettotalpageService(int pagesize, int customerId) {
        return carDao.gettotalpageDao(pagesize,customerId);
    }

    @Override
    public List<Car> allCarService(int pageindex, int pagesize, int customerId) {
        return carDao.allCarDao(pageindex,pagesize,customerId);
    }

    @Override
    public boolean deleteCarService(Car car) {
        return carDao.deleteCarDao(car);
    }

    @Override
    public boolean addCarService(Car car) {
        return carDao.addCarDao(car);
    }
}
