package com.hgkj.model.service;

import com.hgkj.model.entity.Orderdetail;

import java.util.List;

public interface OrderdetailService {
    public List<Orderdetail> allOrderdetailService();
    public boolean addOrderdetailService(Orderdetail orderdetail);
    public boolean deleteOrderdetailService(Orderdetail orderdetail);
    public boolean updateOrderdetailService(Orderdetail orderdetail);
    public Orderdetail getOrderdetailByIdService(String odId);
}
