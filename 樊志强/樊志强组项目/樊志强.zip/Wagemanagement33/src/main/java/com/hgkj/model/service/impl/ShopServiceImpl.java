package com.hgkj.model.service.impl;

import com.hgkj.model.dao.ShopDao;
import com.hgkj.model.entity.Shop;
import com.hgkj.model.service.ShopService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class ShopServiceImpl implements ShopService {
    @Autowired
    private ShopDao shopDao;

    public void setShopService(ShopDao shopDao) {
        this.shopDao = shopDao;
    }

    @Override
    public List<Shop> allshopService() {
        return shopDao.allshopDao();
    }

    @Override
    public boolean insertshopService(Shop shop) {
        return shopDao.insertshopDao(shop);
    }

    @Override
    public boolean deleteshopService(int id) {
        return shopDao.deleteshopDao(id);
    }

    @Override
    public boolean updateshopService(Shop shop) {
        return shopDao.updateshopDao(shop);
    }

    @Override
    public Shop getshopByIdService(int id) {
        return shopDao.getshopByIdDao(id);
    }
}
