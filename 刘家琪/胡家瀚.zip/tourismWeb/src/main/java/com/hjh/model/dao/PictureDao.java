package com.hjh.model.dao;

import com.hjh.model.entity.Line;
import com.hjh.model.entity.Picture;

import java.util.List;

public interface PictureDao {
    public List<Picture> Allpicture(Line line);
    public boolean Addpicture(Picture picture);
    public boolean UPpicture(Picture picture);
}
