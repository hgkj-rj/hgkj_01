package com.hgkj.controller.action;


import com.hgkj.model.entity.Department;
import com.hgkj.model.service.DepartmentService;
import com.opensymphony.xwork2.ActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import java.util.List;

@Controller
@Namespace("/")
@ParentPackage("struts-default")
public class DepartmentAction {

    public int depId;
    private Department department;

    @Autowired
    public DepartmentService departmentService;

    public void setDepartmentService(DepartmentService departmentService) {
        this.departmentService = departmentService;
    }

    @Action(value = "allDepartment" ,results =
            {@Result(name = "all",type = "redirect",location = "html/DepartmentList.jsp")})
    public String allDepartment(){
        List<Department>departmentList = departmentService.allDepartmentService();
        ActionContext.getContext().getSession().put("departmentList",departmentList);
        return "all";
    }

    @Action(value = "addDepartment",results =
            {@Result(name = "all",type = "redirectAction",location = "allDepartment")})
    public String addDepartment(){
        departmentService.addDepartmentService(department);
        return "all";
    }

    @Action(value = "deleteDepartment",results =
            {@Result(name = "all",type = "redirectAction",location = "allDepartment")})
    public String deleteDepartment(){
        departmentService.deleteDepartmentService(depId);
        return "all";
    }

    @Action(value = "updateDepartment",results =
            {@Result(name = "all",type = "redirectAction",location = "allDepartment")} )
    public String updateDepartment(){
        departmentService.updateDepartmentService(department);
        return "all";
    }

    @Action(value = "department",results =
            {@Result(name = "all",type = "redirect",location = "html/DepartmentUpdate.jsp")})
    public String department(){
       Department department = departmentService.department(depId);
       ActionContext.getContext().getSession().put("department",department);
        return "all";
    }

    public int getDepId() {
        return depId;
    }

    public void setDepId(int depId) {
        this.depId = depId;
    }

    public Department getDepartment() {
        return department;
    }

    public void setDepartment(Department department) {
        this.department = department;
    }
}
