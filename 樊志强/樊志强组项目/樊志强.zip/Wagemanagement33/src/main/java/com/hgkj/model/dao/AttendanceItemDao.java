package com.hgkj.model.dao;

import com.hgkj.model.entity.Attendance;

import java.util.List;

public interface AttendanceItemDao {
    public List<Attendance> allAttendance();

    public boolean  addAttendance(Attendance Attendance);

    public boolean  delAttendance(Attendance Attendance);

    public boolean updAttendance(Attendance Attendance);

    public Attendance queryAttendance(Attendance Attendance);
}
