package com.workmoney.model.service;

import com.workmoney.model.dao.DepartmentDao;
import com.workmoney.model.entity.Department;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * user@Bright Rain .
 * 2019/6/29.
 */
@Service
public class DepartmentServiceImpl implements DepartmentService {

    @Autowired
    private DepartmentDao dao;

    @Override
    public List<Department> getAllDepartmentService() {
        return dao.getAllDepartmentDao();
    }

    @Override
    public void addDepartmentService(Department department) {
        dao.addDepartmentDao(department);
    }

    @Override
    public void delDepartmentService(Department department) {
        dao.delDepartmentDao(department);
    }

    @Override
    public Department getDepartmentService(Department department) {
        return dao.getDepartmentDao(department);
    }

    @Override
    public void updateDepartment(Department department) {
        dao.updateDepartmentDao(department);
    }
}
