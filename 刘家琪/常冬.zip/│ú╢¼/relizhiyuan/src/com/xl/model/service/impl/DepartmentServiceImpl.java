package com.xl.model.service.impl;

import com.xl.model.dao.DepartmentDao;
import com.xl.model.dao.impl.DepartmentDaoImpl;
import com.xl.model.entity.Department;
import com.xl.model.service.DepartmentService;

import java.util.List;

public class DepartmentServiceImpl implements DepartmentService {
    private DepartmentDao DepartmentDao=new DepartmentDaoImpl();
    @Override
    public int departmentService(int pageSize) {
     return DepartmentDao.departmentDao(pageSize) ;

    }

    @Override
    public List<Department> allDepartmentService(int pageIndex, int pageSize) {
        return DepartmentDao.allDepartmentDao(pageIndex, pageSize);
    }



    @Override
    public boolean addDepartmentService(Department department) {

        return DepartmentDao.addDepartmentDao(department);
    }

    @Override
    public boolean deleteDepartmentService(int departmentId) {
        return  DepartmentDao.deleteDepartmentDao( departmentId);
    }



    @Override
    public boolean updateDepartmentService(Department department) {
        return DepartmentDao.updateDepartmentDao(department);
    }

    @Override
    public int getDepartmentByIdService(int departmentId) {
        return DepartmentDao.getDepartmentByIdDao(departmentId);
    }
}
