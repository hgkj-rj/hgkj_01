package com.hgkj.model.dao.impl;

import com.hgkj.model.dao.SalaryLogDao;
import com.hgkj.model.entity.SalaryLog;
import com.hgkj.model.entity.Staff;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
@Transactional
public class SalaryLogDaoImpl implements SalaryLogDao {
    @Autowired
    private SessionFactory sessionFactory;
    private Transaction transaction;

    @Override
    public List<SalaryLog> allSalaryLogDao() {
        Query query=getSession().createQuery("from SalaryLog");
        return query.list();
    }

    @Override
    public List<SalaryLog> alSalaryLogDao(SalaryLog salaryLog) {
        String hql="from SalaryLog where staffName like :name and salTime  like :time";
        List<SalaryLog> logList=getSession().createQuery(hql).setParameter("name","%"+salaryLog.getStaffName()+"%").setParameter("time","%"+salaryLog.getSalTime()+"%").list();
        return logList;
    }

    public Transaction getTransaction() {
        return transaction;
    }

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    public void setTransaction(Transaction transaction) {
        this.transaction = transaction;
    }

    public Session getSession(){
        return sessionFactory.getCurrentSession();
    }
}
