package com.hgkj.model.service.impl;

import com.hgkj.model.dao.SubsidyDao;
import com.hgkj.model.entity.Subsidy;
import com.hgkj.model.service.SubsidyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SubsidyServiceImpl implements SubsidyService {
    @Autowired
    private SubsidyDao subsidyDao;

    public void setSubsidyDao(SubsidyDao subsidyDao) {
        this.subsidyDao = subsidyDao;
    }

    @Override
    public List<Subsidy> allSubsidyService() {
        return subsidyDao.allSubsidyDao();
    }

    @Override
    public boolean addSubsidyService(Subsidy subsidy) {
        return subsidyDao.addSubsidyDao(subsidy);
    }

    @Override
    public boolean updateSubsidyService(Subsidy subsidy) {
        return subsidyDao.updateSubsidyDao(subsidy);
    }

    @Override
    public boolean deleteSubsidyService(int subsidyId) {
        return subsidyDao.deleteSubsidyDao(subsidyId);
    }

    @Override
    public Subsidy getByIdSubsidyService(int subsidyId) {
        return subsidyDao.getByIdSubsidyDao(subsidyId);
    }
}
