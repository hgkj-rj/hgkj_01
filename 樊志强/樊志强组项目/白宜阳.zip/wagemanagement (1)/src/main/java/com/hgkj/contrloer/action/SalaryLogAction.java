package com.hgkj.contrloer.action;

import com.hgkj.model.entity.SalaryLog;
import com.hgkj.model.service.SalaryLogService;
import com.opensymphony.xwork2.ActionContext;
import org.apache.struts2.ServletActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import java.util.List;

@Controller
@Namespace("/")
@ParentPackage("struts-default")
public class SalaryLogAction {
    @Autowired
    private SalaryLogService salaryLogService;
    private SalaryLog salaryLog;

    @Action(value = "allSalaryL",results = @Result(name = "allSalaryL",type = "redirect",location = "/html/salarySearch.jsp"))
    public String allSalaryLog(){
        List<SalaryLog>salaryLogList=salaryLogService.allSalaryLogService();
        ServletActionContext.getRequest().getSession().setAttribute("salaryLogList",salaryLogList);
        return "allSalaryL";
    }

    @Action(value = "alSalaryLog",results = @Result(name = "alSalaryLog",type = "redirect",location = "/html/salarySearch.jsp"))
    public String alSalaryLog(){
        List<SalaryLog> salaryLogList=salaryLogService.alSalaryLogService(salaryLog);
        ActionContext.getContext().getSession().put("salaryLogList",salaryLogList);
        return "alSalaryLog";
    }

    public void setSalaryLogService(SalaryLogService salaryLogService) {
        this.salaryLogService = salaryLogService;
    }

    public SalaryLog getSalaryLog() {
        return salaryLog;
    }

    public void setSalaryLog(SalaryLog salaryLog) {
        this.salaryLog = salaryLog;
    }
}
