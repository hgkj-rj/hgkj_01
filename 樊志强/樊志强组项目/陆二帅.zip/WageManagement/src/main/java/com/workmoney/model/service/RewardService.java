package com.workmoney.model.service;

import com.workmoney.model.entity.Reward;
import com.workmoney.model.entity.RewardLog;

import java.util.List;

/**
 * user@Bright Rain .
 * 2019/6/29.
 */
public interface RewardService {

    /**
     * 获取指定奖金信息
     * @param reward
     * @return
     */
    Reward getRewardById(Reward reward);

    /**
     * 获取所有奖金
     * @return
     */
    List<RewardLog> getAllRewardService();

    /**
     * 删除对应员工的奖金信息
     * @param rewardLog
     */
    void delrewardByIdService(RewardLog rewardLog);

    /**
     * 获取所有的奖金类别
     * @return
     */
    List<Reward> getAllRewardType();

    /**
     * 添加对应员工的奖金信息
     * @param rewardLog
     */
    void addEmpRewardService(RewardLog rewardLog);
    /**
     * 修改奖金信息
     * @param
     */
    void editRewardService(Reward reward);
    /**
     * 删除奖金信息
     * @param
     */
    void delRewordByIdService(Reward reward);

    /**
     * 添加奖金
     * @param reward
     */
    void addRewardService(Reward reward);
}
