package com.hgkj.contrloer.action;

import com.hgkj.model.entity.Department;
import com.hgkj.model.entity.Level;
import com.hgkj.model.service.LevelService;
import org.apache.struts2.ServletActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import java.util.List;

@Controller
@Namespace("/")
@ParentPackage("struts-default")
public class LevelAction {
    @Autowired
    private LevelService levelService;
    private Level level;

    public Level getLevel() {
        return level;
    }

    public void setLevel(Level level) {
        this.level = level;
    }

    public void setLevelService(LevelService levelService) {
        this.levelService = levelService;
    }

    @Action(value = "alllevel",results = @Result(name = "all",type = "redirect",location = "/html/levelList.jsp"))
    public String alllevel(){
        List<Level> levelList=levelService.allLevelService();
        ServletActionContext.getRequest().getSession().setAttribute("levelList",levelList);
        return "all";
    }

    @Action(value = "addlevel",results = @Result(name = "adds",type = "redirectAction",params = {"actionName","alllevel"}))
    public String addlevel(){
        boolean r=levelService.addLevelService(level);
        if (r==true){
            return "adds";
        }else {
            return "adde";
        }
    }

    @Action(value = "dellevel",results = @Result(name = "dels",type = "redirectAction",params = {"actionName","alllevel"}))
    public String deletelevel(){
        boolean r=levelService.deleteLevelService(level.getLevelId());
        if (r==true){
            return "dels";
        }else {
            return "dele";
        }
    }

    @Action(value = "updlevel",results = @Result(name = "upds",type = "redirectAction",params = {"actionName","alllevel"}))
    public String Updlevel(){
        boolean r=levelService.updateLevelService(level);
        if (r==true){
            return "upds";
        }else {
            return "upde";
        }
    }

    @Action(value = "getByIdlevels",results = {@Result(name = "getByIds",type = "redirect",location = "/html/levelUpdate.jsp")})
    public String getByIdlevel(){
        Level level1=levelService.getByIdLevelService(level.getLevelId());
        ServletActionContext.getRequest().getSession().setAttribute("level1",level1);
        return "getByIds";
    }
}
