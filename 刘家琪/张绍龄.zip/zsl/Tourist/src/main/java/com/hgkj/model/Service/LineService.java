package com.hgkj.model.Service;

import com.hgkj.model.entity.Line;

import java.util.List;

public interface LineService {
    public int getpageService(int pagesize,String time);
    public List<Line> allLineService(int pageIndex,int pagesize,String time);
    public List<Line> allLineService();
    public List<Line>allGroupService();
    public List<Line>allGroupLineService();
    public List<Line>toIndexLineService(String lineTypeId);
    public List<Line>oneLineService();
    public List<Line>twoLineService();
    public List<Line>moreLineService();
    public boolean  addLineService(Line line);
    public boolean  updateLineService(Line line);
    public Line getLineByIdService(String lineId);
}
