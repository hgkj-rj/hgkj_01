package com.hgkj.model.dao;

import com.hgkj.model.entity.Tourist;

import java.util.List;

public interface TouristDao {
    public List<Tourist> allTouristDao();
    public boolean addTouristDao(Tourist tourist);
}
