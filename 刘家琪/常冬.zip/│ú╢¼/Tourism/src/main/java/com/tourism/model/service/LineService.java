package com.tourism.model.service;

import com.tourism.model.entity.Line;
import com.tourism.model.entity.Linetype;

import java.util.List;

public interface LineService {
    public boolean addLineService(Line line);
    public boolean updateLineService(Line line);
    public List<Line> toIndexLineService();
    public Line getLineByIdService(String lineId);


}
