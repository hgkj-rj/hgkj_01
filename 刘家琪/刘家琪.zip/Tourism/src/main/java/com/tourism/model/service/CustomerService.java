package com.tourism.model.service;

import com.tourism.model.entity.Customer;

public interface CustomerService {
    public Customer loginService(Customer customer);
    public boolean addCustomerService(Customer customer);
}
