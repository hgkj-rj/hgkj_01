package com.workmoney.model.service;

import com.workmoney.model.dao.KaoQinDao;
import com.workmoney.model.entity.Attendance;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * user@Bright Rain .
 * 2019/6/29.
 */
@Service
public class KaoQinServiceImpl implements KaoQinService {

    @Autowired
    private KaoQinDao dao;

    @Override
    public List<Attendance> getAllAttendanceService() {
        return dao.getAllAttendanceDao();
    }

    @Override
    public void addAttendanceService(Attendance attendance) {
        dao.addAttendanceDao(attendance);
    }

    @Override
    public void delAttendanceService(Attendance attendance) {
        dao.delAttendanceDao(attendance);
    }

    @Override
    public Attendance getAttendanceService(Attendance attendance) {
      return   dao.getAttendanceDao(attendance);
    }

    @Override
    public void updateAttendance(Attendance attendance) {
        dao.updateAttendance(attendance);
    }
}
