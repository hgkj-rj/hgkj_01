package com.workmoney.model.dao;

import com.workmoney.model.entity.Department;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * user@Bright Rain .
 * 2019/6/29.
 */

public interface DepartmentDao {

    /**
     * 获取所有部门
     * @return
     */
    List<Department> getAllDepartmentDao();
    /**
     * 添加部门
     * @return
     */
    void addDepartmentDao(Department department);
    /**
     * 删除部门
     * @return
     */
    void delDepartmentDao(Department department);
    /**
     * 获取部门
     * @return
     */
    Department getDepartmentDao(Department department);


    void updateDepartmentDao(Department department);
}
