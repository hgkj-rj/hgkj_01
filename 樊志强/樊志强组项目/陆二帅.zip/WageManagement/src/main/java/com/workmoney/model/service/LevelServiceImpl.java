package com.workmoney.model.service;

import com.workmoney.model.dao.LevelDao;
import com.workmoney.model.entity.Level;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * user@Bright Rain .
 * 2019/6/30.
 */
@Service
public class LevelServiceImpl implements LevelService{

    @Autowired
    private LevelDao dao;

    @Override
    public List<Level> getAllLevelService() {
        return dao.getAllLevelDao();
    }

    @Override
    public void addLevelService(Level level) {
        dao.addLevelDao(level);
    }

    @Override
    public void delLevelService(Level level) {
        dao.delLevelDao(level);
    }

    @Override
    public Level getLevelService(Level level) {
        return dao.getLevelDao(level);
    }

    @Override
    public void updateLevel(Level level) {
        dao.updateLevel(level);
    }
}
