package com.hgkj.model.dao;

import com.hgkj.model.entity.Department;

import java.util.List;

public interface Departmentdao {
    public List<Department> allDepartmentdao();
    public boolean addDepartmentdao(Department department);
    public boolean deleteDepartmentdao(int depId);
    public boolean updateDepartmentdao(Department department);
    public Department department(int depId);
}
