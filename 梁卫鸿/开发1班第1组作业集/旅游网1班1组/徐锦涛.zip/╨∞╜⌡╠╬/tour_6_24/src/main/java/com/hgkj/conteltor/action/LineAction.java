package com.hgkj.conteltor.action;

import com.hgkj.model.entity.Car;
import com.hgkj.model.entity.Line;
import com.hgkj.model.service.CarService;
import com.hgkj.model.service.LineService;
import com.opensymphony.xwork2.ActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import java.util.List;

@Controller
@Namespace("/")
@ParentPackage("struts-default")
public class LineAction {
    @Autowired
    private LineService lineService;
    private CarService carService;
    private Car car;
    private Line line;
    private String message;

    public CarService getCarService() {
        return carService;
    }

    public void setCarService(CarService carService) {
        this.carService = carService;
    }

    public Car getCar() {
        return car;
    }

    public void setCar(Car car) {
        this.car = car;
    }

    public Line getLine() {
        return line;
    }

    public void setLine(Line line) {
        this.line = line;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public LineService getLineService() {
        return lineService;
    }

    public void setLineService(LineService lineService) {
        this.lineService = lineService;
    }
    @Action(value = "allLine", results = @Result(name = "all", type = "redirect", location = "/ht/ck_xianlu_1.jsp"))
    public String allLine(){
        List<Line> lineList = lineService.allLineService();
        for (Line lineList1:lineList){
            System.out.println(lineList1.getLineName());
        }
        ActionContext.getContext().getSession().put("lineList", lineList);
        return "all";
    }

    @Action(value = "allLine1", results = @Result(name = "all", type = "redirect", location = "/ht/ck_xianlu.jsp"))
    public String allLine1(){
        List<Line> lineList1 = lineService.allLineService();
        for (Line lineList2:lineList1){
            System.out.println(lineList2.getLineName());
        }
        ActionContext.getContext().getSession().put("lineList1", lineList1);
        return "all";
    }
    @Action(value = "allLine2", results = @Result(name = "all", type = "redirect", location = "/ht/ck_tuangou.jsp"))
    public String allLine2(){
        List<Line> lineList2 = lineService.allLineService();
        for (Line lineList3:lineList2){
            System.out.println(lineList3.getLineName());
        }
        ActionContext.getContext().getSession().put("lineList2", lineList2);
        return "all";
    }
    @Action(value = "lineById", results = @Result(name = "all1", type = "redirect", location = "/qt/detail.jsp"))
    public String lineById(){
        Line line1 = lineService.lineByIdService(line.getLineID());
        ActionContext.getContext().getSession().put("line1", line1);
        return "all1";
    }
    @Action(value = "lineById1", results = @Result(name = "all1", type = "redirect", location = "/ht/set_tuangou.jsp"))
    public String lineById1(){
        Line line2 = lineService.lineByIdService(line.getLineID());
        ActionContext.getContext().getSession().put("line2", line2);
        return "all1";
    }
    @Action(value = "lineById2", results = @Result(name = "all1", type = "redirect", location = "/qt/order.jsp"))
    public String lineById2(){
        Line line3 = lineService.lineByIdService(line.getLineID());
        ActionContext.getContext().getSession().put("line3", line3);
        return "all1";
    }
    @Action(value = "lineDelete", results = {@Result(name = "delete", type = "redirectAction",params = {"actionName","allline"})})
    public String lineDelete(){
        boolean result = carService.cardeleteService(car.getCarID());
        if (result) {
            message = "ok";
            return "delete";
        } else {
            return "deleteError";
        }
    }


}

