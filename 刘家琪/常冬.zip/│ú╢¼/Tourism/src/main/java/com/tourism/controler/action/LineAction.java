package com.tourism.controler.action;

import com.opensymphony.xwork2.ActionContext;
import com.tourism.model.entity.Line;
import com.tourism.model.entity.Linetype;
import com.tourism.model.entity.Picture;
import com.tourism.model.service.LineService;
import com.tourism.model.service.LinetypeService;
import com.tourism.model.service.PictureService;
import org.apache.struts2.ServletActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import javax.servlet.ServletContext;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Random;

@Controller
@Namespace("/")
@ParentPackage("struts-default")
public class LineAction {
    @Autowired
    private LineService lineService;
@Autowired
private PictureService pictureService;
@Autowired
    private LinetypeService linetypeService;
    private Line line;
    private Picture picture;
    private List<Picture> pictures;
     private File[] upload;
    private String[] uploadFileName;
    private String[] uploadContentType;
    private Picture picture0;
    private Picture picture1;
    private Picture picture2;
    private Picture picture3;

    public LinetypeService getLinetypeService() {
        return linetypeService;
    }

    public void setLinetypeService(LinetypeService linetypeService) {
        this.linetypeService = linetypeService;
    }

    public Line getLine() {
        return line;
    }

    public void setLine(Line line) {
        this.line = line;
    }

    public Picture getPicture() {
        return picture;
    }

    public void setPicture(Picture picture) {
        this.picture = picture;
    }

    public List<Picture> getPictures() {
        return pictures;
    }

    public void setPictures(List<Picture> pictures) {
        this.pictures = pictures;
    }

    public File[] getUpload() {
        return upload;
    }

    public void setUpload(File[] upload) {
        this.upload = upload;
    }

    public String[] getUploadFileName() {
        return uploadFileName;
    }

    public void setUploadFileName(String[] uploadFileName) {
        this.uploadFileName = uploadFileName;
    }

    public String[] getUploadContentType() {
        return uploadContentType;
    }

    public void setUploadContentType(String[] uploadContentType) {
        this.uploadContentType = uploadContentType;
    }

    public Picture getPicture0() {
        return picture0;
    }

    public void setPicture0(Picture picture0) {
        this.picture0 = picture0;
    }

    public Picture getPicture1() {
        return picture1;
    }

    public void setPicture1(Picture picture1) {
        this.picture1 = picture1;
    }

    public Picture getPicture2() {
        return picture2;
    }

    public void setPicture2(Picture picture2) {
        this.picture2 = picture2;
    }

    public Picture getPicture3() {
        return picture3;
    }

    public void setPicture3(Picture picture3) {
        this.picture3 = picture3;
    }

    public PictureService getPictureService() {
        return pictureService;
    }

    public void setPictureService(PictureService pictureService) {
        this.pictureService = pictureService;
    }
    @Action(value = "allLine",results = @Result(name = "all",type = "redirect",location = "/allLine.jsp"))
    public String allLine(){
        List<Line> lineList = lineService.toIndexLineService();
        ActionContext.getContext().getSession().put("lineList",lineList);
        return "all";
    }
    @Action(value = "toIndex",results = @Result(name = "all",type = "redirect",location = "/index.jsp"))
    public String toIndex(){
        List<Linetype> linetypeList=linetypeService.fourLinetypeService();
        ActionContext.getContext().getSession().put("linetypeList",linetypeList);
        List<Line> lineList =  lineService.toIndexLineService(line.getLinetype().getLineTypeId());
        ActionContext.getContext().getSession().put("lineList",lineList);
        return "all";
    }
    @Action(value = "allTuanGou",results = @Result(name = "all",type = "redirect",location = "/allTuanGou.jsp"))
    public String allTuanGou(){
        List<Line> lineList = lineService.toIndexLineService();
        ActionContext.getContext().getSession().put("lineList",lineList);
        return "all";
    }
    @Action(value = "allTuanGouLine",results = @Result(name = "all",type = "redirect",location = "/allTuanGouXianLu.jsp"))
    public String allTuanGouLine(){
        List<Line> lineList = lineService.toIndexLineService();
        ActionContext.getContext().getSession().put("lineList",lineList);
        return "all";
    }
    @Action(value = "addLine",results = {@Result(name = "add", type = "redirectAction", location = "/allLine.action"),
    @Result(name = "error",type = "redirect",location = "/addLine.jsp")})
    public String addLine(){
        boolean flag=false;
        ServletContext application = ServletActionContext.getServletContext();
        String filePath = application.getRealPath("upload");
        File file=new File(filePath);
        if (!file.exists()){
            file.mkdirs();
        }
        for (int i=0;i<upload.length;i++){
            upload[i].renameTo(new File(file,uploadFileName[i]));
        }
        Date date=new Date();
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd  :hh:mm:ss");
        line.setOnTime(dateFormat.format(date));
        line.setLineId(getCharAndNumr(3));
        flag=lineService.addLineService(line);
        if (!flag){
            return "error";
        }
        for (int i=0;i<4;i++){
            pictures.get(i).setLine(line);
            pictures.get(i).setName("upload/"+uploadFileName[i]);
            flag=pictureService.addPictureService(pictures.get(i));
            if (!flag){
                return "error";
            }
        }
        return "add";
    }
    @Action(value = "toaddLine",results = @Result(name = "toadd", type = "redirect", location = "/allLine.jsp"))
    public String toaddLine(){
        List<Linetype> linetypeList=linetypeService.fourLinetypeService();
        ActionContext.getContext().getSession().put("linetypeList",linetypeList);
        return "toadd";
    }
    @Action(value = "findLine",results = @Result(name = "find", type = "redirect", location = "/updateLine.jsp"))
    public String findLine(){
        line=lineService.getLineByIdService(line.getLineId());
        List<Picture> pictureList=pictureService.findPictureService(line.getLineId());
        ActionContext.getContext().getSession().put("line",line);
        ActionContext.getContext().getSession().put("pictureList",pictureList);
        List<Linetype> linetypeList=linetypeService.fourLinetypeService();
        ActionContext.getContext().getSession().put("linetypeList",linetypeList);
        return "find";
    }
    @Action(value = "findTuanGouLine",results = @Result(name = "find", type = "redirect", location = "/updateTuanGouXianXi.jsp"))
    public String findTuanGouLine(){
        line=lineService.getLineByIdService(line.getLineId());
        List<Picture> pictureList=pictureService.findPictureService(line.getLineId());
        ActionContext.getContext().getSession().put("line",line);
        ActionContext.getContext().getSession().put("pictureList",pictureList);
        List<Linetype> linetypeList=linetypeService.fourLinetypeService();
        ActionContext.getContext().getSession().put("linetypeList",linetypeList);
        return "find";
    }
    @Action(value = "updateLine",results = {@Result(name = "update",type = "redirectAction",location = "/allLine.action"),
            @Result(name = "error",type = "redirect",location = "/updateLine.jsp")})
    private String updateLine() {
        boolean flag = false;
        if (upload.length != 0) {
            ServletContext application = ServletActionContext.getServletContext();
            String filePath = application.getRealPath("update");
            File file = new File(filePath);
            if (file.exists()) {
                file.mkdirs();
            }
        }
        flag = lineService.updateLineService(line);
        if (!flag) {
            return "error";
        }
    picture0.setLine(line);
        picture1.setLine(line);
        picture2.setLine(line);
        picture3.setLine(line);

        File tempFile0 = new File(picture0.getName().trim());
        String fileName0 = tempFile0.getName();
        picture0.setName("upload/"+fileName0);

        File tempFile1= new File(picture1.getName().trim());
        String fileName1 = tempFile1.getName();
        picture0.setName("upload/"+fileName1);

        File tempFile2 = new File(picture2.getName().trim());
        String fileName2 = tempFile2.getName();
        picture0.setName("upload/"+fileName2);

        File tempFile3 = new File(picture3.getName().trim());
        String fileName3 = tempFile3.getName();
        picture0.setName("upload/"+fileName3);

        flag = pictureService.updatePictureService(picture0);
        if (!flag){
            return "error";
        }
        flag = pictureService.updatePictureService(picture1);
        if (!flag){
            return "error";
        }
        flag = pictureService.updatePictureService(picture2);
        if (!flag){
            return "error";
        }
        flag = pictureService.updatePictureService(picture3);
        if (!flag){
            return "error";
        }
        return "update";
    }

    @Action(value = "updateTuanGouLine",results = {@Result(name = "update",type = "redirectAction",location = "/allTuanGou.action"),
        @Result(name = "error",type = "redirect",location = "/updateTuanGouXinXi.jsp")})
    public String updateTuanGouLine(){
        boolean flag = false;
        line.setTeamBuy(1);
        flag = lineService.updateLineService(line);
        if (!flag){
            return "error";
        }
        return "update";

    }





    private static String getCharAndNumr(int length){
        String val="";
        Random random=new Random();
        for (int i=0;i<length;i++){
            String charOrNum=random.nextInt(2)%2==0?"char":"num";
            if ("char".equalsIgnoreCase(charOrNum)){
                int choice=random.nextInt(2)%2==0?65:97;
                val +=(char)(choice + random.nextInt(26));
            }else if ("num".equalsIgnoreCase(charOrNum)){
                val +=String.valueOf(random.nextInt(10));
            }
        }
        return val;
    }
}
