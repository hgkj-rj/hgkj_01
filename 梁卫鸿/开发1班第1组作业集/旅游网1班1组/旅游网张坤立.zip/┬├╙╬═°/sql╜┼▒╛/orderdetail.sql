/*
 Navicat Premium Data Transfer

 Source Server         : Mysql
 Source Server Type    : MySQL
 Source Server Version : 50724
 Source Host           : localhost:3306
 Source Schema         : travel

 Target Server Type    : MySQL
 Target Server Version : 50724
 File Encoding         : 65001

 Date: 08/07/2019 09:54:11
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for orderdetail
-- ----------------------------
DROP TABLE IF EXISTS `orderdetail`;
CREATE TABLE `orderdetail`  (
  `odID` int(255) NOT NULL AUTO_INCREMENT COMMENT '订单编号，主键',
  `customerID` int(11) NULL DEFAULT NULL COMMENT '客户编号，外键',
  `lineName` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '线路名称',
  `price` decimal(10, 2) NULL DEFAULT NULL COMMENT '线路价格',
  `orderDate` datetime(0) NULL DEFAULT NULL COMMENT '下订单日期',
  `travelDate` datetime(0) NULL DEFAULT NULL COMMENT '出游日期',
  `total` decimal(10, 2) NULL DEFAULT NULL COMMENT '总价',
  `lineID` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '线路编号，外键',
  `state` int(255) NULL DEFAULT NULL COMMENT '订单显示状态，0为不显示，1为显示',
  PRIMARY KEY (`odID`) USING BTREE,
  INDEX `FK_ORDERDETAIL`(`customerID`) USING BTREE,
  INDEX `FK_ORDERDETAIL_LINE`(`lineID`) USING BTREE,
  CONSTRAINT `FK_ORDERDETAIL` FOREIGN KEY (`customerID`) REFERENCES `customer` (`customerID`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `FK_ORDERDETAIL_LINE` FOREIGN KEY (`lineID`) REFERENCES `line` (`lineID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

SET FOREIGN_KEY_CHECKS = 1;
