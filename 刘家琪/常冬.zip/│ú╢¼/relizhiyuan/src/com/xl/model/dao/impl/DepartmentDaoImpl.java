package com.xl.model.dao.impl;

import com.xl.model.dao.DepartmentDao;
import com.xl.model.entity.Department;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class DepartmentDaoImpl implements DepartmentDao {
    @Override
    public int departmentDao(int pageSize) {
        int totalPage=0;
        Connection connection=DBManager.getConnection();
        PreparedStatement preparedStatement=null;
        ResultSet resultSet=null;
        String sql="select count(*) from department";
        try {
            preparedStatement=connection.prepareStatement(sql);
            resultSet=preparedStatement.executeQuery();
            if (resultSet.next()){
                totalPage=(resultSet.getInt(1)-1)/pageSize+1;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            DBManager.closeAll(connection,preparedStatement,resultSet);
        }
        return totalPage;
    }

    @Override
    public List<Department> allDepartmentDao(int pageIndex, int pageSize) {
        List<Department> departmentList=new ArrayList<>();
        Connection connection=DBManager.getConnection();
        PreparedStatement preparedStatement=null;
        ResultSet resultSet=null;
        String sql="select * from department limit  ?,?";
        try {
            preparedStatement=connection.prepareStatement(sql);
            preparedStatement.setInt(1,(pageIndex-1)*pageSize);
            preparedStatement.setInt(2,pageSize);
            resultSet=preparedStatement.executeQuery();
            while (resultSet.next()){
                Department department=new Department();
                department.setDepartmentId(resultSet.getInt("departmentId"));
                department.setDepartmentName(resultSet.getString("departmentName"));
                department.setDepartmentTime(resultSet.getString("departmentTime"));
                department.setDepartmentBz(resultSet.getString("departmentBz"));

              departmentList.add(department);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            DBManager.closeAll(connection,preparedStatement,resultSet);
        }
        return departmentList;
    }


    @Override
    public int getDepartmentByIdDao(int departmentId) {
       int departmentCount=0;
        Connection connection=DBManager.getConnection();
        PreparedStatement preparedStatement=null;
        ResultSet resultSet=null;
        String sql="select * from employee where departmentId=?";
        try {
            preparedStatement=connection.prepareStatement(sql);
            preparedStatement.setInt(1,departmentId);
            resultSet=preparedStatement.executeQuery();
            if (resultSet.next()){
                departmentCount=resultSet.getInt(1);
            }
        }catch (SQLException e){
            e.printStackTrace();
        }finally {
            DBManager.closeAll(connection,preparedStatement,resultSet);
        }
        return departmentCount;
    }






    @Override
    public boolean addDepartmentDao(Department department){
        String sql = "insert into department(departmentName,departmentTime,departmentBz) values(?,?,?)";
        Object[] objects = {department.getDepartmentName(),department.getDepartmentTime(), department.getDepartmentBz()};
        return DBManager.executeUpdate(sql,objects);
    }

    @Override
    public boolean deleteDepartmentDao(int departmentId) {
        String sql = "delete from department where departmentId=?";
        Object[] objects = {departmentId};
        return DBManager.executeUpdate(sql,objects);
    }






    @Override
    public boolean updateDepartmentDao(Department department) {
        String sql = "update department set departmentName=?,departmentTime=?,departmentBz=? where departmentId=?";
        Object[] objects = {department.getDepartmentName(),department.getDepartmentTime(), department.getDepartmentBz(),department.getDepartmentId()};
        return DBManager.executeUpdate(sql,objects);
    }



}
