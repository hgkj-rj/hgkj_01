package com.hgkj.model.Dao.impl;

import com.hgkj.model.Dao.LineTypeDao;
import com.hgkj.model.entity.Linetype;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
@Repository
@Transactional
public class LineTypeDaoimpl implements LineTypeDao {
    @Autowired
    private SessionFactory sessionFactory;
    private Session session;
    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }
    public Session getSession(){
        return sessionFactory.getCurrentSession();
    }
    @Override
    public List<Linetype> allLineTypeDao() {
       Query query = getSession().createQuery("from Linetype ");
        return query.list();
    }

    @Override
    public List<Linetype> fourLineDao() {
        List<Linetype> linetypeList = getSession().createQuery("from Linetype order by lineTypeId desc ").setMaxResults(4).list();
        for (Linetype linetype:linetypeList){
            System.out.println(linetype);
        }
        return linetypeList;
    }

    @Override
    public boolean addLineTypeDao(Linetype linetype) {
        Boolean flag = false;
        session=getSession();
        try {
            session.save(linetype);
            flag=true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return flag;
    }

    @Override
    public boolean updateLineTypeDao(Linetype linetype) {
        Boolean flag = false;
        session=getSession();
        try {
            session.update(linetype);
            flag=true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return flag;
    }

    @Override
    public Linetype getLineByIdDao(String lineTypeId) {
        session=getSession();
        String hql = "from Linetype where lineTypeId=?";
        Linetype linetype = (Linetype) session.createQuery(hql).setParameter(0,lineTypeId).uniqueResult();
        return linetype;
    }

    @Override
    public Linetype getLastDao() {
        session=getSession();
        String hql = "from Linetype order by lineTypeId desc";
        Linetype linetype =(Linetype) session.createQuery(hql).setMaxResults(1).uniqueResult();
        return linetype;
    }
}
