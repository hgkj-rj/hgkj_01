package com.hgkj.model.dao.impl;

import com.hgkj.model.dao.AttendanceDao;
import com.hgkj.model.entity.Attendance;
import com.hgkj.model.entity.Department;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
@Repository
@Transactional
public class AttendanceDaoImpl implements AttendanceDao {
@Autowired
private SessionFactory sessionFactory;
    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }
    public Session session(){
        return sessionFactory.getCurrentSession();
    }
    @Override
    public List<Attendance> allattendanceDao() {
        String hql="from Attendance ";
        List<Attendance> list=session().createQuery(hql).list();
        return list;
    }

    @Override
    public boolean insertattendanceDao(Attendance attendance) {
        boolean b=false;
        session().save(attendance);
        b=true;
        return b;
    }

    @Override
    public boolean deleteattendanceDao(int id) {
        boolean a=false;
        String hql="delete Attendance where attId=?";
        int b=session().createQuery(hql).setParameter(0,id).executeUpdate();
        if (b!=0){
            a=true;
        }
        return a;
    }

    @Override
    public boolean updateattendanceDao(Attendance attendance) {
        boolean a=false;
        String hql="update Attendance set attName=?,attPercent=? where attId=?";
        int b=session().createQuery(hql).setParameter(0,attendance.getAttName()).setParameter(1,attendance.getAttPercent()).setParameter(2,attendance.getAttId()).executeUpdate();
        if (b!=0){
            a=true;
        }
        return a;
    }

    @Override
    public Attendance getattendanceByIdDao(int id) {
        String hql="from Attendance where attId=?";
        Attendance attendance=(Attendance) session().createQuery(hql).setParameter(0,id).uniqueResult();
        return attendance;
    }
}
