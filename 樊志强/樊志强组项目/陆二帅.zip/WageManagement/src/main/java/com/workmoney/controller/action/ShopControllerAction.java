package com.workmoney.controller.action;

import com.workmoney.model.entity.Shop;
import com.workmoney.model.service.ShopService;
import org.apache.struts2.ServletActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import javax.servlet.http.HttpSession;
import java.util.List;

/**
 * user@Bright Rain .
 * 2019/6/29.
 */
@ParentPackage("struts-default")
@Namespace("/")
@Controller
public class ShopControllerAction {

    @Autowired
    private ShopService shopService;

    private Shop shop;


    @Action(value = "/addshopAction",results = {@Result(name = "success",type = "redirectAction",location = "getAllShopAction")})
    public String addshopAction(){
        shopService.addShopService(shop);
        return "success";
    }


    /**
     * 保存修改
     * @return
     */
    @Action(value = "/editshopAction",results = {@Result(name = "success",type = "redirectAction",location = "getAllShopAction")})
    public String editshopAction(){
        shopService.updateShopByIdService(shop);
        return "success";
    }

    /**
     * 去往修改
     * @return
     */
    @Action(value = "/goEditshopByIdAction",results = {@Result(name = "success",type = "redirect",location = "html/ShopEdit.jsp")})
    public String goEditshopByIdAction(){
        Shop shopByIdService = shopService.getShopByIdService(shop);
        HttpSession session = ServletActionContext.getRequest().getSession();
        session.setAttribute("shop",shopByIdService);
        return "success";
    }

    /**
     * 删除
     * @return
     */
    @Action(value = "/delshopByIdAction",results = {@Result(name = "success",type = "redirectAction",location = "getAllShopAction")})
    public String delshopByIdAction(){
        shopService.delShopByIdService(shop);
        return "success";
    }

    /**
     * 查询所有
     * @return
     */
    @Action(value = "/getAllShopAction",results = {@Result(name = "success",type = "redirect",location = "html/ShopList.jsp")})
    public String getAllShopAction(){
        HttpSession session = ServletActionContext.getRequest().getSession();
        List<Shop> shopList = shopService.getAllShopService();
        session.setAttribute("shopList",shopList);
        return "success";
    }

    public Shop getShop() {
        return shop;
    }

    public void setShop(Shop shop) {
        this.shop = shop;
    }
}
