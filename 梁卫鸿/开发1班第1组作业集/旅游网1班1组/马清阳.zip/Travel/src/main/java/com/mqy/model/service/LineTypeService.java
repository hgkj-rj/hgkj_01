package com.mqy.model.service;

import com.mqy.model.entity.Linetype;

import java.util.List;

public interface LineTypeService {
    /**
     * 查询所有线路类型
     * @return
     */
    public List<Linetype> allLineTypeService();

    /**
     * 添加线路类型
     * @param linetype
     * @return
     */
    public void addLineTypeService(Linetype linetype);

    /**
     * 删除线路类型
     * @param lineTypeId
     * @return
     */
    public void deleteLineTypeService(String lineTypeId);

    /**
     * 修改线路类型
     * @param linetype
     * @return
     */
    public void updateLineTypeService(Linetype linetype);

    /**
     * 获取线路类型
     * @param lineTypeId
     * @return
     */
    public Linetype getLineTypeService(String lineTypeId);
}
