package com.xl.model.service.impl;

import com.xl.model.dao.PayDao;
import com.xl.model.dao.impl.PayDaoImpl;
import com.xl.model.entity.Pay;
import com.xl.model.service.PayService;

import java.util.List;

public class PayServiceImpl implements PayService {
    private PayDao PayDao=new PayDaoImpl();
    @Override
    public int PayService(int pageSize) {
        return  PayDao.PayDao(pageSize);
    }

    @Override
    public List<Pay> allPayService(int pageIndex, int pageSize) {
        return PayDao.allPayDao(pageIndex,pageSize);
    }

    @Override
    public int getPayByIdService(int PayId) {
        return PayDao.getPayByIdDao(PayId);
    }

    @Override
    public boolean addPayService(Pay pay) {
        return PayDao.addPayDao(pay);
    }

    @Override
    public boolean deleteService(Pay pay){
    return PayDao.deletePayDao(pay);
    }

    @Override
    public boolean updatePayService(Pay pay) {

        return PayDao.updatePayDao(pay);
    }
}
