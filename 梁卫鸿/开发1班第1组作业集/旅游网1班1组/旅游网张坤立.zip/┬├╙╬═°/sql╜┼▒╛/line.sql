/*
 Navicat Premium Data Transfer

 Source Server         : Mysql
 Source Server Type    : MySQL
 Source Server Version : 50724
 Source Host           : localhost:3306
 Source Schema         : travel

 Target Server Type    : MySQL
 Target Server Version : 50724
 File Encoding         : 65001

 Date: 08/07/2019 09:53:57
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for line
-- ----------------------------
DROP TABLE IF EXISTS `line`;
CREATE TABLE `line`  (
  `lineID` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '线路编号，主键',
  `lineTypeID` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '线路类型编号，外键',
  `lineName` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '线路名称',
  `days` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '出游天数',
  `vehicle` char(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '出游交通工具',
  `introduction` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '线路简介',
  `reason` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '线路推荐理由',
  `arrange` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '线路行程安排',
  `price` decimal(10, 2) NOT NULL COMMENT '线路价格',
  `teamBuy` int(255) NULL DEFAULT NULL COMMENT '是否为团购线路，值为1时表示为团购线路',
  `teamBuyPrice` decimal(10, 2) NULL DEFAULT NULL COMMENT '线路团购价格',
  `beginTime` datetime(0) NULL DEFAULT NULL COMMENT '线路团购开始时间',
  `endTime` datetime(0) NULL DEFAULT NULL COMMENT '线路团购结束时间',
  `onTime` datetime(0) NOT NULL COMMENT '线路添加时间',
  PRIMARY KEY (`lineID`) USING BTREE,
  INDEX `lineTypeID`(`lineTypeID`) USING BTREE,
  CONSTRAINT `FK_LINE_LINETYPE` FOREIGN KEY (`lineTypeID`) REFERENCES `linetype` (`lineTypeID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of line
-- ----------------------------
INSERT INTO `line` VALUES ('1', '1', '线路1', '10', '火车', '线路1简介', '好', '线路1安排', 1000.00, 1, 800.00, '2019-06-03 16:06:50', '2019-06-06 16:06:58', '2019-06-26 16:07:09');
INSERT INTO `line` VALUES ('2', '1', '线路2', '10', '飞机', '线路2简介', '好', '线路2安排', 2000.00, 0, 1850.00, '2019-06-27 14:41:53', '2019-06-29 14:41:59', '2019-06-27 14:41:57');
INSERT INTO `line` VALUES ('3', '1', '线路3', '10', '自行车', '线路3简介', '好', '线路3安排', 3000.00, 1, 2800.00, '2019-06-28 08:41:58', '2019-06-30 08:42:00', '2019-06-28 08:42:05');

SET FOREIGN_KEY_CHECKS = 1;
