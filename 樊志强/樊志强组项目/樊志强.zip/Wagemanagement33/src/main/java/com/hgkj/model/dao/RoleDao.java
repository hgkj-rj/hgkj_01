package com.hgkj.model.dao;

import com.hgkj.model.entity.Role;
import java.util.List;

public interface RoleDao {
    //查询所有角色类别
    public List<Role> allroleDao();
    //添加角色类别
    public boolean insertroleDao(Role role);
    //删除角色类别
    public boolean deleteroleDao(int id);
    //修改角色类别
    public boolean updateroleDao(Role role);
    //根据Id获取角色信息
    public Role getroleByIdDao(int id);
}
