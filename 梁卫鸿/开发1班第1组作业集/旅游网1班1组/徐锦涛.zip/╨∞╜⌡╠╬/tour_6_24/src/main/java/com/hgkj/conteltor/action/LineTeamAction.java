package com.hgkj.conteltor.action;

import com.hgkj.model.entity.Line;
import com.hgkj.model.service.LineTeamService;
import org.apache.struts2.ServletActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import java.util.List;

@Controller
@Namespace("/")
@ParentPackage("json-default")
public class LineTeamAction {
    @Autowired
    private LineTeamService lineTeamService;
    private Line line;
    private String message;

    public LineTeamService getLineTeamService() {
        return lineTeamService;
    }

    public void setLineTeamService(LineTeamService lineTeamService) {
        this.lineTeamService = lineTeamService;
    }
    @Action(value = "lineTeamAllAction",results = @Result(name = "all",type = "redirect",location = "ht/teamLineShow.jsp"))
    public String lineTeamAllAction(){
        List<Line> lineList=lineTeamService.lineTeamAllService();
        ServletActionContext.getRequest().getSession().setAttribute("lineList",lineList);
        return "all";
    }
    @Action(value = "TeamAllAction",results = @Result(name = "all",type = "redirect",location = "ht/teamShow.jsp"))
    public String TeamAllAction(){
        List<Line> lineList=lineTeamService.lineTeamAllService();
        ServletActionContext.getRequest().getSession().setAttribute("lineList",lineList);
        return "all";
    }
    @Action(value = "lineTeamAddAction",results = @Result(name = "addsuccess",type = "redirect",location = "ht/_right.jsp"))
    public String lineTeamAddAction(){
            boolean rs=lineTeamService.lineTeamAddService(line);
            if(rs){
                return "addsuccess";
            }
            return "adderror";
    }
    @Action(value = "lineTeamDelAction",results = {@Result(name = "del",type = "json",params = {"root","message"})})
    public String lineTeamDelAction(){
        boolean rs= lineTeamService.lineTeamDeleteService(line.getLineID());
        if(rs){
            message="success";
            return "del";
        }
        return "delerror";
    }
    @Action(value = "lineTeamFindAction",results = {@Result(name = "find",type = "redirect",location = "ht/teamMessage.jsp")})
    public String lineTeamIdAction(){
        Line line1=lineTeamService.lineTeamIdService(line.getLineID());
        ServletActionContext.getRequest().getSession().setAttribute("line",line1);
        return "find";
    }
    @Action(value = "lineTeamUpdateAction",results = {@Result(name = "update",type = "redirectAction",params = {"actionName","lineTeamAllAction"})})
    public String lineTeamUpdateAction(){
        System.out.println("111111111111111"+line.getLineID());
            boolean rs=lineTeamService.lineTeamUpdateService(line);
            if(rs){
                return "update";
            }
            return "adderror";
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Line getLine() {
        return line;
    }

    public void setLine(Line line) {
        this.line = line;
    }
}
