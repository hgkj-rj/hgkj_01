package com.hgkj.model.service.impl;

import com.hgkj.model.dao.AwardDao;
import com.hgkj.model.entity.RewardLog;
import com.hgkj.model.service.AwardService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public class AwardServiceImpl implements AwardService {
    @Autowired
    private AwardDao awardDao;

    @Override
    public List<RewardLog> allRewardLogList() {
        return awardDao.allRewardLogList();
    }

    @Override
    public boolean addRewardList(RewardLog rewardLog) {
        return awardDao.addRewardList(rewardLog);
    }

    @Override
    public boolean delRewardList(RewardLog rewardLog) {
        return awardDao.delRewardList(rewardLog);
    }

    @Override
    public boolean updRewardList(RewardLog rewardLog) {
        return awardDao.updRewardList(rewardLog);
    }

    @Override
    public RewardLog onlyRewardList(RewardLog rewardLog) {
        return awardDao.onlyRewardList(rewardLog);
    }
}
