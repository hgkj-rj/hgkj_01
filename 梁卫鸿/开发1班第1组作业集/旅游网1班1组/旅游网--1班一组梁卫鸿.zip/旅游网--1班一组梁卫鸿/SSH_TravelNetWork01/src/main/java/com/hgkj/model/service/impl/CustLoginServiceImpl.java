package com.hgkj.model.service.impl;

import com.hgkj.model.dao.CustLoginDao;
import com.hgkj.model.entity.Customer;
import com.hgkj.model.service.CustLoginService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CustLoginServiceImpl implements CustLoginService {
    @Autowired
    private CustLoginDao custLoginDao;

    public void setCustLoginDao(CustLoginDao custLoginDao) {
        this.custLoginDao = custLoginDao;
    }

    @Override
    public Customer custLoginService(Customer customer) {
        return custLoginDao.custLoginDao(customer);
    }

    @Override
    public boolean custRegisterService(Customer customer) {
        return custLoginDao.custRegisterDao(customer);
    }
}
