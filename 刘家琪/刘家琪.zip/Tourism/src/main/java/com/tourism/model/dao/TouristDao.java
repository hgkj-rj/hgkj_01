package com.tourism.model.dao;

public interface TouristDao {
}
