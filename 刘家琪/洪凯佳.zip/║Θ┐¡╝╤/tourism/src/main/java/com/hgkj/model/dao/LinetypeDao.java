package com.hgkj.model.dao;


import com.hgkj.model.entity.Linetype;

import java.util.List;

public interface LinetypeDao {
    public List<Linetype> allLinetypeDao();
    public boolean addLinetypeDao(Linetype linetype);
    public boolean deleteLinetypeDao(Linetype linetype);
    public boolean updateLinetypeDao(Linetype linetype);
    public Linetype getLinetypeByIdDao(String lineTypeId);
}
