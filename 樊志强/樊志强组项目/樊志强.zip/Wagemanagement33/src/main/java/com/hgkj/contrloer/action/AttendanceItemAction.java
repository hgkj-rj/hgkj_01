package com.hgkj.contrloer.action;


import com.hgkj.model.entity.Attendance;
import com.hgkj.model.entity.Attendance;
import com.hgkj.model.service.AttendanceItemService;
import com.opensymphony.xwork2.ActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import java.util.List;

@Controller
@Namespace("/")
@ParentPackage("struts-default")
public class AttendanceItemAction {
    @Autowired
    private AttendanceItemService attendanceItemService;
    private Attendance attendance;


    @Action(value = "allAttendance",results = @Result(name = "true",type = "redirect",location = "html/attendanceItemList.jsp"))
    public String allAttendance(){
        List<Attendance> AttendanceList =attendanceItemService.allAttendance();
        ActionContext.getContext().getSession().put("AttendanceList",AttendanceList);
        return "true";
    }

    @Action(value = "addAttendance",results = @Result(name = "true",type = "redirectAction",location = "allAttendance.action"))
    public String addAttendance(){
        attendanceItemService.addAttendance(attendance);
        return "true";
    }

    @Action(value = "delAttendance",results = @Result(name = "true",type = "redirectAction",location = "allAttendance.action"))
    public String delAttendance(){
        attendanceItemService.delAttendance(attendance);
        return "true";
    }

    @Action(value = "onlyAttendance",results = @Result(name = "true",type = "redirect",location = "html/attendanceItemEdit.jsp"))
    public String onlyAttendance(){
        Attendance Attendance = attendanceItemService.queryAttendance(attendance);
        ActionContext.getContext().getSession().put("onlyAttendance",Attendance);
        return "true";
    }

    @Action(value = "updAttendance",results = @Result(name = "true",type = "redirectAction",location = "allAttendance.action"))
    public String updAttendance(){
        attendanceItemService.updAttendance(attendance);
        return "true";
    }
    

    public Attendance getAttendance() {
        return attendance;
    }

    public void setAttendance(Attendance attendance) {
        this.attendance = attendance;
    }
}
