package com.hgkj.model.service;

import com.hgkj.model.entity.Attendance;

import java.util.List;

public interface AttendanceItemService {

    public List<Attendance> allAttendance();

    public boolean  addAttendance(Attendance Attendance);

    public boolean  delAttendance(Attendance Attendance);

    public boolean updAttendance(Attendance Attendance);

    public Attendance queryAttendance(Attendance Attendance);
}
