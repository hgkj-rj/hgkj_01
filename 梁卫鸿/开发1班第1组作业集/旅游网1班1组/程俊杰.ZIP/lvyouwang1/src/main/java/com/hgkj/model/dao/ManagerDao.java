package com.hgkj.model.dao;

import com.hgkj.model.entity.Customer;

public interface ManagerDao {
    public boolean managerloginDao(Customer customer);
}
