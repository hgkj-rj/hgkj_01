package com.hgkj.model.dao;

import com.hgkj.model.entity.Customer;

import java.util.List;

public interface CustomerDao {
    public List<Customer> CustomerLoginDao(Customer customer);
    public boolean CustomerAddDao(Customer customer);
}
