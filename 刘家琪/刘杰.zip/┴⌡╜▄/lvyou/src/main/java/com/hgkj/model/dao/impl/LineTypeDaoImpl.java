package com.hgkj.model.dao.impl;

import com.hgkj.model.dao.LineTypeDao;
import com.hgkj.model.entity.Linetype;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
@Transactional
public class LineTypeDaoImpl implements LineTypeDao {
    @Autowired
    private SessionFactory sessionFactory;
    private Session session;

    /*添加路线*/
    @Override
    public boolean addLineTypeDao(Linetype linetype) {
        boolean result=false;
        try {
            this.sessionFactory.getCurrentSession().save(linetype);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

    /*查询所有*/
    @Override
    public List<Linetype> allLineTypeDao() {
        Session session = sessionFactory.openSession();
        List<Linetype> lineList =  session.createQuery("from Linetype ").list();
        return lineList;
    }
    /*删除*/
    @Override
    public boolean deleteLineTypeDao(Integer id) {
        boolean result = false;
        Session session = sessionFactory.openSession();
        Transaction transaction = session.beginTransaction();
        Linetype linetype =session.get(Linetype.class,id);
        try {
            session.delete(linetype);
            transaction.commit();
            result = true;
        }catch (Exception e){
            e.printStackTrace();
            transaction.rollback();
        }
        return result;
    }
    /*查询单个*/
    @Override
    public Linetype getOneLineTypeDao(Integer id) {
        Session session = sessionFactory.openSession();
        System.out.println(id);
        Linetype linetype =  (Linetype)session.createQuery("from Linetype where lineTypeId=?").setInteger(0,id).uniqueResult();
        return linetype;
    }
    /*更新*/
    @Override
    public boolean updateLineTypeDao(Linetype linetype) {
        Session session= sessionFactory.openSession();
        Transaction transaction=session.beginTransaction();
        session.update(linetype);
        transaction.commit();
        session.close();
        return true;
    }
    /*得到图片*/
    @Override
    public String getIconLineTypeDao(Integer id) {
        Session session = sessionFactory.openSession();
        String icon =  (String)session.createQuery("select icon from Linetype where lineTypeId=?").setInteger(0,id).uniqueResult();
        return icon;
    }

    /*得到所有的路线类型*/
    @Override
    public List<Linetype> getTypeNameDao() {
        Session session = sessionFactory.openSession();
        Query query = session.createQuery("select typeName from Linetype");
        List<Linetype> linetypeList = query.list();
        System.out.println(linetypeList.size());
        return linetypeList;
    }

    @Override
    public List<Linetype> ShowTypeNameDao() {
        Session session = sessionFactory.openSession();
        Query query = session.createQuery("from Linetype where show=?").setParameter(0,"显示");
        List<Linetype> linetypeList = query.list();
        System.out.println(linetypeList.size());
        return linetypeList;
    }


    public SessionFactory getSessionFactory() {
        return sessionFactory;
    }

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    public Session getSession() {
        return session;
    }

    public void setSession(Session session) {
        this.session = session;
    }


}
