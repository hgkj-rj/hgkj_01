package com.hgkj.contrloer.action;

import com.hgkj.model.entity.Reward;
import com.hgkj.model.entity.RewardLog;
import com.hgkj.model.entity.Staff;
import com.hgkj.model.service.AwardService;
import com.hgkj.model.service.RewardService;
import com.hgkj.model.service.StaffService;
import com.opensymphony.xwork2.ActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import java.util.List;

@Controller
@Namespace("/")
@ParentPackage("struts-default")
public class AwardAction {
    @Autowired
    private AwardService awardService;
    @Autowired
    private StaffService staffService;
    @Autowired
    private RewardService rewardService;
    
    private RewardLog rewardLog;


    @Action(value = "allAward",results = @Result(name = "true",type = "redirect",location = "html/awardList.jsp"))
    public String allAward(){
        List<RewardLog> rewardLogs = awardService.allRewardLogList();
        ActionContext.getContext().getSession().put("rewardLogs",rewardLogs);
        return "true";
    }


    @Action(value = "addaAward",results = @Result(name = "true",type = "redirect",location = "html/awardAdd.jsp"))
    public String addaAward(){
        List<Staff> staffList = staffService.staffList();
        ActionContext.getContext().getSession().put("staffList",staffList);
        List<Reward> rewardList = rewardService.allReward();
        ActionContext.getContext().getSession().put("rewardList",rewardList);
        return "true";
    }

    @Action(value = "addAward",results = @Result(name = "true",type = "redirectAction",location = "allAward"))
    public String addAward(){
        int rewId = rewardLog.getReward().getRewId();
        List<Reward> rewards = rewardService.allReward();
        for(Reward r:rewards){
            if(rewId==r.getRewId()){
                rewardLog.setRewPrice(r.getRewPrice());
            }
        }
        awardService.addRewardList(rewardLog);
        return "true";
    }

    @Action(value = "delAward",results = @Result(name = "true",type = "redirectAction",location = "allAward"))
    public String delAward(){
     awardService.delRewardList(rewardLog);
        return "true";
    }

    @Action(value = "updAward",results = @Result(name = "true",type = "redirectAction",location = "allAward"))
    public String updAward(){
        System.out.println(rewardLog+"----------------------------------");
        int rewId = rewardLog.getReward().getRewId();
        List<Reward> rewards = rewardService.allReward();
        for(Reward r:rewards){
            if(rewId==r.getRewId()){
                rewardLog.setRewPrice(r.getRewPrice());
            }
        }
        awardService.updRewardList(rewardLog);
        return "true";
    }

    @Action(value = "onlyAward",results = @Result(name = "true",type = "redirect",location = "html/awardEdit.jsp"))
    public String onlyAward(){
        RewardLog rewardLog = awardService.onlyRewardList(this.rewardLog);
        ActionContext.getContext().getSession().put("rewardLog",rewardLog);
        List<Staff> staffList = staffService.staffList();
        ActionContext.getContext().getSession().put("staffList",staffList);
        List<Reward> rewardList = rewardService.allReward();
        ActionContext.getContext().getSession().put("rewardList",rewardList);
        return "true";
    }






    public RewardLog getRewardLog() {
        return rewardLog;
    }

    public void setRewardLog(RewardLog rewardLog) {
        this.rewardLog = rewardLog;
    }
}
