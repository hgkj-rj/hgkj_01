package com.hgkj.controller.action;

import com.hgkj.model.entity.Level;
import com.hgkj.model.service.LevelService;
import com.opensymphony.xwork2.ActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import java.util.List;

@Controller
@Namespace("/")
@ParentPackage("struts-default")
public class LevelAction {
    public int levelId;
    private Level level;

    @Autowired
    public LevelService levelService;

    public void setLevelService(LevelService levelService) {
        this.levelService = levelService;
    }

    @Action(value = "allLeveldao",results =
            {@Result(name = "all",type = "redirect",location = "html/LevelList.jsp")})
    public String allLeveldao(){
        List<Level>levelList = levelService.allLevelService();
        ActionContext.getContext().getSession().put("levelList",levelList);
        return "all";
    }



}
