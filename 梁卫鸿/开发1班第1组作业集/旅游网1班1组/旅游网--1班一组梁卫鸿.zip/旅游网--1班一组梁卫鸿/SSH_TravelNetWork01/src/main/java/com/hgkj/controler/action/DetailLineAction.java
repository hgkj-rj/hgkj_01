package com.hgkj.controler.action;

import com.hgkj.model.entity.Line;
import com.hgkj.model.entity.Picture;
import com.hgkj.model.service.DetailLineService;
import org.apache.struts2.ServletActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

@Controller
@Namespace("/")
@ParentPackage("json-default")
public class DetailLineAction {
    @Autowired
    private DetailLineService detailLineService;
    private Line line;
    private Picture picture;

    public DetailLineService getDetailLineService() {
        return detailLineService;
    }

    public void setDetailLineService(DetailLineService detailLineService) {
        this.detailLineService = detailLineService;
    }
    @Action(value = "detailGroupLineFindAction",results = {@Result(name = "find",type = "redirect",location = "qt/detailGroup.jsp")})
    public String detailGroupLineIdAction(){
        Line line1=detailLineService.lineIdDao(line.getLineId());
        Picture picture1=detailLineService.imagesIdService(picture.getPictureId());
        ServletActionContext.getRequest().getSession().setAttribute("line",line1);
        ServletActionContext.getRequest().getSession().setAttribute("picture",picture1);
        return "find";
    }
    @Action(value = "detailLineFindAction",results = {@Result(name = "find",type = "redirect",location = "qt/detail.jsp")})
    public String detailLineIdAction(){
        Line line1=detailLineService.lineIdDao(line.getLineId());
        Picture picture1=detailLineService.imagesIdService(picture.getPictureId());
        ServletActionContext.getRequest().getSession().setAttribute("line",line1);
        ServletActionContext.getRequest().getSession().setAttribute("picture",picture1);
        return "find";
    }

    public Line getLine() {
        return line;
    }

    public void setLine(Line line) {
        this.line = line;
    }

    public Picture getPicture() {
        return picture;
    }

    public void setPicture(Picture picture) {
        this.picture = picture;
    }
}
