package com.hgkj.model.service;

import com.hgkj.model.entity.Line;

import java.util.List;

public interface LineTeamService {
    public boolean lineTeamAddService(Line line);
    public List<Line> lineTeamAllService();
    public boolean lineTeamDeleteService(String lineId);
    public Line lineTeamIdService(String lineId);
    public boolean lineTeamUpdateService(Line line);
}
