package com.hgkj.contrloer.action;

import com.hgkj.model.entity.Attendance;
import com.hgkj.model.entity.AttendanceLog;
import com.hgkj.model.entity.Department;
import com.hgkj.model.entity.Staff;
import com.hgkj.model.service.AttendanceService;
import com.opensymphony.xwork2.ActionContext;
import org.apache.struts2.ServletActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import java.util.List;

@Controller
@Namespace("/")
@ParentPackage("struts-default")
public class AttendanceAction {
    @Autowired
    private AttendanceService attendanceService;
    private AttendanceLog attendanceLog;

    public AttendanceLog getAttendanceLog() {
        return attendanceLog;
    }
    public void setAttendanceLog(AttendanceLog attendanceLog) {
        this.attendanceLog = attendanceLog;
    }
    public void setAttendanceService(AttendanceService attendanceService) {
        this.attendanceService = attendanceService;
    }

    @Action(value = "allAttendances",results = {@Result(name = "allAttendances",type = "redirect",location = "/html/attendanceList.jsp")})
    public String allAttendance(){
        System.out.println("员工考勤查询");
        List<AttendanceLog>attendanceLogList=attendanceService.allAttendanceLogService();
        ServletActionContext.getRequest().getSession().setAttribute("attendanceLogList",attendanceLogList);
        List<Staff>staffList=attendanceService.allStaffService();
        ServletActionContext.getRequest().getSession().setAttribute("staffList",staffList);
        List<Attendance>attendanceList=attendanceService.allAttendanceService();
        ServletActionContext.getRequest().getSession().setAttribute("attendanceList",attendanceList);
        return "allAttendances";
    }

    @Action(value = "addAttendanceLogs",results = {@Result(name = "adds",type = "redirectAction",params = {"actionName","allAttendances"})})
    public String addAttendance(){
        System.out.println("-------添加考勤记录--------");
        boolean r=attendanceService.addAttendanceLogService(attendanceLog);
        if (r==true){
            return "adds";
        }else {
            return "adde";
        }
    }

    @Action(value = "delAttendanceLog",results = @Result(name = "dels",type = "redirectAction",params = {"actionName","allAttendances"}))
    public String deleteAttendanceLog(){
        boolean r=attendanceService.deleteAttendanceLogService(attendanceLog.getAttenlogId());
        if (r==true){
            return "dels";
        }else {
            return "dele";
        }
    }

    @Action(value = "updAttendanceLog",results = @Result(name = "upds",type = "redirectAction",params = {"actionName","allAttendances"}))
    public String UpdAttendanceLog(){
        System.out.println("---------修改考勤--------");
        boolean r=attendanceService.updateAttendanceLogService(attendanceLog);
        if (r==true){
            return "upds";
        }else {
            return "upde";
        }
    }

    @Action(value = "getByIdAttendanceLogs",results = {@Result(name = "getByIds",type = "redirect",location = "/html/attendanceUpdate.jsp")})
    public String getByIdAttendanceLog(){
        System.out.println("---------根据考勤ID查询--------");
        AttendanceLog attendanceLog1=attendanceService.getByIdAttendanceService(attendanceLog.getAttenlogId());
        ServletActionContext.getRequest().getSession().setAttribute("attendanceLog1",attendanceLog1);
        List<Staff>staffList=attendanceService.allStaffService();
        ServletActionContext.getRequest().getSession().setAttribute("staffList",staffList);
        List<Attendance>attendanceList=attendanceService.allAttendanceService();
        ServletActionContext.getRequest().getSession().setAttribute("attendanceList",attendanceList);
        return "getByIds";
    }

    @Action(value = "alladdAttend",results = @Result(name = "alladdAttend",type = "redirect",location = "/html/salaryAttendanceInfo.jsp"))
    public String alladdAttend(){
        List<AttendanceLog> AttendanceLogList=attendanceService.AttendanceLogService(attendanceLog);
        ActionContext.getContext().getSession().put("AttendanceLogList",AttendanceLogList);
        List<Staff> staffs=attendanceService.allStaffService();
        ActionContext.getContext().getSession().put("staffs",staffs);
        List<Attendance> attendances=attendanceService.allAttendanceService();
        ActionContext.getContext().getSession().put("attendances",attendances);
        return "alladdAttend";
    }
}
