package com.hjh.model.service.Impl;

import com.hjh.model.dao.PictureDao;
import com.hjh.model.entity.Line;
import com.hjh.model.entity.Picture;
import com.hjh.model.service.PictureService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class PictureSeviceImpl implements PictureService {
    @Autowired
    private PictureDao pictureDao;

    public PictureDao getPictureDao() {
        return pictureDao;
    }

    public void setPictureDao(PictureDao pictureDao) {
        this.pictureDao = pictureDao;
    }

    @Override
    public List<Picture> Allpicture(Line line) {
        return pictureDao.Allpicture(line);
    }

    @Override
    public boolean Addpicture(Picture picture) {
        return pictureDao.Addpicture(picture);
    }

    @Override
    public boolean UPpicture(Picture picture) {
        return pictureDao.UPpicture(picture);
    }
}
