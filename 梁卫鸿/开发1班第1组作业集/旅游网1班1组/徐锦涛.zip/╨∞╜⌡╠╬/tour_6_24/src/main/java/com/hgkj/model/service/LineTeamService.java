package com.hgkj.model.service;

import com.hgkj.model.entity.Line;

import java.util.List;

public interface LineTeamService {
    public boolean lineTeamAddService(Line line);
    public List<Line> lineTeamAllService();
    public boolean lineTeamDeleteService(String lineID);
    public Line lineTeamIdService(String lineID);
    public boolean lineTeamUpdateService(Line line);
}
