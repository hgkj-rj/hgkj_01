package com.workmoney.controller.action;

import com.workmoney.model.entity.Staff;
import com.workmoney.model.service.StaffService;
import com.workmoney.util.SercharStaff;
import com.workmoney.util.SercharStaffUpload;
import javafx.application.Application;
import org.apache.struts2.ServletActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Controller;

import javax.servlet.http.HttpSession;
import java.util.List;

/**
 * user@Bright Rain .
 * 2019/6/24.
 */
@ParentPackage("struts-default")
@Namespace("/")
@Controller
public class StaffControllerAction {

    @Autowired
    private StaffService service;

    private Staff staff;

    private SercharStaff sercharStaff;

    //退出

    @Action(value = "staffLogOutAction",results = {@Result(name = "success",type = "redirect",location = "login.jsp"),
            @Result(name = "error",type = "redirect",location = "error.jsp")})
    public String staffLogOutAction(){
        try {
            HttpSession session = ServletActionContext.getRequest().getSession();
            session.invalidate();
            session.setAttribute("flush",1);
            return "success";
        } catch (Exception e) {
            e.printStackTrace();
            return "error";
        }


    }

    //模糊查询员工
    @Action(value = "sercharStaffAction",results = {@Result(name = "success",type = "redirect",location = "html/salarySearch.jsp"),
     @Result(name = "default",type = "redirect",location = "error.jsp")
    })
    public String sercharStaffs(){
        HttpSession session = ServletActionContext.getRequest().getSession();
      List<Staff> sercharStaffList =   service.sercharStaffByNameAndMonth(sercharStaff);
        session.setAttribute("staffList",sercharStaffList);
        return "success";
    }

    //查询员工的工资
    @Action(value  ="/SearchForWagesAction",results = {@Result(name = "success",type = "redirect",location = "html/salarySearch.jsp")})
    public String SearchForWagesAction(){
        HttpSession session = ServletActionContext.getRequest().getSession();
        List<Staff> staffList = service.getStaffListSercharService();
        System.out.println("=======查询所有员工========");
        if(staffList==null){
            System.out.println("查询失败");
        }else {
            session.setAttribute("staffList",staffList);
        }
        return "success";
    }
       //修改密码
    @Action(value = "/updateStaffPwdByIdAction",results = {@Result(name = "faild",type = "redirect",location = "main.jsp"),
    @Result(name = "success",type = "redirect",location = "/login.jsp")})
    public String updateStaffPwdByIdAction(){
        HttpSession session = ServletActionContext.getRequest().getSession();
        Staff staffc = (Staff) session.getAttribute("staff");
        staff.setStaffId(staffc.getStaffId());
        staff.setStaffName(staffc.getStaffName());
        staff.setStaffSex(staffc.getStaffSex());
        staff.setStaffAddress(staffc.getStaffAddress());
        staff.setStaffTel(staffc.getStaffTel());
        staff.setStaffEmail(staffc.getStaffEmail());
        staff.setStaffState(staffc.getStaffState());
        staff.setLevelId(staffc.getLevelId());
        staff.setRolesId(staffc.getRolesId());
        staff.setShopId(staffc.getShopId());
        staff.setDepId(staffc.getDepId());
        Staff staff = service.updateStaffPwdByIdService(this.staff);

        System.out.println("=======修改密码========");
        if(staff==null){
            System.out.println("=======修改密码失败========");
            return "faild";
        }else {
            session.setAttribute("msg","修改密码成功，请重新登陆");
            return "success";
        }

    }

    /**
     * 用户登录
     * @return
     */
    @Action(value = "staffLoginAction",results = {@Result(name = "stafflogin",type = "redirect",location = "main.jsp")
            ,@Result(name = "faild",type = "redirect",location = "login.jsp")})
    public String staffLogin(){
        Staff staff = service.staffLoginService(this.staff);
        HttpSession session = ServletActionContext.getRequest().getSession();
        if(staff==null){
            session.setAttribute("msg","登陆失败");
            System.out.println("========登陆失败==========");
            return "faild";
        }
        session.setAttribute("staff",staff);
        System.out.println("========登陆成功==========");
        return "stafflogin";
    }

    public Staff getStaff() {
        return staff;
    }

    public void setStaff(Staff staff) {
        this.staff = staff;
    }

    public SercharStaff getSercharStaff() {
        return sercharStaff;
    }

    public void setSercharStaff(SercharStaff sercharStaff) {
        this.sercharStaff = sercharStaff;
    }
}
