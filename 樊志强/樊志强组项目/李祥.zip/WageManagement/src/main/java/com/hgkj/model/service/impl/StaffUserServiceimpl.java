package com.hgkj.model.service.impl;

import com.hgkj.model.dao.StaffUserdao;
import com.hgkj.model.dao.impl.StaffUserdaoimpl;
import com.hgkj.model.entity.Staff;
import com.hgkj.model.service.StaffUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class StaffUserServiceimpl implements StaffUserService {
    @Autowired
    private StaffUserdao staffUserdao;

    public void setStaffUserdao(StaffUserdao staffUserdao) {
        this.staffUserdao = staffUserdao;
    }

    @Override
    public List<Staff> loginUserService(Staff staff) {
        return staffUserdao.loginUserDao(staff);
    }

    @Override
    public boolean updateResetpassService(Staff staff) {
        return staffUserdao.updateResetpassdao(staff);
    }
}
