package com.hjh.model.service.Impl;

import com.hjh.model.dao.LineDao;
import com.hjh.model.entity.Line;
import com.hjh.model.service.LineService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class LineServiceImpl implements LineService {
    @Autowired
    LineDao lineDao;

    public void setLineDao(LineDao lineDao) {
        this.lineDao = lineDao;
    }

    public LineDao getLineDao() {
        return lineDao;
    }

    @Override
    public List<Line> AllLine() {
        return lineDao.AllLine();
    }

    @Override
    public boolean AddLine(Line line) {
        return lineDao.AddLine(line);
    }

    @Override
    public boolean UpingLine(Line line) {
        return lineDao.UpingLine(line);
    }

    @Override
    public Line GetLine(String lineid) {
        return lineDao.GetLine(lineid);
    }
}
