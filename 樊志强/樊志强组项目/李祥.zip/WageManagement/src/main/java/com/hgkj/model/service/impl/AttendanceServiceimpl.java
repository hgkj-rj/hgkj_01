package com.hgkj.model.service.impl;

import com.hgkj.model.dao.Attendancedao;
import com.hgkj.model.entity.Attendance;
import com.hgkj.model.service.AttendanceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AttendanceServiceimpl implements AttendanceService {
    @Autowired
   private Attendancedao attendancedao;

    public void setAttendancedao(Attendancedao attendancedao) {
        this.attendancedao = attendancedao;
    }

    @Override
    public List<Attendance> allAttendanceService() {
        return attendancedao.allAttendancedao();
    }

    @Override
    public boolean addAttendanceService(Attendance attendance) {
        return attendancedao.addAttendancedao(attendance);
    }

    @Override
    public boolean deleteAttendanceService(int attId) {
        return attendancedao.deleteAttendancedao(attId);
    }

    @Override
    public boolean updateAttendanceService(Attendance attendance) {
        return attendancedao.updateAttendancedao(attendance);
    }

    @Override
    public Attendance attendance(int attId) {
        return attendancedao.attendance(attId);
    }
}
