package com.hgkj.model.service;

import com.hgkj.model.entity.Staff;

import java.util.List;

public interface StaffinformationService {
    public Staff getByIdService(int staffId);
    public List<Staff> allStaffService();
    public boolean addStaffService(Staff staff);
    public boolean deleteStaffService(int staffId);
    public boolean updateStaffService(Staff staff);
}
