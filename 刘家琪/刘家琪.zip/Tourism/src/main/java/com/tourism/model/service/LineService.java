package com.tourism.model.service;

import com.tourism.model.entity.Line;

import java.util.List;

public interface LineService {
    public int gettotalpageService(int pagesize,String time);
    public List<Line> allLineService(int pageindex, int pagesize,String time);
    public List<Line> allLineService();
    public List<Line> allTuanGouLineService();
    public List<Line> toIndexLineService(String lineTypeId);
    public List<Line> yiLineService();
    public List<Line> erLineService();
    public List<Line> duoLineService();
    public boolean addLineService(Line line);
    public boolean updateLineService(Line line);
    public Line getLineByIdService(String lineId);
}
