package com.hgkj.model.dao;



import com.hgkj.model.entity.Car;

import java.util.List;

public interface CarDao {
    public List<Car> allCarDao();
    public boolean addCarDao(Car car);
    public boolean deleteCarDao(Car car);
    public boolean updateCarDao(Car car);
    public Car getCarByIdDao(String carId);
}
