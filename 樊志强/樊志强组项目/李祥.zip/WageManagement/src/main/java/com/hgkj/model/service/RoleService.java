package com.hgkj.model.service;

import com.hgkj.model.entity.Role;

import java.util.List;

public interface RoleService  {
    public List<Role> roleService();
}
