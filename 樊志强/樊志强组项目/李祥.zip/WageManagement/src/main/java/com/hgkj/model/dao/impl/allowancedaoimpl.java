package com.hgkj.model.dao.impl;

import com.hgkj.model.dao.allowancedao;
import com.hgkj.model.entity.Reward;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
@Transactional
public class allowancedaoimpl implements allowancedao {
    @Autowired
    public SessionFactory sessionFactory;


    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    private Session session(){
       return sessionFactory.getCurrentSession();
    }

    @Override
    public List<Reward> allRewardDao() {
        Query query = session().createQuery("from Reward ");
        return query.list();
    }

    @Override
    public boolean addRewardDao(Reward reward) {
        session().save(reward);
        return false;
    }

    @Override
    public boolean deleteRewardDao(int rewId) {
        Reward reward = session().get(Reward.class,rewId);
        session().delete(reward);
        return false;
    }

    @Override
    public boolean updateRewardDao(Reward reward) {
        session().update(reward);
        return false;
    }

    @Override
    public Reward reward(int rewId) {
        Reward reward = session().get(Reward.class,rewId);
        return reward;
    }
}
