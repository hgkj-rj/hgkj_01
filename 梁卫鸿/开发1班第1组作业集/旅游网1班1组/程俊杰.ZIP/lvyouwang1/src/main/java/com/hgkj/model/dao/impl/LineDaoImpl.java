package com.hgkj.model.dao.impl;

import com.hgkj.model.dao.LineDao;
import com.hgkj.model.entity.Line;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
@Transactional
public class LineDaoImpl implements LineDao {
    @Autowired
    private SessionFactory sessionFactory;


    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    public Session getSession() {
        return sessionFactory.getCurrentSession();
    }

    @Override
    public boolean insertLineDao(Line line) {
        boolean result = false;
//        Line line1 = new Line(line.getLineId(), line.getLineName(), line.getPrice(), line.getIntroduction(), line.getVehicle(),
//                line.getDays(), line.getArrange(), line.getReason(), line.getLinetype().getTypeName());
        try {
            getSession().save(line);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
        }
        return result;
    }

    @Override
    public List<Line> allLineDao() {
        Query query = getSession().createQuery("from Line ");
        return query.list();
    }

    @Override
    public boolean delLineDao(String lineId) {
        boolean result = false;
        try {
            getSession().delete(getSession().get(Line.class, lineId));
            return true;
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
        }
        return result;
    }


    @Override
    public boolean updLineDao(Line line) {
        boolean result = false;
//        Line line1 = getSession().get(Line.class, line.getLineId());
//        line1.setLineId(line.getLineId());
//        line1.setLineTypeId(line.getLineTypeId());
//        line1.set
        try {
            getSession().update(line);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
        }
        return result;
    }

    @Override
    public Line lineByIdDao(String lineId) {
        Line line = getSession().get(Line.class, lineId);
        return line;
    }

    @Override
    public Line teamByIdDao(String lineId) {
        Line line=getSession().get(Line.class,lineId);
        return line;
    }

    @Override
    public boolean updTeamDao(Line line) {
       boolean result=false;
        try {
            getSession().update(line);

            return true;
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
        }
        return result;
    }

    @Override
    public Line SetTeamByIdDao(String lineId) {
        Line line=getSession().get(Line.class,lineId);
        return line;
    }

    @Override
    public boolean setTeamMsgDao(Line line) {
        boolean result=false;
        try {
            getSession().update(line);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
        }
        return result;
    }


}
