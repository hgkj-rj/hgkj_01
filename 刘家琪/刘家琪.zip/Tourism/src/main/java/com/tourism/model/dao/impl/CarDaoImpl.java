package com.tourism.model.dao.impl;

import com.tourism.model.dao.CarDao;
import com.tourism.model.entity.*;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
@Transactional
public class CarDaoImpl implements CarDao {
    @Autowired
    private SessionFactory sessionFactory;

    private Session session;

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    public Session getSession(){
        return sessionFactory.getCurrentSession();
    }

    @Override
    public int gettotalpageDao(int pagesize, int customerId) {
        int totalpage = 0;
        Query query=this.getSession().createQuery("select count(*) from Car where customer.customerId=?").setParameter(0,customerId);
        totalpage=((Number)query.iterate().next()).intValue();
        return totalpage;
    }

    @Override
    public List<Car> allCarDao(int pageindex, int pagesize, int customerId) {
        String hql = "from Car where customer.customerId=?";
        List<Car> carList = getSession().createQuery(hql).setParameter(0,customerId).setFirstResult((pageindex-1)*pagesize).setMaxResults(pagesize).list();
        return carList;
    }

    @Override
    public boolean deleteCarDao(Car car) {
        boolean flag = false;
        session = getSession();
        try {
            session.delete(car);
            flag = true;
        }catch (Exception e){
            e.printStackTrace();
        }
        return flag;
    }

    @Override
    public boolean addCarDao(Car car) {
            boolean flag = false;
            session = getSession();
            Line line = (Line) session.load(Line.class,car.getLine().getLineId());
            car.setLine(line);
            Customer customer = (Customer) session.load(Customer.class,car.getCustomer().getCustomerId());
            car.setCustomer(customer);
            try {
                session.save(car);
                flag = true;
            }catch (Exception e){
                e.printStackTrace();
            }
            return flag;
        }
    }
