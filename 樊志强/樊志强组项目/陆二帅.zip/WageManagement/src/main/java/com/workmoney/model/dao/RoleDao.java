package com.workmoney.model.dao;

import com.workmoney.model.entity.Role;
import com.workmoney.model.entity.Staff;

import java.util.List;

/**
 * user@Bright Rain .
 * 2019/6/27.
 */
public interface RoleDao {
    /**
     * 获取所有的role
     * @return
     */
    List<Role> getAllRole();

    /**
     * 删除角色
     * @param role
     */
    void delRoleByIdDao(Role role);
    /**
     * 添加角色
     * @param role
     */
    void addRoleDao(Role role);

    List<Staff> serchNameAllowDao(String name);
}
