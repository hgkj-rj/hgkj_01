package com.hgkj.model.dao.impl;

import com.hgkj.model.dao.AttendanceDao;
import com.hgkj.model.entity.Attendance;
import com.hgkj.model.entity.AttendanceLog;
import com.hgkj.model.entity.Staff;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
@Transactional
public class AttendanceDaoImpl implements AttendanceDao {
    @Autowired
    private SessionFactory sessionFactory;
    private Transaction transaction;

    @Override
    public List<AttendanceLog> allAttendanceLogDao() {
        System.out.println("考勤Dao层");
        Query query=getSession().createQuery("from AttendanceLog");
        return query.list();
    }

    @Override
    public boolean addAttendanceLogDao(AttendanceLog attendanceLog) {
        boolean flag=false;
        try {
            getSession().save(attendanceLog);
            flag=true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return flag;
    }

    @Override
    public boolean deleteAttendanceLogDao(int attenlogId) {
        boolean flag=false;
        String hql="delete AttendanceLog where attenlogId=?";
        int num=getSession().createQuery(hql).setParameter(0,attenlogId).executeUpdate();
        if (num>0){
            flag=true;
        }
        return flag;
    }

    @Override
    public boolean updateAttendanceLogDao(AttendanceLog attendanceLog) {
        boolean flag=false;
        Session session = getSession();
        session.update(attendanceLog);
        return false;
    }

    @Override
    public AttendanceLog getByIdAttendanceDao(int attenlogId) {
        AttendanceLog attendanceLog=getSession().get(AttendanceLog.class,attenlogId);
        getSession().close();
        return attendanceLog;
    }

    @Override
    public List<Staff> allStaffDao() {
        Query query=getSession().createQuery("from Staff");
        return query.list();
    }

    @Override
    public List<Attendance> allAttendanceDao() {
        Query query=getSession().createQuery("from Attendance");
        return query.list();
    }

    @Override
    public List<AttendanceLog> AttendanceLogDao(AttendanceLog attendanceLog) {
        String hql="from AttendanceLog where staff.staffName=:name";
        List<AttendanceLog> logList=getSession().createQuery(hql).setParameter("name",attendanceLog.getStaff().getStaffName()).list();
        return logList;
    }


    public Transaction getTransaction() {
        return transaction;
    }

    public void setTransaction(Transaction transaction) {
        this.transaction = transaction;
    }

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    public Session getSession(){
        return sessionFactory.getCurrentSession();
    }
}
