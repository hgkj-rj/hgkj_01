package com.hgkj.model.service.impl;

import com.hgkj.model.dao.LineDao;
import com.hgkj.model.entity.Line;
import com.hgkj.model.entity.Picture;
import com.hgkj.model.service.LineService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public class LineServiceImpl implements LineService
{
    @Autowired
    private LineDao lineDao;

    @Override
    public boolean addLineService(Line line) {
        return lineDao.addLineDao(line);
    }

    @Override
    public int getLineIdService() {
        return lineDao.getLineIdDao();
    }

    @Override
    public boolean addPictureService(Picture picture) {
        return lineDao.addPictureDao(picture);
    }

    @Override
    public List<Line> allLineServcie() {
        return lineDao.allLineDao();
    }

    @Override
    public List<Object[]> getOneLineService(int id) {
        return lineDao.getOneLineDao(id);
    }

    @Override
    public List<Object[]> getOneTeamLineService(String name) {
        return lineDao.getOneTeamLineDao(name);
    }

    @Override
    public Line getOneLineTeamService(int id) {
        return lineDao.getOneLineTeamDao(id);
    }

    @Override
    public boolean addLineTeamService(Line line) {
        return lineDao.addLineTeamDao(line);
    }

    @Override
    public boolean updateLineService(Object[] objects) {
        return lineDao.updateLineDao(objects);
    }

    @Override
    public boolean updateLineTeamService(Line line) {
        return lineDao.updateLineTeamDao(line);
    }

    @Override
    public List<Line> whereAllLineService(String name) {
        return lineDao.whereAllLineDao(name);
    }

    @Override
    public List<Line> whereAllDaySerivce(String day) {
        return lineDao.whereAllDayDao(day);
    }

    @Override
    public List<Line> whereNotAllDayService(String day1, String day2) {
        return lineDao.whereNotAllDayDao(day1,day2);
    }

    @Override
    public List<Object[]> getTypeNamereturnQTService(String name) {
        return lineDao.getTypeNamereturnQTDao(name);
    }

    @Override
    public List<Object[]> getTeamReturnQTService() {
        return lineDao.getTeamReturnQTDao();
    }


    public LineDao getLineDao() {
        return lineDao;
    }

    public void setLineDao(LineDao lineDao) {
        this.lineDao = lineDao;
    }



}
