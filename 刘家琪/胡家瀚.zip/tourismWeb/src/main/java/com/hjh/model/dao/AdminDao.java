package com.hjh.model.dao;

import com.hjh.model.entity.Customer;

public interface AdminDao {
    public Customer AdminLoginDao(Customer customer);
    public boolean AddadminDao(Customer customer);
}
