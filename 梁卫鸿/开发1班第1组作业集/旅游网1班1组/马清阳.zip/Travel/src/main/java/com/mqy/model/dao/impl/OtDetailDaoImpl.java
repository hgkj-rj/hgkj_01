package com.mqy.model.dao.impl;

import com.mqy.model.dao.OtDetailDao;

/**
 * @Author:马清阳
 * @Date:2019/6/26 22:46
 * InteliJ IDEA 1.8
 */
public class OtDetailDaoImpl implements OtDetailDao {
}
