package com.workmoney.model.dao.impl;

import com.workmoney.model.dao.SubsidyLogDao;
import com.workmoney.model.entity.Staff;
import com.workmoney.model.entity.Subsidy;
import com.workmoney.model.entity.SubsidyLog;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * user@Bright Rain .
 * 2019/6/27.
 */
@Repository
@Transactional
public class SubsidyLogDaoImpl implements SubsidyLogDao {

    @Autowired
    private SessionFactory sessionFactory;

    @Override
    public List<SubsidyLog> getAllSubsidyLogDao() {
        Session session = sessionFactory.getCurrentSession();
        String hql = "from SubsidyLog ";
        List<SubsidyLog> list = session.createQuery(hql, SubsidyLog.class).list();
        return list;
    }

    @Override
    public List<Subsidy> getAllSubsidyDao() {
        Session session = sessionFactory.getCurrentSession();
        String hql = "from Subsidy ";
        List<Subsidy> list = session.createQuery(hql, Subsidy.class).list();
        return list;
    }

    @Override
    public void addEmpAllowanceDao(SubsidyLog subsidyLog) {
        Session session = sessionFactory.getCurrentSession();
        long time = new Date().getTime();
        Timestamp timestamp = new Timestamp(time);
        String string = timestamp.toString();
        subsidyLog.setSublogTime(string);
        session.save(subsidyLog);
    }

    @Override
    public void delAllowanceByIdDao(SubsidyLog subsidyLog) {
        Session session = sessionFactory.getCurrentSession();
        session.delete(subsidyLog);
    }

    @Override
    public List<SubsidyLog> serchNameAllowAction(String name) {
        Session session = sessionFactory.getCurrentSession();
        //  System.out.println(month);
        String hql =null;

        if(name!=null&&!name.equals("")){
            name="%"+name+"%";
            hql =  "from Staff as s where s.staffName like '"+name+"' " ;
        }else {
            hql =  "from Staff " ;
        }
        List<Staff> list = session.createQuery(hql, Staff.class).list();

        List<SubsidyLog> subsidyLogs = new ArrayList<>();

        for (Staff staff : list) {
            hql = "from SubsidyLog where staff.staffId=?";
            List<SubsidyLog> list1 = session.createQuery(hql, SubsidyLog.class).setParameter(0, staff.getStaffId()).list();
            for(SubsidyLog s :list1){
                subsidyLogs.add(s);
            }
        }
        return subsidyLogs;
    }

    @Override
    public void delSubsidyByIdDao(Subsidy subsidy) {
        Session session = sessionFactory.getCurrentSession();
        session.delete(subsidy);
    }

    @Override
    public Subsidy getSubsidyByIdService(Subsidy subsidy) {
        Session session = sessionFactory.getCurrentSession();
       return session.get(Subsidy.class,subsidy.getSubsidyId());
    }

    @Override
    public void editSubsidyDao(Subsidy subsidy) {
        Session session = sessionFactory.getCurrentSession();
        session.update(subsidy);
    }

    @Override
    public void addSubSidyDao(Subsidy subsidy) {
        Session session = sessionFactory.getCurrentSession();
        session.save(subsidy);
    }

    public SessionFactory getSessionFactory() {
        return sessionFactory;
    }

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }
}
