package com.hgkj.model.dao.impl;

import com.hgkj.model.dao.LinetypeDao;

import com.hgkj.model.entity.Linetype;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
@Transactional
public class LinetypeDaoImpl implements LinetypeDao {
    @Autowired
    private SessionFactory sessionFactory;
    private Session session;

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    public void setSession(Session session) {
        this.session = session;
    }

    public Session getsession(){
        return sessionFactory.getCurrentSession();
    }
    @Override
    public List<Linetype> allLinetypeDao() {
        Query query=getsession().createQuery("from Linetype ");
        return query.list();
    }

    @Override
    public boolean addLinetypeDao(Linetype linetype) {
        boolean f=false;
        session=getsession();
        try {
            session.save(linetype);
            f=true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return f;
    }

    @Override
    public boolean deleteLinetypeDao(Linetype linetype) {
        boolean f=false;
        session = getsession();
        try {
            session.delete(linetype);
            f=true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return f;
    }

    @Override
    public boolean updateLinetypeDao(Linetype linetype) {
        boolean f=false;
        session=getsession();
        try {
            session.update(linetype);
            f=true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return f;
    }

    @Override
    public Linetype getLinetypeByIdDao(String lineTypeId) {
        session =getsession();
        String hql="from Linetype where lineTypeId=?";
        Linetype linetype=(Linetype) session.createQuery(hql).setParameter(0,lineTypeId).uniqueResult();
        return linetype;
    }
}
