package com.hgkj.model.dao.impl;

import com.hgkj.model.dao.AttendanceLogDao;
import com.hgkj.model.entity.AttendanceLog;
import com.hgkj.model.entity.RewardLog;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
@Repository
@Transactional
public class AttendanceLogDaoImpl implements AttendanceLogDao {
    @Autowired
    private SessionFactory sessionFactory;
    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }
    public Session session(){
        return sessionFactory.getCurrentSession();
    }

    @Override
    public List<AttendanceLog> allAttendanceLogDao() {
        String hql="from AttendanceLog ";
        List<AttendanceLog> list=session().createQuery(hql).list();
        return list;
    }

    @Override
    public boolean insertAttendanceLogDao(AttendanceLog attendanceLog) {
        boolean b=false;
        session().save(attendanceLog);
        b=true;
        return b;
    }

    @Override
    public boolean deleteAttendanceLogDao(int id) {
        boolean a=false;
        String hql="delete Attendance where attId=?";
        int b=session().createQuery(hql).setParameter(0,id).executeUpdate();
        if (b!=0){
            a=true;
        }
        return a;
    }

    @Override
    public boolean updateAttendanceLogDao(AttendanceLog attendanceLog) {
        boolean a=false;
        String hql="update AttendanceLog set staff.staffId=?,attendance.attId=?,attlogCount=?,attlogTime=? where attenlogId=?";
        int b=session().createQuery(hql).setParameter(0,attendanceLog.getStaff().getStaffId()).setParameter(1,attendanceLog.getAttendance().getAttId()).setParameter(2,attendanceLog.getAttlogCount()).setParameter(3,attendanceLog.getAttlogTime()).setParameter(4,attendanceLog.getAttenlogId()).executeUpdate();
        if (b!=0){
            a=true;
        }
        return a;
    }

    @Override
    public AttendanceLog getAttendanceLogByIdDao(int id) {
        String hql="from AttendanceLog where attenlogId=?";
        AttendanceLog attendanceLog=(AttendanceLog) session().createQuery(hql).setParameter(0,id).uniqueResult();
        return attendanceLog;
    }
}
