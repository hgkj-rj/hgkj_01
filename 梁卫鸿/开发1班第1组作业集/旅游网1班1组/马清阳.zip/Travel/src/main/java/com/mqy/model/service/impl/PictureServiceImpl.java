package com.mqy.model.service.impl;

import com.mqy.model.dao.PictureDao;
import com.mqy.model.entity.Picture;
import com.mqy.model.service.PictureService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class PictureServiceImpl implements PictureService {
    @Autowired
    private PictureDao pictureDao;

    public void setPictureDao(PictureDao pictureDao) {
        this.pictureDao = pictureDao;
    }

    @Override
    public List<Picture> allPictureService() {
        return pictureDao.allPictureDao();
    }

    @Override
    public void addPictureService(Picture picture) {
        pictureDao.addPictureDao(picture);
    }

    @Override
    public void deletePictureService(int pictureId) {pictureDao.deletePictureDao(pictureId);
    }

    @Override
    public void updatePictureService(Picture picture) {
        pictureDao.updatePictureDao(picture);
    }

    @Override
    public Picture getPictureService(int pictureId) {
        return pictureDao.getPictureDao(pictureId);
    }
}
