package com.hjh.model.service;

import com.hjh.model.entity.Customer;

public interface AdminService {
    public Customer AdminLoginService(Customer customer);
    public boolean AddadminService(Customer customer);
}
