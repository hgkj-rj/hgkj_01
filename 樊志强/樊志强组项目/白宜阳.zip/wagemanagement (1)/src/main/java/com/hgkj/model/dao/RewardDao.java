package com.hgkj.model.dao;

import com.hgkj.model.entity.Reward;

import java.util.List;

/**
 * 奖金增删改查
 */
public interface RewardDao {
    List<Reward>allRewardDao();
    boolean addRewardDao(Reward reward);
    boolean updateRewardDao(Reward reward);
    boolean deleteRewardDao(int rewId);
    Reward getByIdRewardDao(int reWId);
}
