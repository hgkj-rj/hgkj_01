package com.workmoney.model.service;

import com.workmoney.model.entity.Attendance;
import com.workmoney.model.entity.AttendanceLog;

import java.util.List;

/**
 * user@Bright Rain .
 * 2019/6/25.
 */
public interface AttendanceService {

    /**
     * 获取员工信息
     * @param shopManagerId
     * @return
     */
    List<AttendanceLog> getAllAttendanceLog( int shopManagerId );

    /**
     * 获取缺勤类别
     * @return
     */
    List<Attendance> getAttendanceType();


    /**
     * 添加
     * @param attendance
     */
    void addAttendanceService(AttendanceLog attendance);

    /**
     * 获取修改缺勤的员工信息
     * @param staffId
     * @param shopId
     * @return
     */
    AttendanceLog getAttendanceLogById(int staffId, Integer shopId);

    void attendanceEditAction(AttendanceLog attendanceLog);

    void delAttendanceLog(AttendanceLog attendanceLog);

    List<AttendanceLog> attendanceInfoService(int staffId);
}
