package com.mqy.model.dao;

import com.mqy.model.entity.Tourist;

import java.util.List;

/**
 * @Author:马清阳
 * @Date:2019/6/26 22:49
 * InteliJ IDEA 1.8
 */
public interface TouristDao {
    /**
     * 查询所有游客信息
     * @return
     */
    public List<Tourist> allTouristDao();

    /**游客信息
     * @param tourist
     * @return
     */
    public boolean addTouristDao(Tourist tourist);

    /**
     * 删除游客信息
     * @param touristId
     * @return
     */
    public boolean deleteTouristDao(String touristId);

    /**
     * 修改游客信息
     * @param tourist
     * @return
     */
    public boolean updateTouristDao(Tourist tourist);

    /**
     * 获取游客信息
     * @param touristId
     * @return
     */
    public Tourist getTouristDao(String touristId);
}
