package com.hgkj.model.Dao.impl;

import com.hgkj.model.Dao.CustomerDao;
import com.hgkj.model.entity.Customer;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
@Transactional
public class CustomerDaoimpl implements CustomerDao {
    @Autowired
    private SessionFactory sessionFactory;
    private Session session;
    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }
    public Session getSession(){
        return sessionFactory.getCurrentSession();
    }
    @Override
    public Customer qCustomerDao(Customer customer) {
        session = getSession();
        String hql = "from Customer where account=? and password=?";
        Customer customer1 = (Customer) session.createQuery(hql).setParameter(0, customer.getAccount()).setParameter(1, customer.getPassword()).uniqueResult();
        return customer1;

    }

    @Override
    public Boolean addCustomerDao(Customer customer) {
        boolean flag=false;
        session=getSession();
        try {
            session.save(customer);
            flag=true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return flag;
    }
}
