package com.hgkj.model.service;

import com.hgkj.model.dao.StaffUserdao;
import com.hgkj.model.entity.Staff;

import java.util.List;

public interface StaffUserService {
    /**
     * 管理员用户登录
     * 修改密码
     * @param staff
     * @return
     */
    List<Staff> loginUserService(Staff staff);
    public boolean updateResetpassService(Staff staff);
}
