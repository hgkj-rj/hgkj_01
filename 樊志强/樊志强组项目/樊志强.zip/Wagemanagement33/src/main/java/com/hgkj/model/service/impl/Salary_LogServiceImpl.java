package com.hgkj.model.service.impl;

import com.hgkj.model.dao.Salary_LogDao;
import com.hgkj.model.entity.AttendanceLog;
import com.hgkj.model.entity.SalaryLog;
import com.hgkj.model.entity.Staff;
import com.hgkj.model.service.Salary_LogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class Salary_LogServiceImpl implements Salary_LogService {
    @Autowired
    private Salary_LogDao salary_logDao;

    @Override
    public List<SalaryLog> allSalaryList() {
        return salary_logDao.allSalaryList();
    }

    @Override
    public List<SalaryLog> querySalaryService(Staff staff) {
        return salary_logDao.querySalaryDao(staff);
    }

    @Override
    public List SalaryLog_AttendanceLog(int staffId) {
        return salary_logDao.SalaryLog_AttendanceLog(staffId);
    }

    @Override
    public  List<SalaryLog>  dimquery(String name) {
        return salary_logDao.dimquery(name);
    }

    @Override
    public List<SalaryLog> Salary_Next(int index) {
        return salary_logDao.Salary_Next(index);
    }

    @Override
    public int Salary_Pages() {
        return salary_logDao.Salary_Pages();
    }

    @Override
    public List<SalaryLog> Salary_End(Staff staff) {
        return null;
    }

    @Override
    public boolean addSalaryService(SalaryLog salaryLog) {
        return false;
    }

    @Override
    public boolean updSalaryService(SalaryLog salaryLog) {
        return false;
    }

    @Override
    public boolean delSalaryService(SalaryLog salaryLog) {
        return false;
    }
    public void setSalary_logDao(Salary_LogDao salary_logDao) {
        this.salary_logDao = salary_logDao;
    }
}
