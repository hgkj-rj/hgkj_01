package com.tourism.model.dao.impl;

import com.tourism.model.dao.OrderDetailDao;
import com.tourism.model.entity.Line;
import com.tourism.model.entity.Orderdetail;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
@Transactional
public class OrderDetailDaoImpl implements OrderDetailDao {
    @Autowired
    private SessionFactory sessionFactory;

    private Session session;

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    public Session getSession(){
        return sessionFactory.getCurrentSession();
    }

    @Override
    public int gettotalpageDao(int pagesize) {
        int totalpage = 0;
        Query query=this.getSession().createQuery("select count(*) from Orderdetail");
        totalpage=((Number)query.iterate().next()).intValue();
        return totalpage;
    }

    @Override
    public List<Orderdetail> allOrderDetailDao(int pageindex, int pagesize) {
        String hql = "from Orderdetail";
        List<Orderdetail> orderdetailList = getSession().createQuery(hql).setFirstResult((pageindex-1)*pagesize).setMaxResults(pagesize).list();
        return orderdetailList;
    }
}
