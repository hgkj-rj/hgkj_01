package com.workmoney.util;

/**
 * user@Bright Rain .
 * 2019/6/29.
 */
public class Attendancesinfo {

   private String name;
   private String type;

   private int count;

   private double money;

    public Attendancesinfo() {
    }

    public Attendancesinfo(String name, String type, int count, double money) {
        this.name = name;
        this.type = type;
        this.count = count;
        this.money = money;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public double getMoney() {
        return money;
    }

    public void setMoney(double money) {
        this.money = money;
    }
}
