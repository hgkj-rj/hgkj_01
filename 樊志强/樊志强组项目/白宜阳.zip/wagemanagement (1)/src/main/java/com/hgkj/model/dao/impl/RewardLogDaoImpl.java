package com.hgkj.model.dao.impl;

import com.hgkj.model.dao.RewardLogDao;
import com.hgkj.model.entity.RewardLog;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
@Transactional
public class RewardLogDaoImpl implements RewardLogDao {
    @Autowired
    private SessionFactory sessionFactory;
    private Transaction transaction;

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    public Transaction getTransaction() {
        return transaction;
    }

    public void setTransaction(Transaction transaction) {
        this.transaction = transaction;
    }

    public Session getSession(){
        return sessionFactory.getCurrentSession();
    }

    @Override
    public List<RewardLog> allRewardLogDao() {
        Query query=getSession().createQuery("from RewardLog");
        return query.list();
    }

    @Override
    public boolean addRewardLogDao(RewardLog rewardLog) {
        boolean flag=false;
        try {
            getSession().save(rewardLog);
            flag=true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return flag;
    }

    @Override
    public boolean updateRewardLogDao(RewardLog rewardLog) {
        boolean flag=false;
        try {
            getSession().update(rewardLog);
            flag=true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return flag;
    }

    @Override
    public boolean deleteRewardLogDao(int rewlogId) {
        boolean flag=false;
        RewardLog rewardLog=new RewardLog();
        rewardLog.setRewlogId(rewlogId);
        try {
            getSession().delete(rewardLog);
            flag=true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return flag;
    }

    @Override
    public RewardLog getByIdRewardLogDao(int rewlogId) {
        RewardLog rewardLog=getSession().get(RewardLog.class,rewlogId);
        return rewardLog;
    }

    @Override
    public List<RewardLog> alllRewardLogDao(RewardLog rewardLog) {
        String hql="from RewardLog where staff.staffName like:name";
        List<RewardLog> logList=getSession().createQuery(hql).setParameter("name","%"+rewardLog.getStaff().getStaffName()+"%").list();
        return logList;
    }
}
