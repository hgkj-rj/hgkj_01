package com.hgkj.model.service.impl;

import com.hgkj.model.dao.CusregisterDao;
import com.hgkj.model.entity.Customer;
import com.hgkj.model.service.CusregisterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CusregisterServiceImpl implements CusregisterService {
    @Autowired
    private CusregisterDao cusregisterDao;

    public CusregisterDao getCusregisterDao() {
        return cusregisterDao;
    }

    public void setCusregisterDao(CusregisterDao cusregisterDao) {
        this.cusregisterDao = cusregisterDao;
    }


    @Override
    public boolean insertcusService(Customer customer) {
        return cusregisterDao.insertcusDao(customer);
    }

    @Override
    public boolean logincusService(Customer customer) {
        return cusregisterDao.logincusDao(customer);
    }
}
