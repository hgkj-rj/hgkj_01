package com.hgkj.model.Dao;

import com.hgkj.model.entity.Line;

import java.util.List;

public interface LineDao {
    public int getpageDao(int pagesize,String time);
    public List<Line> allLineDao(int pageIndex,int pagesize,String time);
    public List<Line> allLineDao();
    public List<Line>allGroupDao();
    public List<Line>allGroupLineDao();
    public List<Line>toIndexLineDao(String lineTypeId);
    public List<Line>oneLineDao();
    public List<Line>twoLineDao();
    public List<Line>moreLineDao();
    public boolean  addLineDao(Line line);
    public boolean  updateLineDao(Line line);
    public Line getLineByIdDao(String lineId);
}
