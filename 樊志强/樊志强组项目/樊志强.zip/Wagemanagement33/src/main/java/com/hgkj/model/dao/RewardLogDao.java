package com.hgkj.model.dao;


import com.hgkj.model.entity.RewardLog;

import java.util.List;


public interface RewardLogDao {
    //查询所有补贴类别
    public List<RewardLog> allrewardLogDao();
    //添加补贴类别
    public boolean insertrewardLogDao(RewardLog rewardLog);
    //删除补贴类别
    public boolean deleterewardLogDao(int id);
    //修改补贴类别
    public boolean updaterewardLogDao(RewardLog rewardLog);
    //根据Id获取补贴信息
    public RewardLog getrewardLogByIdDao(int id);
}
