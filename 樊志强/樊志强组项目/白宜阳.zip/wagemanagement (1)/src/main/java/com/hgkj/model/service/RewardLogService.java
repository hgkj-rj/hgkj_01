package com.hgkj.model.service;

import com.hgkj.model.entity.RewardLog;

import java.util.List;

public interface RewardLogService {
    List<RewardLog> allRewardLogService();
    boolean addRewardLogService(RewardLog rewardLog);
    boolean updateRewardLogService(RewardLog rewardLog);
    boolean deleteRewardLogService(int rewlogId);
    RewardLog getByIdRewardLogService(int rewlogId);
    List<RewardLog> alllRewardLogService(RewardLog rewardLog);
}
