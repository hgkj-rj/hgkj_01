package com.hgkj.model.dao.impl;

import com.hgkj.model.dao.AttendanceZBDao;
import com.hgkj.model.entity.Attendance;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
@Transactional
public class AttendanceZBDaoImpl implements AttendanceZBDao {
    @Autowired
    private SessionFactory sessionFactory;
    private Transaction transaction;

    public Transaction getTransaction() {
        return transaction;
    }

    public void setTransaction(Transaction transaction) {
        this.transaction = transaction;
    }

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }
    public Session getSession(){
        return sessionFactory.getCurrentSession();
    }

    @Override
    public List<Attendance> allAttendanceDao() {
        Query query=getSession().createQuery("from Attendance");
        return query.list();
    }

    @Override
    public boolean addAttendanceDao(Attendance attendance) {
        boolean flag=false;
        try {
            getSession().save(attendance);
            flag=true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return flag;
    }

    @Override
    public boolean updateAttendanceDao(Attendance attendance) {
        boolean flag=false;
        try {
            getSession().update(attendance);
            flag=true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return flag;
    }

    @Override
    public boolean deleteAttendanceDao(int attId) {
        boolean flag=false;
        Attendance attendance=new Attendance();
        attendance.setAttId(attId);
        try {
            getSession().delete(attendance);
            flag=true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return flag;
    }

    @Override
    public Attendance getByIdAttendanceDao(int attId) {
        Attendance attendance=getSession().get(Attendance.class,attId);
        return attendance;
    }
}
