package com.xl.model.entity;

public class Invitejob {
 private int invitejobId;
 private String invitejobName;
    private String invitejobSex;
    private String invitejobPost;
    private String invitejobEd;
    private int invitejobEx;
    public Invitejob(){}
    public Invitejob(String invitejobName, String invitejobPost, String invitejobSex, String invitejobEd, String invitejobEx){}
    public Invitejob(String invitejobName, String invitejobSex, String invitejobPost, String invitejobEd, int invitejobEx) {
        this.invitejobName = invitejobName;
        this.invitejobSex = invitejobSex;
        this.invitejobPost = invitejobPost;
        this.invitejobEd = invitejobEd;
        this.invitejobEx = invitejobEx;
    }

    public int getInvitejobId() {
        return invitejobId;
    }

    public void setInvitejobId(int invitejobId) {
        this.invitejobId = invitejobId;
    }

    public String getInvitejobName() {
        return invitejobName;
    }

    public void setInvitejobName(String invitejobName) {
        this.invitejobName = invitejobName;
    }

    public String getInvitejobSex() {
        return invitejobSex;
    }

    public void setInvitejobSex(String invitejobSex) {
        this.invitejobSex = invitejobSex;
    }

    public String getInvitejobPost() {
        return invitejobPost;
    }

    public void setInvitejobPost(String invitejobPost) {
        this.invitejobPost = invitejobPost;
    }

    public String getInvitejobEd() {
        return invitejobEd;
    }

    public void setInvitejobEd(String invitejobEd) {
        this.invitejobEd = invitejobEd;
    }

    public int getInvitejobEx() {
        return invitejobEx;
    }

    public void setInvitejobEx(int invitejobEx) {
        this.invitejobEx = invitejobEx;
    }
}
