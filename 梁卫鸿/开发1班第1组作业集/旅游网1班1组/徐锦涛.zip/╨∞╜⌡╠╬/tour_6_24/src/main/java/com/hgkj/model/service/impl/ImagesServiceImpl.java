package com.hgkj.model.service.impl;

import com.hgkj.model.dao.ImagesDao;
import com.hgkj.model.entity.Line;
import com.hgkj.model.entity.Picture;
import com.hgkj.model.service.ImagesService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class ImagesServiceImpl implements ImagesService {
    @Autowired
    private ImagesDao imagesDao;

    public ImagesDao getImagesDao() {
        return imagesDao;
    }

    public void setImagesDao(ImagesDao imagesDao) {
        this.imagesDao = imagesDao;
    }

    @Override
    public List<Picture> imagesAllService() {
        return imagesDao.imagesAllDao();
    }

    @Override
    public boolean imagesInsertService(String lineID, String introduction, String name) {
        return imagesDao.imagesInsertDao(lineID, introduction, name);
    }

    @Override
    public Picture imagesIdService(int pictureID) {
        return imagesDao.imagesIdDao(pictureID);
    }

    @Override
    public boolean imagesUpdateService(int pictureID, String introduction, String name, String lineID) {
        return imagesDao.imagesUpdateService(pictureID, introduction, name, lineID);
    }

    @Override
    public boolean lineAddService(Line line) {
        return imagesDao.lineAddDao(line);
    }

    @Override
    public List<Line> lineAllService() {
        return imagesDao.lineAllDao();
    }

    @Override
    public boolean lineDeleteService(String lineID) {
        return imagesDao.lineDeleteDao(lineID);
    }

    @Override
    public Line lineIdService(String lineID) {
        return imagesDao.lineIdDao(lineID);
    }

    @Override
    public boolean lineUpdateService(Line line) {
        return imagesDao.lineUpdateDao(line);
    }
}
