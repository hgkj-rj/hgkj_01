package com.xl.servlet;

import com.xl.model.entity.Department;
import com.xl.model.entity.Employee;
import com.xl.model.service.EmployeeService;
import com.xl.model.service.impl.EmployeeServiceImpl;
import org.codehaus.jackson.map.ObjectMapper;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

@WebServlet(name = "EmployeeServlet",value = "/EmployeeServlet")
public class EmployeeServlet extends HttpServlet {
   EmployeeService employeeService=new EmployeeServiceImpl();
private int pageSize=2;
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out =response.getWriter();
        ObjectMapper mapper=new ObjectMapper();
        String action = request.getParameter("action");
        if ("all".equals(action)) {
            int pageIndex = request.getParameter("pageIndex") == null ? 1 : Integer.parseInt(request.getParameter("pageIndex"));
            int totalPage = employeeService.EmployeeService(pageSize);
            if (pageIndex < 1) {
                pageIndex = 1;
            } else if (pageIndex > totalPage) {
                pageIndex = totalPage;
            }
            request.getSession().setAttribute("pageIndex", pageIndex);
            request.getSession().setAttribute("totalPage", totalPage);
            List<Employee> employeeList = employeeService.allEmployeeService(pageIndex, pageSize);
            request.getSession().setAttribute("employeeList", employeeList);
            response.sendRedirect("employeeMgr.jsp");

        }else if ("add".equals(action)){

            String employeeName=request.getParameter("employeeName");
            String employeeSex=request.getParameter("employeeSex");
            String departmentId=request.getParameter("departmentId");
            String employeeGongzhong=request.getParameter("employeeGongzhong");
            String employeeXueli=request.getParameter("employeeXueli");
            String employeeTime=request.getParameter("employeeTime");
            Employee employee=new Employee(employeeName,employeeSex,departmentId,employeeGongzhong,employeeXueli,employeeTime);
            boolean result=employeeService.addEmployeeService(employee);
            if (result){

                response.sendRedirect("EmployeeServlet?action=all");
            }else {

                request.getRequestDispatcher("EmployeeAdd.jsp");
            }
        }
        else if ("delete".equals(action)){
            int employeeId = Integer.parseInt(request.getParameter("employeeId"));
            boolean flag=  employeeService.deleteEmployeeService(employeeId);
            String f=String.valueOf(flag);
            String result=mapper.writeValueAsString(f);
            out.println(result);}
    }
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
doPost(request,response);
    }
}
