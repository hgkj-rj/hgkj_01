package com.hgkj.model.dao;

import com.hgkj.model.entity.SubsidyLog;

import java.util.List;

public interface SubsidyLogDao {
    //查询所有员工补贴记录
    public List<SubsidyLog> allsubsidyLogDao();
    //添加员工补贴记录
    public boolean insertsubsidyLogDao(SubsidyLog subsidyLog);
    //删除员工补贴记录
    public boolean deletesubsidyLogDao(int id);
    //修改员工补贴记录
    public boolean updatesubsidyLogDao(SubsidyLog subsidyLog);
    //根据Id获取员工补贴记录
    public SubsidyLog getsubsidyLogByIdDao(int id);
}
