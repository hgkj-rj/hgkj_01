package com.workmoney.model.service;

import com.workmoney.model.entity.Department;

import java.util.List;

/**
 * user@Bright Rain .
 * 2019/6/29.
 */
public interface DepartmentService {
    /**
     * 获取所有部门
     * @return
     */
    List<Department> getAllDepartmentService();
    /**
     * 添加部门
     * @return
     */
    void addDepartmentService(Department department);
    /**
     * 删除部门
     * @return
     */
    void delDepartmentService(Department department);
    /**
     * 获取部门
     * @return
     */
    Department getDepartmentService(Department department);
    /**
     * 修改部门
     * @return
     */
    void updateDepartment(Department department);
}
