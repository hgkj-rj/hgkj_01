package com.hgkj.controler.action;


import com.hgkj.model.entity.Linetype;
import com.hgkj.model.service.LineTypeService;
import com.hgkj.model.service.impl.LineTypeServiceImpl;
import com.opensymphony.xwork2.ActionContext;
import org.apache.commons.io.FileUtils;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.omg.PortableInterceptor.SYSTEM_EXCEPTION;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import sun.misc.BASE64Encoder;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;

@Controller
@Namespace("/")
@ParentPackage("struts-default")
public class LineTypeAction {
    @Autowired
    private LineTypeService lineService = new LineTypeServiceImpl();
    private Linetype linetype;
    private File upload;
    private String img;
    private InputStream inputStream;
    private String uploadFileName;
    private byte[] data;
    private Integer id;

    @Action(value = "AddLineType",results = @Result(name = "AddLineType",type = "redirect",location = "AllLineType"))
    /*上传路线*/
    public String addLineType() throws IOException {
        String path =  "E://IDEA//Travel_01//src//main//webapp//upImg//";
        File file = new File(path);
        if(!file.exists()){
            file.mkdir();
        }
        FileUtils.copyFile(upload,new File(file,uploadFileName));
        String file2 = new File(file,uploadFileName).toString();
        System.out.println("文件名："+uploadFileName);
        System.out.println("file2:"+file2);
        linetype.setIcon(file2);
            /*把图片转成BASE64*/
            try {
                inputStream = new FileInputStream(file2);
                data = new byte[inputStream.available()];
                inputStream.read(data);
                inputStream.close();
            }catch (Exception e){
                e.printStackTrace();
            }
            BASE64Encoder encoder = new BASE64Encoder();
            encoder.encode(data);
        linetype.setIcon(encoder.encode(data));
        lineService.addLineTypeService(linetype);

        return "AddLineType";
    }
    @Action(value = "AllLineType",results = @Result(name = "AllLineType",type = "redirect",location = "ht/showLineType.jsp"))
    /*查看所有路线*/
    public String allLineType(){
        List<Linetype> linetypeList = lineService.allLineTypeSerivce();
        ActionContext.getContext().getSession().put("linetypeList",linetypeList);
        return "AllLineType";
    }


    @Action(value = "DeleteLineType",results = @Result(name = "DeleteLineType",type = "redirect",location = "AllLineType"))
    /*删除路线*/
    public String deleteLineType(){
        lineService.deleteLineTypeService(id);
        return "DeleteLineType";
    }

    /*查询单个路线详细信息*/
    @Action(value = "GetOneLineType",results = @Result(name = "GetOneLineType",type = "redirect",location = "ht/updateLineType.jsp"))
    public String getOneLineType(){
        Linetype linetype = lineService.getOneLineTypeService(id);
        ActionContext.getContext().getSession().put("linetype",linetype);
        return "GetOneLineType";
    }

    /*修改路线信息*/
    @Action(value = "UpdateLineType",results = @Result(name = "UpdateLineType",type = "redirect",location = "AllLineType"))
    public String updateLineType() throws IOException {
        /*icon为空的情况下*/
        if (upload == null){
            linetype.setIcon(lineService.getIconLineTypeService(id));
            linetype.setShow(linetype.getShow());
            lineService.updateLineTypeService(linetype);
            return "UpdateLineType";
        }else {
            /*icon不为空的情况下*/
            String path =  "E://IDEA//Travel_01//src//main//webapp//upImg//";
            File file = new File(path);
            if(!file.exists()){
                file.mkdir();
            }
            FileUtils.copyFile(upload,new File(file,uploadFileName));
            String file2 = new File(file,uploadFileName).toString();
            System.out.println("文件名："+uploadFileName);
            System.out.println("file2:"+file2);
            linetype.setIcon(file2);
            /*把图片转成BASE64*/
            try {
                inputStream = new FileInputStream(file2);
                data = new byte[inputStream.available()];
                inputStream.read(data);
                inputStream.close();
            }catch (Exception e){
                e.printStackTrace();
            }
            BASE64Encoder encoder = new BASE64Encoder();
            encoder.encode(data);
            linetype.setIcon(encoder.encode(data));
            lineService.updateLineTypeService(linetype);
            return "UpdateLineType";
        }

    }


    @Action(value = "LineTypeLine",results = @Result(name = "LineTypeLine",type = "redirect",location = "ht/addLine.jsp"))
    public String lineTypeLine(){
        List<Linetype> linetypeList = lineService.getTypeNameService();
        ActionContext.getContext().getSession().put("linetypeList",linetypeList);
        return "LineTypeLine";
    }

    /*是否在前台显示*/
    @Action(value = "ShowTypeName",results = @Result(name = "ShowTypeName",type = "redirect",location = "qt/index.jsp"))
    public String showTypeName(){
        List<Linetype> lineName = lineService.ShowTypeNameService();
        ActionContext.getContext().getSession().put("lineName",lineName);
        return "ShowTypeName";
    }
    /*是否在前台显示*/
    @Action(value = "ShowTypeName1",results = @Result(name = "ShowTypeName1",type = "redirect",location = "qt/type.jsp"))
    public String showTypeName1(){
        List<Linetype> lineName = lineService.ShowTypeNameService();
        ActionContext.getContext().getSession().put("lineName",lineName);
        return "ShowTypeName1";
    }

    /*是否在前台显示*/
    @Action(value = "ShowTypeName2",results = @Result(name = "ShowTypeName2",type = "redirect",location = "qt/show.jsp"))
    public String showTypeName2(){
        List<Linetype> lineName = lineService.ShowTypeNameService();
        ActionContext.getContext().getSession().put("lineName",lineName);
        return "ShowTypeName2";
    }

    /*是否在前台显示*/
    @Action(value = "ShowTypeName3",results = @Result(name = "ShowTypeName3",type = "redirect",location = "qt/showTeam.jsp"))
    public String showTypeName3(){
        List<Linetype> lineName = lineService.ShowTypeNameService();
        ActionContext.getContext().getSession().put("lineName",lineName);
        return "ShowTypeName3";
    }

    /*是否在前台显示*/
    @Action(value = "ShowTypeName4",results = @Result(name = "ShowTypeName4",type = "redirect",location = "qt/car.jsp"))
    public String showTypeName4(){
        List<Linetype> lineName = lineService.ShowTypeNameService();
        ActionContext.getContext().getSession().put("lineName",lineName);
        return "ShowTypeName4";
    }



    public LineTypeService getLineService() {
        return lineService;
    }

    public void setLineService(LineTypeService lineService) {
        this.lineService = lineService;
    }

    public Linetype getLinetype() {
        return linetype;
    }

    public void setLinetype(Linetype linetype) {
        this.linetype = linetype;
    }

    public File getUpload() {
        return upload;
    }

    public void setUpload(File upload) {
        this.upload = upload;
    }

    public String getImg() {
        return img;
    }

    public void setImg(String img) {
        this.img = img;
    }

    public String getUploadFileName() {
        return uploadFileName;
    }

    public void setUploadFileName(String uploadFileName) {
        this.uploadFileName = uploadFileName;
    }

    public InputStream getInputStream() {
        return inputStream;
    }

    public void setInputStream(InputStream inputStream) {
        this.inputStream = inputStream;
    }

    public byte[] getData() {
        return data;
    }

    public void setData(byte[] data) {
        this.data = data;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }
}
