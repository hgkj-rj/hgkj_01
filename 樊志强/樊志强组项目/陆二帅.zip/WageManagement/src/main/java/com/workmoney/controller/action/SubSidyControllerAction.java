package com.workmoney.controller.action;

import com.workmoney.model.entity.Subsidy;
import com.workmoney.model.service.SubsidyLogService;
import org.apache.struts2.ServletActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import javax.servlet.http.HttpSession;
import java.util.List;

/**
 * user@Bright Rain .
 * 2019/6/29.
 */
@ParentPackage("struts-default")
@Namespace("/")
@Controller
public class SubSidyControllerAction {
    @Autowired
    private SubsidyLogService subsidyLogService;

    private Subsidy subsidy;


    @Action(value = "/addSubSidyAction",results = {@Result(name = "success",type = "redirectAction",location = "getAllSubSidyAction")})
    public String addSubSidyAction(){
        subsidyLogService.addSubSidyService(subsidy);
        return "success";
    }

    /**
     * 修改完成
     * @return
     */
    @Action(value = "/editSubsidyAction",results = {@Result(name = "success",type = "redirectAction",location = "getAllSubSidyAction")})
    public String editSubsidyAction(){
        subsidyLogService.editSubsidyService(subsidy);
        return "success";
    }

    /**
     * 去往修改页面
     * @return
     */
    @Action(value = "/goEditSubsidyByIdAction",results = {@Result(name = "success",type = "redirect",location = "html/SubSidyEdit.jsp")})
    public String goEditSubsidyByIdAction(){
        HttpSession session = ServletActionContext.getRequest().getSession();
        Subsidy subsidy1 = subsidyLogService.getSubsidyByIdService(this.subsidy);
        session.setAttribute("subsidy",subsidy1);
        return "success";
    }

    /**
     * 删除津贴
     * @return
     */
    @Action(value = "/delSubsidyByIdAction",results = {@Result(name = "success",type = "redirectAction",location = "getAllSubSidyAction")})
    public String delSubsidyByIdAction(){
        subsidyLogService.delSubsidyByIdService(subsidy);

        return "success";
    }

    /**
     * 获取所有津贴
     * @return
     */
    @Action(value = "/getAllSubSidyAction",results = {@Result(name = "success",type = "redirect",location = "html/SubSidyList.jsp")})
    public String getAllSubSidyAction(){
        HttpSession session = ServletActionContext.getRequest().getSession();
        List<Subsidy> subsidyList = subsidyLogService.getAllSubsidyService();
        session.setAttribute("subsidyList",subsidyList);
        return "success";
    }

    public Subsidy getSubsidy() {
        return subsidy;
    }

    public void setSubsidy(Subsidy subsidy) {
        this.subsidy = subsidy;
    }
}
