package com.xl.model.service.impl;

import com.xl.model.dao.TrainDao;
import com.xl.model.dao.impl.TrainDaoImpl;
import com.xl.model.entity.Invitejob;
import com.xl.model.entity.Train;
import com.xl.model.service.InvitejobService;
import com.xl.model.service.TrainService;

import java.util.List;

public class TrainServiceImpl implements TrainService {

private TrainDao TrainDao=new TrainDaoImpl();
    @Override
    public int TrainService(int pageSize) {
        return TrainDao.TrainDao(pageSize);
    }

    @Override
    public List<Train> allTrainService(int pageIndex, int pageSize) {
        return TrainDao.allTrainDao(pageIndex,pageSize);
    }

    @Override
    public Train getTrainByIdService(int departmentId) {
        return TrainDao.getTrainByIdDao(departmentId);
    }

    @Override
    public boolean addTrainService(Train train) {
        return TrainDao.addTrainDao(train);
    }

    @Override
    public boolean deleteTrainService(Train train) {
        return TrainDao.deleteTrainDao(train);
    }

    @Override
    public boolean updateTrainService(Train train) {
        return TrainDao.updateTrainDao(train);
    }
}
