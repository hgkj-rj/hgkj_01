package com.hgkj.model.dao.impl;

import com.hgkj.model.dao.LineDao;
import com.hgkj.model.entity.Line;
import com.hgkj.model.entity.Picture;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;


@Repository
@Transactional
public class LineDaoImpl implements LineDao {
    @Autowired
    private SessionFactory sessionFactory;
    private Session session;


    /*添加线路*/
    @Override
    public boolean addLineDao(Line line) {
        boolean result=false;
        try {
            this.sessionFactory.getCurrentSession().save(line);
            result = true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }
    /*得到线路最大ID*/
    @Override
    public int getLineIdDao() {
        int id = 0;
        List<Line> lineId = null;
        Session session = sessionFactory.openSession();
        Query query = session.createQuery("from Line ");
        lineId = query.list();
        for (Line line:lineId){
            /*循环得到最大id*/
            id = line.getLineId();
        }
        return id;
    }
    /*添加图片*/
    @Override
    public boolean addPictureDao(Picture picture) {
        boolean result=false;
        try {
            this.sessionFactory.getCurrentSession().save(picture);
            result = true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }
    /*查询所有*/
    @Override
    public List<Line> allLineDao() {
        Session session = sessionFactory.openSession();
        Query query = session.createQuery("from Line ");
        List<Line> lineList = query.list();
        return lineList;
    }
    /*得到线路加图片*/
    @Override
    public List<Object[]> getOneLineDao(int id) {
        Session session = sessionFactory.openSession();
        List<Object[]> objectList = session.createQuery("from Line l left join l.pictureSet p where l.lineId=?").setInteger(0,id).list();
        return objectList;
    }

    /*修改线路*/
    @Override
    public boolean updateLineDao(Object[] objects) {
        Session session= sessionFactory.openSession();
        Transaction transaction=session.beginTransaction();
        session.update(objects);
        transaction.commit();
        session.close();
        return true;
    }

    /*得到一个团购*/
    @Override
    public Line getOneLineTeamDao(int id) {
        Session session = sessionFactory.openSession();
        Line line =  (Line)session.createQuery("from Line where lineId=?").setInteger(0,id).uniqueResult();
        return line;
    }
    /*添加团购*/
    @Override
    public boolean addLineTeamDao(Line line) {
        Session session= sessionFactory.openSession();
        Transaction transaction=session.beginTransaction();
        session.update(line);
        transaction.commit();
        session.close();
        return true;
    }

    @Override
    public boolean updateLineTeamDao(Line line) {
        Session session= sessionFactory.openSession();
        Transaction transaction=session.beginTransaction();
        session.update(line);
        transaction.commit();
        session.close();
        return true;
    }
    /*一日*/
    @Override
    public List<Line> whereAllLineDao(String name) {
        Session session = sessionFactory.openSession();
        List<Line> lineList =  session.createQuery("from Line where typeName=?").setParameter(0,name).list();
        return lineList;
    }
    /*三日*/
    @Override
    public List<Line> whereAllDayDao(String day) {
        Session session = sessionFactory.openSession();
        List<Line> lineList =  session.createQuery("from Line where days=?").setParameter(0,day).list();
        return lineList;
    }
    /*多日*/
    @Override
    public List<Line> whereNotAllDayDao(String day1, String day2) {
        Session session = sessionFactory.openSession();
        Query query =  session.createQuery("from Line where days not in(?,?)").setParameter(0,day1).setParameter(1,day2);
        query.setFirstResult(0);
        query.setMaxResults(6);
        List<Line> lineList = query.list();
        return lineList;
    }

    @Override
    public List<Object[]> getTypeNamereturnQTDao(String name) {
        Session session = sessionFactory.openSession();
        List<Object[]> objectList = session.createQuery("from Line l left join l.pictureSet p where l.typeName=?").setParameter(0,name).list();
        return objectList;
    }

    @Override
    public List<Object[]> getTeamReturnQTDao() {
        Session session = sessionFactory.openSession();
        List<Object[]> objectList = session.createQuery("from Line l left join l.pictureSet p where l.teamBuy=?").setParameter(0,"团购").list();
        return objectList;
    }

    @Override
    public List<Object[]> getOneTeamLineDao(String name) {
        Session session = sessionFactory.openSession();
        List<Object[]> objectList = session.createQuery("from Line l left join l.pictureSet p where l.lineName=?").setParameter(0,name).list();
        return objectList;
    }


    public SessionFactory getSessionFactory() {
        return sessionFactory;
    }

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    public Session getSession() {
        return session;
    }

    public void setSession(Session session) {
        this.session = session;
    }


}
