package com.workmoney.model.service;

import com.workmoney.model.dao.ShopDao;
import com.workmoney.model.entity.Shop;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * user@Bright Rain .
 * 2019/6/30.
 */
@Service
public class ShopServiceImpl implements ShopService {

    @Autowired
    private ShopDao dao;

    @Override
    public List<Shop> getAllShopService() {
        return dao.getAllShopDao();
    }

    @Override
    public Shop getShopByIdService(Shop shop) {
        return dao.getShopByIdDao(shop);
    }

    @Override
    public void delShopByIdService(Shop shop) {
        dao.delShopByIdDao(shop);
    }

    @Override
    public void addShopService(Shop shop) {
        dao.addShopDao(shop);
    }

    @Override
    public void updateShopByIdService(Shop shop) {
    dao.updateShopByIdDao(shop);
    }
}
