package com.hgkj.model.dao;

import com.hgkj.model.entity.RewardLog;

import java.util.List;

public interface RewardLogDao {
    List<RewardLog> allRewardLogDao();
    boolean addRewardLogDao(RewardLog rewardLog);
    boolean updateRewardLogDao(RewardLog rewardLog);
    boolean deleteRewardLogDao(int rewlogId);
    RewardLog getByIdRewardLogDao(int rewlogId);
    List<RewardLog> alllRewardLogDao(RewardLog rewardLog);
}
