package com.hgkj.model.dao.impl;

import com.hgkj.model.dao.LevelDao;
import com.hgkj.model.entity.Level;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
@Repository
@Transactional
public class LevelDaoImpl implements LevelDao {
    @Autowired
    private SessionFactory sessionFactory;
    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }
    public Session session(){
        return sessionFactory.getCurrentSession();
    }

    @Override
    public List<Level> alllevelDao() {
        String hql="from Level ";
        List<Level> list=session().createQuery(hql).list();
        return list;
    }

    @Override
    public boolean insertlevelDao(Level level) {
        boolean b=false;
        session().save(level);
        b=true;
        return b;
    }

    @Override
    public boolean deletelevelDao(int id) {
        boolean a=false;
        String hql="delete Level where levelId=?";
        int b=session().createQuery(hql).setParameter(0,id).executeUpdate();
        if (b!=0){
            a=true;
        }
        return a;
    }

    @Override
    public boolean updatelevelDao(Level level) {
        boolean a=false;
        String hql="update Level set levelName=?,levelPrice=?where levelId=?";
        int b=session().createQuery(hql).setParameter(0,level.getLevelName()).setParameter(1,level.getLevelPrice()).setParameter(2,level.getLevelId()).executeUpdate();
        if (b!=0){
            a=true;
        }
        return a;
    }

    @Override
    public Level getlevelByIdDao(int id) {
        String hql="from Level where levelId=?";
        Level level=(Level) session().createQuery(hql).setParameter(0,id).uniqueResult();
        return level;
    }

}
