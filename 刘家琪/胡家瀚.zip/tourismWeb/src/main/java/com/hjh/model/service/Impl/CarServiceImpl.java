package com.hjh.model.service.Impl;

import com.hjh.model.dao.CarDao;
import com.hjh.model.entity.Car;
import com.hjh.model.service.CarService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class CarServiceImpl implements CarService {

    @Autowired
    private CarDao carDao;

    public CarDao getCarDao() {
        return carDao;
    }

    public void setCarDao(CarDao carDao) {
        this.carDao = carDao;
    }

    @Override
    public List<Car> AllCar() {
        return carDao.AllCar();
    }

    @Override
    public boolean addCar(Car car) {
        return carDao.addCar(car);
    }

    @Override
    public boolean DeleCar(Car car) {
        return carDao.DeleCar(car);
    }
}
