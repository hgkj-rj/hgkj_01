package com.hgkj.model.service.impl;

import com.hgkj.model.dao.LineDao;
import com.hgkj.model.entity.Line;
import com.hgkj.model.service.LineService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class LineServiceImpl implements LineService {
    @Autowired
    private LineDao lineDao;

    public void setLineDao(LineDao lineDao) {
        this.lineDao = lineDao;
    }

    @Override
    public List<Line> allLineService() {
        return lineDao.allLineDao();
    }

    @Override
    public boolean addLineService(Line line) {
        return lineDao.addLineDao(line);
    }

    @Override
    public boolean deleteLineService(Line line) {
        return lineDao.deleteLineDao(line);
    }

    @Override
    public boolean updateLineService(Line line) {
        return lineDao.updateLineDao(line);
    }

    @Override
    public Line getLineByIdService(String lineId) {
        return lineDao.getLineByIdDao(lineId);
    }
}
