package com.mqy.controler.action;

import com.mqy.model.entity.Linetype;
import com.mqy.model.service.LineTypeService;
import com.opensymphony.xwork2.ActionContext;
import org.apache.commons.io.FileUtils;
import org.apache.struts2.ServletActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

@Controller
@Namespace("/")
@ParentPackage("json-default")
public class LineTypeAction {
    private int pageSize=2;
    private int pageIndex;
    private Linetype linetype;
    private String message;
    private File file; //�õ��ϴ����ļ�
    private String fileContentType; //�õ��ļ�������
    private String fileFileName; //�õ��ļ�������

    @Autowired
    private LineTypeService lineTypeService;

    public void setLineTypeService(LineTypeService lineTypeService) {
        this.lineTypeService = lineTypeService;
    }

    /**
     * �鿴������·����
     * @return
     */
    @Action(value = "allLineTypeAction", results = {
            @Result(name = "all", type = "redirect", location = "ht/seeLineType.jsp")
    })
    public String allLineType() {
        System.out.println("---�鿴������·����---");
        List<Linetype> allLineTypeList = lineTypeService.allLineTypeService();
        ActionContext.getContext().getSession().put("allLineTypeList",
              allLineTypeList);
        return "all";
    }

    /**
     * ������·����
     * @return
     */
    @Action(value = "addLineTypeAction", results = {
       @Result(name = "add", type = "redirectAction", params = {
               "actionName", "allLineTypeAction"})
    })
    public String addLineType() {
        System.out.println("---������·����---");
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss");
        linetype.setTime(sdf.format(new Date()));
        String path= ServletActionContext.getServletContext().getRealPath
            ("img/"+fileFileName);
        File dest=new File(path);
        try {
            FileUtils.copyFile(file,dest);
            linetype.setIcon("img/"+fileFileName);
        } catch (IOException e) {
            e.printStackTrace();
        }
        lineTypeService.addLineTypeService(linetype);
        return "add";
    }

    /**
     * ɾ����·����
     * @return
     */
    @Action(value = "deleteLineTypeAction", results = {
       @Result(name = "delete",type = "redirectAction", params = {
               "actionName", "allLineTypeAction"})
    })
    public String deleteLineType() {
        System.out.println("---ɾ����·����---");
        lineTypeService.deleteLineTypeService(linetype.getLineTypeId());
        return "delete";
    }

    /**
     * �޸���·����
     * @return
     */
    @Action(value = "updateLineTypeAction", results = {
       @Result(name = "update", type = "redirectAction", params = {
              "actionName", "allLineTypeAction"})
    })
    public String updateLineType() {
        System.out.println("---�޸���·����---");
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss");
        linetype.setTime(sdf.format(new Date()));
        String path= ServletActionContext.getServletContext().getRealPath
               ("img/"+fileFileName);
        File dest=new File(path);
        try {
            FileUtils.copyFile(file,dest);
            linetype.setIcon("img/"+fileFileName);
        } catch (IOException e) {
            e.printStackTrace();
        }
        lineTypeService.updateLineTypeService(linetype);
        return "update";
    }

    /**
     * ��ȡ��·���Ͷ���
     * @return
     */
    @Action(value = "findLineTypeAction",results = {
       @Result(name = "find",type = "redirect", location = "ht/updateLineType.jsp")
    })
    public String findLineType() {
        System.out.println("---��ȡ��·���Ͷ���Id---");
        Linetype linetype1 = lineTypeService.getLineTypeService(linetype.getLineTypeId());
        ServletActionContext.getRequest().getSession().setAttribute("linetype1",linetype1);
        return "find";
    }

    public int getPageIndex() {
        return pageIndex;
    }

    public void setPageIndex(int pageIndex) {
        this.pageIndex = pageIndex;
    }

    public File getFile() {
        return file;
    }

    public void setFile(File file) {
        this.file = file;
    }

    public String getFileContentType() {
        return fileContentType;
    }

    public void setFileContentType(String fileContentType) {
        this.fileContentType = fileContentType;
    }

    public String getFileFileName() {
        return fileFileName;
    }

    public void setFileFileName(String fileFileName) {
        this.fileFileName = fileFileName;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Linetype getLinetype() {
        return linetype;
    }

    public void setLinetype(Linetype linetype) {
        this.linetype = linetype;
    }
}
