package com.hgkj.model.service;

import com.hgkj.model.entity.Subsidy;

import java.util.List;

public interface SubsidyService {
    List<Subsidy> allSubsidyService();
    boolean addSubsidyService(Subsidy subsidy);
    boolean updateSubsidyService(Subsidy subsidy);
    boolean deleteSubsidyService(int subsidyId);
    Subsidy getByIdSubsidyService(int subsidyId);
}
