package com.hgkj.controler.action;


import com.hgkj.model.dao.LinetypeDao;
import com.hgkj.model.entity.Line;
import com.hgkj.model.entity.Linetype;
import com.hgkj.model.service.LinetypeService;
import com.opensymphony.xwork2.ActionContext;
import org.apache.struts2.ServletActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import javax.servlet.ServletContext;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Random;

@Controller
@Namespace("/")
@ParentPackage("struts-default")
public class LinetypeAction {
    @Autowired
    private LinetypeService linetypeService;
    private File upload;
    private Linetype linetype;
    private String uploadFileName;
    private String uploadContentType;
    public LinetypeService getLinetypeService() {
        return linetypeService;
    }
    public String getUploadFileName() {
        return uploadFileName;
    }
    public void setUploadFileName(String uploadFileName) {
        this.uploadFileName = uploadFileName;
    }
    public String getUploadContentType() {
        return uploadContentType;
    }
    public void setUploadContentType(String uploadContentType) {
        this.uploadContentType = uploadContentType;
    }
    public File getUpload() {
        return upload;
    }
    public void setUpload(File upload) {
        this.upload = upload;
    }
    public Linetype getLinetype() {
        return linetype;
    }
    public void setLinetype(Linetype linetype) {
        this.linetype = linetype;
    }
    public void setLinetypeService(LinetypeService linetypeService) {
        this.linetypeService = linetypeService;
    }

    @Action(value = "allLinetype",results = {@Result(name = "all",type = "redirect",location = "ht/linetypeAll.jsp")})
    public String allLinetype(){
        List<Linetype> linetypeList=linetypeService.allLinetypeService();
        ActionContext.getContext().getSession().put("linetypeList",linetypeList);
        return "all";
    }

    @Action(value = "addLinetype",results = {@Result(name = "add",type = "redirect",location = "allLinetype.action"),
            @Result(name = "error",type = "redirect",location = "ht/linetypeAdd.jsp")})
    public String addLinetype(){
        ServletContext application = ServletActionContext.getServletContext();
        String filePath = application.getRealPath("upload");
        File file=new File(filePath);
        if (!file.exists()){
            file.mkdirs();
        }
        upload.renameTo(new File(file,uploadFileName));
        linetype.setIcon("upload/"+uploadFileName);
        Date date = new Date();
        SimpleDateFormat dateFormat=new SimpleDateFormat("yyyy-MM-dd :hh:mm:ss");
        linetype.setTime(dateFormat.format(date));
        linetype.setLineTypeId(getCharAndNumr(6));
        boolean f=linetypeService.addLinetypeService(linetype);
        if (f){
            return "add";
        }
        return "error";
    }

    @Action(value = "deleteLinetype",results = {@Result(name = "delete",type = "redirectAction",location = ""),
            @Result(name = "error",type = "redirect",location = "")})
    public String deleteLinetype(){
        boolean f=linetypeService.deleteLinetypeService(linetype);
        if (f){
            return "delete";
        }
        return "error";
    }

    @Action(value = "updateLinetype",results = {@Result(name = "update",type = "redirectAction",location = "/ht/linetypeAll.jsp"),
            @Result(name = "error",type = "redirect",location = "/ht/linetypeUpdate.jsp")})
    public String updateLinetype(){
        if (uploadFileName==null){
            File tempFile = new File(linetype.getIcon().trim());
            String fileName = tempFile.getName();
            linetype.setIcon("upload/"+fileName);
        }else {
            ServletContext application = ServletActionContext.getServletContext();
            String filePath = application.getRealPath("upload");
            File file=new File(filePath);
            if (!file.exists()){
                file.mkdirs();
            }
            upload.renameTo(new File(uploadFileName));
            linetype.setIcon("upload/"+uploadFileName);
        }
        SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
        linetype.setTime(sdf.format(new Date()));
        boolean f=linetypeService.updateLinetypeService(linetype);
        if (f){
            return "update";
        }
        return "error";
    }

    @Action(value = "findLinetype",results = {@Result(name = "find",type = "redirect",location = "/ht/linetypeUpdate.jsp")})
    public String findLinetype(){
        linetype = linetypeService.getLinetypeByIdService(linetype.getLineTypeId());
        ActionContext.getContext().getSession().put("linetype",linetype);
        return "find";
    }


    public String updateNews(){
        SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
        linetype.setTime(sdf.format(new Date()));
        linetypeService.updateLinetypeService(linetype);
        return "update";
    }

    private static String getCharAndNumr(int length) {
        String val="";
        Random random=new Random();
        for (int i=0;i<length;i++){
            String charOrNum = random.nextInt(2) % 2==0?"char":"num";
            if ("char".equalsIgnoreCase(charOrNum)){
                int choice = random.nextInt(2) % 2 ==0?65:97;
                val +=(char)(choice+random.nextInt(26));
            }else if ("num".equalsIgnoreCase(charOrNum)){
                val += String.valueOf(random.nextInt(10));
            }
        }
        return val;
    }
}
