package com.hgkj.model.dao.impl;

import com.hgkj.model.dao.LineDao;
import com.hgkj.model.entity.Line;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
@Repository
@Transactional
public class LineDaoImpl implements LineDao {
    @Autowired
    private SessionFactory sessionFactory;
    public Session getSession(){
        return sessionFactory.getCurrentSession();
    }
    @Override
    public List<Line> allLineDao() {
        Query query = getSession().createQuery("from Line");
        return query.list();
    }

    @Override
    public Line lineByIdDao(String lineID) {
        Line line =new Line();
        line=getSession().get(Line.class,lineID);
        return line;
    }

    @Override
    public boolean linedeleteDao(String lineID) {
        boolean result=false;
        Line line=getSession().get(Line.class,lineID);
        try {
            getSession().delete(line);
            result=true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

    @Override
    public boolean lineAddDao(Line line) {
        boolean result=false;
        try {
            getSession().save(line);
            result=true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }
}
