package com.workmoney.controller.action;

import com.workmoney.model.entity.*;
import com.workmoney.model.service.AttendanceService;
import com.workmoney.model.service.RewardService;
import com.workmoney.model.service.StaffService;
import com.workmoney.model.service.SubsidyLogService;
import com.workmoney.util.ExcelJava;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.struts2.ServletActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * user@Bright Rain .
 * 2019/6/25.
 */

@Namespace("/")
@ParentPackage("json-default")
@Controller
public class StaffExportExeclAction {

    private int staffId;
    private String remark;

    @Autowired
    private StaffService service;

    @Autowired
    private SubsidyLogService logService;

    @Autowired
    private AttendanceService attendanceService;

    @Autowired
    private RewardService rewardService;

    /**
     * 生成所有的工资表
     */
    @Action(value = "/payOffAction",results = {@Result(name = "success",type = "redirect",location = "main.jsp"),
            @Result(name = "error",type = "redirect",location = "error.jsp")})
    public String payOffAction(){
        HttpServletResponse response = ServletActionContext.getResponse();
        HttpServletRequest request = ServletActionContext.getRequest();
        //获取数据
        HttpSession session = request.getSession();
        List<Staff> listSercharService = (ArrayList)session.getAttribute("listSercharService");



        //excel标题
        String[] title = {"员工编号","姓名","性别","所在店铺","等级","基本工资"
                ,"月补贴","月奖金","考勤扣款","应发工资","实发工资","备注"};
        //excel文件名
        String fileName = "员工工资表"+System.currentTimeMillis()+".xls";
        //sheet名
        String sheetName = "员工工资表";
        String content[][] = new String[title.length][title.length];
        for (int i = 0; i < listSercharService.size(); i++) {

            Staff s = listSercharService.get(i);

            content[i][0] = String.valueOf(s.getStaffId());
            content[i][1]=s.getStaffName();
            content[i][2]=s.getStaffSex();
            content[i][3]=s.getShop().getShopName();
            content[i][4]=s.getLevel().getLevelName();
            content[i][5]=s.getLevel().getLevelPrice().toString();
            content[i][6]=s.getSalaryLog().getTotalSubsidy();
            content[i][7]=s.getSalaryLog().getTotalReward();
            content[i][8]=s.getSalaryLog().getAttPercent();
            content[i][9]=s.getSalaryLog().getSalaryOld();
//            content[i][9]= String.valueOf(yinfaMap.get(s.getStaffId()));
            content[i][10]=  s.getSalaryLog().getSalaryTrue();
//            content[i][10]=  String.valueOf(shiFaMap.get(s.getStaffId()));
            content[i][11]=s.getSalaryLog().getSallogRemark();
        }
        HSSFWorkbook wb = ExcelJava.getHSSFWorkbook(sheetName, title, content, null);
//响应到客户端
        try {
            this.setResponseHeader(response, fileName);
            OutputStream os = response.getOutputStream();
            wb.write(os);
            os.flush();
            os.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "success";
    }


    /**
     * 修改备注
     */
    @Action(value = "/updateStaffByIdRemrkAction",results = {@Result(name = "success",type = "redirectAction",location = "excutorSalaryAction"),
    @Result(name = "error",type = "redirect",location = "error.jsp")})
    public String updateRemark(){
      boolean f = service.updateStaffRemarkByIdService(staffId,remark);
        if(f){
            return "success";
        }
        return "error";
    }

    /**
     * 查询员工
     * @return
     */
    @Action(value = "excutorSalaryAction",results = {@Result(name = "success",type = "redirect",location = "html/salaryList.jsp"),
    @Result(name = "error",type = "redirect",location = "error.jsp")})
    public String excutorSalaryAction(){
        List<Staff> listSercharService = service.getStaffListSercharService();
        HttpSession session = ServletActionContext.getRequest().getSession();
        if(listSercharService==null){
            return "error";
        }else {
            session.setAttribute("listSercharService",listSercharService);
            return "success";
        }
    }


    /**
     * 生成自己的文档
     * @return
     */
    @Action(value = "/excutorExcelStaff",results = {@Result(name = "success",type = "redirect",location = "main.jsp")})
    public String exportExcel(){
        HttpServletResponse response = ServletActionContext.getResponse();
        HttpServletRequest request = ServletActionContext.getRequest();
        //获取数据
        HttpSession session = request.getSession();
        Staff staff = (Staff) session.getAttribute("staff");
        List<Staff> list = new ArrayList<>();
        list.add(staff);
        //excel标题
        String[] title = {"员工编号","姓名","性别","所在店铺","等级","基本工资"
        ,"月补贴","月奖金","考勤扣款","应发工资","实发工资","备注"};
        //excel文件名
         String fileName = "员工工资表"+System.currentTimeMillis()+".xls";
        //sheet名
         String sheetName = "员工工资表";
         String content[][] = new String[title.length][title.length];
        for (int i = 0; i < list.size(); i++) {

            Staff s = list.get(i);

            content[i][0] = String.valueOf(s.getStaffId());
            content[i][1]=s.getStaffName();
            content[i][2]=s.getStaffSex();
            content[i][3]=s.getShop().getShopName();
            content[i][4]=s.getLevel().getLevelName();
            content[i][5]=s.getLevel().getLevelPrice().toString();
            content[i][6]=s.getSalaryLog().getTotalSubsidy();
            content[i][7]=s.getSalaryLog().getTotalReward();
            content[i][8]=s.getSalaryLog().getAttPercent();
            content[i][9]=s.getSalaryLog().getSalaryOld();
            content[i][10]=s.getSalaryLog().getSalaryTrue();
            content[i][11]=s.getSalaryLog().getSallogRemark();
        }
        HSSFWorkbook wb = ExcelJava.getHSSFWorkbook(sheetName, title, content, null);
//响应到客户端
        try {
            this.setResponseHeader(response, fileName);
            OutputStream os = response.getOutputStream();
            wb.write(os);
            os.flush();
            os.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "success";
    }

    //发送响应流方法
    public void setResponseHeader(HttpServletResponse response, String fileName) {
        try {
            try {
                fileName = new String(fileName.getBytes(),"ISO8859-1");
            } catch (UnsupportedEncodingException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            response.setContentType("application/octet-stream;charset=ISO8859-1");
            response.setHeader("Content-Disposition", "attachment;filename="+ fileName);
            response.addHeader("Pargam", "no-cache");
            response.addHeader("Cache-Control", "no-cache");
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public int getStaffId() {
        return staffId;
    }

    public void setStaffId(int staffId) {
        this.staffId = staffId;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }
}
