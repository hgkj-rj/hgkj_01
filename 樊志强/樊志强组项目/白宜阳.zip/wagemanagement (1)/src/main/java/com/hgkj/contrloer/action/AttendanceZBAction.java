package com.hgkj.contrloer.action;

import com.hgkj.model.entity.Attendance;
import com.hgkj.model.entity.Department;
import com.hgkj.model.service.AttendanceZBService;
import org.apache.struts2.ServletActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import java.util.List;

@Controller
@Namespace("/")
@ParentPackage("struts-default")
public class AttendanceZBAction {
    @Autowired
    private AttendanceZBService attendanceZBService;
    private Attendance attendance;

    public Attendance getAttendance() {
        return attendance;
    }

    public void setAttendance(Attendance attendance) {
        this.attendance = attendance;
    }

    public void setAttendanceZBService(AttendanceZBService attendanceZBService) {
        this.attendanceZBService = attendanceZBService;
    }

    @Action(value = "allattendance",results = @Result(name = "all",type = "redirect",location = "/html/attendanceZBList.jsp"))
    public String allattendance(){
        List<Attendance> attendanceList=attendanceZBService.allAttendanceService();
        ServletActionContext.getRequest().getSession().setAttribute("attendanceList",attendanceList);
        return "all";
    }

    @Action(value = "addattendance",results = @Result(name = "adds",type = "redirectAction",params = {"actionName","allattendance"}))
    public String addattendance(){
        boolean r=attendanceZBService.addAttendanceService(attendance);
        if (r==true){
            return "adds";
        }else {
            return "adde";
        }
    }

    @Action(value = "delattendance",results = @Result(name = "dels",type = "redirectAction",params = {"actionName","allattendance"}))
    public String deleteattendance(){
        boolean r=attendanceZBService.deleteAttendanceService(attendance.getAttId());
        if (r==true){
            return "dels";
        }else {
            return "dele";
        }
    }

    @Action(value = "updattendance",results = @Result(name = "upds",type = "redirectAction",params = {"actionName","allattendance"}))
    public String Updattendance(){
        boolean r=attendanceZBService.updateAttendanceService(attendance);
        if (r==true){
            return "upds";
        }else {
            return "upde";
        }
    }

    @Action(value = "getByIdattendances",results = {@Result(name = "getByIds",type = "redirect",location = "/html/attendanceZBUpdate.jsp")})
    public String getByIdattendance(){
        Attendance attendance1=attendanceZBService.getByIdAttendanceService(attendance.getAttId());
        ServletActionContext.getRequest().getSession().setAttribute("attendance1",attendance1);
        return "getByIds";
    }
}
