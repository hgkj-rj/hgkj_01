package com.tourism.model.dao;

import com.tourism.model.entity.Linetype;

import java.util.List;

public interface LinetypeDao {
    public boolean addLinetypeDao(Linetype linetype);
    public boolean updateLinetypeDao(Linetype linetype);
    public List<Linetype> allLinetypeDao();
    public Linetype getLinetypeByIdDao(String linetypeId);
}
