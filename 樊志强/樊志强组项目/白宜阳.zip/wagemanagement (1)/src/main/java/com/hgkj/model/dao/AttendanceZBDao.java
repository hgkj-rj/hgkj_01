package com.hgkj.model.dao;

import com.hgkj.model.entity.Attendance;

import java.util.List;

public interface AttendanceZBDao {
    List<Attendance> allAttendanceDao();
    boolean addAttendanceDao(Attendance attendance);
    boolean updateAttendanceDao(Attendance attendance);
    boolean deleteAttendanceDao(int attId);
    Attendance getByIdAttendanceDao(int attId);
}
