package com.workmoney.model.dao.impl;

import com.workmoney.model.dao.RoleDao;
import com.workmoney.model.entity.Role;
import com.workmoney.model.entity.Staff;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * user@Bright Rain .
 * 2019/6/27.
 */
@Repository
@Transactional
public class RoleDaoImpl implements RoleDao {

    @Autowired
    private SessionFactory sessionFactory;

    @Override
    public List<Role> getAllRole() {
        Session session = sessionFactory.getCurrentSession();
        String hql = "from Role ";
        List<Role> roleList = session.createQuery(hql, Role.class).list();
        return roleList;
    }

    @Override
    public void delRoleByIdDao(Role role) {
        Session session = sessionFactory.getCurrentSession();
        session.delete(role);
    }

    @Override
    public void addRoleDao(Role role) {
        Session session = sessionFactory.getCurrentSession();
        session.save(role);
    }

    @Override
    public List<Staff> serchNameAllowDao(String name) {
        Session session = sessionFactory.getCurrentSession();
        //  System.out.println(month);
        String hql =null;

        if(name!=null&&!name.equals("")){
            name="%"+name+"%";
            hql =  "from Staff as s where s.staffName like '"+name+"' " ;
        }else {
            hql =  "from Staff " ;
        }
        List<Staff> list = session.createQuery(hql, Staff.class).list();
        return list;
    }

    public SessionFactory getSessionFactory() {
        return sessionFactory;
    }

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }
}
