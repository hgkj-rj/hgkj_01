package com.xl.model.dao.impl;

import com.xl.model.dao.EmployeeDao;
import com.xl.model.entity.Department;
import com.xl.model.entity.Employee;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class EmployeeDaoImpl implements EmployeeDao {
    @Override
    public int EmployeeDao(int pageSize) {
        int totalPage=0;
        Connection connection=DBManager.getConnection();
        PreparedStatement preparedStatement=null;
        ResultSet resultSet=null;
        String sql="select count(*) from employee";
        try {
            preparedStatement=connection.prepareStatement(sql);
            resultSet=preparedStatement.executeQuery();
            if (resultSet.next()){
                totalPage=(resultSet.getInt(1)-1)/pageSize+1;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            DBManager.closeAll(connection,preparedStatement,resultSet);
        }
        return totalPage;
    }


    @Override
    public List<Employee> allEmployeeDao(int pageIndex, int pageSize) {
        List<Employee> employeeList=new ArrayList<>();
        Connection connection=DBManager.getConnection();
        PreparedStatement preparedStatement=null;
        ResultSet resultSet=null;
        String sql="select * from employee limit  ?,?";
        try {
            preparedStatement=connection.prepareStatement(sql);
            preparedStatement.setInt(1,(pageIndex-1)*pageSize);
            preparedStatement.setInt(2,pageSize);
            resultSet=preparedStatement.executeQuery();
            while (resultSet.next()){
                Employee employee=new Employee();
                employee.setEmployeeId(resultSet.getInt("employeeId"));
                employee.setEmployeeName(resultSet.getString("employeeName"));
                employee.setEmployeeSex(resultSet.getString("employeeSex"));
                employee.setDepartmentId(resultSet.getString("departmentId"));
                employee.setEmployeeGongzhong(resultSet.getString("employeeGongzhong"));
                employee.setEmployeeXueli(resultSet.getString("employeeXueli"));
                employee.setEmployeeTime(resultSet.getString("employeeTime"));
                employeeList.add(employee);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            DBManager.closeAll(connection,preparedStatement,resultSet);
        }
        return employeeList;
    }


    @Override
    public boolean addEmployeeDao(Employee employee) {

        String sql = "insert into employee(employeeName,employeeSex,departmentId,employeeGongzhong,employeeXueli,employeeTime) values(?,?,?,?,?,?)";
        Object[] objects = {employee.getEmployeeName(),employee.getEmployeeSex(), employee.getDepartmentId(),employee.getEmployeeGongzhong(),employee.getEmployeeXueli(),employee.getEmployeeTime()};
        return DBManager.executeUpdate(sql,objects);
    }

    @Override
    public boolean deleteEmployeeDao(int employeeId) {
        String sql = "delete from employee where employeeId=?";
        Object[] objects = {employeeId};
        return DBManager.executeUpdate(sql,objects);
    }

    @Override
    public boolean updateEmployeeDao(Employee employee) {

        String sql = "update employee set employeeName=?,employeeSex=?,employeeGongzhong=? ,departmentId=?,employeeXueli=?,employeeTime=?where employeeId=?";
        Object[] objects = {employee.getEmployeeName(),employee.getEmployeeSex(), employee.getDepartmentId(),employee.getEmployeeGongzhong(),employee.getEmployeeXueli(),employee.getEmployeeTime(),employee.getEmployeeId()};
        return DBManager.executeUpdate(sql,objects);
    }
}
