package com.hgkj.controler.action;

import com.hgkj.model.entity.Customer;
import com.hgkj.model.service.ManagerService;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

@Controller
@Namespace("/ht")
@ParentPackage("struts-default")
public class ManagerAction {
    @Autowired
    private ManagerService managerService;
    private Customer customer;

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public ManagerService getManagerService() {
        return managerService;
    }

    public void setManagerService(ManagerService managerService) {
        this.managerService = managerService;
    }

    @Action(value = "htdenglu", results = {@Result(name = "denglucg", type = "redirect", location = "index.jsp"), @Result(
            name = "dlerror", type = "redirect", location = "index.jsp")})
    public String htdenglu() {
        boolean rs=managerService.managerloginService(customer);
        System.out.println(customer.getAccount()+customer.getPassword());
        if (rs) {
            return "denglucg";

        } else {
            return "dlerror";
        }
    }

//    public String exitAction(){
//
//    }
}
