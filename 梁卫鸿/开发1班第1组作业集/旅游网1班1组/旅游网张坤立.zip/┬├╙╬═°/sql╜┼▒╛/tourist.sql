/*
 Navicat Premium Data Transfer

 Source Server         : Mysql
 Source Server Type    : MySQL
 Source Server Version : 50724
 Source Host           : localhost:3306
 Source Schema         : travel

 Target Server Type    : MySQL
 Target Server Version : 50724
 File Encoding         : 65001

 Date: 08/07/2019 09:54:32
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for tourist
-- ----------------------------
DROP TABLE IF EXISTS `tourist`;
CREATE TABLE `tourist`  (
  `touristID` int(255) NOT NULL AUTO_INCREMENT COMMENT '游客信息编号，主键',
  `IDCard` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '游客身份证号',
  `tel` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '游客手机号',
  `realName` varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '游客真实姓名',
  PRIMARY KEY (`touristID`) USING BTREE,
  INDEX `IDCard`(`IDCard`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 19 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of tourist
-- ----------------------------
INSERT INTO `tourist` VALUES (14, '372922199904235413', '15864521236', '张三1');
INSERT INTO `tourist` VALUES (15, '372922199904235413', '15864521236', '张三2');
INSERT INTO `tourist` VALUES (16, '372922199904235413', '15864521236', '张三3');
INSERT INTO `tourist` VALUES (17, '372922199904235413', '15864521236', '张三4');
INSERT INTO `tourist` VALUES (18, '372922199904235413', '15864521236', '张三5');

SET FOREIGN_KEY_CHECKS = 1;
