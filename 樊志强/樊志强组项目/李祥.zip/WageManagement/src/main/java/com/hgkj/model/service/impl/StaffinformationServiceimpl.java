package com.hgkj.model.service.impl;

import com.hgkj.model.dao.Staffinformationdao;
import com.hgkj.model.entity.Staff;
import com.hgkj.model.service.StaffinformationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class StaffinformationServiceimpl implements StaffinformationService {

    @Autowired
    private Staffinformationdao staffinformationdao;

    public void setStaffinformationdao(Staffinformationdao staffinformationdao) {
        this.staffinformationdao = staffinformationdao;
    }


    @Override
    public Staff getByIdService(int staffId) {
        return staffinformationdao.getByIdDao(staffId);
    }

    @Override
    public List<Staff> allStaffService() {
        return staffinformationdao.allStaffdao();
    }

    @Override
    public boolean addStaffService(Staff staff) {
        return staffinformationdao.addStaffdao(staff);
    }

    @Override
    public boolean deleteStaffService(int staffId) {
        return staffinformationdao.deleteStaffdao(staffId);
    }

    @Override
    public boolean updateStaffService(Staff staff) {
        return staffinformationdao.updateStaffdao(staff);
    }
}
