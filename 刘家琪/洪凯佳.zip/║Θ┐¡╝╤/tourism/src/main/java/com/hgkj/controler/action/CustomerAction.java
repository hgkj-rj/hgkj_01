package com.hgkj.controler.action;

import com.hgkj.model.entity.Customer;
import com.hgkj.model.service.CustomerService;
import com.opensymphony.xwork2.ActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

@Controller
@Namespace("/")
@ParentPackage("struts-default")
public class CustomerAction {
    @Autowired
    private CustomerService customerService;
    private Customer customer;

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public void setCustomerService(CustomerService customerService) {
        this.customerService = customerService;
    }

    @Action(value = "addCustomer", results = {@Result(name = "add", type = "redirectAction", location = "/qt/login.jsp"),
            @Result(name = "error", type = "redirect", location = "/qt/regist.jsp")})
    public String addCustomer() {
        boolean f = customerService.addCustomerService(customer);
        if (f) {
            return "add";
        }
        return "error";
    }

    @Action(value = "htCustomer", results = {@Result(name = "chenggong", type = "redirect", location = "/ht/index.jsp"),
            @Result(name = "error", type = "redirect", location = "/ht/adminLogin.jsp")})
    public String Customer() {
        customer = customerService.CustomerLoginService(customer);
        ActionContext.getContext().getSession().put("customer",customer);
        if (customer != null) {
            if (customer.getType() == 1) {
                return "chenggong";
            } else {
                return "error";
            }
        } else {
            return "error";
        }
    }


    @Action(value = "qtCustomer", results = {@Result(name = "chenggong", type = "redirect", location = "qt/index.jsp"),
            @Result(name = "error", type = "redirect", location = "/qt/login.jsp")})
    public String Customerq() {
        customer = customerService.CustomerLoginService(customer);
        ActionContext.getContext().getSession().put("customer",customer);
        if (customer != null) {
            return "chenggong";
        } else {
            return "error";
        }

    }
}
