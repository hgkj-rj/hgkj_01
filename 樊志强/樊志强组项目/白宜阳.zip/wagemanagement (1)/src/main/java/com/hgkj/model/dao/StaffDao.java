package com.hgkj.model.dao;

import com.hgkj.model.entity.*;

import java.util.List;

public interface StaffDao {
    /**
     * 登录
     * @param staff
     * @return
     */
    List<Staff> loginStaffDao(Staff staff);

    /**
     * 根据Id查询用户
     * @param staffId
     * @return
     */
    Staff getByIdStaffDao(int staffId);

    /**
     * 用户修改密码
     * @param staff
     * @return
     */
    boolean updateStaffDao(Staff staff);

    /**
     * 修改员工信息
     * @param staff
     * @return
     */
    boolean updateStaffXXDao(Staff staff);

    /**
     * 查询所有员工信息
     * @return
     */
    List<Staff>allStaffDao();

    /**
     * 添加员工信息
     * @return
     */
    boolean addStaffDao(Staff staff);

    /**
     * 按照Id删除员工信息
     * @param staffId
     * @return
     */
    boolean deleteStaffDao(int staffId);

    /**
     * 遍历等级名称
     * @return
     */
    List<Level> allLevelDao();

    /**
     * 遍历角色名称
     * @return
     */
    List<Role> allRoleDao();

    /**
     * 遍历部门名称
     * @return
     */
    List<Department> allDepartmentDao();

    /**
     * 遍历店铺名称
     * @return
     */
    List<Shop> allShopDao();
}
