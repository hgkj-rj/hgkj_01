package com.hgkj.model.service;

import com.hgkj.model.entity.*;

import java.util.List;

public interface StaffService {
    /**
     * 登录
     * @param staff
     * @return
     */
    List<Staff> loginStaffService(Staff staff);

    /**
     * 根据Id查询用户
     * @param staffId
     * @return
     */
    Staff getByIdStaffService(int staffId);

    /**
     * 用户修改密码
     * @param staff
     * @return
     */
    boolean updateStaffService(Staff staff);

    /**
     * 修改员工信息
     * @param staff
     * @return
     */
    boolean updateStaffXXService(Staff staff);

    /**
     * 查询所有员工信息
     * @return
     */
    List<Staff>allStaffService();

    /**
     * 添加员工信息
     * @return
     */
    boolean addStaffService(Staff staff);

    /**
     * 按照Id删除员工信息
     * @param staffId
     * @return
     */
    boolean deleteStaffService(int staffId);

    /**
     * 遍历等级名称
     * @return
     */
    List<Level> allLevelService();

    /**
     * 遍历角色名称
     * @return
     */
    List<Role> allRoleService();

    /**
     * 遍历部门名称
     * @return
     */
    List<Department> allDepartmentService();

    /**
     * 遍历店铺名称
     * @return
     */
    List<Shop> allShopService();

}
