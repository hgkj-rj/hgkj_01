/*
Navicat MySQL Data Transfer

Source Server         : zx
Source Server Version : 50624
Source Host           : localhost:3306
Source Database       : tourism

Target Server Type    : MYSQL
Target Server Version : 50624
File Encoding         : 65001

Date: 2019-07-08 21:37:16
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for car
-- ----------------------------
DROP TABLE IF EXISTS `car`;
CREATE TABLE `car` (
  `carId` int(10) NOT NULL AUTO_INCREMENT,
  `customerId` int(10) NOT NULL,
  `lineId` varchar(36) NOT NULL,
  `time` datetime NOT NULL,
  PRIMARY KEY (`carId`),
  KEY `wjl_1` (`customerId`),
  KEY `wj_2` (`lineId`),
  CONSTRAINT `wj_2` FOREIGN KEY (`lineId`) REFERENCES `line` (`lineId`),
  CONSTRAINT `wjl_1` FOREIGN KEY (`customerId`) REFERENCES `customer` (`customerId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of car
-- ----------------------------

-- ----------------------------
-- Table structure for customer
-- ----------------------------
DROP TABLE IF EXISTS `customer`;
CREATE TABLE `customer` (
  `customerId` int(11) NOT NULL AUTO_INCREMENT,
  `account` varchar(12) NOT NULL,
  `name` varchar(12) NOT NULL,
  `password` varchar(12) NOT NULL,
  `gender` char(2) NOT NULL,
  `identityId` varchar(18) NOT NULL,
  `tel` varchar(11) NOT NULL,
  `type` int(1) DEFAULT NULL,
  PRIMARY KEY (`customerId`),
  UNIQUE KEY `yuan1` (`account`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of customer
-- ----------------------------
INSERT INTO `customer` VALUES ('1', '123456', '蔡分', '123', '男', '123456789', '1', null);

-- ----------------------------
-- Table structure for line
-- ----------------------------
DROP TABLE IF EXISTS `line`;
CREATE TABLE `line` (
  `lineId` varchar(12) NOT NULL,
  `lineTypeId` varchar(12) NOT NULL,
  `lineName` varchar(15) NOT NULL,
  `days` varchar(12) NOT NULL,
  `vehicle` char(2) NOT NULL,
  `introduction` varchar(400) DEFAULT NULL,
  `reason` varchar(100) DEFAULT NULL,
  `arrange` varchar(100) DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  `teamBuy` int(1) DEFAULT NULL,
  `teamBuyPrice` decimal(10,2) DEFAULT NULL,
  `beginTime` datetime DEFAULT NULL,
  `endTime` datetime DEFAULT NULL,
  `onTime` datetime NOT NULL,
  PRIMARY KEY (`lineId`),
  KEY `whj_5` (`lineTypeId`),
  CONSTRAINT `whj_5` FOREIGN KEY (`lineTypeId`) REFERENCES `linetype` (`lineTypeId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of line
-- ----------------------------

-- ----------------------------
-- Table structure for linetype
-- ----------------------------
DROP TABLE IF EXISTS `linetype`;
CREATE TABLE `linetype` (
  `lineTypeId` varchar(36) NOT NULL,
  `typeName` varchar(10) NOT NULL,
  `time` datetime NOT NULL,
  `icon` varchar(20) NOT NULL,
  PRIMARY KEY (`lineTypeId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of linetype
-- ----------------------------

-- ----------------------------
-- Table structure for orderdetail
-- ----------------------------
DROP TABLE IF EXISTS `orderdetail`;
CREATE TABLE `orderdetail` (
  `odId` varchar(36) NOT NULL,
  `customerId` int(11) NOT NULL,
  `lineName` varchar(15) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `orderDate` datetime NOT NULL,
  `travelDate` datetime NOT NULL,
  `total` decimal(10,2) NOT NULL,
  `lineId` varchar(36) NOT NULL,
  `state` int(1) NOT NULL,
  PRIMARY KEY (`odId`),
  KEY `wkj_1` (`customerId`),
  KEY `wkj_2` (`lineId`),
  CONSTRAINT `wkj_1` FOREIGN KEY (`customerId`) REFERENCES `customer` (`customerId`),
  CONSTRAINT `wkj_2` FOREIGN KEY (`lineId`) REFERENCES `line` (`lineId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of orderdetail
-- ----------------------------

-- ----------------------------
-- Table structure for picture
-- ----------------------------
DROP TABLE IF EXISTS `picture`;
CREATE TABLE `picture` (
  `pictureId` int(11) NOT NULL,
  `introduction` varchar(20) NOT NULL,
  `name` varchar(20) NOT NULL,
  `lineId` varchar(36) NOT NULL,
  PRIMARY KEY (`pictureId`),
  KEY `wlj_1` (`lineId`),
  CONSTRAINT `wlj_1` FOREIGN KEY (`lineId`) REFERENCES `line` (`lineId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of picture
-- ----------------------------

-- ----------------------------
-- Table structure for tourist
-- ----------------------------
DROP TABLE IF EXISTS `tourist`;
CREATE TABLE `tourist` (
  `touristId` varchar(36) NOT NULL,
  `IdCard` varchar(36) NOT NULL,
  `tel` varchar(15) NOT NULL,
  `realName` decimal(10,2) NOT NULL,
  `odId` varchar(36) NOT NULL,
  PRIMARY KEY (`touristId`),
  KEY `whj_3` (`odId`),
  CONSTRAINT `whj_3` FOREIGN KEY (`odId`) REFERENCES `orderdetail` (`odId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tourist
-- ----------------------------
