package com.workmoney.model.service;

import com.workmoney.model.dao.RewardDao;
import com.workmoney.model.entity.Reward;
import com.workmoney.model.entity.RewardLog;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * user@Bright Rain .
 * 2019/6/29.
 */
@Service
public class RewardServiceImpl  implements RewardService{

    @Autowired
    private RewardDao dao;

    @Override
    public Reward getRewardById(Reward reward) {
        return dao.getRewardById(reward);
    }

    @Override
    public List<RewardLog> getAllRewardService() {
        return dao.getAllReward();
    }

    @Override
    public void delrewardByIdService(RewardLog rewardLog) {
        dao.delrewardByIdDao(rewardLog);
    }

    @Override
    public List<Reward> getAllRewardType() {
        return dao.getAllRewardTypeDao();
    }

    @Override
    public void addEmpRewardService(RewardLog rewardLog) {
        dao.addEmpRewardDao(rewardLog);
    }

    @Override
    public void editRewardService(Reward reward) {
        dao.editRewardDao(reward);
    }

    @Override
    public void delRewordByIdService(Reward reward) {
        dao.delRewordByIdDao(reward);
    }

    @Override
    public void addRewardService(Reward reward) {
        dao.addRewardDao(reward);
    }
}
