/*
 Navicat Premium Data Transfer

 Source Server         : MySQL
 Source Server Type    : MySQL
 Source Server Version : 50720
 Source Host           : localhost:3306
 Source Schema         : travel

 Target Server Type    : MySQL
 Target Server Version : 50720
 File Encoding         : 65001

 Date: 08/07/2019 09:55:51
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for line
-- ----------------------------
DROP TABLE IF EXISTS `line`;
CREATE TABLE `line`  (
  `lineID` varchar(12) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `lineTypeID` varchar(12) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `lineName` varchar(15) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `days` varchar(12) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `vehicle` varchar(2) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `introduction` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `reason` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `arrange` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `price` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `teamBuy` int(255) NULL DEFAULT NULL,
  `teamBuyPrice` decimal(10, 2) NULL DEFAULT NULL,
  `beginTime` datetime(0) NULL DEFAULT NULL,
  `endTime` datetime(0) NULL DEFAULT NULL,
  `onTime` datetime(0) NOT NULL,
  PRIMARY KEY (`lineID`) USING BTREE,
  INDEX `FK_Line_LineType`(`lineTypeID`) USING BTREE,
  CONSTRAINT `FK_Line_LineType` FOREIGN KEY (`lineTypeID`) REFERENCES `linetype` (`lineTypeID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of line
-- ----------------------------
INSERT INTO `line` VALUES ('l1001', 'lT1001', '凤凰古城', '3', '飞机', '古城遗迹', '遗迹吃鸡', '3日游', '5000.00', 0, NULL, NULL, NULL, '2019-06-25 18:00:43');
INSERT INTO `line` VALUES ('l1002', 'lT1002', '九寨沟', '7', '汽车', '山沟沟', '沟水漂流', '7日体验沟水', '7000.00', 1, 5000.00, '2019-06-25 18:02:14', '2019-06-26 18:02:19', '2019-06-27 18:02:22');
INSERT INTO `line` VALUES ('l1003', 'lT1003', '黄果树', '5', '火车', '瀑布游', '瀑布漂流', '5日游水', '3000.00', 0, NULL, NULL, NULL, '2019-06-30 14:47:14');

SET FOREIGN_KEY_CHECKS = 1;
