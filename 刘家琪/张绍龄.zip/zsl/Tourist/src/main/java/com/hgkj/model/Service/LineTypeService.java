package com.hgkj.model.Service;

import com.hgkj.model.entity.Linetype;

import java.util.List;

public interface LineTypeService {
    public List<Linetype> allLineTypeService();
    public List<Linetype> fourLineService();
    public boolean  addLineTypeService(Linetype linetype);
    public boolean  updateLineTypeService(Linetype linetype);
    public Linetype getLineByIdService(String lineTypeId);
    public Linetype getLastService();
}
