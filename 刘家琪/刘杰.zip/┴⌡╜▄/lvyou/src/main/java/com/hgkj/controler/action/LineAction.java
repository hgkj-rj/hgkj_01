package com.hgkj.controler.action;


import com.hgkj.model.entity.*;
import com.hgkj.model.service.LineService;
import com.hgkj.model.service.LineTypeService;
import com.hgkj.model.service.impl.LineServiceImpl;
import com.hgkj.model.service.impl.LineTypeServiceImpl;
import com.opensymphony.xwork2.ActionContext;
import org.apache.commons.io.FileUtils;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import sun.misc.BASE64Encoder;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;

@Controller
@Namespace("/")
@ParentPackage("struts-default")
public class LineAction {
    @Autowired
    private LineService lineService = new LineServiceImpl();
    private LineTypeService lineTypeService = new LineTypeServiceImpl();
    private Line line;
    private Picture picture = new Picture();
    private Picture[] pictures;
    private InputStream inputStream;
    private byte[] data;
    private File[] introduction;
    private File[] img;
    private String[] name;
    private Integer id;
    private String lineName;
    private String typeName;
    private Car car = new Car();


    /*添加*/
    @Action(value = "AddLine", results = @Result(name = "AddLine", type = "redirect", location = "ht/addLine.jsp"))
    public String addLine() throws IOException {
        /*添加线路*/
        lineService.addLineService(line);
        /*得到线路最大ID*/
        int id = lineService.getLineIdService();

        /*一次插入四张图片*/
        for (int i = 0; i <= 3; i++) {
            String path = "E://IDEA//Travel_01//src//main//webapp//upImg//";
            File file = new File(path);
            if (!file.exists()) {
                file.mkdir();
            }
            FileUtils.copyFile(introduction[i], new File(file, name[i]));
            String file2 = new File(file, name[i]).toString();
            System.out.println("文件名：" + name[i]);
            System.out.println("file2:" + file2);
            /*把图片转成BASE64*/
            try {
                inputStream = new FileInputStream(file2);
                data = new byte[inputStream.available()];
                inputStream.read(data);
                inputStream.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
            BASE64Encoder encoder = new BASE64Encoder();
            picture.setIntroduction(encoder.encode(data));
            picture.setName(name[i]);
            picture.setLineId(id);
            lineService.addPictureService(picture);
        }
        return "AddLine";
    }

    /*查询所有线路*/
    @Action(value = "AllLine", results = @Result(name = "AllLine", type = "redirect", location = "ht/showLine.jsp"))
    public String allLine() {
        List<Line> lineList = lineService.allLineServcie();
        ActionContext.getContext().getSession().put("lineList", lineList);
        return "AllLine";
    }

    /*查询团购*/
    @Action(value = "AllTeamLine", results = @Result(name = "AllTeamLine", type = "redirect", location = "ht/ShowTeamLine.jsp"))
    public String allTeamLine() {
        List<Line> lineList = lineService.allLineServcie();
        ActionContext.getContext().getSession().put("lineList", lineList);
        return "AllTeamLine";
    }

    @Action(value = "GetOneLine", results = @Result(name = "GetOneLine", type = "redirect", location = "ht/updateLine.jsp"))
    /*查询单个线路+图片*/
    public String getOneLine() {
        Line line = null;
        List<Picture> pictureList = new ArrayList<>();
        List<Object[]> objectList = lineService.getOneLineService(id);
        for (Object[] object : objectList) {
            line = (Line) object[0];
            picture = (Picture) object[1];
            pictureList.add(picture);
        }
        ActionContext.getContext().getSession().put("line", line);
        ActionContext.getContext().getSession().put("pictureList", pictureList);
        return "GetOneLine";
    }

    /*修改团购信息*/
    @Action(value = "GetOneLineTeam", results = @Result(name = "GetOneLineTeam", type = "redirect", location = "ht/addLineTeam.jsp"))
    public String getOneLineTeam() {
        Line line = lineService.getOneLineTeamService(id);
        ActionContext.getContext().getSession().put("line", line);
        return "GetOneLineTeam";
    }

    /*得到所有路线安排*/
    @Action(value = "AllLineType", results = @Result(name = "AllLineType", type = "redirect", location = "GetOneLine"))
    public String allLineType() {
        List<Linetype> linetypeList = lineTypeService.allLineTypeSerivce();
        ActionContext.getContext().getSession().put("linetypeList", linetypeList);
        return "AllLineType";
    }

    /*得到所有团购路线安排*/
    @Action(value = "AllLineTeam", results = @Result(name = "AllLineTeam", type = "redirect", location = "GetOneLine"))
    public String allLineTeam() {
        List<Linetype> linetypeList = lineTypeService.allLineTypeSerivce();
        ActionContext.getContext().getSession().put("linetypeList", linetypeList);
        return "AllLineTeam";
    }

    /*查询团购*/
    @Action(value = "AllTeam", results = @Result(name = "AllTeam", type = "redirect", location = "ht/showUpdateTeamLine.jsp"))
    public String allTeam() {
        List<Line> lineList = lineService.allLineServcie();
        ActionContext.getContext().getSession().put("lineList", lineList);
        return "AllTeam";
    }

    /*添加团购*/
    @Action(value = "AddLineTeam", results = @Result(name = "AddLineTeam", type = "redirect", location = "ht/showUpdateTeamLine.jsp"))
    public String addLineTeam() {
        lineService.addLineTeamService(line);
        return "AddLineTeam";
    }


    @Action(value = "UpdateLine", results = @Result(name = "UpdateLine", type = "redirect", location = "ht/updateLine.jsp"))
    /*修改*/
    public String updateLine() throws IOException {
//        for (int i = 0; i <= 3; i++) {
//            if (img[i] == null) {
//                System.out.println(pictures[1]);
//            }
//        }
        for (Picture picture : pictures) {
            System.out.println(picture.getName());
        }
        return "UpdateLine";
    }


    /*前台查询旅游产品分类+一日游+二日游+多日游*/
    @Action(value = "WhereAllLine", results = @Result(name = "WhereAllLine", type = "redirect", location = "ShowTypeName"))
    public String whereAllLine() {
        List<Line> jlLine = lineService.whereAllLineService("境内游");
        ActionContext.getContext().getSession().put("jlLine", jlLine);
        List<Line> jwLine = lineService.whereAllLineService("境外游");
        ActionContext.getContext().getSession().put("jwLine", jwLine);
        List<Line> hdLine = lineService.whereAllLineService("海岛游");
        ActionContext.getContext().getSession().put("hdLine", hdLine);
        List<Line> zjLine = lineService.whereAllLineService("自驾游");
        ActionContext.getContext().getSession().put("zjLine", zjLine);


        List<Line> ytLine = lineService.whereAllDaySerivce("1天");
        ActionContext.getContext().getSession().put("ytLine", ytLine);
        List<Line> stLine = lineService.whereAllDaySerivce("3天");
        ActionContext.getContext().getSession().put("stLine", stLine);
        List<Line> drLine = lineService.whereNotAllDayService("1天", "3天");
        ActionContext.getContext().getSession().put("drLine", drLine);
        return "WhereAllLine";
    }

    /*查询所有返回到前台*/
    @Action(value = "GetOneLinereturnQT", results = @Result(name = "GetOneLinereturnQT", type = "redirect", location = "ShowTypeName2"))
    public String getOneLinereturnQT() {
        Line line = null;
        List<Picture> pictureList = new ArrayList<>();
        List<Object[]> objectList = lineService.getOneLineService(id);
        for (Object[] object : objectList) {
            line = (Line) object[0];
            picture = (Picture) object[1];
            pictureList.add(picture);
        }
        ActionContext.getContext().getSession().put("line", line);
        ActionContext.getContext().getSession().put("pictureList", pictureList);
        return "GetOneLinereturnQT";
    }

    /*查询境内境外游*/
    @Action(value = "GetTypeNamereturnQT", results = @Result(name = "GetTypeNamereturnQT", type = "redirect", location = "ShowTypeName1"))
    public String getTypeNamereturnQT() {
        LinkedHashSet<Line> lineList = new LinkedHashSet<>();
        LinkedHashSet<Picture> pictureList = new LinkedHashSet<>();
        List<Object[]> objectList = lineService.getTypeNamereturnQTService(typeName);
        for (Object[] object : objectList) {
            line = (Line) object[0];
            picture = (Picture) object[1];
            pictureList.add(picture);
            lineList.add(line);
        }
        ActionContext.getContext().getSession().put("lineList", lineList);
        ActionContext.getContext().getSession().put("pictureList", pictureList);
        return "GetTypeNamereturnQT";
    }

    @Action(value = "TeamBuy", results = @Result(name = "TeamBuy", type = "redirect", location = "qt/group.jsp"))
    /*前台查询团购*/
    public String teamBuy() {
        LinkedHashSet<Line> lineList = new LinkedHashSet<>();
        LinkedHashSet<Picture> pictureList = new LinkedHashSet<>();
        List<Object[]> objectList = lineService.getTeamReturnQTService();
        for (Object[] object : objectList) {
            line = (Line) object[0];
            picture = (Picture) object[1];
            pictureList.add(picture);
            lineList.add(line);
        }
        ActionContext.getContext().getSession().put("lineList", lineList);
        ActionContext.getContext().getSession().put("pictureList", pictureList);
        return "TeamBuy";
    }


    @Action(value = "GetIconreturnQT", results = @Result(name = "GetIconreturnQT", type = "redirect", location = "qt/showTeam.jsp"))
    /*查询图片商品详细信息*/
    public String getIconreturnQT() {
        Line line = null;
        List<Picture> pictureList = new ArrayList<>();
        List<Object[]> objectList = lineService.getOneLineService(id);
        ActionContext.getContext().getSession().put("objectList", objectList);

        for (Object[] object : objectList) {
            line = (Line) object[0];
            picture = (Picture) object[1];
            pictureList.add(picture);
        }
        ActionContext.getContext().getSession().put("line", line);
        ActionContext.getContext().getSession().put("pictureList", pictureList);
        return "GetIconreturnQT";
    }

    @Action(value = "Cars", results = @Result(name = "Cars", type = "redirect", location = "AddCar"))
    /*保存到购物车*/
    public String cars(){
        Line line = null;
        List<Picture> pictureList = new ArrayList<>();
        List<Object[]> objectList = lineService.getOneLineService(id);
        ActionContext.getContext().getSession().put("objectList", objectList);
        for (Object[] object : objectList) {
            line = (Line) object[0];
            picture = (Picture) object[1];
            pictureList.add(picture);
        }


        return "Cars";
    }


    public LineService getLineService() {
        return lineService;
    }

    public void setLineService(LineService lineService) {
        this.lineService = lineService;
    }

    public Line getLine() {
        return line;
    }

    public void setLine(Line line) {
        this.line = line;
    }

    public Picture getPicture() {
        return picture;
    }

    public void setPicture(Picture picture) {
        this.picture = picture;
    }


    public File[] getIntroduction() {
        return introduction;
    }

    public void setIntroduction(File[] introduction) {
        this.introduction = introduction;
    }

    public String[] getName() {
        return name;
    }

    public void setName(String[] name) {
        this.name = name;
    }

    public InputStream getInputStream() {
        return inputStream;
    }

    public void setInputStream(InputStream inputStream) {
        this.inputStream = inputStream;
    }

    public byte[] getData() {
        return data;
    }

    public void setData(byte[] data) {
        this.data = data;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public LineTypeService getLineTypeService() {
        return lineTypeService;
    }

    public void setLineTypeService(LineTypeService lineTypeService) {
        this.lineTypeService = lineTypeService;
    }

    public File[] getImg() {
        return img;
    }

    public void setImg(File[] img) {
        this.img = img;
    }

    public Picture[] getPictures() {
        return pictures;
    }

    public void setPictures(Picture[] pictures) {
        this.pictures = pictures;
    }

    public String getLineName() {
        return lineName;
    }

    public void setLineName(String lineName) {
        this.lineName = lineName;

    }

    public String getTypeName() {
        return typeName;
    }

    public void setTypeName(String typeName) {

        this.typeName = typeName;
    }

    public Car getCar() {
        return car;
    }

    public void setCar(Car car) {
        this.car = car;
    }
}

