package com.hgkj.model.entity;

import java.math.BigDecimal;
import java.util.HashSet;
import java.util.Set;

public class SalaryLog {
    private int sallogId;
    private String staffName;
    private String shopName;
    private String levelName;
    private String salTime;
    private BigDecimal levelPrice;
    private BigDecimal attPercent;
    private BigDecimal totalSubsidy;
    private BigDecimal totalReward;
    private BigDecimal salaryOld;
    private BigDecimal salaryTrue;
    private String sallogRemark;
    private Staff staff;

    public Staff getStaff() {
        return staff;
    }

    public void setStaff(Staff staff) {
        this.staff = staff;
    }

    public int getSallogId() {
        return sallogId;
    }

    public void setSallogId(int sallogId) {
        this.sallogId = sallogId;
    }

    public String getStaffName() {
        return staffName;
    }

    public void setStaffName(String staffName) {
        this.staffName = staffName;
    }

    public String getShopName() {
        return shopName;
    }

    public void setShopName(String shopName) {
        this.shopName = shopName;
    }

    public String getLevelName() {
        return levelName;
    }

    public void setLevelName(String levelName) {
        this.levelName = levelName;
    }

    public String getSalTime() {
        return salTime;
    }

    public void setSalTime(String salTime) {
        this.salTime = salTime;
    }

    public BigDecimal getLevelPrice() {
        return levelPrice;
    }

    public void setLevelPrice(BigDecimal levelPrice) {
        this.levelPrice = levelPrice;
    }

    public BigDecimal getAttPercent() {
        return attPercent;
    }

    public void setAttPercent(BigDecimal attPercent) {
        this.attPercent = attPercent;
    }

    public BigDecimal getTotalSubsidy() {
        return totalSubsidy;
    }

    public void setTotalSubsidy(BigDecimal totalSubsidy) {
        this.totalSubsidy = totalSubsidy;
    }

    public BigDecimal getTotalReward() {
        return totalReward;
    }

    public void setTotalReward(BigDecimal totalReward) {
        this.totalReward = totalReward;
    }

    public BigDecimal getSalaryOld() {
        return salaryOld;
    }

    public void setSalaryOld(BigDecimal salaryOld) {
        this.salaryOld = salaryOld;
    }

    public BigDecimal getSalaryTrue() {
        return salaryTrue;
    }

    public void setSalaryTrue(BigDecimal salaryTrue) {
        this.salaryTrue = salaryTrue;
    }

    public String getSallogRemark() {
        return sallogRemark;
    }

    public void setSallogRemark(String sallogRemark) {
        this.sallogRemark = sallogRemark;
    }

}
