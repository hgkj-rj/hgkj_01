package com.xl.model.service;

import com.xl.model.entity.Pay;

import java.util.List;

public interface PayService {
    public int PayService(int pageSize);
    public List<Pay> allPayService(int pageIndex, int pageSize);
    public int getPayByIdService(int PayId);
    public boolean addPayService(Pay pay);
    public boolean deleteService(Pay pay);
    public boolean updatePayService(Pay pay);
}
