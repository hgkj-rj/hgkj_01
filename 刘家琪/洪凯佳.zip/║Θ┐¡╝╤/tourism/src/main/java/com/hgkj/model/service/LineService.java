package com.hgkj.model.service;

import com.hgkj.model.entity.Line;

import java.util.List;

public interface LineService {
    public List<Line> allLineService();
    public boolean addLineService(Line line);
    public boolean deleteLineService(Line line);
    public boolean updateLineService(Line line);
    public Line getLineByIdService(String lineId);
}
