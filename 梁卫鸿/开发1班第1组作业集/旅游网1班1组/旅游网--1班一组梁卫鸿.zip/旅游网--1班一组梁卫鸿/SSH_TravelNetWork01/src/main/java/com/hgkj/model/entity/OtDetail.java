package com.hgkj.model.entity;

public class OtDetail {
    private int otId;
    private String odId;
    private String touristId;
    public OtDetail(){}

    public OtDetail(int otId) {
        this.otId = otId;
    }

    public OtDetail(String odId, String touristId) {
        this.odId = odId;
        this.touristId = touristId;
    }

    public String getOdId() {
        return odId;
    }

    public void setOdId(String odId) {
        this.odId = odId;
    }

    public String getTouristId() {
        return touristId;
    }

    public void setTouristId(String touristId) {
        this.touristId = touristId;
    }

    public int getOtId() {
        return otId;
    }

    public void setOtId(int otId) {
        this.otId = otId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        OtDetail otDetail = (OtDetail) o;

        if (otId != otDetail.otId) return false;

        return true;
    }

    @Override
    public int hashCode() {
        return otId;
    }
}
