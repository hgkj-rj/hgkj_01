package com.hgkj.model.service.impl;

import com.hgkj.model.dao.DepartmentDao;
import com.hgkj.model.entity.Department;
import com.hgkj.model.service.DepartmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class DepartmentServiceImpl implements DepartmentService {
    @Autowired
    private DepartmentDao departmentDao;

    public void setDepartmentDao(DepartmentDao departmentDao) {
        this.departmentDao = departmentDao;
    }

    @Override
    public List<Department> alldepartmentService() {
        return departmentDao.alldepartmentDao();
    }

    @Override
    public boolean insertdepartmentService(Department department) {
        return departmentDao.insertdepartmentDao(department);
    }

    @Override
    public boolean deletedepartmentService(int id) {
        return departmentDao.deletedepartmentDao(id);
    }

    @Override
    public boolean updatedepartmentService(Department department) {
        return departmentDao.updatedepartmentDao(department);
    }

    @Override
    public Department getdepartmentByIdService(int id) {
        return departmentDao.getdepartmentByIdDao(id);
    }
}
