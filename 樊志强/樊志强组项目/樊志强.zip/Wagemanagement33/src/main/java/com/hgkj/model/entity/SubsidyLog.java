package com.hgkj.model.entity;

import java.math.BigDecimal;

public class SubsidyLog {
    private int stblogId;
    private BigDecimal subsidyMoney;
    private String sublogTime;
    private Staff staff;
    private Subsidy subsidy;

    public Staff getStaff() {
        return staff;
    }

    public void setStaff(Staff staff) {
        this.staff = staff;
    }

    public Subsidy getSubsidy() {
        return subsidy;
    }

    public void setSubsidy(Subsidy subsidy) {
        this.subsidy = subsidy;
    }

    public int getStblogId() {
        return stblogId;
    }

    public void setStblogId(int stblogId) {
        this.stblogId = stblogId;
    }

    public BigDecimal getSubsidyMoney() {
        return subsidyMoney;
    }

    public void setSubsidyMoney(BigDecimal subsidyMoney) {
        this.subsidyMoney = subsidyMoney;
    }

    public String getSublogTime() {
        return sublogTime;
    }

    public void setSublogTime(String sublogTime) {
        this.sublogTime = sublogTime;
    }

    @Override
    public String toString() {
        return "SubsidyLog{" +
                "stblogId=" + stblogId +
                ", subsidyMoney=" + subsidyMoney +
                ", sublogTime='" + sublogTime + '\'' +
                ", staff=" + staff +
                ", subsidy=" + subsidy +
                '}';
    }
}
