package com.tourism.model.service.impl;

import com.tourism.model.dao.OrderDetailDao;
import com.tourism.model.entity.Orderdetail;
import com.tourism.model.service.OrderDetailService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class OrderDetailServiceImpl implements OrderDetailService {
    @Autowired
    private OrderDetailDao orderDetailDao;

    @Override
    public int gettotalpageService(int pagesize) {
        return orderDetailDao.gettotalpageDao(pagesize);
    }

    @Override
    public List<Orderdetail> allOrderDetailService(int pageindex, int pagesize) {
        return orderDetailDao.allOrderDetailDao(pageindex,pagesize);
    }
}
