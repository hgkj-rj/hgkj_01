package com.workmoney.model.dao;

import com.workmoney.model.entity.Shop;

import java.util.List;

/**
 * user@Bright Rain .
 * 2019/6/30.
 */
public interface ShopDao {

    /**
     * 获取所有店
     * @return
     */
    List<Shop> getAllShopDao();
    /**
     * 获取店
     * @return
     */
    Shop getShopByIdDao(Shop shop);
    /**
     * 删除店
     * @return
     */

    void delShopByIdDao(Shop shop);
    /**
     * 添加店
     * @return
     */
    void addShopDao(Shop shop);
    /**
     * 修改店
     * @return
     */
    void updateShopByIdDao(Shop shop);
}
