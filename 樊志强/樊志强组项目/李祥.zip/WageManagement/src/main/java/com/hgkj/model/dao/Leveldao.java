package com.hgkj.model.dao;

import com.hgkj.model.entity.Level;

import java.util.List;

public interface Leveldao {
   public List<Level> allLeveldao();
   public boolean addLeveldao(Level level);
   public boolean deleteLeveldao(int levelId);
   public boolean updateLevedao(Level level);
   public Level level(int levelId);
}
