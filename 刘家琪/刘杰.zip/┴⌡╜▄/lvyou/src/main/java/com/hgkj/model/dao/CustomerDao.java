package com.hgkj.model.dao;


import com.hgkj.model.entity.Customer;

import java.util.List;

public interface CustomerDao {
    public boolean addCustomerDao(Customer customer);
    public List<Customer> loginCustomerDao(Customer customer);

}
