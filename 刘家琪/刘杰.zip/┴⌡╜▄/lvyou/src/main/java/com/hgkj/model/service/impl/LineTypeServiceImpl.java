package com.hgkj.model.service.impl;

import com.hgkj.model.dao.LineTypeDao;
import com.hgkj.model.entity.Linetype;
import com.hgkj.model.service.LineTypeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class LineTypeServiceImpl implements LineTypeService {
    @Autowired
    private LineTypeDao lineTypeDao;

    @Override
    public boolean addLineTypeService(Linetype linetype) {
        return lineTypeDao.addLineTypeDao(linetype);
    }

    @Override
    public List<Linetype> allLineTypeSerivce() {
        return lineTypeDao.allLineTypeDao();
    }

    @Override
    public boolean deleteLineTypeService(Integer id) {
        return lineTypeDao.deleteLineTypeDao(id);
    }

    @Override
    public Linetype getOneLineTypeService(Integer id) {
        return lineTypeDao.getOneLineTypeDao(id);
    }

    @Override
    public boolean updateLineTypeService(Linetype linetype) {
        return lineTypeDao.updateLineTypeDao(linetype);
    }

    @Override
    public String getIconLineTypeService(Integer id) {
        return lineTypeDao.getIconLineTypeDao(id);
    }

    @Override
    public List<Linetype> getTypeNameService() {
        return lineTypeDao.getTypeNameDao();
    }

    @Override
    public List<Linetype> ShowTypeNameService() {
        return lineTypeDao.ShowTypeNameDao();
    }


    public LineTypeDao getLineTypeDao() {
        return lineTypeDao;
    }

    public void setLineTypeDao(LineTypeDao lineTypeDao) {
        this.lineTypeDao = lineTypeDao;
    }


}
