package com.hgkj.contrloer.action;

import com.hgkj.model.entity.Department;
import com.hgkj.model.entity.Shop;
import com.hgkj.model.service.ShopService;
import org.apache.struts2.ServletActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import java.util.List;

@Controller
@Namespace("/")
@ParentPackage("struts-default")
public class ShopAction {
    @Autowired
    private ShopService shopService;
    private Shop shop;

    public Shop getShop() {
        return shop;
    }

    public void setShop(Shop shop) {
        this.shop = shop;
    }

    public void setShopService(ShopService shopService) {
        this.shopService = shopService;
    }

    @Action(value = "allshop",results = @Result(name = "all",type = "redirect",location = "/html/shopList.jsp"))
    public String allshop(){
        List<Shop> shopList=shopService.allShopService();
        ServletActionContext.getRequest().getSession().setAttribute("shopList",shopList);
        return "all";
    }

    @Action(value = "addshop",results = @Result(name = "adds",type = "redirectAction",params = {"actionName","allshop"}))
    public String addshop(){
        boolean r=shopService.addShopService(shop);
        if (r==true){
            return "adds";
        }else {
            return "adde";
        }
    }

    @Action(value = "delshop",results = @Result(name = "dels",type = "redirectAction",params = {"actionName","allshop"}))
    public String deleteshop(){
        boolean r=shopService.deleteShopService(shop.getShopId());
        if (r==true){
            return "dels";
        }else {
            return "dele";
        }
    }

    @Action(value = "updshop",results = @Result(name = "upds",type = "redirectAction",params = {"actionName","allshop"}))
    public String Updshop(){
        boolean r=shopService.updateShopService(shop);
        if (r==true){
            return "upds";
        }else {
            return "upde";
        }
    }

    @Action(value = "getByIdshops",results = {@Result(name = "getByIds",type = "redirect",location = "/html/shopUpdate.jsp")})
    public String getByIdshop(){
        Shop shop1=shopService.getByIdShopService(shop.getShopId());
        ServletActionContext.getRequest().getSession().setAttribute("shop1",shop1);
        return "getByIds";
    }
}
