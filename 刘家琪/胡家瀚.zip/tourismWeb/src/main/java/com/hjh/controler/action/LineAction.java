package com.hjh.controler.action;

import com.hjh.model.entity.Line;
import com.hjh.model.entity.Linetype;
import com.hjh.model.entity.Picture;
import com.hjh.model.service.LineService;
import com.hjh.model.service.LineTypeService;
import com.hjh.model.service.PictureService;
import com.opensymphony.xwork2.ActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Controller
@Namespace("/")
@ParentPackage("struts-default")
public class LineAction {

    @Autowired
    private LineService lineService;
    @Autowired
    private LineTypeService lineTypeService;
    @Autowired
    private PictureService pictureService;
    private Line line;
    private File upload;
    private String uploadFileName;
    private Picture picture;
    private List<Picture> pictureList;

    public List<Picture> getPictureList() {
        return pictureList;
    }

    public void setPictureList(List<Picture> pictureList) {
        this.pictureList = pictureList;
    }

    public Picture getPicture() {
        return picture;
    }

    public void setPicture(Picture picture) {
        this.picture = picture;
    }

    public PictureService getPictureService() {
        return pictureService;
    }

    public void setPictureService(PictureService pictureService) {
        this.pictureService = pictureService;
    }

    public File getUpload() {
        return upload;
    }

    public void setUpload(File upload) {
        this.upload = upload;
    }

    public String getUploadFileName() {
        return uploadFileName;
    }

    public void setUploadFileName(String uploadFileName) {
        this.uploadFileName = uploadFileName;
    }

    public void setLineService(LineService lineService) {
        this.lineService = lineService;
    }

    public LineService getLineService() {
        return lineService;
    }

    public Line getLine() {
        return line;
    }

    public void setLine(Line line) {
        this.line = line;
    }

    public LineTypeService getLineTypeService() {
        return lineTypeService;
    }

    public void setLineTypeService(LineTypeService lineTypeService) {
        this.lineTypeService = lineTypeService;
    }

    @Action(value = "AllLine", results = {@Result(name = "all", type = "redirect", location = "/ht/allLine.jsp")})
    public String AllLine() {
        List<Line> lines = lineService.AllLine();
        ActionContext.getContext().getSession().put("lines", lines);
        return "all";
    }

    @Action(value = "AddLine", results = {@Result(name = "add", type = "redirectAction", location = "AllLine.action")
            , @Result(name = "error", type = "redirect", location = "/ht/addLine.jsp")})
    public String AddLine() throws Exception{
        String path = "F://Web//tourismWeb//src//main//webapp//ht//images//upload//";
        File file = new File(path);
        if (!file.exists()){
            file.mkdir();
        }
        List<String> list = new ArrayList<>();
        for (String name : uploadFileName.split(", ")) {
            list.add(name);
        }
        for (String img:list){
            picture.setName(img);
        }
        line.setLineid(lineTypeService.GetRan());
        SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
        line.setOntime(sdf.format(new Date()));
        line.setBegintime(sdf.format(new Date()));
        line.setEndtime(sdf.format(new Date()));
        Linetype lineType = lineTypeService.GetLineType(line.getLinetype().getLineTypeid());
        line.setLinetype(lineType);
        if (lineService.AddLine(line)) {
            pictureService.Addpicture(picture);
            return "add";
        } else {
            return "error";
        }
    }

    @Action(value = "UpLine", results = {@Result(name = "up", type = "redirectAction", location = "AllLine.action"),
            @Result(name = "error", type = "redirectAction", location = "/ht/upLine.jsp")})
    public String UpLine() throws Exception{
        String path = "F://Web//tourismWeb//src//main//webapp//ht//images//upload//";
        File file = new File(path);
        if (!file.exists()){
            file.mkdir();
        }
        List<String> list = new ArrayList<>();
        for (String name : uploadFileName.split(", ")) {
            list.add(name);
        }
        for (String img:list){
            picture.setName(img);
        }
        Linetype lineType = lineTypeService.GetLineType(line.getLinetype().getLineTypeid());
        line.setLinetype(lineType);
        line = lineService.GetLine(line.getLineid());
        picture.setLine(line);
        if (lineService.UpingLine(line)) {
            pictureService.UPpicture(picture);
            return "up";
        } else {
            return "error";
        }
    }

    @Action(value = "ByIdLine", results = {@Result(name = "ById", type = "redirect", location = "/ht/upLine.jsp")})
    public String ByIdLine(){
        List<Linetype> linetypeList = lineTypeService.AllLineTypeDao();
        ActionContext.getContext().getSession().put("linetypeList",linetypeList);
        List<Line> lineList = lineService.AllLine();
        ActionContext.getContext().getSession().put("lineList",lineList);
        Line lines = lineService.GetLine(line.getLineid());
        ActionContext.getContext().getSession().put("line",lines);
        pictureList = pictureService.Allpicture(line);
        ActionContext.getContext().getSession().put("pictureList",pictureList);
        return "ById";
    }
}
