package com.mqy.model.service.impl;

import com.mqy.model.dao.LineDao;
import com.mqy.model.entity.Line;
import com.mqy.model.service.LineService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class LineServiceImpl implements LineService {
    @Autowired
    private LineDao lineDao;

    public void setLineDao(LineDao lineDao) {
        this.lineDao = lineDao;
    }

    @Override
    public int getTotalPageService(int pageSize) {
        return lineDao.getTotalPageDao(pageSize);
    }

    @Override
    public List<Line> allLineService(int pageIndex,int pageSize) {
        return lineDao.allLineDao(pageIndex,pageSize);
    }

    @Override
    public List<Line> teamLineService(int pageIndex,int pageSize) {
        return lineDao.teamLineDao(pageIndex,pageSize);
    }

    @Override
    public void addLineService(Line line) {
        lineDao.addLineDao(line);
    }

    @Override
    public void deleteLineService(String lineId) {
        lineDao.deleteLineDao(lineId);
    }

    @Override
    public void updateLineService(Line line) {
        lineDao.updateLineDao(line);
    }

    @Override
    public Line getLineService(String lineId) {
        return lineDao.getLineDao(lineId);
    }
}
