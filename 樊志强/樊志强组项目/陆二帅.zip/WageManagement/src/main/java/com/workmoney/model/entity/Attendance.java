package com.workmoney.model.entity;

import java.util.Objects;

/**
 * user@Bright Rain .
 * 2019/6/21.
 */
public class Attendance {
    private int attId;
    private String attName;
    private String attPercent;

    public int getAttId() {
        return attId;
    }

    public void setAttId(int attId) {
        this.attId = attId;
    }

    public String getAttName() {
        return attName;
    }

    public void setAttName(String attName) {
        this.attName = attName;
    }

    public String getAttPercent() {
        return attPercent;
    }

    public void setAttPercent(String attPercent) {
        this.attPercent = attPercent;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Attendance that = (Attendance) o;
        return attId == that.attId &&
                Objects.equals(attName, that.attName) &&
                Objects.equals(attPercent, that.attPercent);
    }

    @Override
    public int hashCode() {
        return Objects.hash(attId, attName, attPercent);
    }
}
