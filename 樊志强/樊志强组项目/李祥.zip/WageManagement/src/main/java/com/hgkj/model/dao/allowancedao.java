package com.hgkj.model.dao;

import com.hgkj.model.entity.Reward;

import java.util.List;

public interface allowancedao {
    public List<Reward> allRewardDao();
    public boolean addRewardDao(Reward reward);
    public boolean deleteRewardDao(int rewId);
    public boolean updateRewardDao(Reward reward);
    public Reward reward(int rewId);
}
