package com.hgkj.model.dao.impl;

import com.hgkj.model.dao.RoleDao;
import com.hgkj.model.entity.Role;
import com.hgkj.model.entity.Shop;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
@Repository
@Transactional
public class RoleDaoImpl implements RoleDao {
    @Autowired
    private SessionFactory sessionFactory;
    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }
    public Session session(){
        return sessionFactory.getCurrentSession();
    }
    @Override
    public List<Role> allroleDao() {
        String hql = "from Role ";
        List<Role> list = session().createQuery(hql).list();
        return list;
    }
    @Override
    public boolean insertroleDao(Role role) {
        boolean b=false;
        session().save(role);
        b=true;
        return b;
    }

    @Override
    public boolean deleteroleDao(int id) {
        boolean a=false;
        String hql="delete Role where roleId=?";
        int b=session().createQuery(hql).setParameter(0,id).executeUpdate();
        if (b!=0){
            a=true;
        }
        return a;
    }

    @Override
    public boolean updateroleDao(Role role) {
        boolean a=false;
        String hql="update Role set roleName=?where roleId=?";
        int b=session().createQuery(hql).setParameter(0,role.getRoleName()).setParameter(1,role.getRoleId()).executeUpdate();
        if (b!=0){
            a=true;
        }
        return a;
    }

    @Override
    public Role getroleByIdDao(int id) {
        String hql="from Role where roleId=?";
        Role role=(Role) session().createQuery(hql).setParameter(0,id).uniqueResult();
        return role;
    }
}
