package com.hgkj.model.dao.impl;

import com.hgkj.model.dao.RewardDao;
import com.hgkj.model.entity.Reward;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import javax.management.Query;
import java.util.List;
@Repository
@Transactional
public class RewardDaoImpl implements RewardDao {
    @Autowired
    private SessionFactory sessionFactory;
    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }
    public Session session(){
        return sessionFactory.getCurrentSession();
    }
    @Override
    public List<Reward> allrewardDao() {
        String hql="from Reward ";
        List<Reward> list=session().createQuery(hql).list();
        return list;
    }

    @Override
    public boolean insertrewardDao(Reward reward) {
        boolean b=false;
            session().save(reward);
            b=true;
        return b;
    }

    @Override
    public boolean deleterewardDao(int id) {
        boolean a=false;
        String hql="delete Reward where rewId=?";
        int b=session().createQuery(hql).setParameter(0,id).executeUpdate();
        if (b!=0){
            a=true;
        }
        return a;
    }

    @Override
    public boolean updaterewardDao(Reward reward) {
        boolean a=false;
        String hql="update Reward set rewName=?,rewPrice=?where rewId=?";
       int b=session().createQuery(hql).setParameter(0,reward.getRewName()).setParameter(1,reward.getRewPrice()).setParameter(2,reward.getRewId()).executeUpdate();
        System.out.println("我是结果:"+b);
       if (b!=0){
            a=true;
        }
       return a;
    }

    @Override
    public Reward getrewardByIdDao(int id) {
        String hql="from Reward where rewId=?";
        Reward reward=(Reward) session().createQuery(hql).setParameter(0,id).uniqueResult();
        return reward;
    }
}
