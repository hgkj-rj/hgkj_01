package com.hgkj.controler.action;

import com.hgkj.model.entity.Car;
import com.hgkj.model.entity.Line;
import com.hgkj.model.entity.Picture;
import com.hgkj.model.service.ImagesService;
import com.hgkj.model.service.LineService;
import org.apache.commons.io.FileUtils;
import org.apache.struts2.ServletActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@Controller
@Namespace("/")
@ParentPackage("json-default")
public class ManagerLineAction {
    @Autowired
    private ImagesService imagesService;
    private Line line;
    private Picture picture;
    private Car car;
    private String message;
    private File uploadImage; //得到上传的文件
    private String uploadImageContentType; //得到文件的类型
    private String uploadImageFileName; //得到文件的名称
    public ImagesService getImagesService() {
        return imagesService;
    }
    public void setImagesService(ImagesService imagesService) {
        this.imagesService = imagesService;
    }
    @Action(value = "allManagerLine",results = @Result(name = "all",type = "redirect",location = "ht/showLine.jsp"))
    public String allCustomer(){
        List<Line> lineList=imagesService.lineAllService();
        List<Picture> pictureList=imagesService.imagesAllService();
        ServletActionContext.getRequest().getSession().setAttribute("lineList",lineList);
        ServletActionContext.getRequest().getSession().setAttribute("pictureList",pictureList);
        return "all";
    }
    @Action(value = "addLine",results = @Result(name = "addsuccess",type = "redirect",location = "ht/_right.jsp"))
    public String addLine(){
        String realPath=ServletActionContext.getServletContext().getRealPath("/ht/images/")+uploadImageFileName;
        File file = new File(realPath);
        String a="images/"+this.getUploadImageFileName();
        try {
            //保存文件
            FileUtils.copyFile(uploadImage,file);
            boolean rs1=imagesService.lineAddService(line);
            boolean rs=imagesService.imagesInsertService(line.getLineId(),picture.getIntroduction(),a);
            if(rs&&rs1){
                return "addsuccess";
            }
            return "adderror";
        } catch (IOException e) {
            e.printStackTrace();
        }
        return "adderror";
    }
    @Action(value = "ManagerlineDelAction",results = {@Result(name = "del",type = "json",params = {"root","message"})})
    public String ManagerlineDelAction(){
        boolean rs1=imagesService.imagesDeleteService(picture.getPictureId());
        boolean rs= imagesService.lineDeleteService(line.getLineId());
        if(rs&&rs1){
            message="success";
            return "del";
        }
        return "delerror";
    }
    @Action(value = "lineFindAction",results = {@Result(name = "find",type = "redirect",location = "ht/updateLine.jsp")})
    public String lineIdAction(){
        Line line1=imagesService.lineIdService(line.getLineId());
        Picture picture1=imagesService.imagesIdService(picture.getPictureId());
        ServletActionContext.getRequest().getSession().setAttribute("line",line1);
        ServletActionContext.getRequest().getSession().setAttribute("picture",picture1);
        return "find";
    }
    @Action(value = "lineUpdateAction",results = {@Result(name = "update",type = "redirectAction",params = {"actionName","allManagerLine"})})
    public String lineUpdateAction(){
        String realPath=ServletActionContext.getServletContext().getRealPath("/ht/images/")+uploadImageFileName;
        File file = new File(realPath);
        String a="images/"+this.getUploadImageFileName();
        try {
            //保存文件
            FileUtils.copyFile(uploadImage,file);
            boolean rs=imagesService.imagesUpdateService(picture.getPictureId(),picture.getIntroduction(),a,line.getLineId());
            boolean rs1=imagesService.lineUpdateService(line);
            if(rs&&rs1){
                return "update";
            }
            return "adderror";
        } catch (IOException e) {
            e.printStackTrace();
        }
        return "adderror";

    }

    public Car getCar() {
        return car;
    }

    public void setCar(Car car) {
        this.car = car;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Picture getPicture() {
        return picture;
    }

    public void setPicture(Picture picture) {
        this.picture = picture;
    }

    public File getUploadImage() {
        return uploadImage;
    }

    public void setUploadImage(File uploadImage) {
        this.uploadImage = uploadImage;
    }

    public String getUploadImageContentType() {
        return uploadImageContentType;
    }

    public void setUploadImageContentType(String uploadImageContentType) {
        this.uploadImageContentType = uploadImageContentType;
    }

    public String getUploadImageFileName() {
        return uploadImageFileName;
    }

    public void setUploadImageFileName(String uploadImageFileName) {
        this.uploadImageFileName = uploadImageFileName;
    }

    public Line getLine() {
        return line;
    }

    public void setLine(Line line) {
        this.line = line;
    }
}
