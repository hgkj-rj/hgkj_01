package com.xl.model.service;

import com.xl.model.entity.Invitejob;

import java.util.List;

public interface InvitejobService{
    public int invitejobService(int pageSize);
    public List<Invitejob> allInvitejobService(int pageIndex, int pageSize);
    public Invitejob getInvitejobByIdService(int invitejobId);
    public boolean addInvitejobService(Invitejob invitejob);
    public boolean deleteInvitejobService(Invitejob invitejob);
    public boolean updateInvitejobService(Invitejob invitejob);
}
