package com.hgkj.model.dao.impl;

import com.hgkj.model.dao.SalaryLogDao;
import com.hgkj.model.entity.AttendanceLog;
import com.hgkj.model.entity.SalaryLog;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
@Repository
@Transactional
public class SalaryLogDaoImpl implements SalaryLogDao {
    @Autowired
    private SessionFactory sessionFactory;

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }
    public Session session(){
        return sessionFactory.getCurrentSession();
    }

    @Override
    public List<SalaryLog> getsubsidyDao(int id) {
        String hql="from SalaryLog where staff.staffId=?";
        List<SalaryLog> list=session().createQuery(hql).setParameter(0,id).list();
        return list;
    }

    @Override
    public List<SalaryLog> allsubsidyDao() {
        String hql="from SalaryLog ";
        List<SalaryLog> list1=session().createQuery(hql).list();
        return list1;
    }

    @Override
    public List<AttendanceLog> allAttendanceLogDao(int id) {
        String hql="from AttendanceLog where staff.staffId=?";
        List<AttendanceLog> list=session().createQuery(hql).setParameter(0,id).list();
        return list;
    }
}
