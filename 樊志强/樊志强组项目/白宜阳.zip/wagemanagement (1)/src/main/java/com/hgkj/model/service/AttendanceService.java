package com.hgkj.model.service;

import com.hgkj.model.entity.Attendance;
import com.hgkj.model.entity.AttendanceLog;
import com.hgkj.model.entity.Staff;

import java.util.List;

public interface AttendanceService {
    /**
     * 查询员工考勤
     * @return
     */
    List<AttendanceLog> allAttendanceLogService();
    /**
     * 添加考勤管理
     * @param attendanceLog
     * @return
     */
    boolean addAttendanceLogService(AttendanceLog attendanceLog);

    /**
     * 删除考勤
     * @param attenlogId
     * @return
     */
    boolean deleteAttendanceLogService(int attenlogId);

    /**
     * 修改考勤
     * @param attendanceLog
     * @return
     */
    boolean updateAttendanceLogService(AttendanceLog attendanceLog);

    /**
     * 根据Id查考勤
     * @param attenlogId
     * @return
     */
    AttendanceLog getByIdAttendanceService(int attenlogId);

    /**
     * 查询所有员工信息
     * @return
     */
    List<Staff>allStaffService();

    /**
     * 查询考勤类型信息
     * @return
     */
    List<Attendance>allAttendanceService();

    List<AttendanceLog> AttendanceLogService(AttendanceLog attendanceLog);

}
