package com.tourism.model.service.Impl;

import com.tourism.model.dao.LinetypeDao;
import com.tourism.model.entity.Picture;
import com.tourism.model.service.PictureService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PictureServiceImpl implements PictureService {
    @Autowired
    private PictureService pictureService;
    @Override
    public boolean addPictureService(Picture picture) {
        return pictureService.addPictureService(picture);
    }

    @Override
    public boolean updatePictureService(Picture picture) {
        return pictureService.updatePictureService(picture);
    }

    @Override
    public List<Picture> findPictureService(String lineId) {
        return pictureService.findPictureService(lineId);
    }
}
