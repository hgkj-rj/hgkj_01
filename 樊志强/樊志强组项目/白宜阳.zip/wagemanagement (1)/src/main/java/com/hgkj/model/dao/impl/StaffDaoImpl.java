package com.hgkj.model.dao.impl;

import com.hgkj.model.dao.StaffDao;
import com.hgkj.model.entity.*;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
@Transactional
public class StaffDaoImpl implements StaffDao {
    @Autowired
    private SessionFactory sessionFactory;
    private Transaction transaction;

    @Override
    public List<Staff> loginStaffDao(Staff staff) {
        String hql="from Staff where staffName=? and staffPwd=?";
        System.out.println("staffName="+staff.getStaffName());
        System.out.println("staffPwd="+staff.getStaffPwd());
        List<Staff>staffList=getSession().createQuery(hql).setParameter(0,staff.getStaffName()).setParameter(1,staff.getStaffPwd()).list();
        return staffList;
    }

    @Override
    public Staff getByIdStaffDao(int staffId) {
        Staff staff=getSession().get(Staff.class,staffId);
        return staff;
    }

    @Override
    public boolean updateStaffDao(Staff staff) {
        boolean flag=false;
        getSession().update(staff);
        flag=true;
        return flag;
    }

    @Override
    public boolean updateStaffXXDao(Staff staff) {
        boolean flag=false;
        try {
            getSession().update(staff);
            flag=true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return flag;
    }

    @Override
    public List<Staff> allStaffDao() {
        Query query=getSession().createQuery("from Staff ");
        return query.list();
    }

    @Override
    public boolean addStaffDao(Staff staff) {
        boolean flag=false;
        try {
            getSession().save(staff);
            flag=true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return flag;
    }

    @Override
    public boolean deleteStaffDao(int staffId) {
        boolean flag=false;
        Staff staff=new Staff();
        staff.setStaffId(staffId);
        try {
            getSession().delete(staff);
            flag=true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return flag;
    }

    @Override
    public List<Level> allLevelDao() {
        Query query=getSession().createQuery("from Level ");
        return query.list();
    }

    @Override
    public List<Role> allRoleDao() {
        Query query=getSession().createQuery("from Role ");
        return query.list();
    }

    @Override
    public List<Department> allDepartmentDao() {
        Query query=getSession().createQuery("from Department ");
        return query.list();
    }

    @Override
    public List<Shop> allShopDao() {
        Query query=getSession().createQuery("from Shop ");
        return query.list();
    }


    public Transaction getTransaction() {
        return transaction;
    }

    public void setTransaction(Transaction transaction) {
        this.transaction = transaction;
    }

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    public Session getSession(){
        return sessionFactory.getCurrentSession();
    }
}
