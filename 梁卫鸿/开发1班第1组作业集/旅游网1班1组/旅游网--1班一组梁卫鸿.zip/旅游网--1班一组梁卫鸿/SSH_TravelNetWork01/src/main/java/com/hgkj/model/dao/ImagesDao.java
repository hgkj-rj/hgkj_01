package com.hgkj.model.dao;

import com.hgkj.model.entity.Car;
import com.hgkj.model.entity.Images;
import com.hgkj.model.entity.Line;
import com.hgkj.model.entity.Picture;

import java.util.List;

public interface ImagesDao {
    public List<Picture> imagesAllDao();
    public boolean imagesInsertDao(String lineId,String introduction,String name);
    public boolean imagesDeleteDao(int pictureId);
    public Picture imagesIdDao(int pictureId);
    public boolean imagesUpdateService(int pictureId,String introduction,String name,String lineId);
    public boolean lineAddDao(Line line);
    public List<Line> lineAllDao();
    public boolean lineDeleteDao(String lineId);
    public Line lineIdDao(String lineId);
    public boolean lineUpdateDao(Line line);


}
