package com.workmoney.model.dao.impl;

import com.workmoney.model.dao.StaffDao;
import com.workmoney.model.entity.Staff;
import com.workmoney.util.SercharStaff;
import com.workmoney.util.SercharStaffUpload;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * user@Bright Rain .
 * 2019/6/24.
 */
@Repository
@Transactional
public class StaffDaoImpl implements StaffDao {

    @Autowired
    private SessionFactory sessionFactory;
    @Override
    public Staff getStaffLoginDao(Staff staff) {
        Session session = sessionFactory.getCurrentSession();
        String hql = "from Staff where staffName=? and staffPwd=?";
        Staff result = session.createQuery(hql, Staff.class).setParameter(0, staff.getStaffName()).setParameter(1, staff.getStaffPwd()).uniqueResult();
        return result;
    }

    @Override
    public Staff updateStaffPwdByIdDao(Staff staff) {
        Session session = sessionFactory.getCurrentSession();
        session.update(staff);
        Staff staffById = getStaffById(staff.getStaffId());
        return staffById;
    }

    @Override
    public List<Staff> getStaffListSercharDao() {
        Session session = sessionFactory.getCurrentSession();
       String hql = "from Staff ";
        List<Staff> list = session.createQuery(hql, Staff.class).list();
        return list;
    }
    @Override
    public List<Staff> sercharStaffByNameAndMonthDao(SercharStaff sercharStaff) {
        Session session = sessionFactory.getCurrentSession();
        String name = sercharStaff.getName();
        String month = sercharStaff.getMonth();

      //  System.out.println(month);
        String hql =null;
        String trim = name.trim();
        if(name!=null&&!name.equals("")&&trim!=null){
            name="%"+name+"%";
             hql =  "from Staff as s where s.staffName like '"+name+"' " ;
        }


        if (month!=null&&!month.equals("")){
            //System.out.println("cha'xun'shi'jian");
            hql =  "from Staff as s where s.salaryLog.salTime like '%"+month+"%' " ;
        }

        if(name!=null&&!name.equals("")&&month!=null&&!month.equals("")){
            name="%"+name+"%";
            hql =  "from Staff as s where s.staffName like '"+name+"'or s.salaryLog.salTime like '%"+month+"%' " ;
        }else {
            hql =  "from Staff as s where s.staffName like '%"+name+"%' " ;
        }

//        String hql = "from Staff s  left  outer  join SalaryLog lo on s.id=lo.staffId where 1=1 and s.staffName  like ? or lo.salTime like ? ";

        List<Staff> list = session.createQuery(hql, Staff.class).list();


        return list;
    }

    @Override
    public boolean updateStaffRemarkByIdDao(int staffId, String remark) {
        Session session = sessionFactory.getCurrentSession();
        String hql = "update from SalaryLog set sallogRemark = ?  where staffId =?";
        int i = session.createQuery(hql).setParameter(0, remark).setParameter(1, staffId).executeUpdate();
        if(i>=1){
          return true;
        }else {
            return false;
        }
    }

    private Staff getStaffById(Integer id){
        Session session = sessionFactory.getCurrentSession();
        Staff staff = session.get(Staff.class, id);
        return staff;
    }

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }
}
