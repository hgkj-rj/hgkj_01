package com.tourism.controler.action;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.tourism.model.entity.Linetype;
import com.tourism.model.service.LineTypeService;
import org.apache.struts2.ServletActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import javax.servlet.ServletContext;
import java.io.File;
import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Random;

@Controller
@Namespace("/")
@ParentPackage("struts-default")
public class LineTypeAction{
    @Autowired
    private LineTypeService lineTypeService;
    private Linetype linetype;
    private File upload;
    private String uploadFileName;
    private  String uploadContentType;

    public LineTypeService getLineTypeService() {
        return lineTypeService;
    }

    public void setLineTypeService(LineTypeService lineTypeService) {
        this.lineTypeService = lineTypeService;
    }

    public Linetype getLinetype() {
        return linetype;
    }

    public void setLinetype(Linetype linetype) {
        this.linetype = linetype;
    }

    public File getUpload() {
        return upload;
    }

    public void setUpload(File upload) {
        this.upload = upload;
    }

    public String getUploadFileName() {
        return uploadFileName;
    }

    public void setUploadFileName(String uploadFileName) {
        this.uploadFileName = uploadFileName;
    }

    public String getUploadContentType() {
        return uploadContentType;
    }

    public void setUploadContentType(String uploadContentType) {
        this.uploadContentType = uploadContentType;
    }

    @Action(value = "allLineType",results = @Result(name = "all",type = "redirect",location = "/allLineType.jsp"))
    public String allLineType(){
        List<Linetype> linetypeList = lineTypeService.allLineTypeService();
        ActionContext.getContext().getSession().put("linetypeList",linetypeList);
        return "all";
    }

    @Action(value = "addLineType",results = {@Result(name = "add",type = "redirectAction",location = "allLineType.action"),
            @Result(name = "error",type = "redirect",location = "/addLineType.jsp")})
    public String addLineType(){
        ServletContext application = ServletActionContext.getServletContext();
        String filePath = application.getRealPath("upload");
        File file=new File(filePath);
        if(!file.exists()){
            file.mkdirs();
        }
        upload.renameTo(new File(file,uploadFileName));

        linetype.setIcon("upload/"+uploadFileName);
        Date date = new Date();
        SimpleDateFormat dateFormat= new SimpleDateFormat("yyyy-MM-dd :hh:mm:ss");
        linetype.setTime(dateFormat.format(date));
        linetype.setLineTypeId(getCharAndNumr(6));
        boolean flag = lineTypeService.addLineTypeService(linetype);
        if (flag){
            return "add";
        }
        return "error";
    }

    @Action(value = "updateLineType",results = {@Result(name = "update",type = "redirectAction",location = "allLineType.action"),
            @Result(name = "error",type = "redirect",location = "/updateLineType.jsp")})
    public String updateLineType(){
        if (uploadFileName==null){
            File tempFile =new File( linetype.getIcon().trim());
            String fileName = tempFile.getName();
            linetype.setIcon("upload/"+fileName);
        }else {
            ServletContext application = ServletActionContext.getServletContext();
            String filePath = application.getRealPath("upload");
            File file=new File(filePath);
            if(!file.exists()){
                file.mkdirs();
            }
            upload.renameTo(new File(file,uploadFileName));
            linetype.setIcon("upload/"+uploadFileName);
        }
        boolean flag = lineTypeService.updateLineTypeService(linetype);
        if (flag){
            return "update";
        }
        return "error";
    }

    @Action(value = "findLineType",results = {@Result(name = "find",type = "redirect",location = "/updateLineType.jsp")})
    public String findLineType(){
        linetype = lineTypeService.getLineTypeByIdService(linetype.getLineTypeId());
        ActionContext.getContext().getSession().put("linetype",linetype);
        return "find";
    }

    public static String getCharAndNumr(int length) {
        String val = "";
        Random random = new Random();
        for (int i = 0; i < length; i++) {
        // 输出字母还是数字
            String charOrNum = random.nextInt(2) % 2 == 0 ? "char" : "num";
        // 字符串
            if ("char".equalsIgnoreCase(charOrNum)) {
	    // 取得大写字母还是小写字母
	            int choice = random.nextInt(2) % 2 == 0 ? 65 : 97;
	            val += (char) (choice + random.nextInt(26));
            } else if ("num".equalsIgnoreCase(charOrNum)) { // 数字
	            val += String.valueOf(random.nextInt(10));
            }
        }
        return val;
    }
}
