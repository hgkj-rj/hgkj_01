package com.hgkj.model.dao.impl;

import com.hgkj.model.dao.RoleDao;
import com.hgkj.model.entity.Level;
import com.hgkj.model.entity.Role;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
@Transactional
public class RoleDaoImpl implements RoleDao {
    @Autowired
    private SessionFactory sessionFactory;
    private Transaction transaction;

    public Transaction getTransaction() {
        return transaction;
    }

    public void setTransaction(Transaction transaction) {
        this.transaction = transaction;
    }

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }
    public Session getSession(){
        return sessionFactory.getCurrentSession();
    }

    @Override
    public List<Role> allRoleDao() {
        Query query=getSession().createQuery("from Role");
        return query.list();
    }

    @Override
    public boolean addRoleDao(Role role) {
        boolean flag=false;
        try {
            getSession().save(role);
            flag=true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return flag;
    }

    @Override
    public boolean updateRoleDao(Role role) {
        boolean flag=false;
        try {
            getSession().update(role);
            flag=true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return flag;
    }

    @Override
    public boolean deleteRoleDao(int roleId) {
        boolean flag=false;
        Role role=new Role();
        role.setRoleId(roleId);
        try {
            getSession().delete(role);
            flag=true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return flag;
    }

    @Override
    public Role getByIdRoleDao(int roleId) {
        Role role=getSession().get(Role.class,roleId);
        return role;
    }
}
