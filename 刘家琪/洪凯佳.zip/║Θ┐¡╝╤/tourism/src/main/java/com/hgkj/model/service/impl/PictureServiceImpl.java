package com.hgkj.model.service.impl;


import com.hgkj.model.dao.PictureDao;
import com.hgkj.model.entity.Picture;
import com.hgkj.model.service.PictureService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PictureServiceImpl implements PictureService {
    @Autowired
    private PictureDao pictureDao;

    public PictureDao getPictureDao() {
        return pictureDao;
    }

    public void setPictureDao(PictureDao pictureDao) {
        this.pictureDao = pictureDao;
    }


    @Override
    public List<Picture> findPictureService(String lineId) {
        return pictureDao.findPictureDao(lineId);
    }

    @Override
    public boolean addPictureService(Picture picture) {
        return pictureDao.addPictureDao(picture);
    }

    @Override
    public boolean updatePictureService(Picture picture) {
        return pictureDao.updatePictureDao(picture);
    }
}
