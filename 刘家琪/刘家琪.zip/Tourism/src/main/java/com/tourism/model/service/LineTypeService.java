package com.tourism.model.service;

import com.tourism.model.entity.Linetype;

import java.util.List;

public interface LineTypeService {
    public List<Linetype> allLineTypeService();
    public List<Linetype> fourLineTypeService();
    public boolean addLineTypeService(Linetype linetype);
    public boolean updateLineTypeService(Linetype linetype);
    public Linetype getLineTypeByIdService(String lineTypeId);
    public Linetype getLastService();
}
