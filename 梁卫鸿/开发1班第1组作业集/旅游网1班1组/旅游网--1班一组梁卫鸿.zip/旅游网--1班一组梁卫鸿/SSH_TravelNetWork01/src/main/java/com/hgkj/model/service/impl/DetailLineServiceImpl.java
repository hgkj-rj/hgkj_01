package com.hgkj.model.service.impl;

import com.hgkj.model.dao.DetailLineDao;
import com.hgkj.model.entity.Line;
import com.hgkj.model.entity.Picture;
import com.hgkj.model.service.DetailLineService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DetailLineServiceImpl implements DetailLineService {
    @Autowired
    private DetailLineDao detailLineDao;

    public void setDetailLineDao(DetailLineDao detailLineDao) {
        this.detailLineDao = detailLineDao;
    }
    @Override
    public List<Line> lineAllService() {
        return detailLineDao.lineAllDao();
    }

    @Override
    public List<Picture> imagesAllService() {
        return detailLineDao.imagesAllDao();
    }

    @Override
    public Line lineIdDao(String lineId) {
        return detailLineDao.lineIdDao(lineId);
    }

    @Override
    public Picture imagesIdService(int pictureId) {
        return detailLineDao.imagesIdDao(pictureId);
    }
}
