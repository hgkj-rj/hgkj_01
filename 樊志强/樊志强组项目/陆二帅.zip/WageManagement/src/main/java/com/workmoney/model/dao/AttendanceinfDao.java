package com.workmoney.model.dao;

import com.workmoney.model.entity.Attendance;
import com.workmoney.model.entity.AttendanceLog;

import java.util.List;

/**
 * user@Bright Rain .
 * 2019/6/25.
 */
public interface AttendanceinfDao {
   List<AttendanceLog> getAllAttendanceLog(int shopManagerId);

   List<Attendance> getAttendanceTypeDao();

   void addAttendanceDao(AttendanceLog attendance);

    AttendanceLog AttendanceLogByIdDao(int staffId, Integer shopId);

    void attendanceEditAction(AttendanceLog attendanceLog);

    void delAttendanceLogDao(AttendanceLog attendanceLog);

    List<AttendanceLog> attendanceInfoDao(int staffId);
}
