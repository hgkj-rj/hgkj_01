package com.tourism.model.dao.Impl;

import com.tourism.model.dao.PictureDao;
import com.tourism.model.entity.Line;
import com.tourism.model.entity.Picture;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
@Repository
@Transactional

public class PictureDaoImpl implements PictureDao {
    @Autowired
    private SessionFactory sessionFactory;
    private Session session;

    public SessionFactory getSessionFactory() {
        return sessionFactory;
    }

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    public Session getSession() {
        return session;
    }

    public void setSession(Session session) {
        this.session = session;
    }

    @Override
    public boolean addPictureDao(Picture picture) {
        boolean flag=false;
        session = getSession();
        Line line=(Line) session.load(Line.class,picture.getLine().getLineId());
        picture.setLine(line);
        try {
            session.save(picture);
            flag=true;
        }catch (Exception e){
            e.printStackTrace();
        }
        return flag;
    }

    @Override
    public boolean updatePictureDao(Picture picture) {
boolean flag = false;
session = getSession();
Line line = (Line) session.load(Line.class,picture.getLine().getLineId);
        return false;
    }

    @Override
    public List<Picture> findPictureDao(String lineId) {
        session = getSession();
        String hql = "from Picture where line.lineId=?";
        List<Picture> pictureList = session.createQuery(hql).setParameter(0,lineId).list();
        return pictureList;
    }
}
