package com.mqy.model.service;

import com.mqy.model.entity.Customer;

import java.util.List;

public interface CustomerService {
    /**
     *
     * @param customer
     * @return 管理员登录
     */
    public Customer LoginService(Customer customer);

    /**
     * 查询所有用户
     * @return
     */
    public List<Customer> allCustomerService();

    /**
     * 注册用户
     * @param customer
     * @return
     */
    public void registerCustomerService(Customer customer);
}
