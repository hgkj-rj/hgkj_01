package com.tourism.model.dao;

import com.tourism.model.entity.Orderdetail;

import java.util.List;

public interface OrderDetailDao {
    public int gettotalpageDao(int pagesize);
    public List<Orderdetail> allOrderDetailDao(int pageindex, int pagesize);
}
