package com.hgkj.model.service;

import com.hgkj.model.entity.Linetype;

import java.util.List;

public interface XianluService {
    public boolean insertxlService(Linetype linetype);
    public List<Linetype> allLineTypeService();
    public boolean delLineTypeService(String lineTypeId);
    public boolean updLineTypeService(Linetype linetype);
    public Linetype linetypeByIdService(String lineTypeId);
}
