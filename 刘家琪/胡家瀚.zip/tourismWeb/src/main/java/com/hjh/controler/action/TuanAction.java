package com.hjh.controler.action;

import com.hjh.model.entity.Line;
import com.hjh.model.entity.Linetype;
import com.hjh.model.service.LineService;
import com.hjh.model.service.LineTypeService;
import com.opensymphony.xwork2.ActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import java.util.List;
@Controller
@Namespace("/")
@ParentPackage("struts-default")
public class TuanAction {
    @Autowired
    private LineService lineService;
    @Autowired
    private LineTypeService lineTypeService;
    private Line line;

    public LineTypeService getLineTypeService() {
        return lineTypeService;
    }

    public void setLineTypeService(LineTypeService lineTypeService) {
        this.lineTypeService = lineTypeService;
    }

    public LineService getLineService() {
        return lineService;
    }

    public void setLineService(LineService lineService) {
        this.lineService = lineService;
    }

    public Line getLine() {
        return line;
    }

    public void setLine(Line line) {
        this.line = line;
    }

    @Action(value = "AllTuan", results = {@Result(name = "all", type = "redirect", location = "/ht/allTuanGou.jsp")})
    public String AllTuan() {
        List<Line> lines = lineService.AllLine();
        ActionContext.getContext().getSession().put("lines", lines);
        return "all";
    }
    @Action(value = "LookTuan", results = {@Result(name = "look", type = "redirect", location = "/ht/lookTuanGou.jsp")})
    public String LookTuan() {
        List<Line> lines = lineService.AllLine();
        ActionContext.getContext().getSession().put("lines", lines);
        return "look";
    }
    @Action(value = "UpLookTuan",results = {@Result(name = "up", type = "redirect",location = "/ht/upLookTuanGou.jsp")})
    public String UpLookTuan(){
        List<Linetype> linetypeList = lineTypeService.AllLineTypeDao();
        ActionContext.getContext().getSession().put("linetypeList",linetypeList);
        List<Line> lineList = lineService.AllLine();
        ActionContext.getContext().getSession().put("lineList",lineList);
        Line lines = lineService.GetLine(line.getLineid());
        ActionContext.getContext().getSession().put("line",lines);
        return "up";
    }
    @Action(value = "UpingLookTuan", results = {@Result(name = "uping", type = "redirectAction", location = "LookTuan"),
            @Result(name = "error", type = "redirect", location = "/ht/upLookTuanGou.jsp")})
    public String UpingLookTuan() {
        System.out.println(line.toString());
        Linetype lineType = lineTypeService.GetLineType(line.getLinetype().getLineTypeid());
        line.setLinetype(lineType);
        if (lineService.UpingLine(line)) {
            return "uping";
        } else {
            return "error";
        }
    }
}
