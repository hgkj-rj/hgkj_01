package com.xl.model.dao;

import com.xl.model.entity.Pay;
import com.xl.model.entity.Train;

import java.util.List;

public interface PayDao {

    public int PayDao(int pageSize);
    public List<Pay> allPayDao(int pageIndex, int pageSize);
    public int getPayByIdDao(int PayId);
    public boolean addPayDao(Pay pay);
    public boolean deletePayDao(Pay pay);
    public boolean updatePayDao(Pay pay);
}
