/*
 Navicat Premium Data Transfer

 Source Server         : 皮皮虾
 Source Server Type    : MySQL
 Source Server Version : 50624
 Source Host           : localhost:3306
 Source Schema         : wagemanagement

 Target Server Type    : MySQL
 Target Server Version : 50624
 File Encoding         : 65001

 Date: 08/07/2019 18:33:41
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for attendance
-- ----------------------------
DROP TABLE IF EXISTS `attendance`;
CREATE TABLE `attendance`  (
  `att_Id` int(11) NOT NULL AUTO_INCREMENT,
  `att_Name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `att_Percent` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`att_Id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of attendance
-- ----------------------------
INSERT INTO `attendance` VALUES (1, '迟到', '12345');

-- ----------------------------
-- Table structure for attendance_log
-- ----------------------------
DROP TABLE IF EXISTS `attendance_log`;
CREATE TABLE `attendance_log`  (
  `attenlog_Id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_Id` int(11) NULL DEFAULT NULL,
  `att_Id` int(11) NULL DEFAULT NULL,
  `attlog_Count` int(11) NOT NULL,
  `attlog_Time` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`attenlog_Id`) USING BTREE,
  INDEX `att_Id`(`att_Id`) USING BTREE,
  INDEX `staff_Id`(`staff_Id`) USING BTREE,
  CONSTRAINT `att_Id` FOREIGN KEY (`att_Id`) REFERENCES `attendance` (`att_Id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `staff_Id` FOREIGN KEY (`staff_Id`) REFERENCES `staff` (`staffId`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Table structure for department
-- ----------------------------
DROP TABLE IF EXISTS `department`;
CREATE TABLE `department`  (
  `dep_Id` int(10) NOT NULL AUTO_INCREMENT,
  `dep_Name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`dep_Id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 7 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of department
-- ----------------------------
INSERT INTO `department` VALUES (1, '肯德基');
INSERT INTO `department` VALUES (2, '阿瑟东');
INSERT INTO `department` VALUES (6, '黄冈科技啊');

-- ----------------------------
-- Table structure for level
-- ----------------------------
DROP TABLE IF EXISTS `level`;
CREATE TABLE `level`  (
  `level_Id` int(11) NOT NULL AUTO_INCREMENT,
  `level_Name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `level_Price` decimal(10, 2) NOT NULL,
  PRIMARY KEY (`level_Id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of level
-- ----------------------------
INSERT INTO `level` VALUES (1, 'jay', 0.00);

-- ----------------------------
-- Table structure for reward
-- ----------------------------
DROP TABLE IF EXISTS `reward`;
CREATE TABLE `reward`  (
  `rew_Id` int(11) NOT NULL AUTO_INCREMENT,
  `rew_Name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `rew_Price` decimal(19, 2) NOT NULL,
  PRIMARY KEY (`rew_Id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of reward
-- ----------------------------
INSERT INTO `reward` VALUES (1, 'jay', 12314.00);
INSERT INTO `reward` VALUES (3, 'jay-Chou', 123213.00);

-- ----------------------------
-- Table structure for reward_log
-- ----------------------------
DROP TABLE IF EXISTS `reward_log`;
CREATE TABLE `reward_log`  (
  `rewlog_Id` int(10) NOT NULL AUTO_INCREMENT,
  `staff_Id` int(11) NULL DEFAULT NULL,
  `rew_Id` int(11) NULL DEFAULT NULL,
  `rew_price` decimal(10, 2) NOT NULL,
  `rewlog_Time` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`rewlog_Id`) USING BTREE,
  INDEX `reward_staff`(`staff_Id`) USING BTREE,
  INDEX `reward_rew`(`rew_Id`) USING BTREE,
  CONSTRAINT `reward_rew` FOREIGN KEY (`rew_Id`) REFERENCES `reward` (`rew_Id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `reward_staff` FOREIGN KEY (`staff_Id`) REFERENCES `staff` (`staffId`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Table structure for role
-- ----------------------------
DROP TABLE IF EXISTS `role`;
CREATE TABLE `role`  (
  `Role_Id` int(11) NOT NULL AUTO_INCREMENT,
  `role_Name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`Role_Id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of role
-- ----------------------------
INSERT INTO `role` VALUES (1, '店长');

-- ----------------------------
-- Table structure for salary_log
-- ----------------------------
DROP TABLE IF EXISTS `salary_log`;
CREATE TABLE `salary_log`  (
  `sallog_Id` int(11) NOT NULL,
  `staff_Id` int(11) NULL DEFAULT NULL,
  `staff_Name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `shop_Name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `level_Name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `sal_Time` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `level_Price` decimal(10, 2) NOT NULL,
  `att_Percent` decimal(10, 2) NOT NULL,
  `total_Subsidy` decimal(10, 2) NOT NULL,
  `total_reward` decimal(10, 2) NOT NULL,
  `salary_Old` decimal(10, 2) NOT NULL,
  `salary_True` decimal(10, 2) NOT NULL,
  `sallog_Remark` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`sallog_Id`) USING BTREE,
  INDEX `staff_log_Id`(`staff_Id`) USING BTREE,
  CONSTRAINT `staff_log_Id` FOREIGN KEY (`staff_Id`) REFERENCES `staff` (`staffId`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Table structure for shop
-- ----------------------------
DROP TABLE IF EXISTS `shop`;
CREATE TABLE `shop`  (
  `shop_Id` int(11) NOT NULL AUTO_INCREMENT,
  `shop_Name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `shop_Address` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `shop_state` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `shop_supervisor` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `shop_remark` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`shop_Id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of shop
-- ----------------------------
INSERT INTO `shop` VALUES (1, '好再来', '黄冈科技', '营业', '马云1', '');
INSERT INTO `shop` VALUES (2, '啊', '阿三', '营业', '打死', '好评');
INSERT INTO `shop` VALUES (3, '撒的的的', '求稳', '营业', '自行车', '出现');
INSERT INTO `shop` VALUES (4, '去', '我', '营业', '的', '好评');

-- ----------------------------
-- Table structure for staff
-- ----------------------------
DROP TABLE IF EXISTS `staff`;
CREATE TABLE `staff`  (
  `staffId` int(10) NOT NULL AUTO_INCREMENT,
  `staffName` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `staffPwd` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `staffSex` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `staffAddress` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `staffTel` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `staffEmail` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `staffState` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `level_Id` int(11) NULL DEFAULT NULL,
  `roles_Id` int(11) NULL DEFAULT NULL,
  `dep_Id` int(11) NULL DEFAULT NULL,
  `shop_Id` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`staffId`) USING BTREE,
  INDEX `staff_shop`(`shop_Id`) USING BTREE,
  INDEX `staff_level`(`level_Id`) USING BTREE,
  INDEX `staff_dep`(`dep_Id`) USING BTREE,
  INDEX `staff_roles`(`roles_Id`) USING BTREE,
  CONSTRAINT `staff_dep` FOREIGN KEY (`dep_Id`) REFERENCES `department` (`dep_Id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `staff_level` FOREIGN KEY (`level_Id`) REFERENCES `level` (`level_Id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `staff_roles` FOREIGN KEY (`roles_Id`) REFERENCES `role` (`Role_Id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `staff_shop` FOREIGN KEY (`shop_Id`) REFERENCES `shop` (`shop_Id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of staff
-- ----------------------------
INSERT INTO `staff` VALUES (1, 'jay', '1234', '男', '北京', '123456789', '123@qq.com', '', NULL, NULL, NULL, NULL);

-- ----------------------------
-- Table structure for subsidy
-- ----------------------------
DROP TABLE IF EXISTS `subsidy`;
CREATE TABLE `subsidy`  (
  `subsidy_Id` int(11) NOT NULL AUTO_INCREMENT,
  `subsidy_Name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `subsidy_Money` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`subsidy_Id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of subsidy
-- ----------------------------
INSERT INTO `subsidy` VALUES (2, 'fefdh', '1234');

-- ----------------------------
-- Table structure for subsidy_log
-- ----------------------------
DROP TABLE IF EXISTS `subsidy_log`;
CREATE TABLE `subsidy_log`  (
  `stblog_Id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_Id` int(11) NULL DEFAULT NULL,
  `sunsidy_Id` int(11) NULL DEFAULT NULL,
  `subsidy_Money` decimal(10, 2) NOT NULL,
  `sublog_Time` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`stblog_Id`) USING BTREE,
  INDEX `sunsidy_Id`(`sunsidy_Id`) USING BTREE,
  INDEX `subsidy_staff`(`staff_Id`) USING BTREE,
  CONSTRAINT `subsidy_staff` FOREIGN KEY (`staff_Id`) REFERENCES `staff` (`staffId`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `sunsidy_Id` FOREIGN KEY (`sunsidy_Id`) REFERENCES `subsidy` (`subsidy_Id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

SET FOREIGN_KEY_CHECKS = 1;
