package com.hgkj.contrloer.action;


import com.hgkj.model.entity.AttendanceLog;
import com.hgkj.model.entity.SalaryLog;
import com.hgkj.model.entity.Staff;
import com.hgkj.model.service.AttendanceLogService;
import com.hgkj.model.service.Salary_LogService;
import com.hgkj.model.service.StaffService;
import com.opensymphony.xwork2.ActionContext;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.struts2.ServletActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.util.List;

@Controller
@Namespace("/")
@ParentPackage("struts-default")
public class Salary_logAction {
    @Autowired
    private Salary_LogService salary_logService;
    @Autowired
    private StaffService staffService;
    @Autowired
    private AttendanceLogService attendanceLogService;
    private String salaryLogName;
    private Integer salaryLogId;
    private static int index=1;
    private Integer indexjump;
    private static int pages;

    /**
     * 查询所有的工资信息
     * @return
     */
    @Action(value = "salaryList",results = @Result(name = "true",type = "redirect",location = "html/salarySearch.jsp"))
    public String allSalary(){
         Staff staff=(Staff) ActionContext.getContext().getSession().get("staffUser");
         pages = salary_logService.Salary_Pages();
         List<SalaryLog> salaryLogList = salary_logService.querySalaryService(staff);
         if(staff.getRole().getRoleId()!=3){
             pages=salaryLogList.size();
         }
         ActionContext.getContext().getSession().put("salaryList",salaryLogList);
         ActionContext.getContext().getSession().put("pages",pages);
         ActionContext.getContext().getSession().put("index",index);
         return "true";
    }

    /**
     * 查询详细信息
     * @return
     */
    @Action(value = "SL_AL",results = @Result(name = "true",type = "redirect",location = "html/salaryAttendanceInfo.jsp"))
    public String SalaryLog_AttendanceLog(){
        List<String> list = salary_logService.SalaryLog_AttendanceLog(salaryLogId);
        list.add(salaryLogName);
        System.out.println("这是ID"+salaryLogName+"这是集合"+list.toString());
        ActionContext.getContext().getSession().put("salaryAttendanceList",list);//算出迟到次数


        Staff staff=new Staff();
        staff.setStaffId(salaryLogId);
        Staff staff1 = staffService.getStaff(staff);
        BigDecimal levelPrice = staff1.getLevel().getLevelPrice();   //算出基本工资
        return "true";
    }

    /**
     * 模糊查询
     * @return
     */
    @Action(value = "dimquery",results = @Result(name = "true",type = "redirect",location = "html/salarySearch.jsp"))
    public String dimquery(){
        List<SalaryLog> dimquerylist = salary_logService.dimquery(salaryLogName);
        ActionContext.getContext().getSession().put("salaryList",dimquerylist);
        return "true";
    }

    /**
     * 下一页查询
     * @return
     */
    @Action(value = "salaryNextxia",results = @Result(name = "true",type = "redirect",location = "html/salarySearch.jsp"))
    public String salaryNext(){

        if(++index>=pages/2){
          index=pages/2;
        }

        List<SalaryLog> salaryList = salary_logService.Salary_Next(index);
        ActionContext.getContext().getSession().put("salaryList",salaryList);
        ActionContext.getContext().getSession().put("index",index);
        return "true";
    }

    /**
     * 上一页查询
     * @return
     */
    @Action(value = "salaryNextshang",results = @Result(name = "true",type = "redirect",location = "html/salarySearch.jsp"))
    public String salaryNextshang(){

        if(--index<=1){
           index=1;
        }
            List<SalaryLog> salaryList = salary_logService.Salary_Next(index);
            ActionContext.getContext().getSession().put("salaryList",salaryList);
            ActionContext.getContext().getSession().put("index",index);
            return "true";

    }

    /**
     * 跳转页查询
     * @return
     */
    @Action(value = "salaryNextJump",results = @Result(name = "true",type = "redirect",location = "html/salarySearch.jsp"))
    public String salaryNextJump(){
        if(indexjump<=1){
            indexjump=1;
        }
        if(indexjump>=(pages/2)){
            indexjump=(pages/2);
        }
        List<SalaryLog> salaryList = salary_logService.Salary_Next(indexjump);
        ActionContext.getContext().getSession().put("salaryList",salaryList);
        ActionContext.getContext().getSession().put("index",indexjump);
        return "true";

    }

    /**
     *首页查询
     * @return
     */
    @Action(value = "salaryNextHome",results = @Result(name = "true",type = "redirect",location = "html/salarySearch.jsp"))
    public String salaryNextHome(){
         index=1;
        List<SalaryLog> salaryList = salary_logService.Salary_Next(index);
        ActionContext.getContext().getSession().put("salaryList",salaryList);
        ActionContext.getContext().getSession().put("index",index);
        return "true";

    }

    /**
     * 尾页查询
     * @return
     */
    @Action(value = "salaryNextEnd",results = @Result(name = "true",type = "redirect",location = "html/salarySearch.jsp"))
    public String salaryNextEnd(){
        index=pages/2;
        List<SalaryLog> salaryList = salary_logService.Salary_Next(index);
        ActionContext.getContext().getSession().put("salaryList",salaryList);
        ActionContext.getContext().getSession().put("index",index);
        return "true";

    }


    @Action(value = "allsalaryList",results = @Result(name = "true",type = "redirect",location = "html/salaryList.jsp"))
    public String allsalaryList(){
        List<SalaryLog> salaryLogList = salary_logService.allSalaryList();
        ActionContext.getContext().getSession().put("salaryLogList",salaryLogList);
        System.out.println(salaryLogList+"---------------------------((((((((((((((");
        System.out.println(salaryLogList.get(0).getStaff().getStaffName());
        return "true";

    }

    @Action(value = "addGongzi",results = @Result(name = "true",type = "redirect",location = "html/salaryList.jsp"))
    public String addGongzi(){
        HttpServletResponse response= ServletActionContext.getResponse();
        Salary_logAction salary_logAction = new Salary_logAction();
        System.out.println("我发工资了00000000000000000000000000000000000");
            salary_logAction.createExcel(response);

        return "true";

    }

    //创建Excel
    @RequestMapping("/createExcel")
    public String createExcel(HttpServletResponse response) {
        List<SalaryLog> salaryLogList =(List<SalaryLog>) ActionContext.getContext().getSession().get("salaryLogList");

        //创建HSSFWorkbook对象(excel的文档对象)
        HSSFWorkbook wb = new HSSFWorkbook();
//建立新的sheet对象（excel的表单）
        HSSFSheet sheet=wb.createSheet("成绩表");
//在sheet里创建第一行，参数为行索引(excel的行)，可以是0～65535之间的任何一个
        HSSFRow row1=sheet.createRow(0);
//创建单元格（excel的单元格，参数为列索引，可以是0～255之间的任何一个
        HSSFCell cell=row1.createCell(0);
        //设置单元格内容
        cell.setCellValue("员工工资表");
//合并单元格CellRangeAddress构造参数依次表示起始行，截至行，起始列， 截至列
        sheet.addMergedRegion(new CellRangeAddress(0,0,0,3));
//在sheet里创建第二行
        HSSFRow row2=sheet.createRow(1);
        //创建单元格并设置单元格内容
        row2.createCell(0).setCellValue("序号");
        row2.createCell(1).setCellValue("员工编号");
        row2.createCell(2).setCellValue("姓名");
        row2.createCell(3).setCellValue("所在店铺");
        row2.createCell(4).setCellValue("等级");
        row2.createCell(5).setCellValue("基本工资");
        row2.createCell(6).setCellValue("月补贴");
        row2.createCell(7).setCellValue("月奖金");
        row2.createCell(8).setCellValue("考勤扣款");
        row2.createCell(9).setCellValue("应发工资");
        row2.createCell(10).setCellValue("实发工资");
        row2.createCell(11).setCellValue("备注");
        //在sheet里创建第三行
        for(int i=2;i<salaryLogList.size()+2;i++){
            HSSFRow row3=sheet.createRow(i);
            row3.createCell(0).setCellValue(salaryLogList.get(i-2).getSallogId());
            row3.createCell(1).setCellValue(salaryLogList.get(i-2).getStaff().getStaffId());
            row3.createCell(2).setCellValue(salaryLogList.get(i-2).getStaff().getStaffName());
            row3.createCell(3).setCellValue(salaryLogList.get(i-2).getShopName());
            row3.createCell(4).setCellValue(salaryLogList.get(i-2).getLevelName());
            row3.createCell(5).setCellValue(salaryLogList.get(i-2).getLevelPrice().toString());
            row3.createCell(6).setCellValue(salaryLogList.get(i-2).getAttPercent().toString());
            row3.createCell(7).setCellValue(salaryLogList.get(i-2).getTotalSubsidy().toString());
            row3.createCell(8).setCellValue(salaryLogList.get(i-2).getTotalReward().toString());
            row3.createCell(9).setCellValue(salaryLogList.get(i-2).getSalaryOld().toString());
            row3.createCell(10).setCellValue(salaryLogList.get(i-2).getSalaryTrue().toString());
            row3.createCell(11).setCellValue(salaryLogList.get(i-2).getSallogRemark());
        }




//输出Excel文件
        try{
            OutputStream output=response.getOutputStream();
            response.reset();
            response.setHeader("Content-disposition", "attachment; filename=details.xls");
            response.setContentType("application/msexcel");
            wb.write(output);
            output.close();
        }catch (Exception e){
            System.out.println(e);
        }

        return null;
    }



    public void setSalary_logService(Salary_LogService salary_logService) {
        this.salary_logService = salary_logService;
    }

    public void setSalaryLogId(Integer salaryLogId) {
        this.salaryLogId = salaryLogId;
    }

    public void setSalaryLogName(String salaryLogName) {
        this.salaryLogName = salaryLogName;
    }

    public void setIndexjump(Integer indexjump) {
        this.indexjump = indexjump;
    }

    public static void setIndex(int index) {
        Salary_logAction.index = index;
    }
}
