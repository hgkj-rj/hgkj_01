package com.hgkj.model.service;

import com.hgkj.model.entity.Line;
import com.hgkj.model.entity.Picture;

import java.util.List;

public interface DetailLineService {
    public List<Line> lineAllService();
    public List<Picture> imagesAllService();
    public Line lineIdDao(String lineId);
    public Picture imagesIdService(int pictureId);
}
