package com.workmoney.model.service;

import com.workmoney.model.entity.Shop;

import java.util.List;

/**
 * user@Bright Rain .
 * 2019/6/30.
 */
public interface ShopService {

    /**
     * 获取所有店
     * @return
     */
    List<Shop> getAllShopService();
    /**
     * 获取店
     * @return
     */
    Shop getShopByIdService(Shop shop);
    /**
     * 删除店
     * @return
     */

    void delShopByIdService(Shop shop);
    /**
     * 添加店
     * @return
     */
    void addShopService(Shop shop);
    /**
     * 修改店
     * @return
     */
    void updateShopByIdService(Shop shop);
}
