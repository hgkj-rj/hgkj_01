package com.mqy.model.service.impl;

import com.mqy.model.dao.CustomerDao;
import com.mqy.model.entity.Customer;
import com.mqy.model.service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CustomerServiceImpl implements CustomerService {
    @Autowired
    private CustomerDao customerDao;

    public void setCustomerDao(CustomerDao customerDao) {
        this.customerDao = customerDao;
    }

    /**
     * ��¼
     * @param customer
     * @return
     */
    @Override
    public Customer LoginService(Customer customer) {
        return customerDao.LoginDao(customer);
    }

    /**
     * ��ѯ���л�Ա
     * @return
     */
    @Override
    public List<Customer> allCustomerService() {
        return customerDao.allCustomerDao();
    }

    /**
     * ע���Ա
     * @param customer
     * @return
     */
    @Override
    public void registerCustomerService(Customer customer) {
        customerDao.registerCustomerDao(customer);
    }
}
