package com.tourism.model.dao;

public interface CarDao {

}
