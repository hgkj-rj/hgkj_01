package com.hjh.model.dao.Imp;

import com.hjh.model.dao.LineDao;
import com.hjh.model.entity.Line;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
@Repository
@Transactional
public class LineDaoImpl implements LineDao {

    @Autowired
    private SessionFactory sessionFactory;

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    public SessionFactory getSessionFactory() {
        return sessionFactory;
    }

    public Session getSession(){
        return sessionFactory.getCurrentSession();
    }

    @Override
    public List<Line> AllLine() {
        String hql = "from Line";
        List<Line> lineList = getSession().createQuery(hql).list();
        return lineList;
    }

    @Override
    public boolean AddLine(Line line) {
        boolean flag = false;
        try {
            getSession().save(line);
            flag = true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return flag;
    }

    @Override
    public boolean UpingLine(Line line) {
        boolean flag = false;
        try {
            getSession().update(line);
            flag=true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return flag;
    }

    @Override
    public Line GetLine(String lineid) {
        String hql = "from Line where lineid=?";
        Line line = (Line) getSession().createQuery(hql).setParameter(0,lineid).list().get(0);
        return line;
    }
}
