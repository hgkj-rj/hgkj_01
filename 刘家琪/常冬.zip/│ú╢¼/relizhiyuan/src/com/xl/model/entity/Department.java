package com.xl.model.entity;

public class Department {
    private int departmentId;
    private String departmentName;
    private String departmentTime;
    private int departmentCount;
    private String departmentBz;
    public Department(){}
    public Department(int departmentId, String departmentName, String departmentTime, String departmentBz){}
    public Department(String departmentName, String departmentTime, String departmentBz){}
    public Department(String departmentName, String departmentTime, int departmentCount, String departmentBz) {
        this.departmentName = departmentName;
        this.departmentTime = departmentTime;
     this. departmentCount=departmentCount;
        this.departmentBz = departmentBz;
    }
    public int getDepartmentId() {
        return departmentId;
    }

    public void setDepartmentId(int departmentId) {

        this.departmentId = departmentId;
    }

    public String getDepartmentName() {
        return departmentName;
    }

    public void setDepartmentName(String departmentName) {

        this.departmentName = departmentName;
    }

    public String getDepartmentTime() {
        return departmentTime;
    }

    public void setDepartmentTime(String departmentTime) {

        this.departmentTime = departmentTime;
    }
    public int getDepartmentCount() {
        return departmentCount;
    }

    public void setDepartmentCount(int departmentCount) {

        this.departmentCount = departmentCount;
    }


    public String getDepartmentBz() {
        return departmentBz;
    }

    public void setDepartmentBz(String departmentBz) {

        this.departmentBz = departmentBz;
    }
}
