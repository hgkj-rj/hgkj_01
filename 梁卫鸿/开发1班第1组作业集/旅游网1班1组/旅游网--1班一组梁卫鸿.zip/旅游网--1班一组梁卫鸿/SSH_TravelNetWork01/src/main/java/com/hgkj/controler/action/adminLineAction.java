package com.hgkj.controler.action;

import com.hgkj.model.entity.Car;
import com.hgkj.model.entity.Line;
import com.hgkj.model.entity.Picture;
import com.hgkj.model.service.LineService;
import org.apache.struts2.ServletActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import java.util.List;

@Controller
@Namespace("/")
@ParentPackage("struts-default")
public class adminLineAction {
    @Autowired
    private LineService lineService;
    private Line line;
    private Car car;

    public LineService getLineService() {
        return lineService;
    }
    public void setLineService(LineService lineService) {
        this.lineService = lineService;
    }
    @Action(value = "allCustomer",results = @Result(name = "all",type = "redirect",location = "qt/index.jsp"))
    public String allCustomer(){
        List<Line> lineList=lineService.lineAllService();
        List<Picture> pictureList=lineService.imagesAllService();
        ServletActionContext.getRequest().getSession().setAttribute("lineList",lineList);
        ServletActionContext.getRequest().getSession().setAttribute("pictureList",pictureList);
        return "all";
    }
    @Action(value = "lineOrderAction",results = {@Result(name = "find",type = "redirect",location = "qt/order.jsp")})
    public String lineOrderAction(){
        ServletActionContext.getRequest().getSession().setAttribute("carId",car.getCarId());
        Line line1=lineService.lineIdService(line.getLineId());
        ServletActionContext.getRequest().getSession().setAttribute("line",line1);
        return "find";
    }
    @Action(value = "allTypeAction",results = @Result(name = "all",type = "redirect",location = "qt/type.jsp"))
    public String allTypeAction(){
        List<Line> lineList=lineService.lineAllService();
        List<Picture> pictureList=lineService.imagesAllService();
        ServletActionContext.getRequest().getSession().setAttribute("lineList",lineList);
        ServletActionContext.getRequest().getSession().setAttribute("pictureList",pictureList);
        return "all";
    }

    public Car getCar() {
        return car;
    }

    public void setCar(Car car) {
        this.car = car;
    }

    public Line getLine() {
        return line;
    }

    public void setLine(Line line) {
        this.line = line;
    }
}
