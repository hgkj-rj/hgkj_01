package com.hgkj.model.service.impl;

import com.hgkj.model.dao.SalaryLogDao;
import com.hgkj.model.entity.SalaryLog;
import com.hgkj.model.service.SalaryLogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class SalaryLogServiceImpl implements SalaryLogService {
    @Autowired
    private SalaryLogDao salaryLogDao;

    public void setSalaryLogDao(SalaryLogDao salaryLogDao) {
        this.salaryLogDao = salaryLogDao;
    }

    @Override
    public List<SalaryLog> allSalaryLogService() {
        return salaryLogDao.allSalaryLogDao();
    }

    @Override
    public List<SalaryLog> alSalaryLogService(SalaryLog salaryLog) {
        return salaryLogDao.alSalaryLogDao(salaryLog);
    }
}
