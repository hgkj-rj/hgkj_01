package com.hgkj.model.service;

import com.hgkj.model.entity.Car;
import com.hgkj.model.entity.Images;
import com.hgkj.model.entity.Line;
import com.hgkj.model.entity.Picture;

import java.util.List;

public interface ImagesService {
    public List<Picture> imagesAllService();
    public boolean imagesInsertService(String lineId,String introduction,String name);
    public boolean imagesDeleteService(int pictureId);
    public Picture imagesIdService(int pictureId);
    public boolean imagesUpdateService(int pictureId,String introduction,String name,String lineId);
    public boolean lineAddService(Line line);
    public List<Line> lineAllService();
    public boolean lineDeleteService(String lineId);
    public Line lineIdService(String lineId);
    public boolean lineUpdateService(Line line);
}
