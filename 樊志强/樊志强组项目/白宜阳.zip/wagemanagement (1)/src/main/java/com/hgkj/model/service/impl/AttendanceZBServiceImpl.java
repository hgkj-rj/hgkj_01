package com.hgkj.model.service.impl;

import com.hgkj.model.dao.AttendanceZBDao;
import com.hgkj.model.entity.Attendance;
import com.hgkj.model.service.AttendanceZBService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class AttendanceZBServiceImpl implements AttendanceZBService {
    @Autowired
    private AttendanceZBDao attendanceZBDao;

    public void setAttendanceZBDao(AttendanceZBDao attendanceZBDao) {
        this.attendanceZBDao = attendanceZBDao;
    }

    @Override
    public List<Attendance> allAttendanceService() {
        return attendanceZBDao.allAttendanceDao();
    }

    @Override
    public boolean addAttendanceService(Attendance attendance) {
        return attendanceZBDao.addAttendanceDao(attendance);
    }

    @Override
    public boolean updateAttendanceService(Attendance attendance) {
        return attendanceZBDao.updateAttendanceDao(attendance);
    }

    @Override
    public boolean deleteAttendanceService(int attId) {
        return attendanceZBDao.deleteAttendanceDao(attId);
    }

    @Override
    public Attendance getByIdAttendanceService(int attId) {
        return attendanceZBDao.getByIdAttendanceDao(attId);
    }
}
