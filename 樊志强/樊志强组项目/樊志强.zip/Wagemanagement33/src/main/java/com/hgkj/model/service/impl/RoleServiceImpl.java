package com.hgkj.model.service.impl;

import com.hgkj.model.dao.RoleDao;
import com.hgkj.model.entity.Role;
import com.hgkj.model.service.RoleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class RoleServiceImpl implements RoleService {
    @Autowired
    private RoleDao roleDao;

    public RoleDao getRoleDao() {
        return roleDao;
    }

    public void setRoleDao(RoleDao roleDao) {
        this.roleDao = roleDao;
    }

    @Override
    public List<Role> allroleService() {
        return roleDao.allroleDao();
    }

    @Override
    public boolean insertroleService(Role role) {
        return roleDao.insertroleDao(role);
    }

    @Override
    public boolean deleteroleService(int id) {
        return roleDao.deleteroleDao(id);
    }

    @Override
    public boolean updateroleService(Role role) {
        return roleDao.updateroleDao(role);
    }

    @Override
    public Role getroleByIdService(int id) {
        return roleDao.getroleByIdDao(id);
    }
}
