package com.hgkj.model.service.impl;


import com.hgkj.model.dao.OrderdetailDao;
import com.hgkj.model.entity.Orderdetail;
import com.hgkj.model.service.OrderdetailService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class OrderdetailServiceImpl implements OrderdetailService {
    @Autowired
    public OrderdetailDao orderdetailDao;

    public void setOrderdetailDao(OrderdetailDao orderdetailDao) {
        this.orderdetailDao = orderdetailDao;
    }

    @Override
    public List<Orderdetail> allOrderdetailService() {
        return orderdetailDao.allOrderdetailDao();
    }

    @Override
    public boolean addOrderdetailService(Orderdetail orderdetail) {
        return orderdetailDao.addOrderdetailDao(orderdetail);
    }

    @Override
    public boolean deleteOrderdetailService(Orderdetail orderdetail) {
        return orderdetailDao.deleteOrderdetailDao(orderdetail);
    }

    @Override
    public boolean updateOrderdetailService(Orderdetail orderdetail) {
        return orderdetailDao.updateOrderdetailDao(orderdetail);
    }

    @Override
    public Orderdetail getOrderdetailByIdService(String odId) {
        return orderdetailDao.getOrderdetailByIdDao(odId);
    }
}
