package com.hgkj.model.service.impl;

import com.hgkj.model.dao.CarDao;
import com.hgkj.model.entity.*;
import com.hgkj.model.service.CarService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CarServiceImpl implements CarService {
    @Autowired
    private CarDao carDao;
    public void setCarDao(CarDao carDao) {
        this.carDao = carDao;
    }
    @Override
    public boolean CarAddService(int customerId,String lineId,String time)
    {
        return carDao.CarAddDao(customerId,lineId,time);
    }

    @Override
    public List<Car> carAllService() {
        return carDao.carAllDao();
    }

    @Override
    public List<Line> lineAllService() {
        return carDao.lineAllDao();
    }

    @Override
    public List<Picture> pictureAllService() {
        return carDao.pictureAllDao();
    }

    @Override
    public List<Customer> customerAllService() {
        return carDao.customerAllDao();
    }

    @Override
    public boolean carDeleteDao(int carId) {
        return carDao.carDeleteDao(carId);
    }

    @Override
    public Orderdetail orderIdService(String orderId) {
        return carDao.orderIdDao(orderId);
    }

    @Override
    public boolean orderDeleteService(String orderId) {
        return carDao.orderDeleteDao(orderId);
    }

    @Override
    public boolean otDeleteService(int otId) {
        return carDao.otDeleteDao(otId);
    }

    @Override
    public boolean ot1DeleteDao(String odId) {
        return carDao.ot1DeleteDao(odId);
    }
}
