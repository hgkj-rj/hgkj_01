package com.hgkj.model.dao;

import com.hgkj.model.entity.Level;

import java.util.List;

public interface LevelDao {
    List<Level> allLevelDao();
    boolean addLevelDao(Level level);
    boolean updateLevelDao(Level level);
    boolean deleteLevelDao(int levelId);
    Level getByIdLevelDao(int levelId);
}
