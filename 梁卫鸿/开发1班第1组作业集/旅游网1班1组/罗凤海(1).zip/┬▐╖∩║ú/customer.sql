/*
 Navicat Premium Data Transfer

 Source Server         : MySQL
 Source Server Type    : MySQL
 Source Server Version : 50720
 Source Host           : localhost:3306
 Source Schema         : travel

 Target Server Type    : MySQL
 Target Server Version : 50720
 File Encoding         : 65001

 Date: 08/07/2019 09:55:44
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for customer
-- ----------------------------
DROP TABLE IF EXISTS `customer`;
CREATE TABLE `customer`  (
  `customerID` int(255) NOT NULL AUTO_INCREMENT,
  `account` varchar(16) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `name` varchar(6) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `password` varchar(12) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `gender` varchar(2) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `identityID` varchar(18) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `tel` varchar(11) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `type` int(255) NULL DEFAULT NULL,
  PRIMARY KEY (`customerID`) USING BTREE,
  UNIQUE INDEX `account`(`account`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 8 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of customer
-- ----------------------------
INSERT INTO `customer` VALUES (1, '123456789', '张三', '123456', '男', '52215324123564', '1111111111', 1);
INSERT INTO `customer` VALUES (4, '1234567890', '王大锤', '123456', '女', '5221543121512', '111111', 1);
INSERT INTO `customer` VALUES (5, '123', '李四', '123', '男', '522728199801202', '1111111', 1);
INSERT INTO `customer` VALUES (6, '123456', '丽丽', '123456', '女', '52272819980104', '17681850420', NULL);
INSERT INTO `customer` VALUES (7, '111111', '王五', '123456', '男', '252252215212', '1111111', NULL);

SET FOREIGN_KEY_CHECKS = 1;
