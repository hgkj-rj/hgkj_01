package com.tourism.model.dao.Impl;

import com.tourism.model.dao.LinetypeDao;
import com.tourism.model.entity.Customer;
import com.tourism.model.entity.Linetype;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;


import java.util.List;
@Repository
@Transactional
public class LinetypeDaoImpl implements LinetypeDao {
@Autowired
private SessionFactory sessionFactory;
private Session session;

    public SessionFactory getSessionFactory() {
        return sessionFactory;
    }

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    public Session getSession() {
        return session;
    }

    public void setSession(Session session) {
        this.session = session;
    }

    @Override
    public boolean addLinetypeDao(Linetype linetype) {
        boolean flag=false;
        session =getSession();
        try {
            session.save(linetype);
            flag=true;
        }catch (Exception e){
            e.printStackTrace();
        }
        return flag;
    }


    @Override
    public boolean updateLinetypeDao(Linetype linetype) {
        boolean flag=false;
        session =getSession();
        try {
            session.update(linetype);
            flag=true;
        }catch (Exception e){
            e.printStackTrace();
        }
        return flag;
    }


    @Override
    public List<Linetype> allLinetypeDao() {
        Query query=getSession().createQuery("from Linetype ");
        return query.list();
    }

    @Override
    public Linetype getLinetypeByIdDao(String linetypeId) {
        session=getSession();
        String hql="from Linetype where lineTypeId=? ";
        Linetype linetype=(Linetype) session.createQuery(hql).setParameter(0,linetypeId).uniqueResult();

        return linetype;
    }
}
