package com.hgkj.model.service;

import com.hgkj.model.entity.Level;

import java.util.List;

public interface LevelService {
    //查询所有员工级别类别
    public List<Level> alllevelService();
    //添加员工级别类别
    public boolean insertlevelService(Level level);
    //删除员工级别类别
    public boolean deletelevelService(int id);
    //修改员工级别类别
    public boolean updatelevelService(Level level);
    //根据Id获取员工级别信息
    public Level getlevelByIdService(int id);
}
