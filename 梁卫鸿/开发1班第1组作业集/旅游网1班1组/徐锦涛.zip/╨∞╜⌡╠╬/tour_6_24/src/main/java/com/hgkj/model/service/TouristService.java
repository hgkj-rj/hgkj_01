package com.hgkj.model.service;

import com.hgkj.model.entity.Tourist;

import java.util.List;

public interface TouristService {
    public List<Tourist> allTouristService();
    public boolean addTouristService(Tourist tourist);
}
