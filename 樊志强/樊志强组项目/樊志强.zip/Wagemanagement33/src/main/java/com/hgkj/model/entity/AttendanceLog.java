package com.hgkj.model.entity;

public class AttendanceLog {
    private int attenlogId;
    private int attlogCount;
    private String attlogTime;
    private Attendance attendance;
    private Staff staff;

    public Staff getStaff() {
        return staff;
    }

    public void setStaff(Staff staff) {
        this.staff = staff;
    }

    public Attendance getAttendance() {
        return attendance;
    }

    public void setAttendance(Attendance attendance) {
        this.attendance = attendance;
    }

    public int getAttenlogId() {
        return attenlogId;
    }

    public void setAttenlogId(int attenlogId) {
        this.attenlogId = attenlogId;
    }


    public int getAttlogCount() {
        return attlogCount;
    }

    public void setAttlogCount(int attlogCount) {
        this.attlogCount = attlogCount;
    }

    public String getAttlogTime() {
        return attlogTime;
    }

    public void setAttlogTime(String attlogTime) {
        this.attlogTime = attlogTime;
    }

}
