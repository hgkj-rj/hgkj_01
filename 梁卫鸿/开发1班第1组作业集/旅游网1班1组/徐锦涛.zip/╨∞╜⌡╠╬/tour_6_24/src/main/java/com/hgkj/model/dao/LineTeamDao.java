package com.hgkj.model.dao;

import com.hgkj.model.entity.Line;

import java.util.List;

public interface LineTeamDao {
    public boolean lineTeamAddDao(Line line);
    public List<Line> lineTeamAllDao();
    public boolean lineTeamDeleteDao(String lineID);
    public Line lineTeamIdDao(String lineID);
    public boolean lineTeamUpdateDao(Line line);
}
