package com.hgkj.model.service;

public interface PictureService {
}
