package com.hgkj.model.service.impl;

import com.hgkj.model.dao.LevelDao;
import com.hgkj.model.entity.Level;
import com.hgkj.model.service.LevelService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class LevelServiceImpl  implements LevelService {
    @Autowired
    private LevelDao levelDao;

    public void setLevelDao(LevelDao levelDao) {
        this.levelDao = levelDao;
    }

    @Override
    public List<Level> alllevelService() {
        return levelDao.alllevelDao();
    }

    @Override
    public boolean insertlevelService(Level level) {
        return levelDao.insertlevelDao(level);
    }

    @Override
    public boolean deletelevelService(int id) {
        return levelDao.deletelevelDao(id);
    }

    @Override
    public boolean updatelevelService(Level level) {
        return levelDao.updatelevelDao(level);
    }

    @Override
    public Level getlevelByIdService(int id) {
        return levelDao.getlevelByIdDao(id);
    }
}
