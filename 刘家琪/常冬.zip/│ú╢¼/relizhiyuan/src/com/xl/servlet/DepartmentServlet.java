package com.xl.servlet;

import com.xl.model.entity.Department;
import com.xl.model.service.DepartmentService;
import com.xl.model.service.impl.DepartmentServiceImpl;
import org.codehaus.jackson.map.ObjectMapper;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.DriverManager;
import java.util.List;

@WebServlet(name = "DepartmentServlet",value = "/DepartmentServlet")
public class DepartmentServlet extends HttpServlet {
    DepartmentService departmentService=new DepartmentServiceImpl();

    private int pageSize=2;
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out =response.getWriter();
        ObjectMapper mapper=new ObjectMapper();
        String action=request.getParameter("action");
        if ("all".equals(action)){
            int pageIndex=request.getParameter("pageIndex")==null?1:Integer.parseInt(request.getParameter("pageIndex"));
            int totalPage=departmentService.departmentService(pageSize);
                    if (pageIndex<1){
                        pageIndex=1;
                }else if (pageIndex>totalPage){
                    pageIndex=totalPage;
                }
                request.getSession().setAttribute("pageIndex",pageIndex);
                request.getSession().setAttribute("totalPage",totalPage);
                List<Department> departmentList=departmentService.allDepartmentService(pageIndex,pageSize);
                request.getSession().setAttribute("departmentList",departmentList);
                response.sendRedirect("departmentMgr.jsp");

            }else if ("add".equals(action)){
            String departmentName=request.getParameter("departmentName");
            String departmentTime=request.getParameter("departmentTime");
            String departmentBz=request.getParameter("departmentBz");
            Department department=new Department(departmentName,departmentTime,departmentBz);
            boolean result=departmentService.addDepartmentService(department);
            if (result){

                response.sendRedirect("DepartmentServlet?action=all");
            }else {

                request.getRequestDispatcher("departmentAdd.jsp");
            }

        }else if ("update".equals(action)) {
            int departmentId = Integer.parseInt(request.getParameter("departmentId"));
            String departmentName = request.getParameter("departmentName");
            String departmentTime = request.getParameter("departmentTime");
            String departmentBz = request.getParameter("departmentBz");
            Department department = new Department(departmentId,departmentName, departmentTime, departmentBz);
            boolean result = departmentService.updateDepartmentService(department);
            if (result) {

                response.sendRedirect("DepartmentServlet?action=all");
            } else {
           return;
            }
        }
        else if ("delete".equals(action)){
            int departmentId = Integer.parseInt(request.getParameter("departmentId"));
            boolean flag=  departmentService.deleteDepartmentService(departmentId);
            String f=String.valueOf(flag);
            String result=mapper.writeValueAsString(f);
            out.println(result);

        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
       doPost(request,response);
    }
}
