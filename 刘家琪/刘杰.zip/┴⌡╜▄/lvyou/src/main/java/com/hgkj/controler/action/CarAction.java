package com.hgkj.controler.action;

import com.hgkj.model.entity.Car;
import com.hgkj.model.entity.Customer;
import com.hgkj.model.entity.Line;
import com.hgkj.model.service.CarService;
import com.hgkj.model.service.impl.CarServiceImpl;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

@Namespace("/")
@ParentPackage("struts-default")
@Controller
public class CarAction {
    @Autowired
    private CarService carService = new CarServiceImpl();
    private Car car = new Car();
    private Line line;
    private Customer customer = new Customer();


    @Action(value = "AddCar", results = @Result(name = "AddCar", type = "redirect", location = "qt/car.jsp"))
    /*添加到购物车*/
    public String addCar(){

        System.out.println(customer.getCustomerId()+"+==+");
        return "AddCar";
    }










    public CarService getCarService() {
        return carService;
    }

    public void setCarService(CarService carService) {
        this.carService = carService;
    }

    public Car getCar() {
        return car;
    }

    public void setCar(Car car) {
        this.car = car;
    }

    public Line getLine() {
        return line;
    }

    public void setLine(Line line) {
        this.line = line;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }
}
