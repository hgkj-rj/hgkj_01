package com.hgkj.contrloer.action;

import com.hgkj.model.entity.*;
import com.hgkj.model.service.StaffService;
import org.apache.struts2.ServletActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import java.util.List;

@Controller
@Namespace("/")
@ParentPackage("struts-default")
public class StaffloginAction {
    @Autowired
    private StaffService staffService;
    private String message;
    private Staff staff;
    private String staffPwd2;

    public String getStaffPwd2() {
        return staffPwd2;
    }

    public void setStaffPwd2(String staffPwd2) {
        this.staffPwd2 = staffPwd2;
    }

    @Action(value = "slogin",results = {@Result(name = "logins",type = "dispatcher",location = "/main.jsp"),
                                        @Result(name = "logine",type = "dispatcher",location = "/login.jsp")})
    public String StraffLogin(){
        List<Staff>staffList=staffService.loginStaffService(staff);
        if (staffList.size()>0){
            ServletActionContext.getRequest().getSession().setAttribute("staffList",staffList);
            return "logins";
        }else {
            message="登录失败";
            return "logine";
        }
    }

    @Action(value = "getByIds",results = {@Result(name = "getByIds",type = "redirect",location = "/html/resetpass.jsp")})
    public String getByIdStaff(){
        Staff staff1=staffService.getByIdStaffService(staff.getStaffId());
        ServletActionContext.getRequest().getSession().setAttribute("staff1",staff1);
        return "getByIds";
    }

    @Action(value = "updateStaffPwd",results = {@Result(name = "updps",type = "redirect",location = "/welcome/welcomeXGPwd.jsp"),
                                                @Result(name = "updpe",type = "redirect",location = "/html/resetpass.jsp")})
    public String updateStaffPwd(){
        System.out.println("确认密码："+getStaffPwd2());
        if (staffPwd2.equals(staff.getStaffPwd())){
            staffService.updateStaffService(staff);
            return "updps";
        }else{
            return "updpe";
        }
    }

    @Action(value = "allstaff",results = @Result(name = "all",type = "redirect",location = "/html/empList.jsp"))
    public String allstaff(){
        List<Staff> staffList=staffService.allStaffService();
        ServletActionContext.getRequest().getSession().setAttribute("staffList",staffList);
        List<Level> levelList=staffService.allLevelService();
        ServletActionContext.getRequest().getSession().setAttribute("levelList",levelList);
        List<Role> roleList=staffService.allRoleService();
        ServletActionContext.getRequest().getSession().setAttribute("roleList",roleList);
        List<Department> departmentList=staffService.allDepartmentService();
        ServletActionContext.getRequest().getSession().setAttribute("departmentList",departmentList);
        List<Shop> shopList=staffService.allShopService();
        ServletActionContext.getRequest().getSession().setAttribute("shopList",shopList);
        return "all";
    }

    @Action(value = "addstaff",results = @Result(name = "adds",type = "redirectAction",params = {"actionName","allstaff"}))
    public String addstaff(){
        boolean r=staffService.addStaffService(staff);
        if (r==true){
            return "adds";
        }else {
            return "adde";
        }
    }

    @Action(value = "delstaff",results = @Result(name = "dels",type = "redirectAction",params = {"actionName","allstaff"}))
    public String deletestaff(){
        boolean r=staffService.deleteStaffService(staff.getStaffId());
        if (r==true){
            return "dels";
        }else {
            return "dele";
        }
    }

    @Action(value = "updstaff",results = @Result(name = "upds",type = "redirectAction",params = {"actionName","allstaff"}))
    public String Updstaff(){
        System.out.println("员工信息修改中");
        boolean r=staffService.updateStaffXXService(staff);
        if (r==true){
            return "upds";
        }else {
            return "upde";
        }
    }

    @Action(value = "getByIdstaffs",results = {@Result(name = "getByIds",type = "redirect",location = "/html/empUpdate.jsp")})
    public String getByIdstaff(){
        Staff staffLi=staffService.getByIdStaffService(staff.getStaffId());
        ServletActionContext.getRequest().getSession().setAttribute("staffLi",staffLi);
        return "getByIds";
    }

    public Staff getStaff() {
        return staff;
    }

    public void setStaff(Staff staff) {
        this.staff = staff;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public void setStaffService(StaffService staffService) {
        this.staffService = staffService;
    }
}
