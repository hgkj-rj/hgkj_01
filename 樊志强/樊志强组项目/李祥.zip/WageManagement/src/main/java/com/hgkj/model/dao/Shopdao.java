package com.hgkj.model.dao;

import com.hgkj.model.entity.Shop;

import java.util.List;

public interface Shopdao {
    public List<Shop> allShopdao();
    public boolean addShopdao(Shop shop);
    public boolean deleteShopdao(int shopId);
    public boolean updateShopdao(Shop shop);
    public Shop shop(int shopId);
}
