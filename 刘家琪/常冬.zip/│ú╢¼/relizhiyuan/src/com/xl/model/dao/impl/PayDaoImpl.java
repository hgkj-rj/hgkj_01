package com.xl.model.dao.impl;

import com.xl.model.dao.PayDao;
import com.xl.model.entity.Pay;
import com.xl.model.entity.Train;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class PayDaoImpl implements PayDao {
    @Override
    public int PayDao(int pageSize) {
        int totalPage=0;
        Connection connection=DBManager.getConnection();
        PreparedStatement preparedStatement=null;
        ResultSet resultSet=null;
        String sql="select count(*) from pay";
        try {
            preparedStatement=connection.prepareStatement(sql);
            resultSet=preparedStatement.executeQuery();
            if (resultSet.next()){
                totalPage=(resultSet.getInt(1)-1)/pageSize+1;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            DBManager.closeAll(connection,preparedStatement,resultSet);
        }
        return totalPage;
    }

    @Override
    public List<Pay> allPayDao(int pageIndex, int pageSize) {
        List<Pay> payList=new ArrayList<>();
        Connection connection=DBManager.getConnection();
        PreparedStatement preparedStatement=null;
        ResultSet resultSet=null;
        String sql="select * from pay limit  ?,?";
        try {
            preparedStatement=connection.prepareStatement(sql);
            preparedStatement.setInt(1,(pageIndex-1)*pageSize);
            preparedStatement.setInt(2,pageSize);
            resultSet=preparedStatement.executeQuery();
            while (resultSet.next()){
                Pay pay=new Pay();
                pay.setPayId(resultSet.getInt("payId"));
                pay.setPayName(resultSet.getString("payName"));
                pay.setPayBase(resultSet.getInt("payBase"));
                pay.setPayMo(resultSet.getString("payMo"));
                pay.setPayLe(resultSet.getInt("payLe"));
                pay.setPayAtt(resultSet.getInt("payAtt"));
                pay.setPayAb(resultSet.getInt("payAb"));
                pay.setPayOt(resultSet.getInt("payOt"));
                payList.add(pay);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            DBManager.closeAll(connection,preparedStatement,resultSet);
        }
        return payList;
    }

    @Override
    public int getPayByIdDao(int PayId) {

        return 0;
    }

    @Override
    public boolean addPayDao(Pay pay) {

        return false;
    }

    @Override
    public boolean deletePayDao(Pay pay) {

        return false;
    }

    @Override
    public boolean updatePayDao(Pay pay) {

        return false;
    }
}
