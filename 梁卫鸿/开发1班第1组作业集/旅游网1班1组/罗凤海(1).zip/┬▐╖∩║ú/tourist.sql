/*
 Navicat Premium Data Transfer

 Source Server         : MySQL
 Source Server Type    : MySQL
 Source Server Version : 50720
 Source Host           : localhost:3306
 Source Schema         : travel

 Target Server Type    : MySQL
 Target Server Version : 50720
 File Encoding         : 65001

 Date: 08/07/2019 09:56:40
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for tourist
-- ----------------------------
DROP TABLE IF EXISTS `tourist`;
CREATE TABLE `tourist`  (
  `touristID` varchar(36) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `IDCard` varchar(36) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `tel` varchar(15) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `realName` varchar(6) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`touristID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of tourist
-- ----------------------------
INSERT INTO `tourist` VALUES ('yk165', '522728199801202', '1111111', '李四');
INSERT INTO `tourist` VALUES ('yk235', '522728199801202', '1111111', '李四');
INSERT INTO `tourist` VALUES ('yk276', '522728199801202', '1111111', '李四');
INSERT INTO `tourist` VALUES ('yk376', '522728199801202', '1111111', '李四33');
INSERT INTO `tourist` VALUES ('yk480', '522728199801202', '1111111', '李四22');
INSERT INTO `tourist` VALUES ('yk499', '522728199801202', '1111111', '李四');
INSERT INTO `tourist` VALUES ('yk627', '522728199801202', '1111111', '李四');
INSERT INTO `tourist` VALUES ('yk660', '522728199801202', '1111111', '李四');
INSERT INTO `tourist` VALUES ('yk693', '522728199801202', '1111111', '李四');
INSERT INTO `tourist` VALUES ('yk741', '52272819980104', '17681850420', '丽丽2');
INSERT INTO `tourist` VALUES ('yk76', '522728199801202', '1111111', '李四44');
INSERT INTO `tourist` VALUES ('yk818', '522728199801202', '1111111', '李四');
INSERT INTO `tourist` VALUES ('yk825', '52272819980104', '17681850420', '丽丽3');
INSERT INTO `tourist` VALUES ('yk913', '522728199801202', '1111111', '李四');
INSERT INTO `tourist` VALUES ('yk945', '52272819980104', '17681850420', '丽丽1');

SET FOREIGN_KEY_CHECKS = 1;
