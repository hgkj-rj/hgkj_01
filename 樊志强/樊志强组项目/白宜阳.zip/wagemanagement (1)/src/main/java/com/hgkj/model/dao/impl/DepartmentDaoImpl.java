package com.hgkj.model.dao.impl;

import com.hgkj.model.dao.DepartmentDao;
import com.hgkj.model.entity.Department;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
@Transactional
public class DepartmentDaoImpl implements DepartmentDao {
    @Autowired
    private SessionFactory sessionFactory;
    private Transaction transaction;

    public Transaction getTransaction() {
        return transaction;
    }
    public void setTransaction(Transaction transaction) {
        this.transaction = transaction;
    }
    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }
    public Session getSession(){
        return sessionFactory.getCurrentSession();
    }

    @Override
    public List<Department> allDepartmentDao() {
        Query query=getSession().createQuery("from Department");
        return query.list();
    }

    @Override
    public boolean addDepartmentDao(Department department) {
        boolean flag=false;
        try {
            getSession().save(department);
            flag=true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return flag;
    }

    @Override
    public boolean updateDepartmentDao(Department department) {
        boolean flag=false;
        try {
            getSession().update(department);
            flag=true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return flag;
    }

    @Override
    public boolean deleteDepartmentDao(int depId) {
        boolean flag=false;
        Department department=new Department();
        department.setDepId(depId);
        try {
            getSession().delete(department);
            flag=true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return flag;
    }

    @Override
    public Department getByIdDepartmentDao(int depId) {
        Department department=getSession().get(Department.class,depId);
        return department;
    }
}
