package com.tourism.model.service;

public interface TouristService {
}
