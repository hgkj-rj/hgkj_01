package com.hgkj.contorler.action;

import com.hgkj.model.Service.LineService;
import com.hgkj.model.Service.LineTypeService;
import com.hgkj.model.Service.PictureService;
import com.hgkj.model.entity.Line;
import com.hgkj.model.entity.Linetype;
import com.hgkj.model.entity.Picture;
import com.opensymphony.xwork2.ActionContext;
import org.apache.struts2.ServletActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import javax.servlet.ServletContext;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Random;

@Controller
@Namespace("/")
@ParentPackage("struts-default")
public class LineAction {
    @Autowired
    private LineTypeService lineTypeService;
    @Autowired
    private LineService lineService;
    @Autowired
    private PictureService pictureService;
    private Line line;
    private Picture picture;
    private List<Picture> pictures;
    private File[] photo;
    private  String[] photoFileName;
    private  String[] photoContentType;
    private Picture picture0;
    private Picture picture1;
    private Picture picture2;
    private Picture picture3;
    private int pageindex;

    public Picture getPicture() {
        return picture;
    }

    public void setPicture(Picture picture) {
        this.picture = picture;
    }

    public int getPageindex() {
        return pageindex;
    }

    public void setPageindex(int pageindex) {
        this.pageindex = pageindex;
    }

    public Picture getPicture0() {
        return picture0;
    }

    public void setPicture0(Picture picture0) {
        this.picture0 = picture0;
    }

    public Picture getPicture1() {
        return picture1;
    }

    public void setPicture1(Picture picture1) {
        this.picture1 = picture1;
    }

    public Picture getPicture2() {
        return picture2;
    }

    public void setPicture2(Picture picture2) {
        this.picture2 = picture2;
    }

    public Picture getPicture3() {
        return picture3;
    }

    public void setPicture3(Picture picture3) {
        this.picture3 = picture3;
    }

    public LineTypeService getLineTypeService() {
        return lineTypeService;
    }

    public void setLineTypeService(LineTypeService lineTypeService) {
        this.lineTypeService = lineTypeService;
    }

    public PictureService getPictureService() {
        return pictureService;
    }

    public void setPictureService(PictureService pictureService) {
        this.pictureService = pictureService;
    }

    public List<Picture> getPictures() {
        return pictures;
    }

    public void setPictures(List<Picture> pictures) {
        this.pictures = pictures;
    }

    public File[] getPhoto() {
        return photo;
    }

    public void setPhoto(File[] photo) {
        this.photo = photo;
    }

    public String[] getPhotoFileName() {
        return photoFileName;
    }

    public void setPhotoFileName(String[] photoFileName) {
        this.photoFileName = photoFileName;
    }

    public String[] getPhotoContentType() {
        return photoContentType;
    }

    public void setPhotoContentType(String[] photoContentType) {
        this.photoContentType = photoContentType;
    }

    public LineService getLineService() {
        return lineService;
    }

    public void setLineService(LineService lineService) {
        this.lineService = lineService;
    }

    public Line getLine() {
        return line;
    }

    public void setLine(Line line) {
        this.line = line;
    }

    @Action(value = "allLine", results = @Result(name = "all", type = "redirect", location = "/seeline.jsp"))
    public String allLine() {
        List<Line> lineList = lineService.allLineService();
        ActionContext.getContext().getSession().put("lineList", lineList);
        return "all";
    }
    @Action(value = "toIndex", results = @Result(name = "all", type = "redirect", location = "/index.jsp"))
    public String toIndex() {
        List<Linetype> linetypeList = lineTypeService.fourLineService();
        ActionContext.getContext().getSession().put("linetypeList",linetypeList);
        String lineTypeId;
        if(line==null){
            Linetype linetype = lineTypeService.getLastService();
            lineTypeId = linetype.getLineTypeId();
        }else {
            lineTypeId = line.getLinetype().getLineTypeId();
        }
        List<Picture> pictureList1 = pictureService.findlineService(lineTypeId);
        ActionContext.getContext().getSession().put("pictureList1",pictureList1);

        String typeId="12Z1pE";
        List<Line> lineList11 = lineService.toIndexLineService(typeId);
        ActionContext.getContext().getSession().put("lineList11",lineList11);

        typeId="CZ89en";
        List<Line> lineList22 = lineService.toIndexLineService(typeId);
        ActionContext.getContext().getSession().put("lineList22",lineList22);

         typeId="CZ89en";
        List<Line> lineList33 = lineService.toIndexLineService(typeId);
        ActionContext.getContext().getSession().put("lineList33",lineList33);

        typeId="JC1F26";
        List<Line> lineList44 = lineService.toIndexLineService(typeId);
        ActionContext.getContext().getSession().put("lineList44",lineList44);

        List<Line>lineList1 = lineService.allLineService();
        ActionContext.getContext().getSession().put("lineList1",lineList1);

        List<Line>lineListone = lineService.oneLineService();
        ActionContext.getContext().getSession().put("lineListone",lineListone);
        List<Line>lineListtwo = lineService.twoLineService();
        ActionContext.getContext().getSession().put("lineListtwo",lineListtwo);
        List<Line>lineListmore = lineService.moreLineService();
        ActionContext.getContext().getSession().put("lineListmore",lineListmore);

        List<Picture>pictureList = pictureService.allPictureService();
        ActionContext.getContext().getSession().put("pictureList",pictureList);
        return "all";
    }

    @Action(value = "toGroup", results = @Result(name = "all", type = "redirect", location = "/group.jsp"))
    public String toGroup() {
       if(pageindex==0){
           pageindex=1;
       }
       int pagesize=6;
       Date date = new Date();
       SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd :hh:mm:ss");
       String time = dateFormat.format(date);
       int total = lineService.getpageService(pagesize,time);
       total = (total+pagesize-1)/pagesize;
       if(pageindex<1){
           pageindex=1;
       }else  if (pagesize>total){
           pageindex=total;
       }
       ActionContext.getContext().getSession().put("pageindex",pageindex);
       ActionContext.getContext().getSession().put("total",total);
       List<Line> lineList = lineService.allLineService(pageindex,pagesize,time);
       ActionContext.getContext().getSession().put("lineList",lineList);
        return "all";
    }
    @Action(value = "toDetail", results = @Result(name = "all", type = "redirect", location = "/detail.jsp"))
    public String toDetail() {
        line = lineService.getLineByIdService(line.getLineId());
        ActionContext .getContext().getSession().put("line",line);
        List<Picture> pictureList = pictureService.findPictureService(line.getLineId());
        ActionContext.getContext().getSession().put("pictureList",pictureList);
        return "all";
    }
    @Action(value = "toOrder", results = @Result(name = "all", type = "redirect", location = "/order.jsp"))
    public String toOrder() {
        line = lineService.getLineByIdService(line.getLineId());
        ActionContext.getContext().getSession().put("line",line);
        return "all";
    }


    @Action(value = "allGroup", results = @Result(name = "all", type = "redirect", location = "/seegroup.jsp"))
    public String allGroup() {
        List<Line> lineList = lineService.allLineService();
        ActionContext.getContext().getSession().put("lineList", lineList);
        return "all";
    }

    @Action(value = "allGroupLine", results = @Result(name = "all", type = "redirect", location = "/allGroupLine.jsp"))
    public String allGroupLine() {
        List<Line> lineList = lineService.allLineService();
        ActionContext.getContext().getSession().put("lineList", lineList);
        return "all";
    }



    @Action(value = "findGroupLine", results = @Result(name = "find", type = "redirect", location = "/updategroup.jsp"))
    public String findGroupLine() {
     line = lineService.getLineByIdService(line.getLineId());
     List<Picture> pictureList= pictureService.findPictureService(line.getLineId());
     ActionContext.getContext().getSession().put("line",line);
     ActionContext.getContext().getSession().put("pictureList",pictureList);
     List<Linetype> linetypeList = lineTypeService.allLineTypeService();
     ActionContext.getContext().getSession().put("linetypeList",linetypeList);
     return "find";
    }

    @Action(value = "findLine", results = @Result(name = "find", type = "redirect", location = "/updateline.jsp"))
    public String findLine() {
        line = lineService.getLineByIdService(line.getLineId());
        List<Picture> pictureList= pictureService.findPictureService(line.getLineId());
        ActionContext.getContext().getSession().put("line",line);
        ActionContext.getContext().getSession().put("pictureList",pictureList);
        List<Linetype> linetypeList = lineTypeService.allLineTypeService();
        ActionContext.getContext().getSession().put("linetypeList",linetypeList);
        return "find";
    }


  @Action(value = "addLine", results = {@Result(name = "add", type = "redirectAction", location = "allLine.action"),
            @Result(name = "error", type = "redirect", location = "/addline.jsp")})
    public String addLine() {
      ServletContext servletContext = ServletActionContext.getServletContext();
      String filePath = servletContext.getRealPath("upload");
      File file = new File(filePath);
      if (!file.exists()) {
          file.mkdir();
      }
      for (int i = 0; i < photo.length; i++) {
          photo[i].renameTo(new File(file, photoFileName[i]));
      }
      Date date = new Date();
      SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd:hh:mm:ss");
      line.setOnTime(dateFormat.format(date));
      line.setLineId(getCharAndNumr(3));
      boolean flag = lineService.addLineService(line);
      if(!flag){
          return "error";
      }
      for(int i=0;i<4;i++){
          pictures.get(i).setLine(line);
          pictures.get(i).setName("upload/"+photoFileName[i]);
          flag = pictureService.addPictureService(pictures.get(i));
          if(!flag){
              return "error";
          }
      }
      return "add";
  }
    @Action(value = "toalLinetype",results = @Result(name = "toall",type = "redirect",location = "/addline.jsp"))
    public String allLinetype() {
        List<Linetype> linetypeList = lineTypeService.allLineTypeService();
        ActionContext.getContext().getSession().put("linetypeList", linetypeList);
        return "toall";
    }
    @Action(value = "updateLine", results = {@Result(name = "update", type = "redirectAction", location = "allLine.action"),
            @Result(name = "error", type = "redirect", location = "/updateline.jsp")})
    public String updateLine(){
     boolean flag = false;
     if(photo!=null){
         ServletContext application = ServletActionContext.getServletContext();
         String filePath = application.getRealPath("upload");
         File file = new File(filePath);
         if(!file.exists()){
             file.mkdir();
         }
         for(int i=0;i<photo.length;i++){
             photo[i].renameTo(new File(file,photoFileName[i]));
         }
     }
     flag = lineService.updateLineService(line);
     if(!flag){
         return "error";
     }
     picture0.setLine(line);
     picture1.setLine(line);
     picture2.setLine(line);
     picture3.setLine(line);

     File temFile0 = new File(picture0.getName().trim());
     String fileName0=temFile0.getName();
     picture0.setName("upload/"+fileName0);

     File temFile1 = new File(picture1.getName().trim());
     String fileName1=temFile1.getName();
     picture1.setName("upload/"+fileName1);

     File temFile2 = new File(picture2.getName().trim());
     String fileName2=temFile2.getName();
     picture2.setName("upload/"+fileName2);

     File temFile3 = new File(picture3.getName().trim());
     String fileName3=temFile3.getName();
     picture3.setName("upload/"+fileName3);

     flag = pictureService.updatePictureService(picture0);
     if(!flag){
         return "error";
     }
        flag = pictureService.updatePictureService(picture1);
        if(!flag){
            return "error";
        }
        flag = pictureService.updatePictureService(picture2);
        if(!flag){
            return "error";
        }
        flag = pictureService.updatePictureService(picture3);
        if(!flag){
            return "error";
        }
        return "update";
    }

    @Action(value = "updategroupline", results = {@Result(name = "update", type = "redirectAction", location = "allGroup.action"),
            @Result(name = "error", type = "redirect", location = "/updategroup.jsp")})
    public String updategroupline(){
        boolean flag = false;
        line.setTeamBuy(1);
        flag=lineService.updateLineService(line);
        if(!flag){
            return "error";
        }
            return "update";

    }


    public static String getCharAndNumr(int length) {
        String val = "";
        Random random = new Random();
        for (int i = 0; i < length; i++) {
            // 输出字母还是数字
            String charOrNum = random.nextInt(2) % 2 == 0 ? "char" : "num";
            // 字符串
            if ("char".equalsIgnoreCase(charOrNum)) {
                // 取得大写字母还是小写字母
                int choice = random.nextInt(2) % 2 == 0 ? 65 : 97;
                val += (char) (choice + random.nextInt(26));
            } else if ("num".equalsIgnoreCase(charOrNum)) { // 数字
                val += String.valueOf(random.nextInt(10));
            }
        }
        return val;
    }

}

