package com.hgkj.model.service;

import com.hgkj.model.entity.SalaryLog;

import java.util.List;

public interface SalaryLogService {
    /**
     * 查询员工工资
     * @return
     */
    List<SalaryLog> allSalaryLogService();
    List<SalaryLog> alSalaryLogService(SalaryLog salaryLog);
}
