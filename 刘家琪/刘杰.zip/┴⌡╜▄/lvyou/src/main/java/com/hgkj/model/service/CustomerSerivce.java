package com.hgkj.model.service;

import com.hgkj.model.entity.Customer;

import java.util.List;

public interface CustomerSerivce {
    /*添加*/
    public boolean addCustomerSerivce(Customer customer);
    /*登录*/
    public List<Customer> loginCustomerSerivce(Customer customer);
}
