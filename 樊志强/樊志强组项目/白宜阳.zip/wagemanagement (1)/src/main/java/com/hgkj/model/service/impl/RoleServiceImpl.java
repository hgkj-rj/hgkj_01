package com.hgkj.model.service.impl;

import com.hgkj.model.dao.RoleDao;
import com.hgkj.model.entity.Role;
import com.hgkj.model.service.RoleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RoleServiceImpl implements RoleService {
    @Autowired
    private RoleDao roleDao;

    public void setRoleDao(RoleDao roleDao) {
        this.roleDao = roleDao;
    }

    @Override
    public List<Role> allRoleService() {
        return roleDao.allRoleDao();
    }

    @Override
    public boolean addRoleService(Role role) {
        return roleDao.addRoleDao(role);
    }

    @Override
    public boolean updateRoleService(Role role) {
        return roleDao.updateRoleDao(role);
    }

    @Override
    public boolean deleteRoleService(int roleId) {
        return roleDao.deleteRoleDao(roleId);
    }

    @Override
    public Role getByIdRoleService(int roleId) {
        return roleDao.getByIdRoleDao(roleId);
    }
}
