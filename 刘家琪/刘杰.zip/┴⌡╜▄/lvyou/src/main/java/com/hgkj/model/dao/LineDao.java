package com.hgkj.model.dao;

import com.hgkj.model.entity.Line;
import com.hgkj.model.entity.Picture;

import java.util.List;

public interface LineDao {
    public boolean addLineDao(Line line);
    public int getLineIdDao();
    public boolean addPictureDao(Picture picture);
    public List<Line> allLineDao();
    public List<Object[]> getOneLineDao(int id);
    public boolean updateLineDao(Object[] objects);
    public Line getOneLineTeamDao(int id);
    public boolean addLineTeamDao(Line line);
    public boolean updateLineTeamDao(Line line);
    public List<Line> whereAllLineDao(String name);
    public List<Line> whereAllDayDao(String day);
    public List<Line> whereNotAllDayDao(String day1,String day2);
    public List<Object[]> getTypeNamereturnQTDao(String name);
    public List<Object[]> getTeamReturnQTDao();
    public List<Object[]> getOneTeamLineDao(String name);



}
