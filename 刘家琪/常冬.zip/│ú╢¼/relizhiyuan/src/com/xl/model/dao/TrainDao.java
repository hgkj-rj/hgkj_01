package com.xl.model.dao;

import com.xl.model.entity.Department;
import com.xl.model.entity.Train;

import java.util.List;

public interface TrainDao {
    public int TrainDao(int pageSize);
    public List<Train> allTrainDao(int pageIndex, int pageSize);
    public Train getTrainByIdDao(int TrainId);
    public boolean addTrainDao(Train train);
    public boolean deleteTrainDao(Train train);
    public boolean updateTrainDao(Train train);
}
