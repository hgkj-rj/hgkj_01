package com.hgkj.model.service.impl;

import com.hgkj.model.dao.SubsidyDao;
import com.hgkj.model.dao.SubsidyLogDao;
import com.hgkj.model.entity.Subsidy;
import com.hgkj.model.entity.SubsidyLog;
import com.hgkj.model.service.SubsidyLogService;
import com.hgkj.model.service.SubsidyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class SubsidyLogServiceImpl implements SubsidyLogService {
    @Autowired
    private SubsidyLogDao subsidyLogDao;

    public SubsidyLogDao getSubsidyDao() {
        return subsidyLogDao;
    }

    public void setSubsidyDao(SubsidyLogDao subsidyLogDao) {
        this.subsidyLogDao =subsidyLogDao;
    }


    @Override
    public List<SubsidyLog> allsubsidyLogService() {
        return subsidyLogDao.allsubsidyLogDao();
    }

    @Override
    public boolean insertsubsidyLogService(SubsidyLog subsidyLog) {
        return subsidyLogDao.insertsubsidyLogDao(subsidyLog);
    }

    @Override
    public boolean deletesubsidyLogService(int id) {
        return subsidyLogDao.deletesubsidyLogDao(id);
    }

    @Override
    public boolean updatesubsidyLogService(SubsidyLog subsidyLog) {
        return subsidyLogDao.updatesubsidyLogDao(subsidyLog);
    }

    @Override
    public SubsidyLog getsubsidyLogByIdService(int id) {
        return subsidyLogDao.getsubsidyLogByIdDao(id);
    }
}
