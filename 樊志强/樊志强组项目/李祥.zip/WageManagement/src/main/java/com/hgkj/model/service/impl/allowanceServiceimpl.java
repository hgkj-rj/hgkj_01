package com.hgkj.model.service.impl;

import com.hgkj.model.dao.allowancedao;
import com.hgkj.model.entity.Reward;
import com.hgkj.model.service.allowanceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class allowanceServiceimpl implements allowanceService {

    @Autowired
    private allowancedao  allowancedao;

    public void setAllowancedao(com.hgkj.model.dao.allowancedao allowancedao) {
        this.allowancedao = allowancedao;
    }

    @Override
    public List<Reward> allRewardService() {
        return allowancedao.allRewardDao();
    }

    @Override
    public boolean addRewardService(Reward reward) {
        return allowancedao.addRewardDao(reward);
    }

    @Override
    public boolean deleteRewardService(int rewId) {
        return allowancedao.deleteRewardDao(rewId);
    }

    @Override
    public boolean updateRewardService(Reward reward) {
        return allowancedao.updateRewardDao(reward);
    }

    @Override
    public Reward reward(int rewId) {
        return allowancedao.reward(rewId);
    }
}
