package com.hjh.model.dao.Imp;

import com.hjh.model.dao.PictureDao;
import com.hjh.model.entity.Line;
import com.hjh.model.entity.Picture;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
@Repository
@Transactional
public class PictureDaoImpl implements PictureDao {
    @Autowired
    private SessionFactory sessionFactory;

    public SessionFactory getSessionFactory() {
        return sessionFactory;
    }

    public Session getSession(){
        return sessionFactory.getCurrentSession();
    }
    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    @Override
    public List<Picture> Allpicture(Line line) {
        String hql = "from Picture where line.lineid=?";
        List<Picture> pictureList= getSession().createQuery(hql).setParameter(0,line.getLineid()).list();
        return pictureList;
    }

    @Override
    public boolean Addpicture(Picture picture) {
        boolean f = false;
        Session session = getSession();
        Line line = session.load(Line.class,picture.getLine().getLineid());
        picture.setLine(line);
        try {
            session.save(picture);
            f = true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return f;
    }

    @Override
    public boolean UPpicture(Picture picture) {
        boolean f = false;
        Session session = getSession();
        Line line = session.load(Line.class,picture.getLine().getLineid());
        picture.setLine(line);
        try {
            session.update(picture);
            f = true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return f;
    }
}
