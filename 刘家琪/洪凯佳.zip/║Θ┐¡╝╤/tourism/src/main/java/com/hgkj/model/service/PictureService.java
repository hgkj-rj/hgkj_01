package com.hgkj.model.service;

import com.hgkj.model.entity.Picture;

import java.util.List;

public interface PictureService {
    public List<Picture> findPictureService(String lineId);
    public boolean addPictureService(Picture picture);
    public boolean updatePictureService(Picture picture);
}
