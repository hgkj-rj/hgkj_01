package com.hgkj.model.dao;

import com.hgkj.model.entity.Reward;

import java.util.List;

public interface RewardDao {
    //查询所有奖金类别
    public List<Reward> allrewardDao();
    //添加奖金类别
    public boolean insertrewardDao(Reward reward);
    //删除奖金类别
    public boolean deleterewardDao(int id);
    //修改奖金类别
    public boolean updaterewardDao(Reward reward);
    //根据Id获取奖金信息
    public Reward getrewardByIdDao(int id);
}
