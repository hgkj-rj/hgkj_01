package com.hgkj.model.dao;

import com.hgkj.model.entity.AttendanceLog;
import com.hgkj.model.entity.SalaryLog;

import java.util.List;

public interface SalaryLogDao {
    /**
     * 查询员工工资
     * @return
     */
    List<SalaryLog>allSalaryLogDao();
    List<SalaryLog> alSalaryLogDao(SalaryLog salaryLog);
}
