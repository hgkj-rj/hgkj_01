package com.hgkj.model.entity;

import java.math.BigDecimal;

public class Reward {
    private Integer rewId;
    private String rewName;
    private BigDecimal rewPrice;

    public Integer getRewId() {
        return rewId;
    }

    public void setRewId(Integer rewId) {
        this.rewId = rewId;
    }

    public String getRewName() {
        return rewName;
    }

    public void setRewName(String rewName) {
        this.rewName = rewName;
    }

    public BigDecimal getRewPrice() {
        return rewPrice;
    }

    public void setRewPrice(BigDecimal rewPrice) {
        this.rewPrice = rewPrice;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Reward reward = (Reward) o;

        if (rewId != null ? !rewId.equals(reward.rewId) : reward.rewId != null) return false;
        if (rewName != null ? !rewName.equals(reward.rewName) : reward.rewName != null) return false;
        if (rewPrice != null ? !rewPrice.equals(reward.rewPrice) : reward.rewPrice != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = rewId != null ? rewId.hashCode() : 0;
        result = 31 * result + (rewName != null ? rewName.hashCode() : 0);
        result = 31 * result + (rewPrice != null ? rewPrice.hashCode() : 0);
        return result;
    }
}
