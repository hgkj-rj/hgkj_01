package com.hgkj.model.service;

import com.hgkj.model.entity.Reward;

import java.util.List;

public interface RewardService {
    List<Reward> allRewardService();
    boolean addRewardService(Reward reward);
    boolean updateRewardService(Reward reward);
    boolean deleteRewardService(int rewId);
    Reward getByIdRewardService(int reWId);
}
