package com.tourism.controler.action;

import com.opensymphony.xwork2.ActionContext;
import com.tourism.model.entity.Linetype;
import com.tourism.model.service.LinetypeService;
import org.apache.struts2.ServletActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Result;
import org.omg.IOP.ServiceContext;
import org.springframework.beans.factory.annotation.Autowired;

import javax.servlet.ServletContext;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Random;

public class LinetypeAction {
    @Autowired
    private LinetypeService linetypeService;
    private Linetype linetype;
     private File upload;
     private String uploadFileName;
     private String uploadContentType;

    public File getUpload() {
        return upload;
    }

    public void setUpload(File upload) {
        this.upload = upload;
    }

    public String getUploadFileName() {
        return uploadFileName;
    }

    public void setUploadFileName(String uploadFileName) {
        this.uploadFileName = uploadFileName;
    }

    public String getUploadContentType() {
        return uploadContentType;
    }

    public void setUploadContentType(String uploadContentType) {
        this.uploadContentType = uploadContentType;
    }

    public LinetypeService getLinetypeService() {
        return linetypeService;
    }

    public void setLinetypeService(LinetypeService linetypeService) {
        this.linetypeService = linetypeService;
    }

    public Linetype getLinetype() {
        return linetype;
    }

    public void setLinetype(Linetype linetype) {
        this.linetype = linetype;
    }
    @Action(value = "allLinetype",results = @Result(name = "all",type = "redirect",location = "/allLineType.jsp"))
    public String allLinetype(){
        List<Linetype> linetypeList = linetypeService.allLinetypeService();
        ActionContext.getContext().getSession().put("linetypeList",linetypeList);
        return "all";
    }
    @Action(value = "addLinetype",results = {@Result(name = "add",type = "redirectAction",location = "/addLineType.action"),
    @Result(name = "error",type = "redirect",location = "/addLineType.jsp")})
    public  String addLinetype(){
        ServletContext applolication= ServletActionContext.getServletContext();
        String filePath =applolication.getRealPath("upload");
        File file=new File(filePath);
        if (!file.exists()){
            file.mkdirs();

        }
        upload.renameTo(new File(file,uploadFileName));
        linetype.setIcon("upload/"+uploadFileName);
        Date date=new Date();
        SimpleDateFormat dateFormat =new SimpleDateFormat("yyyy-mm-dd :hh:mm:ss");
        linetype.setTime(dateFormat.format(date));
        linetype.setLineTypeId(getCharAndNumr(6));
        boolean flag=linetypeService.addLinetypeService(linetype);
        if (flag){
            return "add";
        }
        return "error";
    }



    @Action(value = "updateLinetype",results = {@Result(name = "update",type = "redirectAction",location = "/updateLineType.action"),
            @Result(name = "error",type = "redirect",location = "/updateLineType.jsp")})
    private String updateLinetype(){
        if (uploadFileName==null){
            File tempFile= new File(linetype.getIcon().trim());
            String fileName = tempFile .getName();
            linetype.setIcon("update/"+fileName);
        }else {
            ServletContext application=ServletActionContext.getServletContext();
            String filePath=application.getRealPath("update");
            File file=new File(filePath);
            if (file.exists()){
                file.mkdirs();
            }
            upload.renameTo(new File(file,uploadFileName));
            linetype.setIcon("upload/"+uploadFileName);
        }
        boolean flag=linetypeService.updateLinetypeService(linetype);
        if (flag){
            return "upload";
        }
        return "find";
    }
private static String getCharAndNumr(int length){
        String val="";
    Random random=new Random();
    for (int i=0;i<length;i++){
        String charOrNum=random.nextInt(2)%2==0?"char":"num";
        if ("char".equalsIgnoreCase(charOrNum)){
            int choice=random.nextInt(2)%2==0?65:97;
            val +=(char)(choice + random.nextInt(26));

        }else if ("num".equalsIgnoreCase(charOrNum)){
            val +=String.valueOf(random.nextInt(10));
        }
    }
    return val;
}
}
