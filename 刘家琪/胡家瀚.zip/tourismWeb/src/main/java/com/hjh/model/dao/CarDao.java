package com.hjh.model.dao;

import com.hjh.model.entity.Car;

import java.util.List;

public interface CarDao {
    public List<Car> AllCar();
    public boolean addCar(Car car);
    public boolean DeleCar(Car car);
}
