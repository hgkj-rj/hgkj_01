package com.hgkj.model.Dao;

import com.hgkj.model.entity.Customer;

public interface CustomerDao {
    public Customer qCustomerDao(Customer customer);
    public  Boolean  addCustomerDao(Customer customer);

}
