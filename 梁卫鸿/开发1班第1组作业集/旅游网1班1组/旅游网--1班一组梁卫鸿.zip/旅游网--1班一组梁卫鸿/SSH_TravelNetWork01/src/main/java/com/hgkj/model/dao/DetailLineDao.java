package com.hgkj.model.dao;

import com.hgkj.model.entity.Line;
import com.hgkj.model.entity.Picture;

import java.util.List;

public interface DetailLineDao {
    public List<Line> lineAllDao();
    public List<Picture> imagesAllDao();
    public Line lineIdDao(String lineId);
    public Picture imagesIdDao(int pictureId);
}
