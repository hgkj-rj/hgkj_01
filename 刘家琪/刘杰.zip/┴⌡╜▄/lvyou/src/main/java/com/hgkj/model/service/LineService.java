package com.hgkj.model.service;

import com.hgkj.model.entity.Line;
import com.hgkj.model.entity.Picture;
import org.apache.taglibs.standard.lang.jstl.test.beans.PublicBean1;

import java.util.List;

public interface LineService {
    /*添加线路*/
    public boolean addLineService(Line line);
    /*获取最大线路ID*/
    public int getLineIdService();
    /*添加图片*/
    public boolean addPictureService(Picture picture);
    /*查询所有*/
    public List<Line> allLineServcie();
    /*查询单个Line+Picture*/
    public List<Object[]> getOneLineService(int id);
    /*查询单个团购Line+Picture*/
    public List<Object[]> getOneTeamLineService(String name);
    /*查询单个Line*/
    public Line getOneLineTeamService(int id);
    /*添加团购信息*/
    public boolean addLineTeamService(Line line);
    /*修改线路*/
    public boolean updateLineService(Object[] objects);
    /*修改团购信息*/
    public boolean updateLineTeamService(Line line);
    /*查询旅游产品分类*/
    public List<Line> whereAllLineService(String name);
    /*一日游、二日游*/
    public List<Line> whereAllDaySerivce(String day);
    /*多日游*/
    public List<Line> whereNotAllDayService(String day1,String day2);
    /*查询线路类型返回前台*/
    public List<Object[]> getTypeNamereturnQTService(String name);
    /*前台查询团购*/
    public List<Object[]> getTeamReturnQTService();
    /*查询图片产品的详细信息*/
    /*得到图片*/
    /*查询单个Line+Picture并返回到前台*/
    /*修改图片*/
}
