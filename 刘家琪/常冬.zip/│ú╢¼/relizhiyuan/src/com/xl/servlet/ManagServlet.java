package com.xl.servlet;

import com.xl.model.entity.Manag;
import com.xl.model.service.ManagService;
import com.xl.model.service.impl.ManagServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(name = "ManagServlet",value = "/ManagServlet")
public class ManagServlet extends HttpServlet {
    private ManagService managService=new ManagServiceImpl();
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");

      String managName=request.getParameter("managName");
        String managPwd=request.getParameter("managPwd");
        Manag manag=new Manag(managName,managPwd);
boolea flag=managService managLoginService(manag);
        if (flag){
            request.getSession().setAttribute("manag",manag);
            response.sendRedirect("mgrMainPage.jsp");
        }
        else {
            response.sendRedirect("mgLogin.jsp");
        }


    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
doPost(request,response);
    }
}
