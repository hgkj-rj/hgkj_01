package com.hgkj.model.service.impl;

import com.hgkj.model.dao.OtDao;
import com.hgkj.model.entity.OtDetail;
import com.hgkj.model.service.OtService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class OtServiceImpl implements OtService {
    @Autowired
    private OtDao otDao;

    public void setOtDao(OtDao otDao) {
        this.otDao = otDao;
    }

    @Override
    public boolean otAddService(String odId, String touristId) {
        return otDao.otAddDao(odId,touristId);
    }

    @Override
    public boolean orderAddService(String odId, String lineName, String price, String orderDate, String travelDate, String total, String lineId, int state, int customerId) {
        return otDao.orderAddDao(odId,lineName,price,orderDate,travelDate,total,lineId,state,customerId);
    }

    @Override
    public boolean touristAddService(String touristId, String idCard, String tel, String realName) {
        return otDao.touristAddDao(touristId,idCard,tel,realName);
    }

    @Override
    public OtDetail OtIdDao(int otId) {
        return otDao.OtIdDao(otId);
    }

    @Override
    public List<OtDetail> otAllService() {
        return otDao.otAllDao();
    }
}
