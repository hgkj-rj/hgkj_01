package com.workmoney.util;

import com.workmoney.model.entity.Staff;
import com.workmoney.model.entity.StaffFuBen;
import org.junit.Before;
import org.junit.Test;
import org.springframework.util.Assert;
import sun.util.resources.cldr.CalendarData;

import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.*;

/**
 * user@Bright Rain .
 * 2019/7/3.
 */
public class TextClass {

    Calendar calendar = null;

    @Test
    public void textClass(){
        String t = null;
        Assert.hasText(t,"是否为文本");
    }

    @Test
    public void textMethod() {
        // 获取年
        int year = calendar.get(Calendar.YEAR);

        // 获取月，这里需要需要月份的范围为0~11，因此获取月份的时候需要+1才是当前月份值
        int month = calendar.get(Calendar.MONTH) + 1;

        // 获取日
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        // 获取时
        int hour = calendar.get(Calendar.HOUR);
        // int hour = calendar.get(Calendar.HOUR_OF_DAY); // 24小时表示

        // 获取分
        int minute = calendar.get(Calendar.MINUTE);

        // 获取秒
        int second = calendar.get(Calendar.SECOND);

        // 星期，英语国家星期从星期日开始计算
        int weekday = calendar.get(Calendar.DAY_OF_WEEK);

        System.out.println("现在是" + year + "年" + month + "月" + day + "日" + hour
                + "时" + minute + "分" + second + "秒" + "星期" + weekday);
    }

    @Test
    public void  text(){
        /**
         * 获取当前时间的方法
         */
        long l = System.currentTimeMillis();
        System.out.println("System获取当前时间"+l);

        Date date = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy年MM月dd日");
        System.out.println("SimpleDateFormat获取当前时间"+sdf.format(date));

        Locale china = Locale.CHINA;

        TimeZone aDefault = TimeZone.getTimeZone("GMT+:08:00");

        Calendar calendar = Calendar.getInstance(aDefault,china);
        // 获取年
        int year = calendar.get(Calendar.YEAR);

        // 获取月，这里需要需要月份的范围为0~11，因此获取月份的时候需要+1才是当前月份值
        int month = calendar.get(Calendar.MONTH) + 1;

        // 获取日
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        // 获取时
        int hour = calendar.get(Calendar.HOUR);
        // int hour = calendar.get(Calendar.HOUR_OF_DAY); // 24小时表示

        // 获取分
        int minute = calendar.get(Calendar.MINUTE);

        // 获取秒
        int second = calendar.get(Calendar.SECOND);

        // 星期，英语国家星期从星期日开始计算
        int weekday = calendar.get(Calendar.DAY_OF_WEEK);

        System.out.println("calendar获取当前时间" + year + "年" + month + "月" + day + "日" + hour
                + "时" + minute + "分" + second + "秒" + "星期" + weekday);
    }


    @Test
    public void text2(){
    String[] availableIDs = TimeZone.getAvailableIDs();

    for (String availableID : availableIDs) {
        System.out.println(availableID);
    }
}


}
