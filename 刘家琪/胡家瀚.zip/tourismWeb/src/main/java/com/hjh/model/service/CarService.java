package com.hjh.model.service;

import com.hjh.model.entity.Car;

import java.util.List;

public interface CarService {
    public List<Car> AllCar();
    public boolean addCar(Car car);
    public boolean DeleCar(Car car);
}
