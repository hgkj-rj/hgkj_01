package com.hgkj.model.dao;

import com.hgkj.model.entity.Role;

import java.util.List;

public interface Roledao {
    public List<Role> roledao();
}
