package com.hgkj.model.Dao;

import com.hgkj.model.entity.Linetype;

import java.util.List;

public interface LineTypeDao {
    public List<Linetype> allLineTypeDao();
    public List<Linetype> fourLineDao();
    public boolean  addLineTypeDao(Linetype linetype);
    public boolean  updateLineTypeDao(Linetype linetype);
    public Linetype getLineByIdDao(String lineTypeId);
    public Linetype getLastDao();
}
