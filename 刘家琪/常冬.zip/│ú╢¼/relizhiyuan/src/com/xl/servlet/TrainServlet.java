package com.xl.servlet;

import com.xl.model.entity.Department;
import com.xl.model.entity.Train;
import com.xl.model.service.DepartmentService;
import com.xl.model.service.TrainService;
import com.xl.model.service.impl.DepartmentServiceImpl;
import com.xl.model.service.impl.TrainServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet(name = "TrainServlet",value = "/TrainServlet")
public class TrainServlet extends HttpServlet {
   TrainService trainService=new TrainServiceImpl();
    private int pageSize=2;
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");
        String action = request.getParameter("action");
        if ("all".equals(action)) {
            int pageIndex = request.getParameter("pageIndex") == null ? 1 : Integer.parseInt(request.getParameter("pageIndex"));
            int totalPage = trainService.TrainService(pageSize);
            if (pageIndex < 1) {
                pageIndex = 1;
            } else if (pageIndex > totalPage) {
                pageIndex = totalPage;
            }
            request.getSession().setAttribute("pageIndex", pageIndex);
            request.getSession().setAttribute("totalPage", totalPage);
            List<Train> trainList = trainService.allTrainService(pageIndex, pageSize);
            request.getSession().setAttribute("trainList", trainList);
            response.sendRedirect("trainMgr.jsp");
        }
    }
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
doPost(request,response);
    }
}
