package com.hgkj.model.service.impl;

import com.hgkj.model.dao.DepartmentDao;
import com.hgkj.model.entity.Department;
import com.hgkj.model.service.DepartmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DespartmentServiceImpl implements DepartmentService {
    @Autowired
    private DepartmentDao departmentDao;

    @Override
    public List<Department> allDepartment() {
        return departmentDao.allDepartment();
    }

    @Override
    public boolean addDepartment(Department Department) {
        return departmentDao.addDepartment(Department);
    }

    @Override
    public boolean delDepartment(Department Department) {
        return departmentDao.delDepartment(Department);
    }

    @Override
    public boolean updDepartment(Department Department) {
        return departmentDao.updDepartment(Department);
    }

    @Override
    public Department queryDepartment(Department Department) {
        return departmentDao.queryDepartment(Department);
    }
}
