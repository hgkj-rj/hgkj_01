package com.hjh.model.entity;

import java.math.BigDecimal;
import java.util.HashSet;
import java.util.Set;

public class Line {
    private String lineid;
    private String lineTypeid;
    private String lineName;
    private String days;
    private String vehicle;
    private String introduction;
    private String reason;
    private String arrange;
    private BigDecimal price;
    private Integer teambuy;
    private BigDecimal teambuyprice;
    private String begintime;
    private String endtime;
    private String ontime;
    private Linetype linetype;
    private Set<Picture> pictureSet = new HashSet<>();
    private Set<Car> carSet = new HashSet<>();

    public Set<Car> getCarSet() {
        return carSet;
    }

    public void setCarSet(Set<Car> carSet) {
        this.carSet = carSet;
    }

    public Set<Picture> getPictureSet() {
        return pictureSet;
    }

    public void setPictureSet(Set<Picture> pictureSet) {
        this.pictureSet = pictureSet;
    }

    public Linetype getLinetype() {
        return linetype;
    }

    public void setLinetype(Linetype linetype) {
        this.linetype = linetype;
    }

    public String getLineid() {
        return lineid;
    }

    public void setLineid(String lineid) {
        this.lineid = lineid;
    }

    public String getLineTypeid() {
        return lineTypeid;
    }

    public void setLineTypeid(String lineTypeid) {
        this.lineTypeid = lineTypeid;
    }

    public String getLineName() {
        return lineName;
    }

    public void setLineName(String lineName) {
        this.lineName = lineName;
    }

    public String getDays() {
        return days;
    }

    public void setDays(String days) {
        this.days = days;
    }

    public String getVehicle() {
        return vehicle;
    }

    public void setVehicle(String vehicle) {
        this.vehicle = vehicle;
    }

    public String getIntroduction() {
        return introduction;
    }

    public void setIntroduction(String introduction) {
        this.introduction = introduction;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public String getArrange() {
        return arrange;
    }

    public void setArrange(String arrange) {
        this.arrange = arrange;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public Integer getTeambuy() {
        return teambuy;
    }

    public void setTeambuy(Integer teambuy) {
        this.teambuy = teambuy;
    }

    public BigDecimal getTeambuyprice() {
        return teambuyprice;
    }

    public void setTeambuyprice(BigDecimal teambuyprice) {
        this.teambuyprice = teambuyprice;
    }

    public String getBegintime() {
        return begintime;
    }

    public void setBegintime(String begintime) {
        this.begintime = begintime;
    }

    public String getEndtime() {
        return endtime;
    }

    public void setEndtime(String endtime) {
        this.endtime = endtime;
    }

    public String getOntime() {
        return ontime;
    }

    public void setOntime(String ontime) {
        this.ontime = ontime;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Line line = (Line) o;

        if (lineid != null ? !lineid.equals(line.lineid) : line.lineid != null) return false;
        if (lineTypeid != null ? !lineTypeid.equals(line.lineTypeid) : line.lineTypeid != null) return false;
        if (lineName != null ? !lineName.equals(line.lineName) : line.lineName != null) return false;
        if (days != null ? !days.equals(line.days) : line.days != null) return false;
        if (vehicle != null ? !vehicle.equals(line.vehicle) : line.vehicle != null) return false;
        if (introduction != null ? !introduction.equals(line.introduction) : line.introduction != null) return false;
        if (reason != null ? !reason.equals(line.reason) : line.reason != null) return false;
        if (arrange != null ? !arrange.equals(line.arrange) : line.arrange != null) return false;
        if (price != null ? !price.equals(line.price) : line.price != null) return false;
        if (teambuy != null ? !teambuy.equals(line.teambuy) : line.teambuy != null) return false;
        if (teambuyprice != null ? !teambuyprice.equals(line.teambuyprice) : line.teambuyprice != null) return false;
        if (begintime != null ? !begintime.equals(line.begintime) : line.begintime != null) return false;
        if (endtime != null ? !endtime.equals(line.endtime) : line.endtime != null) return false;
        if (ontime != null ? !ontime.equals(line.ontime) : line.ontime != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = lineid != null ? lineid.hashCode() : 0;
        result = 31 * result + (lineTypeid != null ? lineTypeid.hashCode() : 0);
        result = 31 * result + (lineName != null ? lineName.hashCode() : 0);
        result = 31 * result + (days != null ? days.hashCode() : 0);
        result = 31 * result + (vehicle != null ? vehicle.hashCode() : 0);
        result = 31 * result + (introduction != null ? introduction.hashCode() : 0);
        result = 31 * result + (reason != null ? reason.hashCode() : 0);
        result = 31 * result + (arrange != null ? arrange.hashCode() : 0);
        result = 31 * result + (price != null ? price.hashCode() : 0);
        result = 31 * result + (teambuy != null ? teambuy.hashCode() : 0);
        result = 31 * result + (teambuyprice != null ? teambuyprice.hashCode() : 0);
        result = 31 * result + (begintime != null ? begintime.hashCode() : 0);
        result = 31 * result + (endtime != null ? endtime.hashCode() : 0);
        result = 31 * result + (ontime != null ? ontime.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "Line{" +
                "lineid='" + lineid + '\'' +
                ", lineTypeid='" + lineTypeid + '\'' +
                ", lineName='" + lineName + '\'' +
                ", days='" + days + '\'' +
                ", vehicle='" + vehicle + '\'' +
                ", introduction='" + introduction + '\'' +
                ", reason='" + reason + '\'' +
                ", arrange='" + arrange + '\'' +
                ", price=" + price +
                ", teambuy=" + teambuy +
                ", teambuyprice=" + teambuyprice +
                ", begintime='" + begintime + '\'' +
                ", endtime='" + endtime + '\'' +
                ", ontime='" + ontime + '\'' +
                ", linetype=" + linetype +
                '}';
    }

}
