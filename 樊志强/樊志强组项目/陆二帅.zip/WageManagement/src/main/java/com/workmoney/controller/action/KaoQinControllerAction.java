package com.workmoney.controller.action;

import com.workmoney.model.entity.Attendance;
import com.workmoney.model.service.AttendanceService;
import com.workmoney.model.service.KaoQinService;
import org.apache.struts2.ServletActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import javax.servlet.http.HttpSession;
import java.util.List;

/**
 * user@Bright Rain .
 * 2019/6/29.
 */
@ParentPackage("struts-default")
@Namespace("/")
@Controller
public class KaoQinControllerAction {

    @Autowired
    private AttendanceService service;

    @Autowired
    private KaoQinService kaoQinService;

    private Attendance attendance;

    @Action(value = "/addAttendanceAction",results = {@Result(name = "success",type = "redirectAction",location = "getAllAttendanceAction")})
    public String addAttendanceAction(){
        kaoQinService.addAttendanceService(attendance);
        return "success";
    }

    /**
     * 修改
     * @return
     */
    @Action(value = "/editattendanceAction",results = {@Result(name = "success",type = "redirectAction",location = "getAllAttendanceAction")})
    public String editattendanceAction(){
        kaoQinService.updateAttendance(attendance);
        return "success";
    }

    /**
     * 去往修改页面
     * @return
     */
    @Action(value = "/goEditattendanceByIdAction",results = {@Result(name = "success",type = "redirect",location = "html/AttEdit.jsp")})
    public String goEditattendanceByIdAction(){
        HttpSession session = ServletActionContext.getRequest().getSession();
        Attendance attendance = kaoQinService.getAttendanceService(this.attendance);
        session.setAttribute("attendance",attendance);
        return "success";
    }

    /**
     * 删除单个考勤
     * @return
     */
    @Action(value = "/delattendanceByIdAction",results = {@Result(name = "success",type = "redirectAction",location = "getAllAttendanceAction")})
    public String delattendanceByIdAction(){
        kaoQinService.delAttendanceService(attendance);
        return "success";
    }

    /**
     * 获取所有考勤类别
     * @return
     */
    @Action(value = "/getAllAttendanceAction",results = {@Result(name = "success",type = "redirect",location = "html/AttList.jsp")})
    public String getAllAttendanceAction(){
        HttpSession session = ServletActionContext.getRequest().getSession();
        List<Attendance> attendanceType = service.getAttendanceType();
        session.setAttribute("attendanceType",attendanceType);

        return "success";
    }

    public Attendance getAttendance() {
        return attendance;
    }

    public void setAttendance(Attendance attendance) {
        this.attendance = attendance;
    }
}
