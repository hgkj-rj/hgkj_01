/*
 Navicat Premium Data Transfer

 Source Server         : xutao
 Source Server Type    : MySQL
 Source Server Version : 50724
 Source Host           : localhost:3306
 Source Schema         : tour

 Target Server Type    : MySQL
 Target Server Version : 50724
 File Encoding         : 65001

 Date: 07/07/2019 18:07:00
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for car
-- ----------------------------
DROP TABLE IF EXISTS `car`;
CREATE TABLE `car`  (
  `carID` int(11) NOT NULL AUTO_INCREMENT,
  `customerID` int(11) NOT NULL,
  `lineID` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `time` datetime(0) NOT NULL,
  PRIMARY KEY (`carID`) USING BTREE,
  INDEX `KF_a`(`customerID`) USING BTREE,
  INDEX `KF_b`(`lineID`) USING BTREE,
  CONSTRAINT `KF_a` FOREIGN KEY (`customerID`) REFERENCES `customer` (`customerID`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `KF_b` FOREIGN KEY (`lineID`) REFERENCES `line` (`lineID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 7 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of car
-- ----------------------------
INSERT INTO `car` VALUES (1, 1, '1', '2019-07-01 09:59:23');
INSERT INTO `car` VALUES (4, 2, '2', '2019-06-26 09:55:04');
INSERT INTO `car` VALUES (6, 2, '3', '2019-06-25 09:59:13');

-- ----------------------------
-- Table structure for customer
-- ----------------------------
DROP TABLE IF EXISTS `customer`;
CREATE TABLE `customer`  (
  `customerID` int(11) NOT NULL AUTO_INCREMENT,
  `account` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `password` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `gender` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `identityID` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `tel` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `type` int(255) NULL DEFAULT NULL,
  PRIMARY KEY (`customerID`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 7 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of customer
-- ----------------------------
INSERT INTO `customer` VALUES (1, '123456', '张三', '1111', '男', '1212312321423543', '2222222', 2);
INSERT INTO `customer` VALUES (2, '111111', '111', '2222', '男', '11111111111111', '11111111111', 1);
INSERT INTO `customer` VALUES (6, '333333', 'kebao', '333333', '女', '343434343434343434', '15812345678', 1);

-- ----------------------------
-- Table structure for images
-- ----------------------------
DROP TABLE IF EXISTS `images`;
CREATE TABLE `images`  (
  `imageId` int(11) NOT NULL AUTO_INCREMENT,
  `imageUrl` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`imageId`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for line
-- ----------------------------
DROP TABLE IF EXISTS `line`;
CREATE TABLE `line`  (
  `lineID` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `lineTypeID` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `lineName` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `days` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `vehicle` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `introduction` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `reason` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `arrange` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `price` decimal(10, 2) NULL DEFAULT NULL,
  `teamBuy` int(11) NULL DEFAULT NULL,
  `teamBuyPrice` decimal(10, 2) NULL DEFAULT NULL,
  `beginTime` datetime(0) NULL DEFAULT NULL,
  `endTime` datetime(0) NULL DEFAULT NULL,
  `onTime` datetime(0) NULL DEFAULT NULL,
  PRIMARY KEY (`lineID`) USING BTREE,
  INDEX `KF_n`(`lineTypeID`) USING BTREE,
  CONSTRAINT `KF_n` FOREIGN KEY (`lineTypeID`) REFERENCES `linetype` (`lineTypeID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of line
-- ----------------------------
INSERT INTO `line` VALUES ('1', '1', '线路111', '阳光3日游', '飞机', '空中飞行', '速度快', '没有', 1500.00, 2, 1000.00, '2019-06-03 14:50:28', '2019-06-06 14:50:33', '2019-06-01 14:50:48');
INSERT INTO `line` VALUES ('2', '2', '线路222', '森林3日游', '大巴', '陆地', '慢慢观赏', '没有', 800.00, 1, 600.00, '2019-06-03 14:51:56', '2019-06-06 14:52:01', '2019-06-02 14:52:05');
INSERT INTO `line` VALUES ('3', '3', '线路333', '天山5日游', '火车', '陆地', '没什么', '没', 900.00, 2, 700.00, '2019-06-24 09:57:33', '2019-06-28 09:57:47', '2019-07-01 09:58:02');

-- ----------------------------
-- Table structure for linetype
-- ----------------------------
DROP TABLE IF EXISTS `linetype`;
CREATE TABLE `linetype`  (
  `lineTypeID` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `typeName` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `time` datetime(0) NULL DEFAULT NULL,
  `icon` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`lineTypeID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of linetype
-- ----------------------------
INSERT INTO `linetype` VALUES ('1', '境内游', '2019-06-04 14:46:30', '1');
INSERT INTO `linetype` VALUES ('2', '境外游', '2019-05-31 14:47:37', '2');
INSERT INTO `linetype` VALUES ('3', '海岛游', '2019-06-25 09:55:59', '2');

-- ----------------------------
-- Table structure for orderdetail
-- ----------------------------
DROP TABLE IF EXISTS `orderdetail`;
CREATE TABLE `orderdetail`  (
  `odID` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `customerID` int(11) NOT NULL,
  `lineName` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `price` decimal(10, 2) NOT NULL,
  `orderDate` datetime(0) NOT NULL,
  `travelDate` datetime(0) NOT NULL,
  `total` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `lineID` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `state` int(11) NOT NULL,
  PRIMARY KEY (`odID`) USING BTREE,
  INDEX `KF_d`(`customerID`) USING BTREE,
  INDEX `KF_e`(`lineID`) USING BTREE,
  CONSTRAINT `KF_d` FOREIGN KEY (`customerID`) REFERENCES `customer` (`customerID`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `KF_e` FOREIGN KEY (`lineID`) REFERENCES `line` (`lineID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for ot_detail
-- ----------------------------
DROP TABLE IF EXISTS `ot_detail`;
CREATE TABLE `ot_detail`  (
  `otID` int(11) NOT NULL AUTO_INCREMENT,
  `odID` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `touristID` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`otID`) USING BTREE,
  INDEX `KF_f`(`odID`) USING BTREE,
  INDEX `KF_g`(`touristID`) USING BTREE,
  CONSTRAINT `KF_f` FOREIGN KEY (`odID`) REFERENCES `orderdetail` (`odID`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `KF_g` FOREIGN KEY (`touristID`) REFERENCES `tourist` (`touristID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for picture
-- ----------------------------
DROP TABLE IF EXISTS `picture`;
CREATE TABLE `picture`  (
  `pictureID` int(11) NOT NULL AUTO_INCREMENT,
  `introduction` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `lineID` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`pictureID`) USING BTREE,
  INDEX `KF_c`(`lineID`) USING BTREE,
  CONSTRAINT `KF_c` FOREIGN KEY (`lineID`) REFERENCES `line` (`lineID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for tourist
-- ----------------------------
DROP TABLE IF EXISTS `tourist`;
CREATE TABLE `tourist`  (
  `touristID` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `IDCard` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `tel` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `realName` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`touristID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of tourist
-- ----------------------------
INSERT INTO `tourist` VALUES ('1', '1234423', '21323', 'zxcv');
INSERT INTO `tourist` VALUES ('2', '222222222', '222222', 'fsddsf');

SET FOREIGN_KEY_CHECKS = 1;
