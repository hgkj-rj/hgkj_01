package com.tourism.model.service;

import com.tourism.model.entity.Orderdetail;

import java.util.List;

public interface OrderDetailService {
    public int gettotalpageService(int pagesize);
    public List<Orderdetail> allOrderDetailService(int pageindex, int pagesize);
}
