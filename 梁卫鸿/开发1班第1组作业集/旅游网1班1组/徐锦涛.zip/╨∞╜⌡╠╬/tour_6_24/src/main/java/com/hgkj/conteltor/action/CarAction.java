package com.hgkj.conteltor.action;

import com.hgkj.model.entity.Car;
import com.hgkj.model.entity.Line;
import com.hgkj.model.service.CarService;
import com.opensymphony.xwork2.ActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import java.util.List;

@Controller
@Namespace("/")
@ParentPackage("struts-default")
public class CarAction {
    @Autowired
    private CarService carService;
    private Car car;
    private String message;

    public CarService getCarService() {
        return carService;
    }

    public void setCarService(CarService carService) {
        this.carService = carService;
    }

    public Car getCar() {
        return car;
    }

    public void setCar(Car car) {
        this.car = car;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    @Action(value = "allCar", results = @Result(name = "all", type = "redirect", location = "/qt/cart.jsp"))
    public String allCar(){
        List<Car> carList = carService.allCarService();
        ActionContext.getContext().getSession().put("carList", carList);
        return "all";
    }
    @Action(value = "CarDelete", results = {@Result(name = "delete", type = "redirectAction",params = {"actionName","allCar"})})
    public String CarDelete(){
        boolean result = carService.cardeleteService(car.getCarID());
        if (result) {
            message = "ok";
            return "delete";
        } else {
            return "deleteError";
        }
    }

}
