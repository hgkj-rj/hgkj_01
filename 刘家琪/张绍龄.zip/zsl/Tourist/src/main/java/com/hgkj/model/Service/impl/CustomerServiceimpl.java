package com.hgkj.model.Service.impl;

import com.hgkj.model.Dao.CustomerDao;
import com.hgkj.model.Service.CustomerService;
import com.hgkj.model.entity.Customer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CustomerServiceimpl implements CustomerService {
    @Autowired
    private CustomerDao customerDao;

    public void setCustomerDao(CustomerDao customerDao) {
        this.customerDao = customerDao;
    }

    public CustomerDao getCustomerDao() {
        return customerDao;
    }

    @Override

    public Customer qCustomerService(Customer customer) {
        return customerDao.qCustomerDao(customer);
    }

    @Override
    public Boolean addCustomerService(Customer customer) {
        return customerDao.addCustomerDao(customer);
    }


}
