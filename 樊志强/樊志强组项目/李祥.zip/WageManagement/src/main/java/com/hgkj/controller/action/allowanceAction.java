package com.hgkj.controller.action;


import com.hgkj.model.entity.Reward;
import com.hgkj.model.service.allowanceService;
import com.opensymphony.xwork2.ActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import java.io.Reader;
import java.util.List;

@Controller
@Namespace("/")
@ParentPackage("struts-default")
public class allowanceAction {
    public int rewId;
    private Reward reward;

    @Autowired
    public allowanceService allowanceService;

    public void setAllowanceService(com.hgkj.model.service.allowanceService allowanceService) {
        this.allowanceService = allowanceService;
    }

    @Action(value = "allReward",results =
            {@Result(name = "all",type = "redirect",location = "html/RewardList.jsp")})
    public String allReward(){
        List<Reward>rewardList = allowanceService.allRewardService();
        ActionContext.getContext().getSession().put("rewardList",rewardList);
        return "all";
    }

    @Action(value = "addReward",results =
            {@Result(name = "all",type = "redirectAction",location = "allReward")})
    public String addReward(){
        allowanceService.addRewardService(reward);
        return "all";
    }

    @Action(value = "deleteReward",results =
            {@Result(name = "all",type = "redirectAction",location = "allReward")})
   public String deleteReward(){
        allowanceService.deleteRewardService(rewId);
        return "all";
    }

    @Action(value = "updateReward",results =
            {@Result(name = "all",type = "redirectAction",location = "allReward")})
    public String updateReward(){
        allowanceService.updateRewardService(reward);
        return "all";
    }

    @Action(value = "reward" ,results =
            {@Result(name = "all",type = "redirect",location ="html/RewardUpdate.jsp" )})
    public String reward(){
        Reward reward = allowanceService.reward(rewId);
        ActionContext.getContext().getSession().put("reward",reward);
        return "all";
    }


    public int getRewardId() {
        return rewId;
    }

    public void setRewardId(int rewardId) {
        this.rewId = rewardId;
    }

    public Reward getReward() {
        return reward;
    }

    public void setReward(Reward reward) {
        this.reward = reward;
    }
}
