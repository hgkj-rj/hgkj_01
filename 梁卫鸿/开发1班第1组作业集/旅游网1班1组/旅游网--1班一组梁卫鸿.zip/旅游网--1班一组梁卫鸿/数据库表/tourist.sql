/*
 Navicat Premium Data Transfer

 Source Server         : shopcar
 Source Server Type    : MySQL
 Source Server Version : 50720
 Source Host           : localhost:3306
 Source Schema         : travelnetwork

 Target Server Type    : MySQL
 Target Server Version : 50720
 File Encoding         : 65001

 Date: 07/07/2019 21:21:18
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for tourist
-- ----------------------------
DROP TABLE IF EXISTS `tourist`;
CREATE TABLE `tourist`  (
  `touristID` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `IDCard` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `tel` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `realName` decimal(10, 2) NULL DEFAULT NULL,
  PRIMARY KEY (`touristID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of tourist
-- ----------------------------
INSERT INTO `tourist` VALUES ('tur104', '111', '111', 111.00);
INSERT INTO `tourist` VALUES ('tur119', '2', '2', 2.00);
INSERT INTO `tourist` VALUES ('tur396', '111', '111', 111.00);
INSERT INTO `tourist` VALUES ('tur400', '111', '111', 111.00);
INSERT INTO `tourist` VALUES ('tur535', '111', '1', 111.00);
INSERT INTO `tourist` VALUES ('tur551', '111', '111', 111.00);
INSERT INTO `tourist` VALUES ('tur696', '111', '111', 111.00);
INSERT INTO `tourist` VALUES ('tur847', '111', '111', 111.00);
INSERT INTO `tourist` VALUES ('tur894', '111', '111', 111.00);

SET FOREIGN_KEY_CHECKS = 1;
