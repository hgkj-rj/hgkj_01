/*
 Navicat MySQL Data Transfer

 Source Server         : localhost
 Source Server Type    : MySQL
 Source Server Version : 50723
 Source Host           : localhost:3306
 Source Schema         : tourism

 Target Server Type    : MySQL
 Target Server Version : 50723
 File Encoding         : 65001

 Date: 08/07/2019 16:23:40
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for car
-- ----------------------------
DROP TABLE IF EXISTS `car`;
CREATE TABLE `car`  (
  `carid` int(255) NOT NULL,
  `customerid` int(11) NOT NULL,
  `lineid` varchar(36) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `time` datetime(0) NOT NULL,
  PRIMARY KEY (`carid`) USING BTREE,
  INDEX `FKn4ql1rgcsewmnumq36xnx7h1n`(`lineid`) USING BTREE,
  INDEX `FKivjg53k1iw733at16ckhffg7o`(`customerid`) USING BTREE,
  CONSTRAINT `FKivjg53k1iw733at16ckhffg7o` FOREIGN KEY (`customerid`) REFERENCES `customer` (`customerId`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `FKn4ql1rgcsewmnumq36xnx7h1n` FOREIGN KEY (`lineid`) REFERENCES `line` (`lineid`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `car_ibfk_1` FOREIGN KEY (`customerid`) REFERENCES `customer` (`customerId`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of car
-- ----------------------------
INSERT INTO `car` VALUES (1, 1, 'H7DSLF', '2019-07-05 08:37:39');
INSERT INTO `car` VALUES (2, 1, 'JUFG56', '2019-07-26 08:38:01');
INSERT INTO `car` VALUES (3, 2, 'H7DSLF', '2019-07-23 08:38:35');

-- ----------------------------
-- Table structure for customer
-- ----------------------------
DROP TABLE IF EXISTS `customer`;
CREATE TABLE `customer`  (
  `customerId` int(11) NOT NULL AUTO_INCREMENT,
  `accout` varchar(12) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `name` varchar(16) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `password` varchar(18) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `gender` char(12) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `identityid` varchar(18) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `tel` varchar(11) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `type` int(11) NULL DEFAULT 0,
  PRIMARY KEY (`customerId`) USING BTREE,
  UNIQUE INDEX `hgfgh`(`accout`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of customer
-- ----------------------------
INSERT INTO `customer` VALUES (1, '741852', '张三', '123', '男', '421182135498654562', '1254895410', 0);
INSERT INTO `customer` VALUES (2, '125489', '李四', '321', '女', '421182198745625133', '1332548492', 1);

-- ----------------------------
-- Table structure for line
-- ----------------------------
DROP TABLE IF EXISTS `line`;
CREATE TABLE `line`  (
  `lineid` varchar(13) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `lineTypeid` varchar(12) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `lineName` varchar(15) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `days` varchar(12) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `vehicle` char(2) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `introduction` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `reason` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `arrange` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `price` decimal(10, 2) NOT NULL,
  `teambuy` int(255) NULL DEFAULT 0,
  `teambuyprice` decimal(10, 2) NULL DEFAULT NULL,
  `begintime` datetime(0) NULL DEFAULT NULL,
  `endtime` datetime(0) NULL DEFAULT NULL,
  `ontime` datetime(0) NOT NULL,
  PRIMARY KEY (`lineid`) USING BTREE,
  INDEX `FKgp32mqe3plqiixjj5ofdalc2l`(`lineTypeid`) USING BTREE,
  CONSTRAINT `FKgp32mqe3plqiixjj5ofdalc2l` FOREIGN KEY (`lineTypeid`) REFERENCES `linetype` (`lineTypeid`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of line
-- ----------------------------
INSERT INTO `line` VALUES ('H7DSLF', 'DSDA', '泰国7日游', '7', '飞机', '毒瓦斯防守打法', '快，风土人情', '德哈卡实践活动卡实践活动', 5000.00, 0, 2500.00, '2019-06-11 17:22:33', '2019-06-25 17:22:38', '2019-06-25 17:22:50');
INSERT INTO `line` VALUES ('JUFG56', 'SDSA34', '安徽5日游', '5', '公交', '发送到发发插大', '方式分散图书馆', '大萨达所多变得更', 200.00, 1, 500.00, '2019-06-04 17:27:41', '2019-06-06 17:27:46', '2019-06-21 17:27:49');
INSERT INTO `line` VALUES ('M7WDBL', 'SDSA34', '安徽3日游', '3', '公交', '第三个', '方式发生的', '打完', 200.00, 0, NULL, '2019-07-02 09:58:57', '2019-07-02 09:58:57', '2019-07-02 09:58:57');

-- ----------------------------
-- Table structure for linetype
-- ----------------------------
DROP TABLE IF EXISTS `linetype`;
CREATE TABLE `linetype`  (
  `lineTypeid` varchar(36) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `typeName` varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `time` datetime(0) NOT NULL,
  `iocn` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`lineTypeid`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of linetype
-- ----------------------------
INSERT INTO `linetype` VALUES ('DSD2', '境外游', '2019-06-25 17:08:11', 'zx.jpg');
INSERT INTO `linetype` VALUES ('DSDA', '海岛游', '2019-06-14 17:52:58', 'tjjd.jpg');
INSERT INTO `linetype` VALUES ('SDSA34', '境内游', '2019-06-13 17:12:51', 'tjjd.jpg');
INSERT INTO `linetype` VALUES ('VO7T6D', '境外世界游', '2019-07-01 12:33:15', 'zx.jpg');

-- ----------------------------
-- Table structure for orderdetail
-- ----------------------------
DROP TABLE IF EXISTS `orderdetail`;
CREATE TABLE `orderdetail`  (
  `odid` varchar(36) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `customerid` int(11) NOT NULL,
  `lineName` varchar(15) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `price` decimal(10, 2) NOT NULL,
  `orderdate` datetime(0) NOT NULL,
  `traveldate` datetime(0) NOT NULL,
  `total` decimal(10, 2) NOT NULL,
  `lineid` varchar(36) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `state` int(255) NOT NULL DEFAULT 0,
  PRIMARY KEY (`odid`) USING BTREE,
  INDEX `lineid`(`lineid`) USING BTREE,
  INDEX `customerid`(`customerid`) USING BTREE,
  CONSTRAINT `orderdetail_ibfk_2` FOREIGN KEY (`lineid`) REFERENCES `line` (`lineid`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `orderdetail_ibfk_3` FOREIGN KEY (`customerid`) REFERENCES `customer` (`customerId`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for picture
-- ----------------------------
DROP TABLE IF EXISTS `picture`;
CREATE TABLE `picture`  (
  `picetureid` int(11) NOT NULL AUTO_INCREMENT,
  `introduction` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `name` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `lineid` varchar(36) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`picetureid`) USING BTREE,
  INDEX `FKrxyx3yerc74m79tvu6k5u3n3m`(`lineid`) USING BTREE,
  CONSTRAINT `FKrxyx3yerc74m79tvu6k5u3n3m` FOREIGN KEY (`lineid`) REFERENCES `line` (`lineid`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of picture
-- ----------------------------
INSERT INTO `picture` VALUES (1, 'DSA', 'gg.png', 'H7DSLF');
INSERT INTO `picture` VALUES (2, 'FSD', 'rmdht.png', 'H7DSLF');
INSERT INTO `picture` VALUES (3, 'TFS', 'tam.png', 'H7DSLF');
INSERT INTO `picture` VALUES (4, 'HJT', 'wfj.png', 'H7DSLF');

-- ----------------------------
-- Table structure for tourist
-- ----------------------------
DROP TABLE IF EXISTS `tourist`;
CREATE TABLE `tourist`  (
  `touristid` varchar(36) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `idcard` varchar(36) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `tel` varchar(15) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `realName` varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `odid` varchar(36) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`touristid`) USING BTREE,
  INDEX `odid`(`odid`) USING BTREE,
  CONSTRAINT `tourist_ibfk_1` FOREIGN KEY (`odid`) REFERENCES `orderdetail` (`odid`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

SET FOREIGN_KEY_CHECKS = 1;
