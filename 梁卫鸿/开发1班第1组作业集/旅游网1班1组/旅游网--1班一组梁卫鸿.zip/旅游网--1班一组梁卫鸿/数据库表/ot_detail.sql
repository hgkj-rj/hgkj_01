/*
 Navicat Premium Data Transfer

 Source Server         : shopcar
 Source Server Type    : MySQL
 Source Server Version : 50720
 Source Host           : localhost:3306
 Source Schema         : travelnetwork

 Target Server Type    : MySQL
 Target Server Version : 50720
 File Encoding         : 65001

 Date: 07/07/2019 21:21:04
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for ot_detail
-- ----------------------------
DROP TABLE IF EXISTS `ot_detail`;
CREATE TABLE `ot_detail`  (
  `otID` int(11) NOT NULL AUTO_INCREMENT,
  `odID` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `touristID` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`otID`) USING BTREE,
  INDEX `FK_OT_od_odID`(`odID`) USING BTREE,
  INDEX `FK_OT_tour_tourID`(`touristID`) USING BTREE,
  CONSTRAINT `FK_OT_od_odID` FOREIGN KEY (`odID`) REFERENCES `orderdetail` (`odID`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `FK_OT_tour_tourID` FOREIGN KEY (`touristID`) REFERENCES `tourist` (`touristID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 75 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of ot_detail
-- ----------------------------
INSERT INTO `ot_detail` VALUES (68, 'tur509', 'tur551');
INSERT INTO `ot_detail` VALUES (74, 'tur296', 'tur104');

SET FOREIGN_KEY_CHECKS = 1;
