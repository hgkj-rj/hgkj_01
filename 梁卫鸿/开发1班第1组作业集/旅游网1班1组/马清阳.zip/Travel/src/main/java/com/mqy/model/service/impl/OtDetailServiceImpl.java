package com.mqy.model.service.impl;

import com.mqy.model.service.OtDetailService;

/**
 * @Author:马清阳
 * @Date:2019/6/26 22:47
 * InteliJ IDEA 1.8
 */
public class OtDetailServiceImpl implements OtDetailService {
}
