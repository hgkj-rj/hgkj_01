package com.hgkj.contrloer.action;

import com.hgkj.model.entity.*;
import com.hgkj.model.service.AttendanceLogService;
import com.hgkj.model.service.AttendanceService;
import com.hgkj.model.service.StaffService;
import com.opensymphony.xwork2.ActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import java.util.List;

@Controller
@Namespace("/")
@ParentPackage("json-default")
public class AttendanceLogAction {
    @Autowired
    private AttendanceLogService attendanceLogService;
    private AttendanceLog attendanceLog;
    private int id;
    @Autowired
    private StaffService staffService;
    @Autowired
    private AttendanceService attendanceService;
    @Action(value = "allattendanceLog",results = {@Result(name = "all",type = "redirect",location = "html/attendanceList.jsp")})
    public String allattendanceLog(){
        List<AttendanceLog> attendanceLogList=attendanceLogService.allAttendanceLogService();
        ActionContext.getContext().getSession().put("attendanceLogList",attendanceLogList);
        return "all";
    }
    @Action(value = "allattendanceLogmanage",results = {@Result(name = "all",type = "redirect",location = "html/attendanceAdd.jsp")})
    public String allStaff(){
        List<Staff> staffList=staffService.allstaffService();
        List<Attendance> attendanceList=attendanceService.allattendanceService();
        ActionContext.getContext().getSession().put("staffList",staffList);
        ActionContext.getContext().getSession().put("attendanceList",attendanceList);
        return "all";
    }
    @Action(value = "insertattendanceLog",results = {@Result(name = "insert",type = "redirectAction",location = "allattendanceLog")})
    public String insert(){
        if(attendanceLogService.insertAttendanceLogService(attendanceLog)){
            return "insert";
        }else {
            return "noinsert";
        }


    }
    @Action(value = "updateattendanceLog",results = {@Result(name = "update",type = "redirectAction",location = "allattendanceLog"),@Result(name = "noupdate",type = "redirect",location = "../attendanceupdate.jsp")})
    public String update(){
        if (attendanceLogService.updateAttendanceLogService(attendanceLog)){
            return "update";
        }else {
            return "noupdate";
        }

    }
    @Action(value = "deleteattendanceLog",results = {@Result(name = "delete",type = "json",params = {"root","delete"})})
    public String delete(){
        attendanceLogService.deleteAttendanceLogService(id);
        return "delete";
    }
    @Action(value = "getattendanceLog",results = {@Result(name = "get",type = "redirect",location = "html/attendanceupdate.jsp")})
    public String getrewardmanage(){
        attendanceLog=attendanceLogService.getAttendanceLogByIdService(id);
        List<Staff> staffList=staffService.allstaffService();
        List<Attendance> attendanceList=attendanceService.allattendanceService();
        System.out.println(attendanceList.get(0).getAttId()+"++++++++++++++++++++++++++++++");
        ActionContext.getContext().getSession().put("staffList",staffList);
        ActionContext.getContext().getSession().put("attendanceList",attendanceList);
        ActionContext.getContext().getSession().put("attendanceLog",attendanceLog);
        return "get";
    }
    public AttendanceLogService getAttendanceLogService() {
        return attendanceLogService;
    }

    public void setAttendanceLogService(AttendanceLogService attendanceLogService) {
        this.attendanceLogService = attendanceLogService;
    }

    public AttendanceLog getAttendanceLog() {
        return attendanceLog;
    }

    public void setAttendanceLog(AttendanceLog attendanceLog) {
        this.attendanceLog = attendanceLog;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public StaffService getStaffService() {
        return staffService;
    }

    public void setStaffService(StaffService staffService) {
        this.staffService = staffService;
    }

    public AttendanceService getAttendanceService() {
        return attendanceService;
    }

    public void setAttendanceService(AttendanceService attendanceService) {
        this.attendanceService = attendanceService;
    }
}
