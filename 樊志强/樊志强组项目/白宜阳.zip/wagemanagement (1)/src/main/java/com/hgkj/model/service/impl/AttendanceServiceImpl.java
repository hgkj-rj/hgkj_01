package com.hgkj.model.service.impl;

import com.hgkj.model.dao.AttendanceDao;
import com.hgkj.model.entity.Attendance;
import com.hgkj.model.entity.AttendanceLog;
import com.hgkj.model.entity.Staff;
import com.hgkj.model.service.AttendanceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AttendanceServiceImpl implements AttendanceService {
    @Autowired
    private AttendanceDao attendanceDao;

    public void setAttendanceDao(AttendanceDao attendanceDao) {
        this.attendanceDao = attendanceDao;
    }

    @Override
    public List<AttendanceLog> allAttendanceLogService() {
        return attendanceDao.allAttendanceLogDao();
    }

    @Override
    public boolean addAttendanceLogService(AttendanceLog attendanceLog) {
        return attendanceDao.addAttendanceLogDao(attendanceLog);
    }

    @Override
    public boolean deleteAttendanceLogService(int attenlogId) {
        return attendanceDao.deleteAttendanceLogDao(attenlogId);
    }

    @Override
    public boolean updateAttendanceLogService(AttendanceLog attendanceLog) {
        return attendanceDao.updateAttendanceLogDao(attendanceLog);
    }

    @Override
    public AttendanceLog getByIdAttendanceService(int attenlogId) {
        return attendanceDao.getByIdAttendanceDao(attenlogId);
    }

    @Override
    public List<Staff> allStaffService() {
        return attendanceDao.allStaffDao();
    }

    @Override
    public List<Attendance> allAttendanceService() {
        return attendanceDao.allAttendanceDao();
    }

    @Override
    public List<AttendanceLog> AttendanceLogService(AttendanceLog attendanceLog) {
        return attendanceDao.AttendanceLogDao(attendanceLog);
    }

}
