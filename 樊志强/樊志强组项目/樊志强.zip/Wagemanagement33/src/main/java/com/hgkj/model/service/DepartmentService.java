package com.hgkj.model.service;


import com.hgkj.model.entity.Department;

import java.util.List;

public interface DepartmentService {
    //查询所有部门类别
    public List<Department> alldepartmentService();
    //添加部门类别
    public boolean insertdepartmentService(Department department);
    //删除部门类别
    public boolean deletedepartmentService(int id);
    //修改部门类别
    public boolean updatedepartmentService(Department department);
    //根据Id获取部门信息
    public Department getdepartmentByIdService(int id);
}
