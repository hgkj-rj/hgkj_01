package com.hgkj.controller.action;


import com.hgkj.model.dao.Leveldao;
import com.hgkj.model.entity.*;
import com.hgkj.model.service.*;
import com.opensymphony.xwork2.ActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import javax.print.attribute.standard.MediaSize;
import java.util.List;

@Controller
@Namespace("/")
@ParentPackage("struts-default")
public class StaffinformationAction {
    private int staffId;
    private Staff staff;
    private Level level;
    private Shop shop;
    private Role role;
    private Department department;


    @Autowired
    private StaffinformationService staffinformationService;
    private LevelService levelService;
    private ShopService shopService;
    private DepartmentService departmentService;
    private RoleService roleService;

    @Action(value = "find",results =
            {@Result(name = "success",type = "redirect",location = "html/empUpdate.jsp")})
    public String find(){
        Staff staff = staffinformationService.getByIdService(staffId);
        ActionContext.getContext().getSession().put("staff",staff);
        List<Level>levelList = levelService.levelService();
        ActionContext.getContext().getSession().put("levelList",levelList);
        List<Shop>shopList = shopService.allShopService();
        ActionContext.getContext().getSession().put("shopList",shopList);
        List<Department>departmentList =departmentService.allDepartmentService();
        ActionContext.getContext().getSession().put("departmentList",departmentList);
        List<Role>roleList = roleService.roleService();
        ActionContext.getContext().getSession().put("roleList",roleList);
        return "success";
    }
    @Action(value = "getfind",results =
            {@Result(name = "success",type = "redirect",location = "html/empAdd.jsp")})
    public String getfind(){
        Staff staff = staffinformationService.getByIdService(staffId);
        ActionContext.getContext().getSession().put("staff",staff);
        List<Level>levelList = levelService.levelService();
        ActionContext.getContext().getSession().put("levelList",levelList);
        List<Shop>shopList = shopService.allShopService();
        ActionContext.getContext().getSession().put("shopList",shopList);
        List<Department>departmentList = departmentService.allDepartmentService();
        ActionContext.getContext().getSession().put("departmentList",departmentList);
        List<Role>roleList = roleService.roleService();
        ActionContext.getContext().getSession().put("roleList",roleList);
        return "success";
    }

    @Action(value = "getByStaffId",results =
            {@Result(name = "success",type = "redirect",location = "html/resetpass.jsp")})
    public String getByStaffId(){
        //System.out.println(staffId);
        Staff staff = staffinformationService.getByIdService(staffId);
        ActionContext.getContext().getSession().put("staff",staff);
        return "success";
    }

    @Action(value = "allStaff", results =
            {@Result(name = "all",type = "redirect",location = "html/empList.jsp")})
    public String allStaff(){
        List<Staff>staffList=staffinformationService.allStaffService();
        ActionContext.getContext().getSession().put("staffList",staffList);
        return "all";
    }

    @Action(value = "addStaff",results =
            {@Result(name = "add" ,type = "redirectAction",location = "allStaff")})
    public String addStaff(){
        staffinformationService.addStaffService(staff);
        return "add";
    }

    @Action(value = "deleteStaff",results =
            {@Result(name = "delete" ,type = "redirectAction" ,location = "allStaff")})
    public String deleteStaff(){
        staffinformationService.deleteStaffService(staffId);
        return "delete";
    }

    @Action(value = "updateStaff",results =
            {@Result(name = "update" ,type = "redirectAction",location = "allStaff")})
    public String updateStaff(){
        staffinformationService.updateStaffService(staff);
        return "update";
    }




    public void setStaffinformationService(StaffinformationService staffinformationService) {
        this.staffinformationService = staffinformationService;
    }

    public int getStaffId() {
        return staffId;
    }

    public void setStaffId(int staffId) {
        this.staffId = staffId;
    }

    public Staff getStaff() {
        return staff;
    }

    public void setStaff(Staff staff) {
        this.staff = staff;
    }

    public Level getLevel() {
        return level;
    }

    public void setLevel(Level level) {
        this.level = level;
    }

    public Shop getShop() {
        return shop;
    }

    public void setShop(Shop shop) {
        this.shop = shop;
    }

    public Role getRole() {
        return role;
    }

    public void setRole(Role role) {
        this.role = role;
    }

    public Department getDepartment() {
        return department;
    }

    public void setDepartment(Department department) {
        this.department = department;
    }

    public StaffinformationService getStaffinformationService() {
        return staffinformationService;
    }
}
