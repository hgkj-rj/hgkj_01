package com.hgkj.model.dao.impl;

import com.hgkj.model.dao.SalaryLogDao;
import com.hgkj.model.dao.SubsidyLogDao;
import com.hgkj.model.entity.Attendance;
import com.hgkj.model.entity.AttendanceLog;
import com.hgkj.model.entity.SalaryLog;
import com.hgkj.model.entity.SubsidyLog;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
@Repository
@Transactional
public class SubsidyLogDaoImpl implements SubsidyLogDao {
    @Autowired
    private SessionFactory sessionFactory;
    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }
    public Session session(){
        return sessionFactory.getCurrentSession();
    }

    @Override
    public List<SubsidyLog> allsubsidyLogDao() {
        String hql="from SubsidyLog ";
        List<SubsidyLog> list=session().createQuery(hql).list();
        return list;
    }

    @Override
    public boolean insertsubsidyLogDao(SubsidyLog subsidyLog) {
        boolean b=false;
        session().save(subsidyLog);
        b=true;
        return b;
    }

    @Override
    public boolean deletesubsidyLogDao(int id) {
        boolean a=false;
        String hql="delete SubsidyLog where stblogId=?";
        int b=session().createQuery(hql).setParameter(0,id).executeUpdate();
        if (b!=0){
            a=true;
        }
        return a;
    }

    @Override
    public boolean updatesubsidyLogDao(SubsidyLog subsidyLog) {
        boolean a=false;
        String hql="update SubsidyLog set staff.staffId=?,subsidy.subsidyId=?,sublogTime=?where stblogId=?";
        int b=session().createQuery(hql).setParameter(0,subsidyLog.getStaff().getStaffId()).setParameter(1,subsidyLog.getSubsidy().getSubsidyId()).setParameter(2,subsidyLog.getSublogTime()).setParameter(3,subsidyLog.getStblogId()).executeUpdate();
        if (b!=0){
            a=true;
        }
        return a;    }

    @Override
    public SubsidyLog getsubsidyLogByIdDao(int id) {
        String hql="from SubsidyLog where stblogId=?";
        SubsidyLog subsidyLog=(SubsidyLog) session().createQuery(hql).setParameter(0,id).uniqueResult();
        return subsidyLog;
    }
}
