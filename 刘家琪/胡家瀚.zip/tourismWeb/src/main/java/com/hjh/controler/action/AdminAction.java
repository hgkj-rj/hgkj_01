package com.hjh.controler.action;

import com.hjh.model.entity.Customer;
import com.hjh.model.service.AdminService;
import com.opensymphony.xwork2.ActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;


@Controller
@Namespace("/")
@ParentPackage("struts-default")
public class AdminAction {

    @Autowired
    private AdminService adminService;
    private Customer customer;

    public void setAdminService(AdminService adminService) {
        this.adminService = adminService;
    }

    public AdminService getAdminService() {
        return adminService;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    @Action(value = "adminLoginH",results = {@Result(name = "hlogin",type = "redirect",location = "/ht/index.jsp"),
            @Result(name = "noadmin",type = "redirect",location = "/ht/adminLogin.jsp"),
            @Result(name = "error",type = "redirect",location = "/ht/adminLogin.jsp")})
    public String adminLoginH(){
        Customer customer1 = adminService.AdminLoginService(customer);
        ActionContext.getContext().getSession().put("customer",customer1);
       if (customer1!=null){
           if (customer1.getType()!=0){
               return "hlogin";
           }else {
               return "noadmin";
           }
       }
       return "error";
    }

    @Action(value = "adminLoginQ",results = {@Result(name = "qlogin",type = "redirect",location = "/qt/index.jsp"),
            @Result(name = "error",type = "redirect",location = "/qt/login.jsp")})
    public String adminLoginQ(){
        Customer customer1 = adminService.AdminLoginService(customer);
        ActionContext.getContext().getSession().put("customer",customer1);
        if (customer1!=null){
            return "qlogin";
        }
        return "error";
    }

    @Action(value = "backSpace",results = {@Result(name = "back",type = "redirect",location = "/qt/index.jsp")})
    public String backSpace(){
        customer = null;
        ActionContext.getContext().getSession().put("customer",customer);
        return "back";
    }

    @Action(value = "addAdmin",results = {@Result(name = "add",type = "redirect",location = "/qt/login.jsp"),
            @Result(name = "error",type = "redirect",location = "/qt/regist.jsp")})
    public String addAdmin(){
        if (adminService.AddadminService(customer)){
            return "add";
        }
        return "error";
    }

    @Action(value = "backSpace1",results = {@Result(name = "back1",type = "redirect",location = "/ht/adminLogin.jsp")})
    public String backSpace1(){
        customer = null;
        ActionContext.getContext().getSession().put("customer",customer);
        return "back1";
    }
}
