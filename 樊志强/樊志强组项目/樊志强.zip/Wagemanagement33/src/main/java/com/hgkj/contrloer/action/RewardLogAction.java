package com.hgkj.contrloer.action;

import com.hgkj.model.entity.Reward;
import com.hgkj.model.entity.RewardLog;
import com.hgkj.model.entity.Staff;
import com.hgkj.model.entity.SubsidyLog;
import com.hgkj.model.service.RewardLogService;
import com.hgkj.model.service.RewardService;
import com.hgkj.model.service.StaffService;
import com.opensymphony.xwork2.ActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import java.util.List;


@Controller
@Namespace("/")
@ParentPackage("json-default")
public class RewardLogAction {
   private RewardLog rewardLog;
   private int id;
   @Autowired
   private RewardLogService rewardService;
   @Autowired
   private RewardService rewardService1;
   @Autowired
   private StaffService staffService;

    @Action(value = "allrewardLog",results = {@Result(name = "all",type = "redirect",location = "html/rewardLogList.jsp")})
    public String allreward(){
        List<RewardLog> rewardLogList=rewardService.allrewardLogService();
        ActionContext.getContext().getSession().put("rewardLogList",rewardLogList);
        return "all";
    }
    @Action(value = "allrewardmanage",results = {@Result(name = "all",type = "redirect",location = "html/rewardLogAdd.jsp")})
    public String allStaff(){
        List<Reward> rewardList=rewardService1.allrewardService();
        List<Staff> staffList=staffService.allstaffService();
        ActionContext.getContext().getSession().put("rewardList",rewardList);
        ActionContext.getContext().getSession().put("staffList",staffList);
        return "all";
    }
    @Action(value = "insertrewardLog",results = {@Result(name = "insert",type = "redirectAction",location = "allrewardLog")})
    public String insert(){
        System.out.println(rewardLog);
        if(rewardService.insertrewardLogService(rewardLog)){
            return "insert";
        }else {
            return "noinsert";
        }


    }
    @Action(value = "updaterewardLog",results = {@Result(name = "update",type = "redirectAction",location = "allrewardLog"),@Result(name = "noupdate",type = "redirect",location = "../attendenceList.jsp")})
    public String update(){
        if (rewardService.updaterewardLogService(rewardLog)){
            return "update";
        }else {
            return "noupdate";
        }

    }
    @Action(value = "deleterewardLog",results = {@Result(name = "delete",type = "json",params = {"root","delete"})})
    public String delete(){
        rewardService.deleterewardLogService(id);
        return "delete";
    }
    @Action(value = "getrewardLog",results = {@Result(name = "get",type = "redirect",location = "html/rewardLogUpdate.jsp")})
    public String getrewardmanage(){
        rewardLog=rewardService.getrewardLogByIdService(id);
        List<Staff> staffList=staffService.allstaffService();
        List<Reward> rewardList=rewardService1.allrewardService();
        ActionContext.getContext().getSession().put("staffList",staffList);
        ActionContext.getContext().getSession().put("rewardList",rewardList);
        ActionContext.getContext().getSession().put("rewardLog",rewardLog);
        return "get";
    }


    public RewardLog getRewardLog() {
        return rewardLog;
    }

    public void setRewardLog(RewardLog rewardLog) {
        this.rewardLog = rewardLog;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public RewardLogService getRewardService() {
        return rewardService;
    }

    public void setRewardService(RewardLogService rewardService) {
        this.rewardService = rewardService;
    }

    public RewardService getRewardService1() {
        return rewardService1;
    }

    public void setRewardService1(RewardService rewardService1) {
        this.rewardService1 = rewardService1;
    }

    public StaffService getStaffService() {
        return staffService;
    }

    public void setStaffService(StaffService staffService) {
        this.staffService = staffService;
    }
}
