package com.hgkj.model.service.impl;

import com.hgkj.model.dao.Subsidydao;
import com.hgkj.model.entity.Subsidy;
import com.hgkj.model.service.SubsidyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public class SubsidyServiceimpl implements SubsidyService {
    @Autowired
    private Subsidydao subsidydao;

    public void setSubsidydao(Subsidydao subsidydao) {
        this.subsidydao = subsidydao;
    }

    @Override
    public List<Subsidy> allSubsidyService() {
        return subsidydao.allSubsidydao();
    }

    @Override
    public boolean updateSubsidyService(Subsidy subsidy) {
        return subsidydao.updateSubsidydao(subsidy);
    }

    @Override
    public boolean deleteSubsidyService(int subsidyId) {
        return subsidydao.deleteSubsidydao(subsidyId);
    }

    @Override
    public boolean addSubsidyService(Subsidy subsidy) {
        return subsidydao.addSubsidydao(subsidy);
    }

    @Override
    public Subsidy subsiService(int subsidyId) {
        return subsidydao.subsidy(subsidyId);
    }
}
