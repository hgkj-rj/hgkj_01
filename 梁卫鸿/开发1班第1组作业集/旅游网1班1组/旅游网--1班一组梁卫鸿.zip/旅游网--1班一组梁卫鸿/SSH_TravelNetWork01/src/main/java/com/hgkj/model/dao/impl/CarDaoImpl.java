package com.hgkj.model.dao.impl;

import com.hgkj.model.dao.CarDao;
import com.hgkj.model.entity.*;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
@Transactional
public class CarDaoImpl implements CarDao {
    @Autowired
    private SessionFactory sessionFactory;
    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }
    public Session getSession(){
        return sessionFactory.getCurrentSession();
    }

    @Override
    public boolean CarAddDao(int customerId,String lineId,String time) {
        boolean result=false;
        Car car=new Car(customerId,lineId,time);
        try {
            getSession().save(car);
            result=true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

    @Override
    public List<Car> carAllDao() {
        String hql="from Car ";
        Query query=getSession().createQuery(hql);
        return query.list();
    }

    @Override
    public List<Line> lineAllDao() {
        String hql="from Line ";
        Query query=getSession().createQuery(hql);
        return query.list();
    }

    @Override
    public List<Picture> pictureAllDao() {
        String hql="from Picture ";
        Query query=getSession().createQuery(hql);
        return query.list();
    }

    @Override
    public List<Customer> customerAllDao() {
        String hql="from Customer ";
        Query query=getSession().createQuery(hql);
        return query.list();
    }

    @Override
    public boolean carDeleteDao(int carId) {
        boolean resoult=false;
        Car car=getSession().get(Car.class,carId);
        try {
            getSession().delete(car);
            resoult=true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return resoult;
    }

    @Override
    public Orderdetail orderIdDao(String orderId) {
        Orderdetail orderdetail=getSession().get(Orderdetail.class,orderId);
        return orderdetail;
    }

    @Override
    public boolean orderDeleteDao(String orderId) {
        boolean resoult=false;
        Orderdetail orderdetail=getSession().get(Orderdetail.class,orderId);
        try {
            getSession().delete(orderdetail);
            resoult=true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return resoult;
    }

    @Override
    public boolean otDeleteDao(int otId) {
        boolean resoult=false;
        OtDetail otDetail=getSession().get(OtDetail.class,otId);
        try {
            getSession().delete(otDetail);
            resoult=true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return resoult;
    }

    @Override
    public boolean ot1DeleteDao(String odId) {
        boolean resoult=false;
        /* String hql="delete from OtDetail where odId='"+odId+"'";*/
        OtDetail otDetail=getSession().get(OtDetail.class,odId);
        try {
            getSession().delete(otDetail);
            resoult=true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return resoult;

    }
}
