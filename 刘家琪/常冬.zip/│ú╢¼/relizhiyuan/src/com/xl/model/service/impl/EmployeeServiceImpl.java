package com.xl.model.service.impl;

import com.xl.model.dao.EmployeeDao;
import com.xl.model.dao.impl.EmployeeDaoImpl;
import com.xl.model.entity.Employee;
import com.xl.model.service.EmployeeService;

import java.util.List;

public class EmployeeServiceImpl implements EmployeeService {
    private EmployeeDao EmployeeDao=new EmployeeDaoImpl();
    @Override
    public int EmployeeService(int pageSize) {
        return EmployeeDao.EmployeeDao(pageSize) ;
    }

    @Override
    public List<Employee> allEmployeeService(int pageIndex, int pageSize) {
        return EmployeeDao.allEmployeeDao(pageIndex,pageSize);
    }

    @Override
    public boolean addEmployeeService(Employee employee) {

        return EmployeeDao.addEmployeeDao(employee);
    }

    @Override
    public boolean deleteEmployeeService(int employeeId) {

        return EmployeeDao.deleteEmployeeDao(employeeId);
    }

    @Override
    public boolean updateEmployeeService(Employee employee) {

        return EmployeeDao.updateEmployeeDao(employee);
    }
}
