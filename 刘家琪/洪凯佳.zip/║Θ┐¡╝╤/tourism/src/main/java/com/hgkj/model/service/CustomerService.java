package com.hgkj.model.service;

import com.hgkj.model.entity.Customer;

public interface CustomerService {
    public Customer CustomerLoginService(Customer customer);
    public boolean addCustomerService(Customer customer);
}
