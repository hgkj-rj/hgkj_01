package com.hgkj.model.dao.impl;

import com.hgkj.model.dao.RewardDao;
import com.hgkj.model.entity.Reward;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
@Transactional
public class RewardDaoImpL implements RewardDao {
    @Autowired
    private SessionFactory sessionFactory;
    private Transaction transaction;

    public Transaction getTransaction() {
        return transaction;
    }

    public void setTransaction(Transaction transaction) {
        this.transaction = transaction;
    }

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    public Session getSession(){
        return sessionFactory.getCurrentSession();
    }

    @Override
    public List<Reward> allRewardDao() {
        Query query=getSession().createQuery("from Reward");
        return query.list();
    }

    @Override
    public boolean addRewardDao(Reward reward) {
        boolean flag=false;
        try {
            getSession().save(reward);
            flag=true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return flag;
    }

    @Override
    public boolean updateRewardDao(Reward reward) {
        boolean flag=false;
        try {
            getSession().update(reward);
            flag=true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return flag;
    }

    @Override
    public boolean deleteRewardDao(int rewId) {
        boolean flag=false;
        Reward reward=new Reward();
        reward.setRewId(rewId);
        try {
            getSession().delete(reward);
            flag=true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return flag;
    }

    @Override
    public Reward getByIdRewardDao(int reWId) {
        Reward reward=getSession().get(Reward.class,reWId);
        return reward;
    }
}
