package com.hgkj.contrloer.action;

import com.hgkj.model.entity.Attendance;
import com.hgkj.model.entity.Staff;
import com.hgkj.model.entity.Subsidy;
import com.hgkj.model.entity.SubsidyLog;
import com.hgkj.model.service.StaffService;
import com.hgkj.model.service.SubsidyLogService;
import com.hgkj.model.service.SubsidyService;
import com.opensymphony.xwork2.ActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import java.util.List;

@Controller
@Namespace("/")
@ParentPackage("json-default")
public class SubsidyLogAction {
    @Autowired
    private SubsidyLogService subsidyLogService;
    private SubsidyLog subsidyLog;
    private int id;
    @Autowired
    private StaffService staffService;
    @Autowired
    private SubsidyService subsidyService;

    public SubsidyService getSubsidyService() {
        return subsidyService;
    }

    public void setSubsidyService(SubsidyService subsidyService) {
        this.subsidyService = subsidyService;
    }

    public StaffService getStaffService() {
        return staffService;
    }

    public void setStaffService(StaffService staffService) {
        this.staffService = staffService;
    }

    public SubsidyLogService getSubsidyLogService() {
        return subsidyLogService;
    }

    public void setSubsidyLogService(SubsidyLogService subsidyLogService) {
        this.subsidyLogService = subsidyLogService;
    }

    public SubsidyLog getSubsidyLog() {
        return subsidyLog;
    }

    public void setSubsidyLog(SubsidyLog subsidyLog) {
        this.subsidyLog = subsidyLog;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
    @Action(value = "allsubsidyLog",results = {@Result(name = "all",type = "redirect",location = "html/allowanceAdd.jsp")})
    public String allreward(){
        List<SubsidyLog> subsidyLogList=subsidyLogService.allsubsidyLogService();
        ActionContext.getContext().getSession().put("subsidyLogList",subsidyLogList);
        return "all";
    }
    @Action(value = "allstaffmanage",results = {@Result(name = "all",type = "redirect",location = "html/allowanceEmpList.jsp")})
    public String allStaff(){
        List<Staff> staffList=staffService.allstaffService();
        ActionContext.getContext().getSession().put("staffList",staffList);
        return "all";
    }
    @Action(value = "insertsubsidyLog",results = {@Result(name = "insert",type = "redirectAction",location = "allsubsidyLog")})
    public String insert(){
        System.out.println(subsidyLog);
        if(subsidyLogService.insertsubsidyLogService(subsidyLog)){
            return "insert";
        }else {
            return "noinsert";
        }

    }
    @Action(value = "updatesubsidyLog",results = {@Result(name = "update",type = "redirectAction",location = "allsubsidyLog"),@Result(name = "noupdate",type = "redirect",location = "../attendenceList.jsp")})
    public String update(){
        if (subsidyLogService.updatesubsidyLogService(subsidyLog)){
            return "update";
        }else {
            return "noupdate";
        }

    }
    @Action(value = "deletesubsidyLog",results = {@Result(name = "delete",type = "json",params = {"root","delete"})})
    public String delete(){
        subsidyLogService.deletesubsidyLogService(id);
        return "delete";
    }
    @Action(value = "getsubsidyLog",results = {@Result(name = "get",type = "redirect",location = "html/allowanceUpdate.jsp")})
    public String getrewardmanage(){
        subsidyLog=subsidyLogService.getsubsidyLogByIdService(id);
        List<Staff> staffList=staffService.allstaffService();
        List<Subsidy> subsidyList=subsidyService.allsubsidyService();
        ActionContext.getContext().getSession().put("staffList",staffList);
        ActionContext.getContext().getSession().put("subsidyList",subsidyList);
        ActionContext.getContext().getSession().put("subsidyLog",subsidyLog);
        return "get";
    }
}
