package com.hgkj.model.entity;

public class OtDetail {
    private int otId;
    private String odId;
    private String touristId;

    public int getOtId() {
        return otId;
    }

    public void setOtId(int otId) {
        this.otId = otId;
    }

    public String getOdId() {
        return odId;
    }

    public void setOdId(String odId) {
        this.odId = odId;
    }

    public String getTouristId() {
        return touristId;
    }

    public void setTouristId(String touristId) {
        this.touristId = touristId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        OtDetail otDetail = (OtDetail) o;

        if (otId != otDetail.otId) return false;
        if (odId != null ? !odId.equals(otDetail.odId) : otDetail.odId != null) return false;
        if (touristId != null ? !touristId.equals(otDetail.touristId) : otDetail.touristId != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = otId;
        result = 31 * result + (odId != null ? odId.hashCode() : 0);
        result = 31 * result + (touristId != null ? touristId.hashCode() : 0);
        return result;
    }
}
