package com.hgkj.model.service;

import com.hgkj.model.entity.Department;

import java.util.List;

public interface DepartmentService {

   public List<Department> allDepartmentService();

   public boolean addDepartmentService(Department department);

   public boolean deleteDepartmentService(int depId);

   public boolean updateDepartmentService(Department department);

   public Department department(int depId);
}