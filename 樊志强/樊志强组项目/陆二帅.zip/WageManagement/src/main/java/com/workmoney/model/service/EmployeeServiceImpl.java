package com.workmoney.model.service;

import com.workmoney.model.dao.EmployeeDao;
import com.workmoney.model.entity.StaffFuBen;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * user@Bright Rain .
 * 2019/6/26.
 */
@Service
public class EmployeeServiceImpl implements EmployeeService {

    @Autowired
    private EmployeeDao dao;

    @Override
    public void addEmployee(StaffFuBen staffFuBen) {
        dao.addEmployeeDao(staffFuBen);
    }

    @Override
    public void delEmpService(StaffFuBen staffFuBen) {
        dao.delEmpDao(staffFuBen);
    }

    @Override
    public StaffFuBen getEmpByIdService(StaffFuBen staffFuBen) {

        return  dao.getEmpByIdDao(staffFuBen);
    }

    @Override
    public void updateEmployeeById(StaffFuBen staffFuBen) {
        dao.updateEmployeeByIdDao(staffFuBen);
    }

    @Override
    public List<StaffFuBen> getAllStaffFuBenService() {

        return dao.getAllStaffFuBenDao();
    }

    @Override
    public void updateRoleByIdService(StaffFuBen staff) {
        dao.updateRoleByIdDao(staff);
    }
}
