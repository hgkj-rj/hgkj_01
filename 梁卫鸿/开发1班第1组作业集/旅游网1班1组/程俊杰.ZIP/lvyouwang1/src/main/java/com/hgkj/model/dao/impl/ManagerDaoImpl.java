package com.hgkj.model.dao.impl;

import com.hgkj.model.dao.ManagerDao;
import com.hgkj.model.entity.Customer;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
@Repository
@Transactional
public class ManagerDaoImpl implements ManagerDao {
    @Autowired
    private SessionFactory sessionFactory;

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    public Session getSession() {
        return sessionFactory.getCurrentSession();
    }

    @Override
    public boolean managerloginDao(Customer customer) {
        boolean result=false;
        String hql = "from Customer where account=? and password=?";
        List<Customer> customerList = getSession().createQuery(hql).
                setParameter(0, customer.getAccount()).setParameter(1, customer.getPassword()).list();

       // System.out.println(customer.getAccount() + "-----" + customer.getPassword());
        for (Customer customer1 : customerList) {
            customer.setCustomerId(customer1.getCustomerId());
            return true;
        }
        return result;
    }
}
