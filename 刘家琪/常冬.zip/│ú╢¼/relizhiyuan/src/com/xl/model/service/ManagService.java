package com.xl.model.service;

import com.xl.model.entity.Manag;

import java.util.List;

public interface ManagService {
    public boolean managLoginService(Manag manag);
    public List<Manag> allManagService();
}
