package com.hgkj.model.dao;

import com.hgkj.model.entity.Orderdetail;

import java.util.List;

public interface OrderdetailDao {
    public List<Orderdetail> allOrderdetailDao();
    public boolean addOrderdetailDao(Orderdetail orderdetail);
    public boolean deleteOrderdetailDao(Orderdetail orderdetail);
    public boolean updateOrderdetailDao(Orderdetail orderdetail);
    public Orderdetail getOrderdetailByIdDao(String odId);
}
