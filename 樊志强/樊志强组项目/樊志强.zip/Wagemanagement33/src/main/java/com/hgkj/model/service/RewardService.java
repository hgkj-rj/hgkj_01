package com.hgkj.model.service;

import com.hgkj.model.entity.Reward;

import java.util.List;

public interface RewardService {
    //查询所有奖金类别
    public List<Reward> allrewardService();
    //添加奖金类别
    public boolean insertrewardService(Reward reward);
    //删除奖金类别
    public boolean deleterewardService(int id);
    //修改奖金类别
    public boolean updaterewardService(Reward reward);
    //根据Id获取奖金信息
    public Reward getrewardByIdService(int id);
}
