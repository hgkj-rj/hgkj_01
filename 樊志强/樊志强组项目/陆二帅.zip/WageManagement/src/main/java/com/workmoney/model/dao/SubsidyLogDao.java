package com.workmoney.model.dao;

import com.workmoney.model.entity.Subsidy;
import com.workmoney.model.entity.SubsidyLog;

import java.util.List;

/**
 * user@Bright Rain .
 * 2019/6/27.
 */
public interface SubsidyLogDao {

    /**
     * 查询所有的补助
     * @return
     */
    List<SubsidyLog> getAllSubsidyLogDao();
    /**
     * 查询所有的补助类别
     * @return
     */
    List<Subsidy> getAllSubsidyDao();
    /**
     * 添加补助
     * @return
     */
    void addEmpAllowanceDao(SubsidyLog subsidyLog);
    /**
     * 删除补助
     * @return
     */
    void delAllowanceByIdDao(SubsidyLog subsidyLog);

    List<SubsidyLog> serchNameAllowAction(String name);

    void delSubsidyByIdDao(Subsidy subsidy);

    Subsidy getSubsidyByIdService(Subsidy subsidy);

    void editSubsidyDao(Subsidy subsidy);

    void addSubSidyDao(Subsidy subsidy);
}
