package com.hgkj.contrloer.action;

import com.hgkj.model.entity.RewardLog;
import com.hgkj.model.service.RewardLogService;
import com.opensymphony.xwork2.ActionContext;
import org.apache.struts2.ServletActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import java.util.List;

@Controller
@Namespace("/")
@ParentPackage("struts-default")
public class RewardLogAction {
    @Autowired
    private RewardLogService rewardLogService;
    private RewardLog rewardLog;

    public RewardLog getRewardLog() {
        return rewardLog;
    }

    public void setRewardLog(RewardLog rewardLog) {
        this.rewardLog = rewardLog;
    }

    public void setRewardLogService(RewardLogService rewardLogService) {
        this.rewardLogService = rewardLogService;
    }

    @Action(value = "allRewardLog",results = @Result(name = "all",type = "redirect",location = "/html/rewardLogList.jsp"))
    public String allRewardLog(){
        List<RewardLog> rewardLogList=rewardLogService.allRewardLogService();
        ServletActionContext.getRequest().getSession().setAttribute("rewardLogList",rewardLogList);
        return "all";
    }

    @Action(value = "alllRewardLog",results = @Result(name = "alllRewardLog",type = "redirect",location = "/html/rewardLogList.jsp"))
    public String alllRewardLog(){
        List<RewardLog> rewardLogList=rewardLogService.alllRewardLogService(rewardLog);
        ActionContext.getContext().getSession().put("rewardLogList",rewardLogList);
        return "alllRewardLog";
    }

    @Action(value = "addRewardLog",results = @Result(name = "adds",type = "redirectAction",params = {"actionName","allRewardLog"}))
    public String addRewardLog(){
        boolean r=rewardLogService.addRewardLogService(rewardLog);
        if (r==true){
            return "adds";
        }else {
            return "adde";
        }
    }

    @Action(value = "delRewardLog",results = @Result(name = "dels",type = "redirectAction",params = {"actionName","allRewardLog"}))
    public String deleteRewardLog(){
        boolean r=rewardLogService.deleteRewardLogService(rewardLog.getRewlogId());
        if (r==true){
            return "dels";
        }else {
            return "dele";
        }
    }

    @Action(value = "updRewardLog",results = @Result(name = "upds",type = "redirectAction",params = {"actionName","allRewardLog"}))
    public String UpdRewardLog(){
        boolean r=rewardLogService.updateRewardLogService(rewardLog);
        if (r==true){
            return "upds";
        }else {
            return "upde";
        }
    }

    @Action(value = "getByIdRewardLogs",results = {@Result(name = "getByIds",type = "redirect",location = "/html/")})
    public String getByIdRewardLog(){
        RewardLog rewardLog1=rewardLogService.getByIdRewardLogService(rewardLog.getRewlogId());
        ServletActionContext.getRequest().getSession().setAttribute("rewardLog1",rewardLog1);
        return "getByIds";
    }
}
