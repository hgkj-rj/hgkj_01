package com.workmoney.model.dao.impl;

import com.workmoney.model.dao.EmployeeDao;
import com.workmoney.model.entity.Staff;
import com.workmoney.model.entity.StaffFuBen;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * user@Bright Rain .
 * 2019/6/26.
 */
@Repository
@Transactional
public class EmployeeDaoImpl implements EmployeeDao {

    @Autowired
    private SessionFactory sessionFactory;

    @Override
    public void addEmployeeDao(StaffFuBen staffFuBen) {
        Session session = sessionFactory.getCurrentSession();
        Staff staff = new Staff();
        staff.setStaffName(staffFuBen.getStaffName());
        staff.setStaffPwd(staffFuBen.getStaffPwd());
        staff.setStaffPwd(staffFuBen.getStaffSex());
        staff.setStaffPwd(staffFuBen.getStaffAddress());
         staff.setStaffTel(staffFuBen.getStaffTel());
         staff.setStaffEmail(staffFuBen.getStaffEmail());
         staff.setStaffState(staffFuBen.getStaffState());
         staff.setLevelId(staffFuBen.getLevel().getLevelId());
        staff.setRolesId(staffFuBen.getRole().getRoleId());
        staff.setDepId(staffFuBen.getDepartment().getDepId());
         staff.setShopId(staffFuBen.getShop().getShopId());

        session.save(staffFuBen);
    }

    @Override
    public void delEmpDao(StaffFuBen staffFuBen) {
        Session session = sessionFactory.getCurrentSession();
        session.delete(staffFuBen);
    }

    @Override
    public StaffFuBen getEmpByIdDao(StaffFuBen staffFuBen) {
        Session session = sessionFactory.getCurrentSession();
        StaffFuBen fuBen = session.get(StaffFuBen.class, staffFuBen.getStaffId());
        return fuBen;
    }

    @Override
    public void updateEmployeeByIdDao(StaffFuBen staffFuBen) {
        Session session = sessionFactory.getCurrentSession();
        String hql ="update Staff set staffName=?,staffPwd=?,staffSex=?,staffAddress=?,staffTel=?,staffEmail=?,staffState=?,levelId=?,rolesId=?,depId=?,shopId=? where staffId=?";
        session.createQuery(hql)
                .setParameter(0,staffFuBen.getStaffName())
                .setParameter(1,staffFuBen.getStaffPwd())
                .setParameter(2,staffFuBen.getStaffSex())
                .setParameter(3,staffFuBen.getStaffAddress())
                .setParameter(4,staffFuBen.getStaffTel())
                .setParameter(5,staffFuBen.getStaffEmail())
                .setParameter(6,staffFuBen.getStaffState())
                .setParameter(7,staffFuBen.getLevel().getLevelId())
                .setParameter(8,staffFuBen.getRole().getRoleId())
                .setParameter(9,staffFuBen.getDepartment().getDepId())
                .setParameter(10,staffFuBen.getShop().getShopId())
                .setParameter(11,staffFuBen.getStaffId())
                .executeUpdate();


    }

    @Override
    public List<StaffFuBen> getAllStaffFuBenDao() {
        Session session = sessionFactory.getCurrentSession();
        String hql = "from Staff";
        List<StaffFuBen> list = session.createQuery(hql, StaffFuBen.class).list();
        return list;
    }

    @Override
    public void updateRoleByIdDao(StaffFuBen staff) {
        Session session = sessionFactory.getCurrentSession();
        String hql = "update Staff set rolesId=? where staffId=?";
        System.out.println("员工id"+staff.getStaffId()+"角色修改id"+staff.getRole().getRoleId());
     session.createQuery(hql).setParameter(0,staff.getRole().getRoleId()).setParameter(1,staff.getStaffId()).executeUpdate();

    }

    public SessionFactory getSessionFactory() {
        return sessionFactory;
    }

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }
}
