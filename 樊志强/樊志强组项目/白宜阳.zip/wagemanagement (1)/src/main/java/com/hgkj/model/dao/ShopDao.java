package com.hgkj.model.dao;

import com.hgkj.model.entity.Department;
import com.hgkj.model.entity.Shop;

import java.util.List;

public interface ShopDao {
    List<Shop> allShopDao();
    boolean addShopDao(Shop shop);
    boolean updateShopDao(Shop shop);
    boolean deleteShopDao(int shopId);
    Shop getByIdShopDao(int shopId);
}
