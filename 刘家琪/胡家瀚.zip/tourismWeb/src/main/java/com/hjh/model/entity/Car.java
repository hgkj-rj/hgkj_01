package com.hjh.model.entity;

import java.sql.Timestamp;

public class Car {
    private int carid;
    private Timestamp time;
    private Line line;
    private Customer customer;

    public Line getLine() {
        return line;
    }

    public void setLine(Line line) {
        this.line = line;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public int getCarid() {
        return carid;
    }

    public void setCarid(int carid) {
        this.carid = carid;
    }

    public Timestamp getTime() {
        return time;
    }

    public void setTime(Timestamp time) {
        this.time = time;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Car car = (Car) o;

        if (carid != car.carid) return false;
        if (time != null ? !time.equals(car.time) : car.time != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = carid;
        result = 31 * result + (time != null ? time.hashCode() : 0);
        return result;
    }
}
