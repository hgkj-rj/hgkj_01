package com.workmoney.model.service;

import com.workmoney.model.entity.Role;
import com.workmoney.model.entity.Staff;

import java.util.List;

/**
 * user@Bright Rain .
 * 2019/6/27.
 */
public interface RoleService {
    /**
     * 获取角色
     * @return
     */
    List<Role> getAllRoll();

    /**
     * 删除角色
     * @param role
     */
    void delRoleByIdService(Role role);
    /**
     * 添加角色
     * @param role
     */
    void addRoleService(Role role);

    List<Staff> serchNameAllowService(String name);
}
