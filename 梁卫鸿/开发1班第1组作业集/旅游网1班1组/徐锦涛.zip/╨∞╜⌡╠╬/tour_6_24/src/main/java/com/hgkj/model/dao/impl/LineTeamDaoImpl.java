package com.hgkj.model.dao.impl;

import com.hgkj.model.dao.LineTeamDao;
import com.hgkj.model.entity.Line;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
@Transactional
public class LineTeamDaoImpl implements LineTeamDao {
    @Autowired
    private SessionFactory sessionFactory;
    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }
    public Session getSession(){
        return sessionFactory.getCurrentSession();
    }
    @Override
    public boolean lineTeamAddDao(Line line) {
        boolean result=false;
        try {
            getSession().save(line);
            result=true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

    @Override
    public List<Line> lineTeamAllDao() {
        String hql="from Line ";
        Query query=getSession().createQuery(hql);
        return query.list();
    }

    @Override
    public boolean lineTeamDeleteDao(String lineID) {
        boolean resoult=false;
        Line line=getSession().get(Line.class,lineID);
        try {
            getSession().delete(line);
            resoult=true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return resoult;
    }

    @Override
    public Line lineTeamIdDao(String lineID) {
        Line line=getSession().get(Line.class,lineID);
        return line;
    }

    @Override
    public boolean lineTeamUpdateDao(Line line) {
        boolean resoult=false;
        try {
            getSession().update(line);
            resoult=true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return resoult;
    }
}
