package com.hgkj.model.dao;

import com.hgkj.model.entity.Linetype;

import java.util.List;

public interface LineTypeDao {
    public boolean addLineTypeDao(Linetype linetype);
    public List<Linetype> allLineTypeDao();
    public boolean deleteLineTypeDao(Integer id);
    public Linetype getOneLineTypeDao(Integer id);
    public boolean updateLineTypeDao(Linetype linetype);
    public String getIconLineTypeDao(Integer id);
    public List<Linetype> getTypeNameDao();
    public List<Linetype> ShowTypeNameDao();



}
