package com.hgkj.controler.action;

import com.hgkj.model.entity.*;
import com.hgkj.model.service.CarService;
import org.apache.struts2.ServletActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import java.util.ArrayList;
import java.util.List;

@Controller
@Namespace("/")
@ParentPackage("json-default")
public class CarAction {
    @Autowired
    private CarService carService;
    private Car car;
    private Line line;
    private OtDetail otDetail;
    private String message;
    private String allPrice;
    private int count;
    private int price;
    private int[] otId1;
    private int[] otId2;

    public CarService getCarService() {
        return carService;
    }

    public void setCarService(CarService carService) {
        this.carService = carService;
    }
    @Action(value = "carAll",results ={@Result(name = "all",type = "redirect",location = "qt/cart.jsp"),
            @Result(name = "error",type = "redirect",location = "qt/login.jsp")})
    public String carAll(){
        int a=0;
        if(ServletActionContext.getRequest().getSession().getAttribute("customerId")!=null) {
            a = (int) ServletActionContext.getRequest().getSession().getAttribute("customerId");
            List<Car> carList = carService.carAllService();
            List<Line> lineList = carService.lineAllService();
            List<Picture> pictureList = carService.pictureAllService();
            ServletActionContext.getRequest().getSession().setAttribute("carList", carList);
            ServletActionContext.getRequest().getSession().setAttribute("lineList", lineList);
            ServletActionContext.getRequest().getSession().setAttribute("pictureList", pictureList);
            ServletActionContext.getRequest().getSession().setAttribute("a", a);
            return "all";
        }
        return "error";
    }
    @Action(value = "carAdd",results = {@Result(name = "addsuccess",type = "redirectAction",params = {"actionName","carAll"}),
            @Result(name = "adderror",type = "redirect",location = "qt/login.jsp")})
    public String carAdd(){
        int a=0;
        java.text.SimpleDateFormat formater =new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss"); //编写系统时间格式
        java.util.Date daytime = new java.util.Date();//得到当前系统时间
        String systime = formater.format(daytime);//格式化
        if(ServletActionContext.getRequest().getSession().getAttribute("customerId")!=null) {
            a = (int) ServletActionContext.getRequest().getSession().getAttribute("customerId");
            if (a != 0) {
                boolean rs = carService.CarAddService(a, line.getLineId(), systime);
                if (rs) {
                    return "addsuccess";
                }
                return "adderror";
            } else {
                return "adderror";
            }
        }
        return "adderror";
    }
    @Action(value = "carDelAction",results = {@Result(name = "del",type = "json",params = {"root","message"})})
    public String carDelAction(){
        boolean rs=carService.carDeleteDao(car.getCarId());
        if(rs){
            message="success";
            return "del";
        }
        return "delerror";
    }
    @Action(value = "buyOrderAction",results = {@Result(name = "del",type = "redirect",location = "qt/historyOrders.jsp")})
    public String buyOrderAction(){
        int a=0;
        String odId=null;
        double pri=0;
        pri=Double.parseDouble(line.getPrice());
        double total=count* pri;
        List<OtDetail> otDetailList=new ArrayList<>();

        for (int i=0;i<otId1.length;i++){
            int otId=otId1[i];
            OtDetail otDetail=new OtDetail(otId);
            otDetailList.add(otDetail);
        }
        ServletActionContext.getRequest().getSession().setAttribute("otId",otDetail.getOtId());
        ServletActionContext.getRequest().getSession().setAttribute("otDetailList",otDetailList);

        ServletActionContext.getRequest().getSession().setAttribute("total",total);
        if(ServletActionContext.getRequest().getSession().getAttribute("touristId")!=null){
        if(ServletActionContext.getRequest().getSession().getAttribute("carId")!=null) {
            odId=ServletActionContext.getRequest().getSession().getAttribute("touristId").toString();
            a = (int) ServletActionContext.getRequest().getSession().getAttribute("carId");
            boolean rs = carService.carDeleteDao(a);
            Orderdetail orderdetail=carService.orderIdService(odId);
            ServletActionContext.getRequest().getSession().setAttribute("order",orderdetail);
            if (rs) {
                message = "success";
                return "del";
            }
        }
        }
        return "delerror";
    }
    @Action(value = "orderDelAction",results = {@Result(name = "del",type = "json",params = {"root","message"})})
    public String orderDelAction(){
        int otId3=0;
        boolean rs=false;
        String odId=null;

        if(ServletActionContext.getRequest().getSession().getAttribute("otId")!=null) {
            if(ServletActionContext.getRequest().getSession().getAttribute("touristId")!=null) {
                odId = ServletActionContext.getRequest().getSession().getAttribute("touristId").toString();
                for (int i = 0; i < otId2.length; i++) {
                    otId3 = otId2[i];
                    rs = carService.otDeleteService(otId3);
                }
            }

                boolean rs1=carService.orderDeleteService(odId);
                if (rs&&rs1) {
                    message = "success";
                    return "del";
                }
        }
        return "delerror";
    }
   /* @Action(value = "orderDelAction",results = {@Result(name = "del",type = "redirectAction",params = {"actionName","buyOrderAction"})})
    public String orderDelAction(){
        int otId3=0;
        boolean rs=false;
        String odId=null;

        if(ServletActionContext.getRequest().getSession().getAttribute("otId")!=null) {
            if(ServletActionContext.getRequest().getSession().getAttribute("touristId")!=null) {
                odId = ServletActionContext.getRequest().getSession().getAttribute("touristId").toString();
                System.out.println(otId2.length+"aaaaaaaaaaaaaaaaaa");
                for (int i = 0; i < otId2.length; i++) {
                    otId3 = otId2[i];
                    System.out.println(otId3+"bbbbbbbbb");
                    rs = carService.otDeleteService(otId3);
                }
            }
            boolean rs1=carService.orderDeleteService(odId);
            if (rs&&rs1) {
                message = "success";
                return "del";
            }
        }
        return "delerror";
    }*/

    public int[] getOtId2() {
        return otId2;
    }

    public void setOtId2(int[] otId2) {
        this.otId2 = otId2;
    }

    public int[] getOtId1() {
        return otId1;
    }

    public void setOtId1(int[] otId1) {
        this.otId1 = otId1;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public OtDetail getOtDetail() {
        return otDetail;
    }

    public void setOtDetail(OtDetail otDetail) {
        this.otDetail = otDetail;
    }

    public String getAllPrice() {
        return allPrice;
    }

    public void setAllPrice(String allPrice) {
        this.allPrice = allPrice;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Line getLine() {
        return line;
    }

    public void setLine(Line line) {
        this.line = line;
    }

    public Car getCar() {
        return car;
    }

    public void setCar(Car car) {
        this.car = car;
    }
}
