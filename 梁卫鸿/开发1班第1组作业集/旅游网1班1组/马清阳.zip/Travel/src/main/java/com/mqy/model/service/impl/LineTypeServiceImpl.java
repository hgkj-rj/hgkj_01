package com.mqy.model.service.impl;

import com.mqy.model.dao.LineTypeDao;
import com.mqy.model.entity.Linetype;
import com.mqy.model.service.LineTypeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class LineTypeServiceImpl implements LineTypeService {
    @Autowired
    private LineTypeDao lineTypeDao;

    public void setLineTypeDao(LineTypeDao lineTypeDao) {
        this.lineTypeDao = lineTypeDao;
    }

    @Override
    public List<Linetype> allLineTypeService() {
        return lineTypeDao.allLineTypeDao();
    }

    @Override
    public void addLineTypeService(Linetype linetype) {
        lineTypeDao.addLineTypeDao(linetype);
    }

    @Override
    public void deleteLineTypeService(String lineTypeId) {
        lineTypeDao.deleteLineTypeDao(lineTypeId);
    }

    @Override
    public void updateLineTypeService(Linetype linetype) {
        lineTypeDao.updateLineTypeDao(linetype);
    }

    @Override
    public Linetype getLineTypeService(String lineTypeId) {
        return lineTypeDao.getLineTypeDao(lineTypeId);
    }
}
