package com.hgkj.model.dao.impl;

import com.hgkj.model.dao.TouristDao;
import com.hgkj.model.entity.Tourist;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
@Repository
@Transactional
public class TouristDaoImpl implements TouristDao {
    @Autowired
    private SessionFactory sessionFactory;
    private Session getSession(){
        return sessionFactory.getCurrentSession();
    }

    @Override
    public List<Tourist> allTouristDao() {
        Query query=getSession().createQuery("from Tourist ");
        return query.list();
    }

    @Override
    public boolean addTouristDao(Tourist tourist) {
        boolean result=false;
        Tourist tourist1=new Tourist(tourist.getTouristId(),tourist.getRealName(),tourist.getIDCard(),tourist.getTel());
        try {
            getSession().save(tourist1);
            result=true;
        }catch (Exception e){
            e.printStackTrace();
        }
        return result;
    }
}
