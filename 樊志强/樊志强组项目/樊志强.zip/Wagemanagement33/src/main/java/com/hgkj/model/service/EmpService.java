package com.hgkj.model.service;

/**
 * 这是员工信息管理表
 */
public interface EmpService {
}
