package com.hgkj.model.service.impl;

import com.hgkj.model.dao.Leveldao;
import com.hgkj.model.entity.Level;
import com.hgkj.model.service.LevelService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class LevelServiceimpl implements LevelService {
    @Autowired
    private Leveldao leveldao;

    public void setLeveldao(Leveldao leveldao) {
        this.leveldao = leveldao;
    }


    @Override
    public List<Level> allLevelService() {
        return leveldao.allLeveldao();
    }

    @Override
    public boolean addLevelService(Level level) {
        return leveldao.addLeveldao(level);
    }

    @Override
    public boolean deleteLevelService(int levelId) {
        return leveldao.deleteLeveldao(levelId);
    }

    @Override
    public boolean updateLeveService(Level level) {
        return leveldao.updateLevedao(level);
    }

    @Override
    public Level level(int levelId) {
        return leveldao.level(levelId);
    }
}
