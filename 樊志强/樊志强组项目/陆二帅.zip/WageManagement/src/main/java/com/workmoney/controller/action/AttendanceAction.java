package com.workmoney.controller.action;

import com.workmoney.model.entity.Attendance;
import com.workmoney.model.entity.AttendanceLog;
import com.workmoney.model.entity.SalaryLog;
import com.workmoney.model.entity.Staff;
import com.workmoney.model.service.AttendanceService;
import com.workmoney.util.Attendancesinfo;
import org.apache.struts2.ServletActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import javax.servlet.http.HttpSession;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * user@Bright Rain .
 * 2019/6/25.
 */
@ParentPackage("struts-default")
@Namespace("/")
@Controller
public class AttendanceAction {

    @Autowired
    private AttendanceService service;

    private AttendanceLog attendanceLog;

    private Staff staff;

    private int id;

    /**
     * 如果是管理员 添0
     * 不是管理员请填编号
     * 考勤详细
     * @return
     */

    @Action(value = "/attendanceInfoAction",results = {@Result(name = "success",type = "redirect",location = "html/salaryAttendanceInfo.jsp")})
    public String attendanceInfoAction(){
        HttpSession session = ServletActionContext.getRequest().getSession();
        List<AttendanceLog> attendanceLogs = service.attendanceInfoService(id);
        List<Attendancesinfo> list = new ArrayList<>();
        //计算扣除的钱
        for (AttendanceLog log : attendanceLogs) {
            if(log.getAttlogCount()!=null){
                //次数
                int i = Integer.parseInt(log.getAttlogCount());
                //百分点
                String attPercent = log.getAttendance().getAttPercent();
                double v1 = Double.parseDouble(attPercent);
                //基本工资
                BigDecimal levelPrice = log.getStaff().getSalaryLog().getLevelPrice();
                double v = levelPrice.doubleValue();
                double  sum =i*v1*v;

                Attendancesinfo attendancesinfo = new Attendancesinfo(log.getStaff().getStaffName(),log.getAttendance().getAttName(),i,sum);
                list.add(attendancesinfo);
            }
        }
        session.setAttribute("attendancesinfoList",list);
        return "success";
    }


    @Action(value = "/delAttendanceAction",results = {@Result(name = "success",type = "redirectAction",location = "attendanceListAction"),
            @Result(name = "error",type = "redirect",location = "error.jsp")
    })
    public String delAttendanceAction(){
        service.delAttendanceLog(attendanceLog);
        return "success";
    }

    /**
     * 修改考勤
     * @return
     */
    @Action(value = "/attendanceEditAction",results = {@Result(name = "success",type = "redirectAction",location = "attendanceListAction"),
            @Result(name = "error",type = "redirect",location = "error.jsp")
    })
    public String attendanceEditAction(){
        service.attendanceEditAction(attendanceLog);
        return "success";
    }

    /**
     * 去往修改缺勤记录的页面
     */
    @Action(value = "/editAttendanceAction",results = {@Result(name = "success",type = "redirect",location = "html/attendanceEdit.jsp")})
    public String editAttendanceAction(){

        HttpSession session = ServletActionContext.getRequest().getSession();
        Staff staf1f1 = (Staff)session.getAttribute("staff");
        //缺勤类别
        List<Attendance> list = service.getAttendanceType();
        session.setAttribute("attendanceType",list);
       AttendanceLog attendanceLog =  service.getAttendanceLogById(staff.getStaffId(),staf1f1.getShopId());
        session.setAttribute("attendanceLog",attendanceLog);
       return "success";
    }
    /**
     * 添加缺勤记录
     */
    @Action(value = "/attendanceAddAction",results = {@Result(name = "success",type = "redirectAction",location = "attendanceListAction"),
            @Result(name = "error",type = "redirect",location = "error.jsp")
    })
    public String attendanceAddAction(){

        System.out.println(attendanceLog.getStaff().getStaffId()+"==="+attendanceLog.getAttendance().getAttId()+"=="+attendanceLog.getAttlogCount());

        service.addAttendanceService(attendanceLog);
        return "success";
    }
    /**
     *  去往 添加缺勤页面
     */
    @Action(value = "/attendanceAddJspAction",results = {@Result(name = "success",type = "redirect",location = "html/attendanceAdd.jsp"),
            @Result(name = "error",type = "redirect",location = "error.jsp")
    })
    public String attendanceAddJspAction(){
        HttpSession session = ServletActionContext.getRequest().getSession();
        List<Attendance> list = service.getAttendanceType();
        session.setAttribute("attendanceType",list);
        return "success";
    }


    /**
     * 获取店长下面的所有员工考勤信息
     * @return
     */
    @Action(value = "attendanceListAction",results = {
            @Result(name = "success",type = "redirect",location = "html/attendanceList.jsp"),
            @Result(name = "error",type = "redirect",location = "error.jsp")
    })
    public String attendanceListAction(){
        HttpSession session = ServletActionContext.getRequest().getSession();
        Staff staff = (Staff)session.getAttribute("staff");
        List<AttendanceLog> attendanceList = service.getAllAttendanceLog(staff.getShopId());
        if(attendanceList==null){
            return "error";
        }else {
            session.setAttribute("attendanceList",attendanceList);
            return "success";
        }
    }

    public void setStaff(Staff staff) {
        this.staff = staff;
    }

    public AttendanceLog getAttendanceLog() {
        return attendanceLog;
    }

    public void setAttendanceLog(AttendanceLog attendanceLog) {
        this.attendanceLog = attendanceLog;
    }

    public Staff getStaff() {
        return staff;
    }

    public void setService(AttendanceService service) {
        this.service = service;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}
