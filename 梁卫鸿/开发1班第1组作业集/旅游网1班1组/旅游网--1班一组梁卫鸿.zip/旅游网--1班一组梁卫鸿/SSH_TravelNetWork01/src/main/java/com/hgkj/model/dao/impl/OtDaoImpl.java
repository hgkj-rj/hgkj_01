package com.hgkj.model.dao.impl;

import com.hgkj.model.dao.OtDao;
import com.hgkj.model.entity.Orderdetail;
import com.hgkj.model.entity.OtDetail;
import com.hgkj.model.entity.Picture;
import com.hgkj.model.entity.Tourist;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
@Transactional
public class OtDaoImpl implements OtDao {
    @Autowired
    private SessionFactory sessionFactory;
    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }
    public Session getSession(){
        return sessionFactory.getCurrentSession();
    }
    @Override
    public boolean otAddDao(String odId, String touristId) {
        boolean result=false;
        OtDetail otDetail=new OtDetail(odId,touristId);
        try {
            getSession().save(otDetail);
            result=true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

    @Override
    public boolean orderAddDao(String odId, String lineName, String price, String orderDate, String travelDate, String total, String lineId, int state, int customerId) {
        boolean result=false;
        Orderdetail orderdetail=new Orderdetail(odId,lineName,price,orderDate,travelDate,total,lineId,state,customerId);
        try {
            getSession().save(orderdetail);
            result=true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

    @Override
    public boolean touristAddDao(String touristId, String idCard, String tel, String realName) {
        boolean result=false;
        Tourist tourist=new Tourist(touristId,idCard,tel,realName);
        try {
            getSession().save(tourist);
            result=true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

    @Override
    public OtDetail OtIdDao(int otId) {
        OtDetail otDetail=getSession().get(OtDetail.class,otId);
        return otDetail;
    }

    @Override
    public List<OtDetail> otAllDao() {
        String hql="from OtDetail ";
        Query query=getSession().createQuery(hql);
        return query.list();
    }
}
