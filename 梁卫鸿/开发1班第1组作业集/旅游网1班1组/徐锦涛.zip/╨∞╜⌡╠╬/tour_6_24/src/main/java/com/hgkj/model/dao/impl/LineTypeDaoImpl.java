package com.hgkj.model.dao.impl;

import com.hgkj.model.dao.LineTypeDao;
import com.hgkj.model.entity.Linetype;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
@Transactional
public class LineTypeDaoImpl implements LineTypeDao {
    @Autowired
    private SessionFactory sessionFactory;
    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }
    public Session getSession(){
        return sessionFactory.getCurrentSession();
    }

    @Override
    public List<Linetype> lineTypeAllDao() {
        String hql="from Linetype ";
        Query query=getSession().createQuery(hql);
        return query.list();
    }

    @Override
    public boolean lineTypeAddDao(String lineTypeID,String typeName,String icon) {
        boolean result=false;
        Linetype linetype1=new Linetype(lineTypeID,typeName,icon);
        try {
            getSession().save(linetype1);
            result=true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

    @Override
    public boolean lineTypeDeleteDao(String lineTypeID) {
        boolean resoult=false;
        Linetype lineType=getSession().get(Linetype.class,lineTypeID);
        try {
            getSession().delete(lineType);
            resoult=true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return resoult;
    }

    @Override
    public Linetype lineTypeIdDao(String lineTypeID) {
        Linetype lineType=new Linetype();
           lineType=getSession().get(Linetype.class,lineTypeID);
        return lineType;
    }

    @Override
    public boolean lineTypeUpdateDao(String lineTypeID,String typeName,String icon) {
        boolean resoult=false;
        Linetype linetype=new Linetype(lineTypeID,typeName,icon);
        try {
            getSession().update(linetype);
            resoult=true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return resoult;
    }
}
