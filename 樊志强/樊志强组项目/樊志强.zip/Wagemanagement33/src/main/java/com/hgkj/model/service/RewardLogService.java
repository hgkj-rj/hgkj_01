package com.hgkj.model.service;

import com.hgkj.model.entity.RewardLog;

import java.util.List;

public interface RewardLogService {
    //查询所有补贴类别
    public List<RewardLog> allrewardLogService();
    //添加补贴类别
    public boolean insertrewardLogService(RewardLog rewardLog);
    //删除补贴类别
    public boolean deleterewardLogService(int id);
    //修改补贴类别
    public boolean updaterewardLogService(RewardLog rewardLog);
    //根据Id获取补贴信息
    public RewardLog getrewardLogByIdService(int id);
}
