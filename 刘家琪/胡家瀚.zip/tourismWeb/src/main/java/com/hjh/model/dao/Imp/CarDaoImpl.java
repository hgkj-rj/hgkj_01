package com.hjh.model.dao.Imp;

import com.hjh.model.dao.CarDao;
import com.hjh.model.entity.Car;
import com.hjh.model.entity.Line;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
@Repository
@Transactional
public class CarDaoImpl implements CarDao {
    @Autowired
    private SessionFactory sessionFactory;

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    public SessionFactory getSessionFactory() {
        return sessionFactory;
    }
    public Session getSession(){
        return sessionFactory.getCurrentSession();
    }
    @Override
    public List<Car> AllCar() {
        String hql = "from Line";
        List<Car> carList = getSession().createQuery(hql).list();
        return carList;
    }

    @Override
    public boolean addCar(Car car) {
        boolean f = false;
        Session session = getSession();
        Line line = session.load(Line.class,car.getLine().getLineid());
        car.setLine(line);
        try {
            session.save(car);
            f = true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return f;
    }

    @Override
    public boolean DeleCar(Car car) {
        boolean f = false;
        Session session = getSession();
        Line line = session.load(Line.class,car.getLine().getLineid());
        car.setLine(line);
        try {
            session.delete(car);
            f = true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return f;
    }
}
