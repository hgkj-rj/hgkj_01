package com.hgkj.model.service.impl;

import com.hgkj.model.dao.SubsidyDao;
import com.hgkj.model.entity.Subsidy;
import com.hgkj.model.service.SubsidyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class SubsidyServiceImpl implements SubsidyService {
    @Autowired
    private SubsidyDao subsidyDao;
    @Override
    public List<Subsidy> allsubsidyService() {
        return subsidyDao.allsubsidyDao();
    }

    @Override
    public boolean insertsubsidyService(Subsidy subsidy) {
        return subsidyDao.insertsubsidyDao(subsidy);
    }

    @Override
    public boolean deletesubsidyService(int id) {
        return subsidyDao.deletesubsidyDao(id);
    }

    @Override
    public boolean updatesubsidyService(Subsidy subsidy) {
        return subsidyDao.updatesubsidyDao(subsidy);
    }

    @Override
    public Subsidy getsubsidyByIdService(int id) {
        return subsidyDao.getsubsidyByIdDao(id);
    }

    public SubsidyDao getSubsidyDao() {
        return subsidyDao;
    }

    public void setSubsidyDao(SubsidyDao subsidyDao) {
        this.subsidyDao = subsidyDao;
    }
}
