package com.hgkj.model.service;

import com.hgkj.model.entity.AttendanceLog;

import java.util.List;

public interface AttendanceLogService {
    //查询所有补贴类别
    public List<AttendanceLog> allAttendanceLogService();
    //添加补贴类别
    public boolean insertAttendanceLogService(AttendanceLog attendanceLog);
    //删除补贴类别
    public boolean deleteAttendanceLogService(int id);
    //修改补贴类别
    public boolean updateAttendanceLogService(AttendanceLog attendanceLog);
    //根据Id获取补贴信息
    public AttendanceLog getAttendanceLogByIdService(int id);
}
