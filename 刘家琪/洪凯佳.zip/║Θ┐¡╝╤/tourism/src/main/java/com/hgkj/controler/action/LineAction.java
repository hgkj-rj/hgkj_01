package com.hgkj.controler.action;


import com.hgkj.model.entity.Line;
import com.hgkj.model.entity.Linetype;
import com.hgkj.model.entity.Picture;
import com.hgkj.model.service.LineService;
import com.hgkj.model.service.LinetypeService;
import com.hgkj.model.service.PictureService;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.config.ServletContextAwareConfigurationProvider;
import org.apache.struts2.ServletActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.context.support.ServletContextAttributeExporter;

import javax.servlet.ServletContext;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Random;

@Controller
@Namespace("/")
@ParentPackage("struts-default")
public class LineAction {
    @Autowired
    private LineService lineService;
    @Autowired
    private PictureService pictureService;
    @Autowired
    private LinetypeService linetypeService;
    private Line line;
    private Picture picture;
    private List<Picture> pictures;
    private File[] upload;
    private String[] uploadFileName;
    private String[] uploadContentType;
    private Picture picture1;
    private Picture picture2;
    private Picture picture3;
    private Picture picture4;
    public Line getLine() {
        return line;
    }
    public void setLine(Line line) {
        this.line = line;
    }
    public void setLineService(LineService lineService) {
        this.lineService = lineService;
    }
    public LineService getLineService() {
        return lineService;
    }
    public PictureService getPictureService() {
        return pictureService;
    }
    public void setPictureService(PictureService pictureService) {
        this.pictureService = pictureService;
    }
    public LinetypeService getLinetypeService() {
        return linetypeService;
    }
    public void setLinetypeService(LinetypeService linetypeService) {
        this.linetypeService = linetypeService;
    }
    public Picture getPicture() {
        return picture;
    }
    public void setPicture(Picture picture) {
        this.picture = picture;
    }
    public List<Picture> getPictures() {
        return pictures;
    }
    public void setPictures(List<Picture> pictures) {
        this.pictures = pictures;
    }
    public File[] getUpload() {
        return upload;
    }
    public void setUpload(File[] upload) {
        this.upload = upload;
    }
    public String[] getUploadFileName() {
        return uploadFileName;
    }
    public void setUploadFileName(String[] uploadFileName) {
        this.uploadFileName = uploadFileName;
    }
    public String[] getUploadContentType() {
        return uploadContentType;
    }
    public void setUploadContentType(String[] uploadContentType) {
        this.uploadContentType = uploadContentType;
    }
    public Picture getPicture1() {
        return picture1;
    }
    public void setPicture1(Picture picture1) {
        this.picture1 = picture1;
    }
    public Picture getPicture2() {
        return picture2;
    }
    public void setPicture2(Picture picture2) {
        this.picture2 = picture2;
    }
    public Picture getPicture3() {
        return picture3;
    }
    public void setPicture3(Picture picture3) {
        this.picture3 = picture3;
    }
    public Picture getPicture4() {
        return picture4;
    }
    public void setPicture4(Picture picture4) {
        this.picture4 = picture4;
    }

    @Action(value = "allLine",results = {@Result(name = "all",type = "redirect",location = "/ht/lineAll.jsp")})
    public String allLine(){
        List<Line> lineList=lineService.allLineService();
        ActionContext.getContext().getSession().put("lineList",lineList);
        return "all";
    }

    @Action(value = "toIndex",results = @Result(name = "all",type = "redirect",location = "/qt/index.jsp"))
    public String toIndex(){
        List<Line> lineList=lineService.allLineService();
        ActionContext.getContext().getSession().put("lineList",lineList);
        return "all";
    }

    @Action(value = "allTuanGou",results = @Result(name = "all",type = "redirect",location = "/ht/tuangou1All.jsp"))
    public String allTuanGou(){
        List<Line> lineList = lineService.allLineService();
        ActionContext.getContext().getSession().put("lineList",lineList);
        return "all";
    }

    @Action(value = "allTuanGouLine",results = @Result(name = "all",type = "redirect",location = "/ht/tuangou2All.jsp"))
    public String allTuanGouLine(){
        List<Line> lineList = lineService.allLineService();
        ActionContext.getContext().getSession().put("lineList",lineList);
        return "all";
    }

    @Action(value = "addLine",results = {@Result(name = "add",type = "redirectAction",location = "allLine.action"),
            @Result(name = "error",type = "redirect",location = "/ht/lineAdd.jsp")})
    public String addLine(){
        boolean f=false;
        ServletContext application = ServletActionContext.getServletContext();
        String filePath=application.getRealPath("upload");
        File file=new File(filePath);
        if (!file.exists()){
            file.mkdirs();
        }
        for (int i=0;i<upload.length;i++){
            upload[i].renameTo(new File(file,uploadFileName[1]));
        }
        Date date=new Date();
        SimpleDateFormat deteFormat = new SimpleDateFormat("yyyy-MM-dd :hh:mm:ss");
        line.setOnTime(deteFormat.format(date));
        line.setLineId(getCharAndNumr(3));
        f=lineService.addLineService(line);
        if (!f){
            return "error";
        }
        for (int i=0;i<4;i++){
            pictures.get(i).setLine(line);
            pictures.get(i).setName("upload/"+uploadFileName[i]);
            f=pictureService.addPictureService(pictures.get(i));
            if (!f){
                return "error";
            }
        }
        return "add";
    }

    private static String getCharAndNumr(int length) {
        String val="";
        Random random=new Random();
        for (int i=0;i<length;i++){
            String charOrNum = random.nextInt(2) % 2==0?"char":"num";
            if ("char".equalsIgnoreCase(charOrNum)){
                int choice = random.nextInt(2) % 2 ==0?65:97;
                val +=(char)(choice+random.nextInt(26));
            }else if ("num".equalsIgnoreCase(charOrNum)){
                val += String.valueOf(random.nextInt(10));
            }
        }
        return val;
    }

    @Action(value = "toaddLine",results = @Result(name = "toadd",type = "redirect",location = "/ht/lineAdd.jsp"))
    public String toaddLine(){
        List<Linetype> linetypeList=linetypeService.allLinetypeService();
        ActionContext.getContext().getSession().put("linetypeList",linetypeList);
        return "toadd";
    }

    @Action(value = "deleteLine",results = {@Result(name = "delete",type = "redirectAction",location = ""),
            @Result(name = "error",type = "redirect",location = "")})
    public String deleteLine(){
        boolean f=lineService.deleteLineService(line);
        if (f){
            return "add";
        }
        return "error";
    }

    @Action(value = "updateLine",results = {@Result(name = "update",type = "redirectAction",location = "allLine.action"),
            @Result(name = "error",type = "redirect",location = "ht/lineUpdate.jsp")})
    public String updateLine(){
        boolean f=false;
        if (upload.length!=0){
            ServletContext application=ServletActionContext.getServletContext();
            String filePath = application.getRealPath("upload");
            File file=new File(filePath);
            if (!file.exists()){
                file.exists();
            }
            for (int i=0;i<upload.length;i++){
                upload[i].renameTo(new File(file,uploadFileName[i]));
            }
        }

        f=lineService.updateLineService(line);
        if (!f){
            return "error";
        }
        picture1.setLine(line);
        picture2.setLine(line);
        picture3.setLine(line);
        picture4.setLine(line);

        File tempFile1=new File(picture1.getName().trim());
        String fileName1=tempFile1.getName();
        picture1.setName("upload/"+fileName1);

        File tempFile2=new File(picture2.getName().trim());
        String fileName2=tempFile2.getName();
        picture2.setName("upload/"+fileName2);

        File tempFile3=new File(picture3.getName().trim());
        String fileName3=tempFile3.getName();
        picture3.setName("upload/"+fileName3);

        File tempFile4=new File(picture4.getName().trim());
        String fileName4=tempFile4.getName();
        picture4.setName("upload/"+fileName4);

        f=pictureService.updatePictureService(picture1);
        if (!f){
            return "error";
        }

        f=pictureService.updatePictureService(picture2);
        if (!f){
            return "error";
        }

        f=pictureService.updatePictureService(picture3);
        if (!f){
            return "error";
        }

        f=pictureService.updatePictureService(picture4);
        if (!f){
            return "error";
        }
        return "update";
    }

    @Action(value = "updateTuanGouLine",results = {@Result(name = "update",type = "redirectAction",location = "allTuanGou.action"),
            @Result(name = "error",type = "redirect",location = "")})
    public String updateTuanGouLine(){
        boolean f=false;
        line.setTeamBuy(1);
        f=lineService.updateLineService(line);

        if (!f){
            return "error";
        }
        return "update";
    }

    @Action(value = "findLine",results = {@Result(name = "find",type = "redirect",location = "/ht/lineUpdate.jsp")})
    public String findLine(){
        line = lineService.getLineByIdService(line.getLineId());
        List<Picture> pictureList=pictureService.findPictureService(line.getLineId());
        ActionContext.getContext().getSession().put("Line",line);
        ActionContext.getContext().getSession().put("pictureList",pictureList);
        List<Linetype> linetypeList=linetypeService.allLinetypeService();
        ActionContext.getContext().getSession().put("linetypeList",linetypeList);
        return "find";
    }

    @Action(value = "findTuanGouLine",results = {@Result(name = "find",type = "redirect",location = "/ht/tuangouUpdate.jsp")})
    public String findTuanGouLine(){
        line = lineService.getLineByIdService(line.getLineId());
        List<Picture> pictureList=pictureService.findPictureService(line.getLineId());
        ActionContext.getContext().getSession().put("line",line);
        ActionContext.getContext().getSession().put("pictureList",pictureList);
        List<Linetype> linetypeList=linetypeService.allLinetypeService();
        ActionContext.getContext().getSession().put("linetypeList",linetypeList);
        return "find";
    }
}
