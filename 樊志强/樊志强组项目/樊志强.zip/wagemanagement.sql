/*
 Navicat Premium Data Transfer

 Source Server         : localhost
 Source Server Type    : MySQL
 Source Server Version : 50724
 Source Host           : localhost:3306
 Source Schema         : wagemanagement

 Target Server Type    : MySQL
 Target Server Version : 50724
 File Encoding         : 65001

 Date: 08/07/2019 16:19:43
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for attendance
-- ----------------------------
DROP TABLE IF EXISTS `attendance`;
CREATE TABLE `attendance`  (
  `att_Id` int(11) NOT NULL AUTO_INCREMENT,
  `att_Name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `att_Percent` double(11, 2) NOT NULL,
  PRIMARY KEY (`att_Id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of attendance
-- ----------------------------
INSERT INTO `attendance` VALUES (1, '迟到', 0.02);
INSERT INTO `attendance` VALUES (2, '旷工', 0.05);
INSERT INTO `attendance` VALUES (3, '早退', 0.02);

-- ----------------------------
-- Table structure for attendance_log
-- ----------------------------
DROP TABLE IF EXISTS `attendance_log`;
CREATE TABLE `attendance_log`  (
  `attenlog_Id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_Id` int(11) NULL DEFAULT NULL,
  `att_Id` int(11) NULL DEFAULT NULL,
  `attlog_Count` int(11) NOT NULL,
  `attlog_Time` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`attenlog_Id`) USING BTREE,
  INDEX `att_Id`(`att_Id`) USING BTREE,
  INDEX `staff_Id`(`staff_Id`) USING BTREE,
  CONSTRAINT `FK1fk2eaal2bns1kxyanw48xkjc` FOREIGN KEY (`staff_Id`) REFERENCES `staff` (`staffId`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `FK6rwwqs7caervlmokymw8ijihn` FOREIGN KEY (`att_Id`) REFERENCES `attendance` (`att_Id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `att_Id` FOREIGN KEY (`att_Id`) REFERENCES `attendance` (`att_Id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `staff_Id` FOREIGN KEY (`staff_Id`) REFERENCES `staff` (`staffId`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 6 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of attendance_log
-- ----------------------------
INSERT INTO `attendance_log` VALUES (1, 1, 1, 1, '2019/06/26');
INSERT INTO `attendance_log` VALUES (2, 2, 2, 1, '2019/06/26');
INSERT INTO `attendance_log` VALUES (3, 3, 3, 1, '2019/06/26');
INSERT INTO `attendance_log` VALUES (4, 3, 1, 1, '2019/06/26');
INSERT INTO `attendance_log` VALUES (5, 3, 3, 1, '2019/06/27');

-- ----------------------------
-- Table structure for department
-- ----------------------------
DROP TABLE IF EXISTS `department`;
CREATE TABLE `department`  (
  `dep_Id` int(10) NOT NULL AUTO_INCREMENT,
  `dep_Name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`dep_Id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 6 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of department
-- ----------------------------
INSERT INTO `department` VALUES (1, '门店部');
INSERT INTO `department` VALUES (2, '事业发展部');
INSERT INTO `department` VALUES (3, '采购部');
INSERT INTO `department` VALUES (4, '行政部');
INSERT INTO `department` VALUES (5, '人事部');

-- ----------------------------
-- Table structure for level
-- ----------------------------
DROP TABLE IF EXISTS `level`;
CREATE TABLE `level`  (
  `level_Id` int(11) NOT NULL AUTO_INCREMENT,
  `level_Name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `level_Price` decimal(10, 2) NOT NULL,
  PRIMARY KEY (`level_Id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 26 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of level
-- ----------------------------
INSERT INTO `level` VALUES (1, '门店-实习生', 2000.00);
INSERT INTO `level` VALUES (2, '门店-专一级', 2500.00);
INSERT INTO `level` VALUES (3, '门店-专二级', 3000.00);
INSERT INTO `level` VALUES (4, '门店-专三级', 3500.00);
INSERT INTO `level` VALUES (5, '门店-专四级', 4000.00);
INSERT INTO `level` VALUES (6, '事业发展-实习生', 2500.00);
INSERT INTO `level` VALUES (7, '事业发展-专一级', 3000.00);
INSERT INTO `level` VALUES (8, '事业发展-专二级', 3500.00);
INSERT INTO `level` VALUES (9, '事业发展-专三级', 4000.00);
INSERT INTO `level` VALUES (10, '事业发展-专四级', 4500.00);
INSERT INTO `level` VALUES (11, '采购-实习生', 2000.00);
INSERT INTO `level` VALUES (12, '采购-专一级', 2500.00);
INSERT INTO `level` VALUES (13, '采购-专二级', 3000.00);
INSERT INTO `level` VALUES (14, '采购-专三级', 3500.00);
INSERT INTO `level` VALUES (15, '采购-专四级', 4000.00);
INSERT INTO `level` VALUES (16, '行政-实习生', 3000.00);
INSERT INTO `level` VALUES (17, '行政-专一级', 3500.00);
INSERT INTO `level` VALUES (18, '行政-专二级', 4000.00);
INSERT INTO `level` VALUES (19, '行政-专三级', 4500.00);
INSERT INTO `level` VALUES (20, '行政-专四级', 5000.00);
INSERT INTO `level` VALUES (21, '人事-实习生', 2500.00);
INSERT INTO `level` VALUES (22, '人事-专一级', 3000.00);
INSERT INTO `level` VALUES (23, '人事-专二级', 3500.00);
INSERT INTO `level` VALUES (24, '人事-专三级', 4000.00);
INSERT INTO `level` VALUES (25, '人事-专四级', 4500.00);

-- ----------------------------
-- Table structure for reward
-- ----------------------------
DROP TABLE IF EXISTS `reward`;
CREATE TABLE `reward`  (
  `rew_Id` int(11) NOT NULL AUTO_INCREMENT,
  `rew_Name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `rew_Price` decimal(10, 2) NOT NULL,
  PRIMARY KEY (`rew_Id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of reward
-- ----------------------------
INSERT INTO `reward` VALUES (1, '业务突出贡献奖', 1000.00);
INSERT INTO `reward` VALUES (2, '业务能力奖', 300.00);
INSERT INTO `reward` VALUES (3, '全勤奖', 50.00);

-- ----------------------------
-- Table structure for reward_log
-- ----------------------------
DROP TABLE IF EXISTS `reward_log`;
CREATE TABLE `reward_log`  (
  `rewlog_Id` int(10) NOT NULL AUTO_INCREMENT,
  `staff_Id` int(11) NULL DEFAULT NULL,
  `rew_Id` int(11) NULL DEFAULT NULL,
  `rew_price` decimal(10, 2) NOT NULL,
  `rewlog_Time` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`rewlog_Id`) USING BTREE,
  INDEX `reward_staff`(`staff_Id`) USING BTREE,
  INDEX `reward_rew`(`rew_Id`) USING BTREE,
  CONSTRAINT `FK1lsdusbli368y9oeftprw4kw6` FOREIGN KEY (`staff_Id`) REFERENCES `staff` (`staffId`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `FK5snrol82613adyasla3yb3fdx` FOREIGN KEY (`rew_Id`) REFERENCES `reward` (`rew_Id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `reward_rew` FOREIGN KEY (`rew_Id`) REFERENCES `reward` (`rew_Id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `reward_staff` FOREIGN KEY (`staff_Id`) REFERENCES `staff` (`staffId`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 10 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of reward_log
-- ----------------------------
INSERT INTO `reward_log` VALUES (1, 1, 1, 1000.00, '2019/06/25');
INSERT INTO `reward_log` VALUES (2, 1, 2, 300.00, '2019/06/26');
INSERT INTO `reward_log` VALUES (3, 3, 3, 50.00, '2019/07/01');
INSERT INTO `reward_log` VALUES (8, 1, 1, 200.00, '2019/6/8');
INSERT INTO `reward_log` VALUES (9, 1, 1, 200.00, '2019/6/8');

-- ----------------------------
-- Table structure for role
-- ----------------------------
DROP TABLE IF EXISTS `role`;
CREATE TABLE `role`  (
  `Role_Id` int(11) NOT NULL AUTO_INCREMENT,
  `role_Name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`Role_Id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of role
-- ----------------------------
INSERT INTO `role` VALUES (1, '员工');
INSERT INTO `role` VALUES (2, '管理员');
INSERT INTO `role` VALUES (3, '店长');

-- ----------------------------
-- Table structure for salary_log
-- ----------------------------
DROP TABLE IF EXISTS `salary_log`;
CREATE TABLE `salary_log`  (
  `sallog_Id` int(11) NOT NULL,
  `staff_Id` int(11) NULL DEFAULT NULL,
  `staff_Name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `shop_Name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `level_Name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `sal_Time` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `level_Price` decimal(10, 2) NOT NULL,
  `att_Percent` decimal(10, 2) NOT NULL,
  `total_Subsidy` decimal(10, 2) NOT NULL,
  `total_reward` decimal(10, 2) NOT NULL,
  `salary_Old` decimal(10, 2) NOT NULL,
  `salary_True` decimal(10, 2) NOT NULL,
  `sallog_Remark` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`sallog_Id`) USING BTREE,
  INDEX `staff_log_Id`(`staff_Id`) USING BTREE,
  CONSTRAINT `FKnurxdm7n3lqnjgbe3r8uw9340` FOREIGN KEY (`staff_Id`) REFERENCES `staff` (`staffId`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `staff_log_Id` FOREIGN KEY (`staff_Id`) REFERENCES `staff` (`staffId`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of salary_log
-- ----------------------------
INSERT INTO `salary_log` VALUES (1, 1, '@chenanqi', '港饮之饮', '门店-专四级', '2019/06/31', 4000.00, 80.00, 200.00, 1000.00, 5200.00, 5120.00, '要加油哟，24k纯帅');
INSERT INTO `salary_log` VALUES (2, 2, 'xiaobai', '原始部落串串', '门店-专四级', '2019/06/31', 4000.00, 200.00, 150.00, 300.00, 4450.00, 4250.00, '万千少女梦 come on！man');
INSERT INTO `salary_log` VALUES (3, 3, 'badgril', '港饮之饮', '事业发展-专一级', '2019/06/31', 3000.00, 60.00, 150.00, 50.00, 3200.00, 3040.00, '哎哟！还不错哦！');

-- ----------------------------
-- Table structure for shop
-- ----------------------------
DROP TABLE IF EXISTS `shop`;
CREATE TABLE `shop`  (
  `shop_Id` int(11) NOT NULL AUTO_INCREMENT,
  `shop_Name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `shop_Address` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `shop_state` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `shop_supervisor` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `shop_remark` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`shop_Id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of shop
-- ----------------------------
INSERT INTO `shop` VALUES (1, '港饮之饮', '南湖大道47号', '1', '@chenanqi', '24k纯帅');
INSERT INTO `shop` VALUES (2, '原始部落串串', '学生街21号', '1', 'xiaobai', '万千少女梦');

-- ----------------------------
-- Table structure for staff
-- ----------------------------
DROP TABLE IF EXISTS `staff`;
CREATE TABLE `staff`  (
  `staffId` int(10) NOT NULL AUTO_INCREMENT,
  `staffName` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `staffPwd` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `staffSex` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `staffAddress` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `staffTel` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `staffEmail` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `staffState` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `level_Id` int(11) NULL DEFAULT NULL,
  `roles_Id` int(11) NULL DEFAULT NULL,
  `dep_Id` int(11) NULL DEFAULT NULL,
  `shop_Id` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`staffId`) USING BTREE,
  INDEX `staff_shop`(`shop_Id`) USING BTREE,
  INDEX `staff_level`(`level_Id`) USING BTREE,
  INDEX `staff_dep`(`dep_Id`) USING BTREE,
  INDEX `staff_roles`(`roles_Id`) USING BTREE,
  CONSTRAINT `FK5m13xmclav0pt1k5chxkdwex3` FOREIGN KEY (`level_Id`) REFERENCES `level` (`level_Id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `FKistssg7jbq1b2pcdlug7hobiq` FOREIGN KEY (`roles_Id`) REFERENCES `role` (`Role_Id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `FKk4xhi49ywxwh6kivmp8ux9yfr` FOREIGN KEY (`dep_Id`) REFERENCES `department` (`dep_Id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `FKrcydhvn6wbiouophxxh7iiosn` FOREIGN KEY (`shop_Id`) REFERENCES `shop` (`shop_Id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `staff_dep` FOREIGN KEY (`dep_Id`) REFERENCES `department` (`dep_Id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `staff_level` FOREIGN KEY (`level_Id`) REFERENCES `level` (`level_Id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `staff_roles` FOREIGN KEY (`roles_Id`) REFERENCES `role` (`Role_Id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `staff_shop` FOREIGN KEY (`shop_Id`) REFERENCES `shop` (`shop_Id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of staff
-- ----------------------------
INSERT INTO `staff` VALUES (1, '@chenanqi', 'galigaygay', '男', '黄冈科技职业学院', '13838383388', '38383388@qq.com', '0', 5, 3, 1, 1);
INSERT INTO `staff` VALUES (2, 'xiaobai', 'xiaobai', '男', '黄冈科技职业学院', '88088208820', '36363366@qq.com', '0', 5, 3, 1, 1);
INSERT INTO `staff` VALUES (3, 'badgril', 'badgril', '女', '黄冈师范学院', '999999', '9696969@qq.com', '0', 7, 1, 3, NULL);
INSERT INTO `staff` VALUES (4, 'guanliyuan', 'guanliyuan', '男', '黄冈科技职业学院', '777777', '777777@qq.com', '1', NULL, 2, NULL, NULL);

-- ----------------------------
-- Table structure for subsidy
-- ----------------------------
DROP TABLE IF EXISTS `subsidy`;
CREATE TABLE `subsidy`  (
  `subsidy_Id` int(11) NOT NULL AUTO_INCREMENT,
  `subsidy_Name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `subsidy_Money` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`subsidy_Id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of subsidy
-- ----------------------------
INSERT INTO `subsidy` VALUES (1, '交通补助', '150');
INSERT INTO `subsidy` VALUES (2, '午餐补助', '300');

-- ----------------------------
-- Table structure for subsidy_log
-- ----------------------------
DROP TABLE IF EXISTS `subsidy_log`;
CREATE TABLE `subsidy_log`  (
  `stblog_Id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_Id` int(11) NULL DEFAULT NULL,
  `sunsidy_Id` int(11) NULL DEFAULT NULL,
  `subsidy_Money` decimal(10, 2) NOT NULL,
  `sublog_Time` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`stblog_Id`) USING BTREE,
  INDEX `sunsidy_Id`(`sunsidy_Id`) USING BTREE,
  INDEX `subsidy_staff`(`staff_Id`) USING BTREE,
  CONSTRAINT `FKbmijdonnn9uy49oequ25w2lel` FOREIGN KEY (`staff_Id`) REFERENCES `staff` (`staffId`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `FKy7pf4vowqnyis0sbxd96yey` FOREIGN KEY (`sunsidy_Id`) REFERENCES `subsidy` (`subsidy_Id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `subsidy_staff` FOREIGN KEY (`staff_Id`) REFERENCES `staff` (`staffId`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `sunsidy_Id` FOREIGN KEY (`sunsidy_Id`) REFERENCES `subsidy` (`subsidy_Id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of subsidy_log
-- ----------------------------
INSERT INTO `subsidy_log` VALUES (1, 1, 2, 200.00, '2019/06/21');
INSERT INTO `subsidy_log` VALUES (2, 2, 1, 150.00, '2019/06/25');
INSERT INTO `subsidy_log` VALUES (3, 3, 1, 150.00, '2019/06/25');

SET FOREIGN_KEY_CHECKS = 1;
