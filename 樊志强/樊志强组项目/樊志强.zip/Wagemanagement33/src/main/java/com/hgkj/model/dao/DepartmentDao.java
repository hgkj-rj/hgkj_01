package com.hgkj.model.dao;


import com.hgkj.model.entity.Department;

import java.util.List;

public interface DepartmentDao {
    //查询所有部门类别
    public List<Department> alldepartmentDao();
    //添加部门类别
    public boolean insertdepartmentDao(Department department);
    //删除部门类别
    public boolean deletedepartmentDao(int id);
    //修改部门类别
    public boolean updatedepartmentDao(Department department);
    //根据Id获取部门信息
    public Department getdepartmentByIdDao(int id);
}
