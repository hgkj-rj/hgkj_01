/*
 Navicat Premium Data Transfer

 Source Server         : shopcar
 Source Server Type    : MySQL
 Source Server Version : 50720
 Source Host           : localhost:3306
 Source Schema         : travelnetwork

 Target Server Type    : MySQL
 Target Server Version : 50720
 File Encoding         : 65001

 Date: 07/07/2019 21:20:44
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for orderdetail
-- ----------------------------
DROP TABLE IF EXISTS `orderdetail`;
CREATE TABLE `orderdetail`  (
  `odID` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `lineName` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `price` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `orderDate` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `travelDate` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `total` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `lineID` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `state` int(11) NOT NULL,
  `customerID` int(11) NOT NULL,
  PRIMARY KEY (`odID`) USING BTREE,
  INDEX `FK_order_line_lineID`(`lineID`) USING BTREE,
  INDEX `FK_order_cust_custID`(`customerID`) USING BTREE,
  CONSTRAINT `FK_order_cust_custID` FOREIGN KEY (`customerID`) REFERENCES `customer` (`customerID`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `FK_order_line_lineID` FOREIGN KEY (`lineID`) REFERENCES `line` (`lineID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of orderdetail
-- ----------------------------
INSERT INTO `orderdetail` VALUES ('tur296', '凤凰古城', '2000.00', '2019-07-07', '2019-07-08', '258', '1', 1, 1);
INSERT INTO `orderdetail` VALUES ('tur509', '凤凰古城', '2000.00', '2019-07-07', '2019-07-08', '258', '1', 1, 1);

SET FOREIGN_KEY_CHECKS = 1;
