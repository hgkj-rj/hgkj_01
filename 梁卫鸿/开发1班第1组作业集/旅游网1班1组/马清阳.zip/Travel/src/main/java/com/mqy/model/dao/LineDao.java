package com.mqy.model.dao;

import com.mqy.model.entity.Line;

import java.util.List;

public interface LineDao {
    /**
     * 获取总页数
     * @param pageSize
     * @return
     */
    public int getTotalPageDao(int pageSize);

    /**
     * 查询所有线路
     * @return
     */
    public List<Line> allLineDao(int pageIndex,int pageSize);

    /**
     * 查询所有团购线路
     * @return
     */
    public List<Line> teamLineDao(int pageIndex,int pageSize);

    /**
     * 添加线路
     * @param line
     * @return
     */
    public void addLineDao(Line line);

    /**
     * 删除线路
     * @param lineId
     * @return
     */
    public void deleteLineDao(String lineId);

    /**
     * 修改线路
     * @param line
     * @return
     */
    public void updateLineDao(Line line);

    /**
     * 获取线路
     * @param lineId
     * @return
     */
    public Line getLineDao(String lineId);
}
