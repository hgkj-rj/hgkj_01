package com.workmoney.controller.action;

import com.workmoney.model.entity.Staff;
import com.workmoney.model.entity.StaffFuBen;
import com.workmoney.model.service.EmployeeService;
import com.workmoney.model.service.StaffService;
import org.apache.struts2.ServletActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import javax.servlet.http.HttpSession;
import java.util.List;

/**
 * user@Bright Rain .
 * 2019/6/26.
 */
@ParentPackage("struts-default")
@Namespace("/")
@Controller
public class EmployeeControllerAction {

    @Autowired
    private StaffService staffService;

    @Autowired
    private EmployeeService service;

    private StaffFuBen staffFuBen;

    /**
     * 修改
     */
    @Action(value = "/editEmpAction",results = {@Result(name = "success",type = "redirectAction",location = "getEmpAllAction")})

    public String editEmpAction(){
        service.updateEmployeeById(staffFuBen);
        return "success";
    }

    /**
     * 去往编辑页面
     */
    @Action(value = "/toEditEmp",results = {@Result(name = "success",type = "redirect",location = "html/empEdit.jsp")})
    public String toEditEmp(){
        HttpSession session = ServletActionContext.getRequest().getSession();
        StaffFuBen staffFuBen1 = service.getEmpByIdService(staffFuBen);
        session.setAttribute("staffFuBen",staffFuBen1);
        return "success";
    }

    /**
     * 删除员工
     */

    @Action(value = "/delEmpAction",results = {@Result(name = "success",type = "redirectAction",location = "getEmpAllAction")})
    public String delEmpAction(){
        service.delEmpService(staffFuBen);
        return "success";
    }

    /**
     * 添加员工
     */
    @Action(value = "/addEmpAction",results = {@Result(name = "success",type = "redirectAction",location = "getEmpAllAction")})
    public String addEmpAction(){
        service.addEmployee(staffFuBen);
        return "success";
    }

    /**
     * 跳转到员工跳转页面
     */

    @Action(value = "/goEmpAddAction",results = {@Result(name = "success",type = "redirect",location = "html/empAdd.jsp")})
    public String goEmpAddAction(){

        return "success";
    }

    /**
     * 获取所有员工
     * @return
     */
    @Action(value = "/getEmpAllAction",results = {@Result(name = "success",type = "redirect",location = "html/empList.jsp"),
            @Result(name = "error",type = "redirect",location = "error.jsp")
    })
    public String getAllEmp(){
        HttpSession session = ServletActionContext.getRequest().getSession();
        List<Staff> staffList = staffService.getStaffListSercharService();
       // List<StaffFuBen> staffLists = service.getAllStaffFuBenService();
        session.setAttribute("staffList",staffList);
        return "success";
    }

    public StaffService getStaffService() {
        return staffService;
    }

    public void setStaffService(StaffService staffService) {
        this.staffService = staffService;
    }

    public StaffFuBen getStaffFuBen() {
        return staffFuBen;
    }

    public void setStaffFuBen(StaffFuBen staffFuBen) {
        this.staffFuBen = staffFuBen;
    }
}
