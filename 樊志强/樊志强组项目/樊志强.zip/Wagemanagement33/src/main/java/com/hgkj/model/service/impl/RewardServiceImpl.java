package com.hgkj.model.service.impl;

import com.hgkj.model.dao.RewardDao;
import com.hgkj.model.entity.Reward;
import com.hgkj.model.service.RewardService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class RewardServiceImpl implements RewardService {
    @Autowired
    private RewardDao rewardDao;

    public void setRewardDao(RewardDao rewardDao) {
        this.rewardDao = rewardDao;
    }

    @Override
    public List<Reward> allrewardService() {
        return rewardDao.allrewardDao();
    }

    @Override
    public boolean insertrewardService(Reward reward) {
        return rewardDao.insertrewardDao(reward);
    }

    @Override
    public boolean deleterewardService(int id) {
        return rewardDao.deleterewardDao(id);
    }

    @Override
    public boolean updaterewardService(Reward reward) {
        return rewardDao.updaterewardDao(reward);
    }

    @Override
    public Reward getrewardByIdService(int id) {
        return rewardDao.getrewardByIdDao(id);
    }
}
