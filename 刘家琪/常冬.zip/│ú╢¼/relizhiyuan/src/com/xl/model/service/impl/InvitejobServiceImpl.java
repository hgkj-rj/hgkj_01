package com.xl.model.service.impl;

import com.xl.model.dao.InvitejobDao;
import com.xl.model.dao.impl.InvitejobDaoImpl;
import com.xl.model.entity.Invitejob;
import com.xl.model.service.InvitejobService;

import java.util.List;

public class InvitejobServiceImpl implements InvitejobService {
    private InvitejobDao InvitejobDao=new InvitejobDaoImpl();
    @Override
    public int invitejobService(int pageSize) {
        return InvitejobDao.invitejobDao(pageSize);
    }

    @Override
    public List<Invitejob> allInvitejobService(int pageIndex, int pageSize) {
        return InvitejobDao.allInvitejobDao(pageIndex,pageSize);
    }

    @Override
    public Invitejob getInvitejobByIdService(int invitejobId) {
        return InvitejobDao.getInvitejobByIdDao(invitejobId);
    }

    @Override
    public boolean addInvitejobService(Invitejob invitejob) {

        return InvitejobDao.addInvitejobDao(invitejob);
    }

    @Override
    public boolean deleteInvitejobService(Invitejob invitejob) {

        return InvitejobDao.deleteInvitejobDao(invitejob);
    }

    @Override
    public boolean updateInvitejobService(Invitejob invitejob) {
        return InvitejobDao.updateInvitejobDao(invitejob);
    }
}
