package com.xl.model.entity;

public class Employee {
    private Integer employeeId;
    private String employeeName;
    private String employeeSex;
    private String departmentId;
    private String employeeGongzhong;
    private String employeeXueli;
    private String employeeTime;
    public Employee(){}
    public Employee(String employeeName, String employeeSex, String departmentId, String employeeGongzhong, String employeeXueli, String employeeTime) {
        this.employeeName = employeeName;
        this.employeeSex = employeeSex;
        this.departmentId = departmentId;
        this.employeeGongzhong = employeeGongzhong;
        this.employeeXueli = employeeXueli;
        this.employeeTime = employeeTime;
    }

    public Integer getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(Integer employeeId) {
        this.employeeId = employeeId;
    }

    public String getEmployeeName() {
        return employeeName;
    }

    public void setEmployeeName(String employeeName) {
        this.employeeName = employeeName;
    }

    public String getEmployeeSex() {
        return employeeSex;
    }

    public void setEmployeeSex(String employeeSex) {
        this.employeeSex = employeeSex;
    }

    public String getDepartmentId() {
        return departmentId;
    }

    public void setDepartmentId(String departmentId) {
        this.departmentId = departmentId;
    }

    public String getEmployeeGongzhong() {
        return employeeGongzhong;
    }

    public void setEmployeeGongzhong(String employeeGongzhong) {
        this.employeeGongzhong = employeeGongzhong;
    }

    public String getEmployeeXueli() {
        return employeeXueli;
    }

    public void setEmployeeXueli(String employeeXueli) {
        this.employeeXueli = employeeXueli;
    }

    public String getEmployeeTime() {
        return employeeTime;
    }

    public void setEmployeeTime(String employeeTime) {
        this.employeeTime = employeeTime;
    }
}
