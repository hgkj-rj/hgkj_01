package com.hgkj.model.service.impl;

import com.hgkj.model.dao.LineDao;
import com.hgkj.model.entity.Line;
import com.hgkj.model.service.LineService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class LineServiceImpl implements LineService {
    @Autowired
    private LineDao lineDao;

    public LineDao getLineDao() {
        return lineDao;
    }

    public void setLineDao(LineDao lineDao) {
        this.lineDao = lineDao;
    }

    @Override
    public boolean insertLineService(Line line) {
        return lineDao.insertLineDao(line);
    }

    @Override
    public List<Line> allLineService() {
        return lineDao.allLineDao();
    }

    @Override
    public boolean delLineService(String lineId) {
        return lineDao.delLineDao(lineId);
    }

    @Override
    public boolean updLineService(Line line) {
        return lineDao.updLineDao(line);
    }

    @Override
    public Line lineByIdService(String lineId) {
        return lineDao.lineByIdDao(lineId);
    }

    @Override
    public Line teamByIdService(String lineId) {
        return lineDao.teamByIdDao(lineId);
    }

    @Override
    public boolean updTeamService(Line line) {
        return lineDao.updTeamDao(line);
    }

    @Override
    public Line SetTeamByIdService(String lineId) {
        return lineDao.teamByIdDao(lineId);
    }

    @Override
    public boolean setTeamMsgService(Line line) {
        return lineDao.updTeamDao(line);
    }
}
