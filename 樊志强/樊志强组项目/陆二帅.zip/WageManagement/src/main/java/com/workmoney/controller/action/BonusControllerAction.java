package com.workmoney.controller.action;

import com.workmoney.model.entity.Reward;
import com.workmoney.model.service.RewardService;
import org.apache.struts2.ServletActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import javax.servlet.http.HttpSession;
import java.util.List;

/**
 * user@Bright Rain .
 * 2019/6/29.
 */
@ParentPackage("struts-default")
@Namespace("/")
@Controller
public class BonusControllerAction {

    @Autowired
    private RewardService rewardService;

    private Reward reward;

    @Action(value = "/addRewardAction",results = {@Result(name = "success",type = "redirectAction",location = "getBonusListAction")})
    public String addRewardAction(){
        rewardService.addRewardService(reward);
        return "success";
    }

    /**
     * 删除
     */
    @Action(value = "/delRewordByIdAction",results = {@Result(name = "success",type = "redirectAction",location = "getBonusListAction")})
    public String delRewordByIdAction(){
        rewardService.delRewordByIdService(reward);
        return "success";
    }


    /**
     * 修改
     * @return
     */
    @Action(value = "/editRewardAction",results = {@Result(name = "success",type = "redirectAction",location = "getBonusListAction")})
    public String editRewardAction(){
        rewardService.editRewardService(reward);
        return "success";
     }

    /**
     * 去望修改页面
     * @return
     */
    @Action(value = "/goEditRewordByIdAction",results = {@Result(name = "success",type = "redirect",location = "html/bonusEdit.jsp")})
    public String goEditRewordByIdAction(){
        HttpSession session = ServletActionContext.getRequest().getSession();
        Reward rewardById = rewardService.getRewardById(reward);
        session.setAttribute("reward",rewardById);
        return "success";
    }

    /**
     * 获取所有奖金信息
     * @return
     */
    @Action(value = "/getBonusListAction",results = {@Result(name = "success",type = "redirect",location = "html/bonusList.jsp")})
    public String getBonusListAction(){
        HttpSession session = ServletActionContext.getRequest().getSession();
        List<Reward> rewardType = rewardService.getAllRewardType();
        session.setAttribute("rewardType",rewardType);
        return "success";
    }

    public Reward getReward() {
        return reward;
    }

    public void setReward(Reward reward) {
        this.reward = reward;
    }
}
