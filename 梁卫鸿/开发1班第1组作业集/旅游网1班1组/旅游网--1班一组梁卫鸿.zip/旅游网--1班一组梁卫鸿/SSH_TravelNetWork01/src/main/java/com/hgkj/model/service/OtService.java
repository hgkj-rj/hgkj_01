package com.hgkj.model.service;

import com.hgkj.model.entity.OtDetail;

import java.util.List;

public interface OtService {
    public boolean otAddService(String odId,String touristId);
    public boolean orderAddService(String odId,String lineName,String price,String orderDate,String travelDate,String total,
                               String lineId,int state,int customerId);
    public boolean touristAddService(String touristId,String idCard,String tel,String realName);
    public OtDetail OtIdDao(int  otId);
    public List<OtDetail> otAllService();
}
