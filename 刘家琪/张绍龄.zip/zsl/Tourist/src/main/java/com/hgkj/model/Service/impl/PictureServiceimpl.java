package com.hgkj.model.Service.impl;

import com.hgkj.model.Dao.PictureDao;
import com.hgkj.model.Service.PictureService;
import com.hgkj.model.entity.Picture;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PictureServiceimpl implements PictureService {
    @Autowired
    private PictureDao pictureDao;

    public PictureDao getPictureDao() {
        return pictureDao;
    }

    public void setPictureDao(PictureDao pictureDao) {
        this.pictureDao = pictureDao;
    }

    @Override
    public List<Picture> allPictureService() {
        return pictureDao.allPictureDao();
    }

    @Override
    public List<Picture> findPictureService(String lineId) {
        return pictureDao.findPictureDao(lineId);
    }

    @Override
    public List<Picture> findlineService(String lineTypeId) {
        return pictureDao.findlineDao(lineTypeId);
    }

    @Override
    public boolean addPictureService(Picture picture) {
        return pictureDao.addPictureDao(picture);
    }

    @Override
    public boolean updatePictureService(Picture picture) {
        return pictureDao.updatePictureDao(picture);
    }
}
