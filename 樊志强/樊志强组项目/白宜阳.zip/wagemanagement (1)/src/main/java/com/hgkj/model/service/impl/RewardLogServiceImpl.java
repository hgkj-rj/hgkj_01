package com.hgkj.model.service.impl;

import com.hgkj.model.dao.RewardLogDao;
import com.hgkj.model.entity.RewardLog;
import com.hgkj.model.service.RewardLogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RewardLogServiceImpl implements RewardLogService {
    @Autowired
    private RewardLogDao rewardLogDao;

    public void setRewardLogDao(RewardLogDao rewardLogDao) {
        this.rewardLogDao = rewardLogDao;
    }

    @Override
    public List<RewardLog> allRewardLogService() {
        return rewardLogDao.allRewardLogDao();
    }

    @Override
    public boolean addRewardLogService(RewardLog rewardLog) {
        return rewardLogDao.addRewardLogDao(rewardLog);
    }

    @Override
    public boolean updateRewardLogService(RewardLog rewardLog) {
        return rewardLogDao.updateRewardLogDao(rewardLog);
    }

    @Override
    public boolean deleteRewardLogService(int rewlogId) {
        return rewardLogDao.deleteRewardLogDao(rewlogId);
    }

    @Override
    public RewardLog getByIdRewardLogService(int rewlogId) {
        return rewardLogDao.getByIdRewardLogDao(rewlogId);
    }

    @Override
    public List<RewardLog> alllRewardLogService(RewardLog rewardLog) {
        return rewardLogDao.alllRewardLogDao(rewardLog);
    }
}
