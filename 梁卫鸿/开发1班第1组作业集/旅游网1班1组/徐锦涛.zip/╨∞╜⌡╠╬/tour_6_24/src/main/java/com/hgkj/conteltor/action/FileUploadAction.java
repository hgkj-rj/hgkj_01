package com.hgkj.conteltor.action;

import com.hgkj.model.entity.Images;
import com.hgkj.model.entity.Picture;
import com.hgkj.model.service.ImagesService;
import com.opensymphony.xwork2.ActionSupport;
import org.apache.commons.io.FileUtils;
import org.apache.struts2.ServletActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import java.io.File;
import java.io.IOException;
import java.util.List;

@Controller
@Namespace("/")
@ParentPackage("struts-default")
        public class FileUploadAction extends ActionSupport {
        @Autowired
        private ImagesService imagesService;
        private Picture picture;
       private File uploadImage; //得到上传的文件
        private String uploadImageContentType; //得到文件的类型
        private String uploadImageFileName; //得到文件的名称
    public ImagesService getImagesService() {
        return imagesService;
    }
    public void setImagesService(ImagesService imagesService) {
        this.imagesService = imagesService;
    }
    private Images images;
      @Action(value = "FileUpload",results = @Result(name = "addsuccess",type = "redirect",location = "images.jsp"))
        public String FileUpload(){
          System.out.println(this.getUploadImage()+"4444444444444");
          System.out.println(this.getUploadImageFileName()+"5555555555555");
          System.out.println(this.getUploadImageContentType()+"666666666666");
            //获取要保存文件夹的物理路径(绝对路径)
            String realPath=ServletActionContext.getServletContext().getRealPath("/images/")+uploadImageFileName;
            File file = new File(realPath);
            String a="images/"+this.getUploadImageFileName();
            try {
                //保存文件
                FileUtils.copyFile(uploadImage, file);
                boolean rs=imagesService.imagesInsertService(picture.getLineID(),picture.getIntroduction(),realPath);
                if(rs){
                    return "addsuccess";
                }
                return "adderror";

            } catch (IOException e) {
                e.printStackTrace();
            }
            return "SUCCESS";
        }
    @Action(value = "showImages",results = @Result(name = "show",type = "redirect",location = "images.jsp"))
    public String showImages(){
        List<Picture> imagesList=imagesService.imagesAllService();
        ServletActionContext.getRequest().getSession().setAttribute("imagesList",imagesList);
        return "show";
    }

    public Picture getPicture() {
        return picture;
    }

    public void setPicture(Picture picture) {
        this.picture = picture;
    }

    public Images getImages() {
            return images;
        }

        public void setImages(Images images) {
            this.images = images;
        }

        public File getUploadImage() {
                return uploadImage;
            }

        public void setUploadImage(File uploadImage) {
            this.uploadImage = uploadImage;
        }

        public String getUploadImageContentType() {
            return uploadImageContentType;
        }

        public void setUploadImageContentType(String uploadImageContentType) {
            this.uploadImageContentType = uploadImageContentType;
        }

        public String getUploadImageFileName() {
            return uploadImageFileName;
        }

        public void setUploadImageFileName(String uploadImageFileName) {
            this.uploadImageFileName = uploadImageFileName;
        }
    }

