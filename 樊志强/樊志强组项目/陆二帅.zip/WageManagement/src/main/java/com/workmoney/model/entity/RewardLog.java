package com.workmoney.model.entity;

import java.math.BigDecimal;
import java.util.Objects;

/**
 * user@Bright Rain .
 * 2019/6/21.
 */
public class RewardLog {
    private int rewlogId;
    private BigDecimal rewPrice;
    private String rewlogTime;

    private Reward reward;

    private Staff staff;

    public Reward getReward() {
        return reward;
    }

    public void setReward(Reward reward) {
        this.reward = reward;
    }

    public Staff getStaff() {
        return staff;
    }

    public void setStaff(Staff staff) {
        this.staff = staff;
    }

    public int getRewlogId() {
        return rewlogId;
    }

    public void setRewlogId(int rewlogId) {
        this.rewlogId = rewlogId;
    }


    public BigDecimal getRewPrice() {
        return rewPrice;
    }

    public void setRewPrice(BigDecimal rewPrice) {
        this.rewPrice = rewPrice;
    }

    public String getRewlogTime() {
        return rewlogTime;
    }

    public void setRewlogTime(String rewlogTime) {
        this.rewlogTime = rewlogTime;
    }


}
