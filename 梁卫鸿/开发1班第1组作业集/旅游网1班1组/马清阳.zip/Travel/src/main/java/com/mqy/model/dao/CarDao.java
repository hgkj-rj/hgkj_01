package com.mqy.model.dao;

import com.mqy.model.entity.Car;

import java.util.List;

/**
 * @Author:马清阳
 * @Date:2019/6/26 22:22
 * InteliJ IDEA 1.8
 */
public interface CarDao {
    /**
     * 查看购物车
     * @return
     */
    public List<Car> carListDao();

    /**
     * 添加购物记录
     * @return
     */
    public boolean addCarDao(Car car);

    /**
     * 删除购物记录
     * @return
     */
    public boolean deleteCarDao(int carId);
}
