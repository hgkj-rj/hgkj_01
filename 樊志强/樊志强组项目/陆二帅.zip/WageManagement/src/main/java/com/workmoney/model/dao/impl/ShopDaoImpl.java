package com.workmoney.model.dao.impl;

import com.workmoney.model.dao.ShopDao;
import com.workmoney.model.entity.Shop;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * user@Bright Rain .
 * 2019/6/30.
 */
@Repository
@Transactional
public class ShopDaoImpl implements ShopDao {

    @Autowired
    private SessionFactory sessionFactory;

    @Override
    public List<Shop> getAllShopDao() {
        Session session = sessionFactory.getCurrentSession();
        String hql = "from Shop ";
        List<Shop> shopList = session.createQuery(hql, Shop.class).list();

        return shopList;
    }

    @Override
    public Shop getShopByIdDao(Shop shop) {
        Session session = sessionFactory.getCurrentSession();
        Shop shop1 = session.get(Shop.class, shop.getShopId());
        return shop1;
    }

    @Override
    public void delShopByIdDao(Shop shop) {
        Session session = sessionFactory.getCurrentSession();
         session.delete(shop);

    }

    @Override
    public void addShopDao(Shop shop) {
        Session session = sessionFactory.getCurrentSession();
        session.save(shop);
    }

    @Override
    public void updateShopByIdDao(Shop shop) {
        Session session = sessionFactory.getCurrentSession();
        session.update(shop);
    }

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }
}
