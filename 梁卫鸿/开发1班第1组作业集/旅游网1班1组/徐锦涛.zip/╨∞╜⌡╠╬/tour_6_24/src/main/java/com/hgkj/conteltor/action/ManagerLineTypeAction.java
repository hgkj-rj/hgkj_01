package com.hgkj.conteltor.action;

import com.hgkj.model.entity.Linetype;
import com.hgkj.model.service.LineTypeService;
import org.apache.commons.io.FileUtils;
import org.apache.struts2.ServletActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import java.io.File;
import java.io.IOException;
import java.util.List;

@Controller
@Namespace("/")
@ParentPackage("json-default")
public class ManagerLineTypeAction {
    @Autowired
    private LineTypeService lineTypeService;
    private Linetype linetype;
    private String message;
    private File uploadImage; //得到上传的文件
    private String uploadImageContentType; //得到文件的类型
    private String uploadImageFileName; //得到文件的名称

    public LineTypeService getLineTypeService() {
        return lineTypeService;
    }

    public void setLineTypeService(LineTypeService lineTypeService) {
        this.lineTypeService = lineTypeService;
    }
    @Action(value = "allManagerLineType",results = @Result(name = "all",type = "redirect",location = "/ht/ck_xianlu_leixing.jsp"))
    public String allManagerLineType(){
        List<Linetype> linetypeList=lineTypeService.lineTypeAllService();
        ServletActionContext.getRequest().getSession().setAttribute("linetypeList",linetypeList);
        return "all";
    }
    @Action(value = "addLineType",results = @Result(name = "addsuccess",type = "redirect",location = "ht/_right.jsp"))
    public String addLineType(){
        String realPath=ServletActionContext.getServletContext().getRealPath("/ht/images/")+uploadImageFileName;
        File file = new File(realPath);
        String a="images/"+this.getUploadImageFileName();
        try {
            //保存文件
            FileUtils.copyFile(uploadImage,file);
            boolean rs=lineTypeService.lineTypeAddService(linetype.getLineTypeID(),linetype.getTypeName(),a);
            if(rs){
                return "addsuccess";
            }
            return "adderror";
        } catch (IOException e) {
            e.printStackTrace();
        }
        return "adderror";
    }
    @Action(value = "ManagerlineTypeDelAction",results = {@Result(name = "del",type = "json",params = {"root","message"})})
    public String ManagerlineTypeDelAction(){
        boolean rs= lineTypeService.lineTypeDeleteService(linetype.getLineTypeID());
        if(rs){
            message="success";
            return "del";
        }
        return "delerror";
    }
    @Action(value = "lineTypeFindAction",results = {@Result(name = "find",type = "redirect",location = "/ht/updatelinetype.jsp")})
    public String lineTypeIdAction(){
        Linetype linetype1=lineTypeService.lineTypeIdService(linetype.getLineTypeID());
        ServletActionContext.getRequest().getSession().setAttribute("linetype1",linetype1);
        return "find";
    }
    @Action(value = "lineTypeUpdateAction",results = {@Result(name = "update",type = "redirectAction",params = {"actionName","allManagerLineType"})})
    public String lineTypeUpdateAction(){
        String realPath=ServletActionContext.getServletContext().getRealPath("/ht/images/")+uploadImageFileName;
        File file = new File(realPath);
        String a="images/"+this.getUploadImageFileName();
        try {
            //保存文件
            FileUtils.copyFile(uploadImage,file);
            boolean rs=lineTypeService.lineTypeUpdateService(linetype.getLineTypeID(),linetype.getTypeName(),a);
            if(rs){
                return "update";
            }
            return "adderror";
        } catch (IOException e) {
            e.printStackTrace();
        }
        return "adderror";
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Linetype getLinetype() {
        return linetype;
    }

    public void setLinetype(Linetype linetype) {
        this.linetype = linetype;
    }

    public File getUploadImage() {
        return uploadImage;
    }

    public void setUploadImage(File uploadImage) {
        this.uploadImage = uploadImage;
    }

    public String getUploadImageContentType() {
        return uploadImageContentType;
    }

    public void setUploadImageContentType(String uploadImageContentType) {
        this.uploadImageContentType = uploadImageContentType;
    }

    public String getUploadImageFileName() {
        return uploadImageFileName;
    }

    public void setUploadImageFileName(String uploadImageFileName) {
        this.uploadImageFileName = uploadImageFileName;
    }
}
