package com.workmoney.model.service;

import com.workmoney.model.entity.Attendance;

import java.util.List;

/**
 * user@Bright Rain .
 * 2019/6/29.
 */
public interface KaoQinService {
    /**
     * 获取所有考勤
     * @return
     */
    List<Attendance> getAllAttendanceService();
    /**
     * 添加考勤
     * @return
     */
    void addAttendanceService(Attendance Attendance);
    /**
     * 删除考勤
     * @return
     */
    void delAttendanceService(Attendance Attendance);
    /**
     * 获取考勤
     * @return
     */
    Attendance getAttendanceService(Attendance Attendance);
    /**
     * 修改考勤
     * @return
     */
    void updateAttendance(Attendance Attendance);
}
