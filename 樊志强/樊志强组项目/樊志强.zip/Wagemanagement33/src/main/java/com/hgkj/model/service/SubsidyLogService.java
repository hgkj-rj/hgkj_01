package com.hgkj.model.service;

import com.hgkj.model.entity.SubsidyLog;

import java.util.List;

public interface SubsidyLogService {
    //查询所有员工补贴记录
    public List<SubsidyLog> allsubsidyLogService();
    //添加员工补贴记录
    public boolean insertsubsidyLogService(SubsidyLog subsidyLog);
    //删除员工补贴记录
    public boolean deletesubsidyLogService(int id);
    //修改员工补贴记录
    public boolean updatesubsidyLogService(SubsidyLog subsidyLog);
    //根据Id获取员工补贴记录
    public SubsidyLog getsubsidyLogByIdService(int id);
}
