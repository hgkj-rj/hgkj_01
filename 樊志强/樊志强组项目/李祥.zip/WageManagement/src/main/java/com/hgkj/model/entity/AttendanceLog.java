package com.hgkj.model.entity;

public class AttendanceLog {
    private Integer attenlogId;
    private Integer attlogCount;
    private String attlogTime;

    public Integer getAttenlogId() {
        return attenlogId;
    }

    public void setAttenlogId(Integer attenlogId) {
        this.attenlogId = attenlogId;
    }

    public Integer getAttlogCount() {
        return attlogCount;
    }

    public void setAttlogCount(Integer attlogCount) {
        this.attlogCount = attlogCount;
    }

    public String getAttlogTime() {
        return attlogTime;
    }

    public void setAttlogTime(String attlogTime) {
        this.attlogTime = attlogTime;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        AttendanceLog that = (AttendanceLog) o;

        if (attenlogId != null ? !attenlogId.equals(that.attenlogId) : that.attenlogId != null) return false;
        if (attlogCount != null ? !attlogCount.equals(that.attlogCount) : that.attlogCount != null) return false;
        if (attlogTime != null ? !attlogTime.equals(that.attlogTime) : that.attlogTime != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = attenlogId != null ? attenlogId.hashCode() : 0;
        result = 31 * result + (attlogCount != null ? attlogCount.hashCode() : 0);
        result = 31 * result + (attlogTime != null ? attlogTime.hashCode() : 0);
        return result;
    }
}
