package com.mqy.model.service.impl;

import com.mqy.model.service.OrderdetailService;

/**
 * @Author:马清阳
 * @Date:2019/6/26 22:44
 * InteliJ IDEA 1.8
 */
public class OrderdetailServiceImpl implements OrderdetailService {
}
