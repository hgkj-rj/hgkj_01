package com.hgkj.model.dao.impl;

import com.hgkj.model.dao.CustLoginDao;
import com.hgkj.model.entity.Customer;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
@Transactional
public class CustLoginDaoImpl implements CustLoginDao {
    @Autowired
    private SessionFactory sessionFactory;
    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }
    public Session getSession(){
        return sessionFactory.getCurrentSession();
    }
    @Override
    public Customer custLoginDao(Customer customer) {
        String hql="from Customer where account='"+customer.getAccount()+"' and password='"+customer.getPassword()+"'";
        List<Customer> customerList=getSession().createQuery(hql).list();
        for(Customer customer1:customerList){
            customer.setCustomerId(customer1.getCustomerId());
            customer.setType(customer1.getType());
        }

        return customer;
    }

    @Override
    public boolean custRegisterDao(Customer customer) {
        boolean result=false;
        Customer customer1=new Customer(customer.getAccount(), customer.getPassword(),customer.getName(),
                customer.getIdentityId(), customer.getGender() , customer.getTel());
        try {
            getSession().save(customer1);
            result=true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }


}
