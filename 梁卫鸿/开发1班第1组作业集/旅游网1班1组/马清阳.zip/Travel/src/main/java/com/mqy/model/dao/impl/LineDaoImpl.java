package com.mqy.model.dao.impl;

import com.mqy.model.dao.LineDao;
import com.mqy.model.entity.Line;
import com.mqy.model.entity.Linetype;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
@Transactional
public class LineDaoImpl implements LineDao {
    @Autowired
    private SessionFactory sessionFactory;

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    public Session getSession() {
        return sessionFactory.getCurrentSession();
    }

    /**
     * ��ȡ��ҳ��
     * @param pageSize
     * @return
     */
    @Override
    public int getTotalPageDao(int pageSize) {
        String hql="select count(*) from Line";
        long count=(Long) getSession().createQuery(hql).uniqueResult();
        int totalPage=((int) count-1)/pageSize+1;
        return totalPage;
    }

    /**
     * ��ѯ������·
     * @return
     */
    @Override
    public List<Line> allLineDao(int pageIndex,int pageSize) {
        Query query=getSession().createQuery("from Line").setFirstResult(
                (pageIndex-1)*pageSize).setMaxResults(pageSize);
        return query.list();

    }

    /**
     * ��ѯ�����Ź���·
     * @return
     */
    @Override
    public List<Line> teamLineDao(int pageIndex,int pageSize) {
        String hql="from Line where teamBuy=1";
        Query query=getSession().createQuery(hql).setFirstResult(
                (pageIndex-1)*pageSize).setMaxResults(pageSize);
        return query.list();
    }

    /**
     * ������·
     * @param line
     * @return
     */
    @Override
    public void addLineDao(Line line) {
        getSession().save(line);
    }

    /**
     * ɾ����·
     * @param lineId
     * @return
     */
    @Override
    public void deleteLineDao(String lineId) {
        getSession().delete(getSession().get(Line.class,lineId));
    }

    /**
     * �޸���·
     * @param line
     * @return
     */
    @Override
    public void updateLineDao(Line line) {
        getSession().update(line);
    }

    /**
     * ��ȡ��·����
     * @param lineId
     * @return
     */
    @Override
    public Line getLineDao(String lineId) {
        Line line=getSession().get(Line.class,lineId);
        return line;
    }
}
