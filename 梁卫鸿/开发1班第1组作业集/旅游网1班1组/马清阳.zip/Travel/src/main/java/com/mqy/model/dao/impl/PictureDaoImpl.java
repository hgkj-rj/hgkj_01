package com.mqy.model.dao.impl;

import com.mqy.model.dao.PictureDao;
import com.mqy.model.entity.Line;
import com.mqy.model.entity.Picture;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
@Repository
@Transactional
public class PictureDaoImpl implements PictureDao {
    @Autowired
    private SessionFactory sessionFactory;

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }
    public Session getSession(){
        return sessionFactory.getCurrentSession();
    }

    /**
     * ��ѯ������·ͼƬ
     * @return
     */
    @Override
    public List<Picture> allPictureDao() {
        Query query =getSession().createQuery("from Picture");
        return query.list();
    }

    /**
     * ������·ͼƬ
     * @param picture
     * @return
     */
    @Override
    public void addPictureDao(Picture picture) {
        getSession().save(picture);
    }

    /**
     * ɾ����·ͼƬ
     * @param pictureId
     * @return
     */
    @Override
    public void deletePictureDao(int pictureId) {
        getSession().delete(getSession().get(Picture.class,pictureId));
    }

    @Override
    public void updatePictureDao(Picture picture) {
        getSession().update(picture);
    }

    @Override
    public Picture getPictureDao(int pictureId) {
        Picture picture=getSession().get(Picture.class,pictureId);
        return picture;
    }
}
