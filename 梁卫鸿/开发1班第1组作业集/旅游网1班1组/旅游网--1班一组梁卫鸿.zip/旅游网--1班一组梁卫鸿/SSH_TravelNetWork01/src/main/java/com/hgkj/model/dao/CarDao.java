package com.hgkj.model.dao;

import com.hgkj.model.entity.*;

import java.util.List;

public interface CarDao {
    public boolean CarAddDao(int customerId,String lineId,String time);
    public List<Car> carAllDao();
    public List<Line> lineAllDao();
    public List<Picture> pictureAllDao();
    public List<Customer> customerAllDao();
    public boolean carDeleteDao(int carId);
    public Orderdetail orderIdDao(String orderId);
    public boolean orderDeleteDao(String orderId);
    public boolean otDeleteDao(int otId);
    public boolean ot1DeleteDao(String odId);
}
