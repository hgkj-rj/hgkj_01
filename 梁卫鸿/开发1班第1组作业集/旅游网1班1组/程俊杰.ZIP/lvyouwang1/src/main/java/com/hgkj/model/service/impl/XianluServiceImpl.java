package com.hgkj.model.service.impl;

import com.hgkj.model.dao.XianluDao;
import com.hgkj.model.entity.Linetype;
import com.hgkj.model.service.XianluService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class XianluServiceImpl implements XianluService {
    @Autowired
    private XianluDao xianluDao;

    public XianluDao getXianluDao() {
        return xianluDao;
    }

    public void setXianluDao(XianluDao xianluDao) {
        this.xianluDao = xianluDao;
    }

    @Override
    public boolean insertxlService(Linetype linetype) {

        return xianluDao.insertxlDao(linetype);
    }

    @Override
    public List<Linetype> allLineTypeService() {
        return xianluDao.allLineTypeDao();
    }

    @Override
    public boolean delLineTypeService(String lineTypeId) {
        return xianluDao.delLineTypeDao(lineTypeId);
    }

    @Override
    public boolean updLineTypeService(Linetype linetype) {
        return xianluDao.updLineTypeDao(linetype);
    }

    @Override
    public Linetype linetypeByIdService(String lineTypeId) {
        return xianluDao.linetypeByIdDao(lineTypeId);
    }
}
