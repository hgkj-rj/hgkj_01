package com.hgkj.model.Service;

import com.hgkj.model.entity.Customer;

public interface CustomerService {
    public Customer qCustomerService(Customer customer);
    public  Boolean  addCustomerService(Customer customer);
}
