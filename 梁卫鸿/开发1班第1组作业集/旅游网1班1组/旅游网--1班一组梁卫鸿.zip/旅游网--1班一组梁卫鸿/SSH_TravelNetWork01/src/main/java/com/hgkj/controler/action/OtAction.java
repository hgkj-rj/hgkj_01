package com.hgkj.controler.action;

import com.hgkj.model.entity.Line;
import com.hgkj.model.entity.Orderdetail;
import com.hgkj.model.entity.OtDetail;
import com.hgkj.model.entity.Tourist;
import com.hgkj.model.service.OtService;
import org.apache.struts2.ServletActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import java.util.ArrayList;
import java.util.List;

@Controller
@Namespace("/")
@ParentPackage("json-default")
public class OtAction {
    @Autowired
    private OtService otService;
    private Tourist tourist;
    private Line line;
    private Orderdetail orderdetail;

    private String[] realName;
    private String[] tel;
    private String[] idCard;

    public OtService getOtService() {
        return otService;
    }
    public void setOtService(OtService otService) {
        this.otService = otService;
    }
    @Action(value = "addOtAction",results = {@Result(name = "addsuccess",type = "redirect",location = "qt/buyOrders.jsp")})
    public String addOtAction(){
        int a=0;
        boolean rs2=false;
        boolean rs1=false;
        String touristId=null;
        String odId=null;
        String idCard1=null;
        String tel2=null;
        String realName3=null;
        java.text.SimpleDateFormat formater =new java.text.SimpleDateFormat("yyyy-MM-dd"); //编写系统时间格式
        java.util.Date daytime = new java.util.Date();//得到当前系统时间
        String systime = formater.format(daytime);//格式化
        if(ServletActionContext.getRequest().getSession().getAttribute("touristId")!=null) {
            odId=ServletActionContext.getRequest().getSession().getAttribute("touristId").toString();
            if (ServletActionContext.getRequest().getSession().getAttribute("customerId") != null) {
                a = (int) ServletActionContext.getRequest().getSession().getAttribute("customerId");
                boolean rs = otService.orderAddService(odId, line.getLineName(), line.getPrice(),
                        systime, orderdetail.getTravelDate(), "258", line.getLineId(), 1, a);
                for (int i = 0; i < realName.length; i++) {
                    int touristId1 = (int) (Math.random() * 1000);
                    touristId = "tur" + touristId1;
                     idCard1 = idCard[i];
                     tel2 = tel[i];
                     realName3 = realName[i];
                     rs2 = otService.touristAddService(touristId, idCard1, tel2, realName3);
                        rs1=otService.otAddService(odId,touristId);
                }
                List<OtDetail> otDetailList=otService.otAllService();
                ServletActionContext.getRequest().getSession().setAttribute("otDetailList",otDetailList);
                ServletActionContext.getRequest().getSession().setAttribute("count",realName.length);
                ServletActionContext.getRequest().getSession().setAttribute("price",line.getPrice());

                if (rs&&rs1&&rs2) {
                    return "addsuccess";
                }
                return "error";
            }
        }
        return "error";
    }

    @Action(value = "ArraylistAction",results = {@Result(name = "listSuccess",type = "redirect",location = "qt/conformOrders.jsp")})
    public String ArraylistAction(){
        int a=0;
        java.text.SimpleDateFormat formater =new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss"); //编写系统时间格式
        java.util.Date daytime = new java.util.Date();//得到当前系统时间
        String systime = formater.format(daytime);//格式化

        String date=orderdetail.getTravelDate();
        ServletActionContext.getRequest().getSession().setAttribute("date",date);

        List<Tourist> touristList=new ArrayList();
        String touristId=null;
            for (int i = 0; i < realName.length; i++) {
                int touristId1 = (int) (Math.random() * 1000);
                touristId = "tur" + touristId1;
                String idCard1 = idCard[i];
                String tel2 = tel[i];
                String realName3 = realName[i];
                Tourist tourist = new Tourist(touristId, idCard1, tel2, realName3);
                touristList.add(tourist);
        }
        ServletActionContext.getRequest().getSession().setAttribute("touristId",touristId);
        ServletActionContext.getRequest().getSession().setAttribute("touristList",touristList);
        return "listSuccess";
    }
    public String[] getRealName() {
        return realName;
    }

    public void setRealName(String[] realName) {
        this.realName = realName;
    }

    public String[] getTel() {
        return tel;
    }

    public void setTel(String[] tel) {
        this.tel = tel;
    }

    public String[] getIdCard() {
        return idCard;
    }

    public void setIdCard(String[] idCard) {
        this.idCard = idCard;
    }

    public Orderdetail getOrderdetail() {
        return orderdetail;
    }

    public void setOrderdetail(Orderdetail orderdetail) {
        this.orderdetail = orderdetail;
    }

    public Line getLine() {
        return line;
    }

    public void setLine(Line line) {
        this.line = line;
    }

    public Tourist getTourist() {
        return tourist;
    }

    public void setTourist(Tourist tourist) {
        this.tourist = tourist;
    }
}
