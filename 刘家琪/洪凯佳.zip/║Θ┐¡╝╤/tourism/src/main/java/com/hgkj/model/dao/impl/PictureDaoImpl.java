package com.hgkj.model.dao.impl;

import com.hgkj.model.dao.PictureDao;
import com.hgkj.model.entity.Line;
import com.hgkj.model.entity.Picture;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;


@Repository
@Transactional
public class PictureDaoImpl implements PictureDao {
    @Autowired
    private SessionFactory sessionFactory;
    private Session session;

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    public Session getSession() {
        return sessionFactory.getCurrentSession();
    }

    @Override
    public List<Picture> findPictureDao(String lineId) {
        session = getSession();
        String hql = "from Picture where line.lineId=?";
        List<Picture> pictureList = session.createQuery(hql).setParameter(0,lineId).list();
        return pictureList;
    }

    @Override
    public boolean addPictureDao(Picture picture) {
        boolean f=false;
        session = getSession();
        Line line=(Line) session.load(Line.class,picture.getLine().getLineId());
        picture.setLine(line);
        try {
            session.save(picture);
            f=true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return f;
    }

    @Override
    public boolean updatePictureDao(Picture picture) {
        boolean f=false;
        session = getSession();
        Line line =(Line) session.load(Line.class,picture.getLine().getLineId());
        picture.setLine(line);
        try {
            session.update(picture);
            f=true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return f;
    }
}
