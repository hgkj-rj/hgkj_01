package com.tourism.model.service.Impl;

import com.tourism.model.dao.LinetypeDao;
import com.tourism.model.entity.Linetype;
import com.tourism.model.service.LinetypeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class LinetypeServiceImpl implements LinetypeService {
    @Autowired
    private LinetypeDao linetypeDao;

    public LinetypeDao getLinetypeDao() {
        return linetypeDao;
    }

    public void setLinetypeDao(LinetypeDao linetypeDao) {
        this.linetypeDao = linetypeDao;
    }

    @Override
    public boolean addLinetypeService(Linetype linetype) {

        return linetypeDao.addLinetypeDao(linetype);
    }

    @Override
    public boolean updateLinetypeService(Linetype linetype) {

        return linetypeDao.updateLinetypeDao(linetype);
    }

    @Override
    public List<Linetype> fourLinetypeService() {

        return linetypeDao.allLinetypeDao();
    }

    @Override
    public Linetype getLinetypeByIdService(String linetypeId) {
        return linetypeDao.getLinetypeByIdDao(linetypeId);
    }
}
