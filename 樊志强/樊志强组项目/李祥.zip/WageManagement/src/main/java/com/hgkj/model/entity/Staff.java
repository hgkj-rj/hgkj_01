package com.hgkj.model.entity;

public class Staff {
    private Integer staffId;
    private String staffName;
    private String staffPwd;
    private String staffSex;
    private String staffAddress;
    private String staffTel;
    private String staffEmail;
    private String staffState;

    private Department department;
    private Level level;
    private Role role;
    private Shop shop;

    public Department getDepartment() {
        return department;
    }

    public void setDepartment(Department department) {
        this.department = department;
    }

    public Level getLevel() {
        return level;
    }

    public void setLevel(Level level) {
        this.level = level;
    }

    public Role getRole() {
        return role;
    }

    public void setRole(Role role) {
        this.role = role;
    }

    public Shop getShop() {
        return shop;
    }

    public void setShop(Shop shop) {
        this.shop = shop;
    }

    public Integer getStaffId() {
        return staffId;
    }

    public void setStaffId(Integer staffId) {
        this.staffId = staffId;
    }

    public String getStaffName() {
        return staffName;
    }

    public void setStaffName(String staffName) {
        this.staffName = staffName;
    }

    public String getStaffPwd() {
        return staffPwd;
    }

    public void setStaffPwd(String staffPwd) {
        this.staffPwd = staffPwd;
    }

    public String getStaffSex() {
        return staffSex;
    }

    public void setStaffSex(String staffSex) {
        this.staffSex = staffSex;
    }

    public String getStaffAddress() {
        return staffAddress;
    }

    public void setStaffAddress(String staffAddress) {
        this.staffAddress = staffAddress;
    }

    public String getStaffTel() {
        return staffTel;
    }

    public void setStaffTel(String staffTel) {
        this.staffTel = staffTel;
    }

    public String getStaffEmail() {
        return staffEmail;
    }

    public void setStaffEmail(String staffEmail) {
        this.staffEmail = staffEmail;
    }

    public String getStaffState() {
        return staffState;
    }

    public void setStaffState(String staffState) {
        this.staffState = staffState;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Staff staff = (Staff) o;

        if (staffId != null ? !staffId.equals(staff.staffId) : staff.staffId != null) return false;
        if (staffName != null ? !staffName.equals(staff.staffName) : staff.staffName != null) return false;
        if (staffPwd != null ? !staffPwd.equals(staff.staffPwd) : staff.staffPwd != null) return false;
        if (staffSex != null ? !staffSex.equals(staff.staffSex) : staff.staffSex != null) return false;
        if (staffAddress != null ? !staffAddress.equals(staff.staffAddress) : staff.staffAddress != null) return false;
        if (staffTel != null ? !staffTel.equals(staff.staffTel) : staff.staffTel != null) return false;
        if (staffEmail != null ? !staffEmail.equals(staff.staffEmail) : staff.staffEmail != null) return false;
        if (staffState != null ? !staffState.equals(staff.staffState) : staff.staffState != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = staffId != null ? staffId.hashCode() : 0;
        result = 31 * result + (staffName != null ? staffName.hashCode() : 0);
        result = 31 * result + (staffPwd != null ? staffPwd.hashCode() : 0);
        result = 31 * result + (staffSex != null ? staffSex.hashCode() : 0);
        result = 31 * result + (staffAddress != null ? staffAddress.hashCode() : 0);
        result = 31 * result + (staffTel != null ? staffTel.hashCode() : 0);
        result = 31 * result + (staffEmail != null ? staffEmail.hashCode() : 0);
        result = 31 * result + (staffState != null ? staffState.hashCode() : 0);
        return result;
    }
}
