package com.hjh.model.service.Impl;

import com.hjh.model.dao.LineTypeDao;
import com.hjh.model.entity.Linetype;
import com.hjh.model.service.LineTypeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class LineTypeServiceImpl implements LineTypeService {

    @Autowired
    private LineTypeDao lineTypeDao;

    public LineTypeDao getLineTypeDao() {
        return lineTypeDao;
    }

    public void setLineTypeDao(LineTypeDao lineTypeDao) {
        this.lineTypeDao = lineTypeDao;
    }

    @Override
    public List<Linetype> AllLineTypeDao() {
        return lineTypeDao.AllLineTypeDao();
    }

    @Override
    public boolean AddLine(Linetype linetype) {
        return lineTypeDao.AddLine(linetype);
    }

    @Override
    public boolean UpingLineType(Linetype linetype) {
        return lineTypeDao.UpingLineType(linetype);
    }

    @Override
    public Linetype GetLineType(String lineTypeid) {
        return lineTypeDao.GetLineType(lineTypeid);
    }

    @Override
    public String GetRan() {
        return lineTypeDao.GetRan();
    }
}
