package com.hgkj.contrloer.action;

import com.hgkj.model.entity.Reward;
import com.hgkj.model.entity.Subsidy;
import com.hgkj.model.service.SubsidyService;
import org.apache.struts2.ServletActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import java.util.List;

@Controller
@Namespace("/")
@ParentPackage("struts-default")
public class SubsidyAction {
    @Autowired
    private SubsidyService subsidyService;
    private Subsidy subsidy;

    public Subsidy getSubsidy() {
        return subsidy;
    }

    public void setSubsidy(Subsidy subsidy) {
        this.subsidy = subsidy;
    }

    public void setSubsidyService(SubsidyService subsidyService) {
        this.subsidyService = subsidyService;
    }

    @Action(value = "allSubsidy",results = @Result(name = "all",type = "redirect",location = "/html/subsidyList.jsp"))
    public String allSubsidy(){
        List<Subsidy> subsidyList=subsidyService.allSubsidyService();
        ServletActionContext.getRequest().getSession().setAttribute("subsidyList",subsidyList);
        return "all";
    }

    @Action(value = "addSubsidy",results = @Result(name = "adds",type = "redirectAction",params = {"actionName","allSubsidy"}))
    public String addSubsidy(){
        boolean r=subsidyService.addSubsidyService(subsidy);
        if (r==true){
            return "adds";
        }else {
            return "adde";
        }
    }

    @Action(value = "delSubsidy",results = @Result(name = "dels",type = "redirectAction",params = {"actionName","allSubsidy"}))
    public String deleteReward(){
        boolean r=subsidyService.deleteSubsidyService(subsidy.getSubsidyId());
        if (r==true){
            return "dels";
        }else {
            return "dele";
        }
    }

    @Action(value = "updSubsidy",results = @Result(name = "upds",type = "redirectAction",params = {"actionName","allSubsidy"}))
    public String UpdReward(){
        boolean r=subsidyService.updateSubsidyService(subsidy);
        if (r==true){
            return "upds";
        }else {
            return "upde";
        }
    }

    @Action(value = "getByIdSubsidys",results = {@Result(name = "getByIds",type = "redirect",location = "/html/subsidyUpdate.jsp")})
    public String getByIdSubsidy(){
        Subsidy subsidy1=subsidyService.getByIdSubsidyService(subsidy.getSubsidyId());
        ServletActionContext.getRequest().getSession().setAttribute("subsidy1",subsidy1);
        return "getByIds";
    }
}
