package com.workmoney.model.dao;

import com.workmoney.model.entity.Reward;
import com.workmoney.model.entity.RewardLog;

import java.util.List;

/**
 * user@Bright Rain .
 * 2019/6/29.
 */
public interface RewardDao {
    List<RewardLog> getAllReward();

    void delrewardByIdDao(RewardLog rewardLog);

    List<Reward> getAllRewardTypeDao();

    void addEmpRewardDao(RewardLog rewardLog);

    Reward getRewardById(Reward reward);

    void editRewardDao(Reward reward);

    void delRewordByIdDao(Reward reward);

    void addRewardDao(Reward reward);
}
