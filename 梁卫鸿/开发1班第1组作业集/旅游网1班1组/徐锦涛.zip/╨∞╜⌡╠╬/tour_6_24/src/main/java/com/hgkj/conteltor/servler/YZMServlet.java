package com.hgkj.conteltor.servler;

import javax.imageio.ImageIO;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.Random;

@WebServlet(name = "YZMServlet",value = "/YZMServlet")
public class YZMServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("image/jpeg;charset=UTF-8");
        BufferedImage image=new BufferedImage(70,30,BufferedImage.TYPE_3BYTE_BGR);
        Graphics graphics=image.createGraphics();
        graphics.setColor(randcomColor());
        graphics.setFont(new Font("楷书",Font.BOLD,20));
        graphics.fillRect(0,0,70,30);
        String yzm=randomString();
        request.getSession().setAttribute("yzm",yzm);
        for (int i=0;i<yzm.length();i++){
            graphics.setColor(Color.yellow);
            graphics.drawString(yzm.substring(i,i+1),i*15+5,20);
            graphics.drawLine(0,i*7+3,70,i*7+2);
        }
        ServletOutputStream outputStream=response.getOutputStream();
        ImageIO.write(image,"png",outputStream);
        outputStream.flush();
        outputStream.close();

    }
    private String randomString(){
        String yzm="";
        char[] chars={'0','1','2','3','4','5','6','7','8','9','A','B','C','D','R','E','U','I','O','P','J','K','L','F','M','豪','审','可','爱','拟'};
        Random random=new Random();
        for (int i=0;i<4;i++){
            int index=random.nextInt(chars.length);
            yzm+=chars[index];
        }
        return yzm;
    }
    private Color randcomColor(){
        Random random=new Random();
        int r=random.nextInt(256);
        int g=random.nextInt(256);
        int b=random.nextInt(256);
        return new Color(r,g,b);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }
}
