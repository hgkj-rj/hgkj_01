package com.tourism.model.dao.impl;

import com.tourism.model.dao.PictureDao;
import com.tourism.model.entity.Line;
import com.tourism.model.entity.Linetype;
import com.tourism.model.entity.Picture;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
@Transactional
public class PictureDaoImpl implements PictureDao {
    @Autowired
    private SessionFactory sessionFactory;

    private Session session;

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    public Session getSession(){
        return sessionFactory.getCurrentSession();
    }


    @Override
    public List<Picture> allPictureDao() {
        Query query = getSession().createQuery("from Picture");
        return query.list();
    }

    @Override
    public List<Picture> findPictureDao(String lineId) {
        session = getSession();
        String hql = "from Picture where line.lineId=?";
        List<Picture> pictureList = session.createQuery(hql).setParameter(0,lineId).list();
        return pictureList;
    }

    @Override
    public List<Picture> findlineDao(String lineTypeId) {
        session = getSession();
        String hql = "from Picture where line.linetype.lineTypeId=?";
        List<Picture> pictureList = session.createQuery(hql).setParameter(0,lineTypeId).list();
        return pictureList;
    }

    @Override
    public boolean addPictureDao(Picture picture) {
        boolean flag = false;
        session = getSession();
        Line line =(Line) session.load(Line.class,picture.getLine().getLineId());
        picture.setLine(line);
        try {
            session.save(picture);
            flag = true;
        }catch (Exception e){
            e.printStackTrace();
        }
        return flag;
    }

    @Override
    public boolean updatePictureDao(Picture picture) {
        boolean flag = false;
        session = getSession();
        Line line = (Line) session.load(Line.class,picture.getLine().getLineId());
        picture.setLine(line);
        try {
            session.update(picture);
            flag = true;
        }catch (Exception e){
            e.printStackTrace();
        }
        return flag;
    }
}
