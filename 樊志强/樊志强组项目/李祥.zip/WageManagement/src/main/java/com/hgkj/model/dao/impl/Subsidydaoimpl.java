package com.hgkj.model.dao.impl;

import com.hgkj.model.dao.Subsidydao;
import com.hgkj.model.entity.Subsidy;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
@Transactional
public class Subsidydaoimpl implements Subsidydao {
    @Autowired
    public SessionFactory sessionFactory;

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    private Session session(){
       return sessionFactory.getCurrentSession();
    }


    @Override
    public List<Subsidy> allSubsidydao() {
        Query query=session().createQuery("from Subsidy ");
        return query.list();
    }

    @Override
    public boolean updateSubsidydao(Subsidy subsidy) {
        session().update(subsidy);
        return false;
    }

    @Override
    public boolean deleteSubsidydao(int subsidyId) {
        Subsidy subsidy = session().get(Subsidy.class,subsidyId);
        session().delete(subsidy);
        return false;
    }

    @Override
    public boolean addSubsidydao(Subsidy subsidy) {
        session().save(subsidy);
        return false;
    }

    @Override
    public Subsidy subsidy(int subsidyId) {
        Subsidy subsidy = session().get(Subsidy.class,subsidyId);
        return subsidy;
    }
}
