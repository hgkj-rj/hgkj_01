package com.hgkj.model.service;

import com.hgkj.model.entity.Line;

import java.util.List;

public interface LineService {
   public boolean insertLineService(Line line);
   public List<Line> allLineService();
   public boolean delLineService(String lineId);
   public boolean updLineService(Line line);
   public Line lineByIdService(String lineId);
   public Line teamByIdService(String lineId);
   public boolean updTeamService(Line line);
   public Line SetTeamByIdService(String lineId);
   public boolean setTeamMsgService(Line line);
}
