package com.workmoney.model.dao.impl;

import com.workmoney.model.dao.RewardDao;
import com.workmoney.model.entity.Reward;
import com.workmoney.model.entity.RewardLog;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

/**
 * user@Bright Rain .
 * 2019/6/29.
 */
@Repository
@Transactional
public class RewardDaoImpl implements RewardDao {
    @Autowired
    private SessionFactory sessionFactory;

    @Override
    public List<RewardLog> getAllReward() {
        String hql = "from RewardLog ";
        Session session = sessionFactory.getCurrentSession();
        List<RewardLog> list = session.createQuery(hql, RewardLog.class).list();
        return list;
    }

    @Override
    public void delrewardByIdDao(RewardLog rewardLog) {
        Session session = sessionFactory.getCurrentSession();
        session.delete(rewardLog);
    }

    @Override
    public List<Reward> getAllRewardTypeDao() {
        String hql = "from Reward ";
        Session session = sessionFactory.getCurrentSession();
        List<Reward> list = session.createQuery(hql, Reward.class).list();
        return list;
    }

    @Override
    public void addEmpRewardDao(RewardLog rewardLog) {
        Session session = sessionFactory.getCurrentSession();
        SimpleDateFormat sda = new SimpleDateFormat("yyyy-MM-dd");
        String format = sda.format(new Date());
        rewardLog.setRewlogTime(format);
        session.save(rewardLog);
    }

    @Override
    public Reward getRewardById(Reward reward) {
        Session session = sessionFactory.getCurrentSession();
        Reward reward1 = session.get(Reward.class, reward.getRewId());
        return reward1;
    }

    @Override
    public void editRewardDao(Reward reward) {
        Session session = sessionFactory.getCurrentSession();
        session.update(reward);
    }

    @Override
    public void delRewordByIdDao(Reward reward) {
        Session session = sessionFactory.getCurrentSession();
        session.delete(reward);
    }

    @Override
    public void addRewardDao(Reward reward) {
        Session session = sessionFactory.getCurrentSession();
        session.save(reward);
    }


    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }
}
