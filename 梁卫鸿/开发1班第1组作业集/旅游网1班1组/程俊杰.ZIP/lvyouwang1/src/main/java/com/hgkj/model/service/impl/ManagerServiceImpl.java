package com.hgkj.model.service.impl;

import com.hgkj.model.dao.ManagerDao;
import com.hgkj.model.entity.Customer;
import com.hgkj.model.service.ManagerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ManagerServiceImpl implements ManagerService {
    @Autowired
    private ManagerDao managerDao;

    public ManagerDao getManagerDao() {
        return managerDao;
    }

    public void setManagerDao(ManagerDao managerDao) {
        this.managerDao = managerDao;
    }

    @Override
    public boolean managerloginService(Customer customer) {
       return managerDao.managerloginDao(customer);

    }
}
