package com.hgkj.model.dao;

import com.hgkj.model.entity.Linetype;

import java.util.List;

public interface XianluDao {
    public boolean insertxlDao(Linetype linetype);
    public List<Linetype> allLineTypeDao();
    public boolean delLineTypeDao(String lineTypeId);
    public boolean updLineTypeDao(Linetype linetype);
    public Linetype linetypeByIdDao(String lineTypeId);
}
