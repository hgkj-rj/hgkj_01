package com.workmoney.util;

/**
 * user@Bright Rain .
 * 2019/6/24.
 */
public class SercharStaffUpload {
    private int staffId;
    private String staffName;
    private String staffPwd;
    private String staffSex;
    private String staffAddress;
    private String staffTel;
    private String staffEmail;
    private String staffState;
    private Integer levelId;
    private Integer rolesId;
    private Integer depId;
    private Integer shopId;
    private String  levelName;
    private String levelPrice;
    private String totalSubsidy;
    private String totalReward;
    private String attPercent;
    private String salaryOld;
    private String salaryTrue;

    public int getStaffId() {
        return staffId;
    }

    public void setStaffId(int staffId) {
        this.staffId = staffId;
    }

    public String getStaffName() {
        return staffName;
    }

    public void setStaffName(String staffName) {
        this.staffName = staffName;
    }

    public String getStaffPwd() {
        return staffPwd;
    }

    public void setStaffPwd(String staffPwd) {
        this.staffPwd = staffPwd;
    }

    public String getStaffSex() {
        return staffSex;
    }

    public void setStaffSex(String staffSex) {
        this.staffSex = staffSex;
    }

    public String getStaffAddress() {
        return staffAddress;
    }

    public void setStaffAddress(String staffAddress) {
        this.staffAddress = staffAddress;
    }

    public String getStaffTel() {
        return staffTel;
    }

    public void setStaffTel(String staffTel) {
        this.staffTel = staffTel;
    }

    public String getStaffEmail() {
        return staffEmail;
    }

    public void setStaffEmail(String staffEmail) {
        this.staffEmail = staffEmail;
    }

    public String getStaffState() {
        return staffState;
    }

    public void setStaffState(String staffState) {
        this.staffState = staffState;
    }

    public Integer getLevelId() {
        return levelId;
    }

    public void setLevelId(Integer levelId) {
        this.levelId = levelId;
    }

    public Integer getRolesId() {
        return rolesId;
    }

    public void setRolesId(Integer rolesId) {
        this.rolesId = rolesId;
    }

    public Integer getDepId() {
        return depId;
    }

    public void setDepId(Integer depId) {
        this.depId = depId;
    }

    public Integer getShopId() {
        return shopId;
    }

    public void setShopId(Integer shopId) {
        this.shopId = shopId;
    }

    public String getLevelName() {
        return levelName;
    }

    public void setLevelName(String levelName) {
        this.levelName = levelName;
    }

    public String getLevelPrice() {
        return levelPrice;
    }

    public void setLevelPrice(String levelPrice) {
        this.levelPrice = levelPrice;
    }

    public String getTotalSubsidy() {
        return totalSubsidy;
    }

    public void setTotalSubsidy(String totalSubsidy) {
        this.totalSubsidy = totalSubsidy;
    }

    public String getTotalReward() {
        return totalReward;
    }

    public void setTotalReward(String totalReward) {
        this.totalReward = totalReward;
    }

    public String getAttPercent() {
        return attPercent;
    }

    public void setAttPercent(String attPercent) {
        this.attPercent = attPercent;
    }

    public String getSalaryOld() {
        return salaryOld;
    }

    public void setSalaryOld(String salaryOld) {
        this.salaryOld = salaryOld;
    }

    public String getSalaryTrue() {
        return salaryTrue;
    }

    public void setSalaryTrue(String salaryTrue) {
        this.salaryTrue = salaryTrue;
    }
}
