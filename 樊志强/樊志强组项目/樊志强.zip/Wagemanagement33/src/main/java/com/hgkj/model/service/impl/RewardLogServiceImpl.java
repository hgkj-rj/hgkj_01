package com.hgkj.model.service.impl;

import com.hgkj.model.dao.RewardDao;
import com.hgkj.model.dao.RewardLogDao;
import com.hgkj.model.entity.RewardLog;
import com.hgkj.model.service.RewardLogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class RewardLogServiceImpl implements RewardLogService {
    @Autowired
    private RewardLogDao rewardLogDao;

    public RewardLogDao getRewardLogDao() {
        return rewardLogDao;
    }

    public void setRewardLogDao(RewardLogDao rewardLogDao) {
        this.rewardLogDao = rewardLogDao;
    }

    @Override
    public List<RewardLog> allrewardLogService() {
        return rewardLogDao.allrewardLogDao();
    }

    @Override
    public boolean insertrewardLogService(RewardLog rewardLog) {
        return rewardLogDao.insertrewardLogDao(rewardLog);
    }

    @Override
    public boolean deleterewardLogService(int id) {
        return rewardLogDao.deleterewardLogDao(id);
    }

    @Override
    public boolean updaterewardLogService(RewardLog rewardLog) {
        return rewardLogDao.updaterewardLogDao(rewardLog);
    }

    @Override
    public RewardLog getrewardLogByIdService(int id) {
        return rewardLogDao.getrewardLogByIdDao(id);
    }
}
