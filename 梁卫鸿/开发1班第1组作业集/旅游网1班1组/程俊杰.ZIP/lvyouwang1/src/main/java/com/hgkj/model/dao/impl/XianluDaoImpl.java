package com.hgkj.model.dao.impl;

import com.hgkj.model.dao.XianluDao;
import com.hgkj.model.entity.Linetype;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
@Transactional
public class XianluDaoImpl implements XianluDao {
    @Autowired
    private SessionFactory sessionFactory;



    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }
    public Session getSession() {
        return sessionFactory.getCurrentSession();
    }

    @Override
    public boolean insertxlDao(Linetype linetype) {
        boolean result=false;
      //  Linetype linetype1=new Linetype(linetype.getLineTypeId(),linetype.getTypeName(),linetype.getTime(),linetype.getIcon());
        try {
            getSession().save(linetype);
            result=true;
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
        }
        return result;
    }

    @Override
    public List<Linetype> allLineTypeDao() {
        Query query=getSession().createQuery("from Linetype");
        return query.list();
    }

    @Override
    public boolean delLineTypeDao(String lineTypeId) {
        boolean result=false;
        System.out.println(lineTypeId);
        if (lineTypeId!=null){
     getSession().delete(getSession().get(Linetype.class,lineTypeId));
     return true;
        }
        return result;
    }

    @Override
    public boolean updLineTypeDao(Linetype linetype) {
        boolean result=false;

       // getSession().update(linetype);
//       Linetype linetype1=getSession().get(Linetype.class,linetype.getLineTypeId());
//       linetype1.setLineTypeId(linetype.getLineTypeId());
//       linetype1.setTypeName(linetype.getTypeName());
//       linetype1.setTime(linetype.getTime());
//       linetype1.setIcon(linetype.getIcon());
        try {
            getSession().update(linetype);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
        }

        return result;
    }

    @Override
    public Linetype linetypeByIdDao(String lineTypeId) {

            Linetype linetype=getSession().get(Linetype.class,lineTypeId);
        return linetype;
    }

}
