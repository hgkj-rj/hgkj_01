package com.xl.model.entity;

public class Manag {
    private int managId;
    private String managName;
    private String managPwd;
    public Manag(){}
    public Manag(String managName, String managPwd) {
        this.managName = managName;
        this.managPwd = managPwd;
    }

    public int getManagId() {
        return managId;
    }

    public void setManagId(int managId) {
        this.managId = managId;
    }

    public String getManagName() {
        return managName;
    }

    public void setManagName(String managName) {
        this.managName = managName;
    }

    public String getManagPwd() {
        return managPwd;
    }

    public void setManagPwd(String managPwd) {
        this.managPwd = managPwd;
    }


}
