package com.hgkj.model.dao.impl;

import com.hgkj.model.dao.CarDao;
import com.hgkj.model.entity.Car;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
@Transactional
public class CarDaoImpl implements CarDao {
    @Autowired
    private SessionFactory sessionFactory;
    private Session session;
    @Override
    public List<Car> allCarDao() {
        return null;
    }

    @Override
    public boolean addCarDao(Car car) {
        return false;
    }

    @Override
    public boolean deleteCarDao(Car car) {
        return false;
    }

    @Override
    public boolean updateCarDao(Car car) {
        return false;
    }

    @Override
    public Car getCarByIdDao(String carId) {
        return null;
    }
}
