package com.tourism.model.dao;

import com.tourism.model.entity.Linetype;

import java.util.List;

public interface LineTypeDao {
    public List<Linetype> allLineTypeDao();
    public List<Linetype> fourLineTypeDao();
    public boolean addLineTypeDao(Linetype linetype);
    public boolean updateLineTypeDao(Linetype linetype);
    public Linetype getLineTypeByIdDao(String lineTypeId);
    public Linetype getLastDao();
}
