package com.hgkj.model.service;

import com.hgkj.model.entity.Linetype;

import java.util.List;

public interface LineTypeService {
    public List<Linetype> lineTypeAllService();
    public boolean lineTypeAddService(String lineTypeId,String typeName,String icon);
    public boolean lineTypeDeleteService(String lineTypeId);
    public Linetype lineTypeIdService(String lineTypeId);
    public boolean lineTypeUpdateService(String lineTypeId,String typeName,String icon);
}
