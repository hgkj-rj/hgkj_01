package com.hgkj.model.service;


import com.hgkj.model.entity.Linetype;

import java.util.List;

public interface LinetypeService {
    public List<Linetype> allLinetypeService();
    public boolean addLinetypeService(Linetype linetype);
    public boolean deleteLinetypeService(Linetype linetype);
    public boolean updateLinetypeService(Linetype linetype);
    public Linetype getLinetypeByIdService(String lineTypeId);
}
