package com.hgkj.model.dao.impl;

import com.hgkj.model.dao.Leveldao;
import com.hgkj.model.entity.Level;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
@Transactional
public class leveldaoimpl implements Leveldao {
    @Autowired
    public SessionFactory sessionFactory;

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    public Session session(){
        return sessionFactory.getCurrentSession();
    }


    @Override
    public List<Level> allLeveldao() {
        Query query = session().createQuery("from Level ");
        return query.list();
    }

    @Override
    public boolean addLeveldao(Level level) {
        session().save(level);
        return false;
    }

    @Override
    public boolean deleteLeveldao(int levelId) {
        Level level = session().get(Level.class,levelId);
        session().delete(level);
        return false;
    }

    @Override
    public boolean updateLevedao(Level level) {
        session().update(level);
        return false;
    }

    @Override
    public Level level(int levelId) {
        Level level = session().get(Level.class,levelId);
        return level;
    }
}
