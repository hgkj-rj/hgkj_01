package com.hgkj.model.dao;

import com.hgkj.model.entity.Subsidy;

import java.util.List;

public interface SubsidyDao {
    //查询所有补贴类别
    public List<Subsidy> allsubsidyDao();
    //添加补贴类别
    public boolean insertsubsidyDao(Subsidy subsidy);
    //删除补贴类别
    public boolean deletesubsidyDao(int id);
    //修改补贴类别
    public boolean updatesubsidyDao(Subsidy subsidy);
    //根据Id获取补贴信息
    public Subsidy getsubsidyByIdDao(int id);
}
