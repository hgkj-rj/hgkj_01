package com.workmoney.model.service;

import com.workmoney.model.entity.Level;

import java.util.List;

/**
 * user@Bright Rain .
 * 2019/6/30.
 */
public interface LevelService {

    List<Level> getAllLevelService();
    
    /**
     * 添加等级
     * @return
     */
    void addLevelService(Level level);
    /**
     * 删除等级
     * @return
     */
    void delLevelService(Level level);
    /**
     * 获取等级
     * @return
     */
    Level getLevelService(Level level);
    /**
     * 修改等级
     * @return
     */
    void updateLevel(Level level);
    

}
