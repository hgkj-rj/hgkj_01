package com.hgkj.conteltor.action;

import com.hgkj.model.entity.Customer;
import com.hgkj.model.service.CustomerService;
import com.opensymphony.xwork2.ActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import java.util.List;

@Controller
@Namespace("/")
@ParentPackage("struts-default")
public class LoginAction {
    @Autowired
    private CustomerService customerService;
    private Customer customer;
    private String message;

    public void setMessage(String message) {
        this.message = message;
    }

    public String getMessage() {
        return message;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomerService(CustomerService customerService) {
        this.customerService = customerService;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    @Action(value = "denglu", results = {
            @Result(name = "denglu", type = "redirect", location = "/qt/index.jsp"),
            @Result(name = "dengluError", type = "redirect", location = "qt/login.jsp")})
    public String denglu() {
        List<Customer> customerList = customerService.CustomerLoginService(customer);
        if (customerList != null) {
            return "denglu";
        } else {
            return "dengluError";
        }
    }

    @Action(value = "guanluyuan", results = {
            @Result(name = "login", type = "redirect", location = "/ht/index.jsp"),
            @Result(name = "loginfalse", type = "redirect", location = "ht/adminLogin.jsp")})
    public String guanluyuan() {
        String result="loginfalse";
        int type=0;
        List<Customer> customerList = customerService.CustomerLoginService(customer);
        for(Customer customer1:customerList){
            type=customer1.getType();
            if (customer1.getAccount().equals(customer.getAccount()) && customer1.getPassword().equals(customer.getPassword()) ){
                if (type==1){
                    result="login";
                    ActionContext.getContext().getSession().put("ManagerName",customer1.getName());
                }
            }
        }
        return result;
    }
    @Action(value = "addCustomer", results = {@Result(name = "add", type = "redirect",location = "/qt/login.jsp"),
            @Result(name = "addError", type = "redirect", location = "qt/regist.jsp")})
    public String addCustomer() {
        boolean addcus = customerService.CustomerAddService(customer);
        if (addcus) {
            return "add";
        } else {
            return "addError";
        }
    }
}