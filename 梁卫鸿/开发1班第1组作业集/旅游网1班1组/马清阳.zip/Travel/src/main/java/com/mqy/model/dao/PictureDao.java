package com.mqy.model.dao;

import com.mqy.model.entity.Picture;

import java.util.List;

public interface PictureDao {

    /**
     * 查询所有图片
     * @return
     */
    public List<Picture> allPictureDao();

    /**
     * 添加图片
     * @param picture
     * @return
     */
    public void addPictureDao(Picture picture);

    /**
     * 删除图片
     * @param pictureId
     * @return
     */
    public void deletePictureDao(int pictureId);

    /**
     * 修改图片
     * @param picture
     */
    public void updatePictureDao(Picture picture);

    /**
     * 获取图片对象
     * @param pictureId
     * @return
     */
    public Picture getPictureDao(int pictureId);
}
