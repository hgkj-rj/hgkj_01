package com.hgkj.model.service;

import com.hgkj.model.entity.Subsidy;

import java.util.List;

public interface SubsidyService {
    public List<Subsidy> allSubsidyService();
    public boolean updateSubsidyService(Subsidy subsidy);
    public boolean deleteSubsidyService(int subsidyId);
    public boolean addSubsidyService(Subsidy subsidy);
    public Subsidy subsiService (int subsidyId);

}
