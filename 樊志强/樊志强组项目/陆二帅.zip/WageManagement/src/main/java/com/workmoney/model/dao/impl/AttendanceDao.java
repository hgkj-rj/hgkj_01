package com.workmoney.model.dao.impl;

import com.workmoney.model.dao.AttendanceinfDao;
import com.workmoney.model.entity.Attendance;
import com.workmoney.model.entity.AttendanceLog;
import com.workmoney.model.entity.Staff;
import org.apache.struts2.ServletActionContext;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import javax.servlet.http.HttpSession;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

/**
 * user@Bright Rain .
 * 2019/6/25.
 */
@Repository
@Transactional
public class AttendanceDao implements AttendanceinfDao {

    @Autowired
    private SessionFactory sessionFactory;

    //查询员工
    public List<AttendanceLog> getAllAttendanceLog(int shopManagerId){

        HttpSession httpSession = ServletActionContext.getRequest().getSession();
        String hql = "from AttendanceLog  where staff.shopId = ? and staff.rolesId=3";

        Staff staff = (Staff) httpSession.getAttribute("staff");
        Integer rolesId = staff.getRolesId();
        if(rolesId==1||rolesId==2){
            hql = "from AttendanceLog  where staff.shopId = ? and (staff.rolesId =4 or staff.rolesId =3)";
        }
        Session session = sessionFactory.getCurrentSession();
        List<AttendanceLog> list = session.createQuery(hql, AttendanceLog.class).setParameter(0,shopManagerId).list();
        return list;
    }

    @Override
    public List<Attendance> getAttendanceTypeDao() {
        String hql = "from Attendance ";
        Session session = sessionFactory.getCurrentSession();
        List<Attendance> list = session.createQuery(hql, Attendance.class).list();
        return list;
    }

    @Override
    public void addAttendanceDao(AttendanceLog attendance) {
        Session session = sessionFactory.getCurrentSession();
        attendance.setAttlogTime(new Timestamp(new Date().getTime()));
        session.save(attendance);
    }

    @Override
    public AttendanceLog AttendanceLogByIdDao(int staffId, Integer shopId) {
        Session session = sessionFactory.getCurrentSession();
        String hql = "from AttendanceLog where staff.staffId=? and staff.shopId=?";
        AttendanceLog attendanceLog = session.createQuery(hql, AttendanceLog.class).setParameter(0, staffId).setParameter(1, shopId).uniqueResult();
        return attendanceLog;
    }

    @Override
    public void attendanceEditAction(AttendanceLog attendanceLog) {
        Session session = sessionFactory.getCurrentSession();
        attendanceLog.setAttlogTime(new Timestamp(new Date().getTime()));
        String hql = "update AttendanceLog set attlogCount=? ,attendance.attId=? where attenlogId=?";
        session.createQuery(hql).setParameter(0,attendanceLog.getAttlogCount()).setParameter(1,attendanceLog.getAttendance().getAttId()).setParameter(2,attendanceLog.getAttenlogId()).executeUpdate();

    }

    @Override
    public void delAttendanceLogDao(AttendanceLog attendanceLog) {
        Session session = sessionFactory.getCurrentSession();
        session.delete(attendanceLog);
    }

    @Override
    public List<AttendanceLog> attendanceInfoDao(int staffId) {
        Session session = sessionFactory.getCurrentSession();
        String hql = null;
        if(staffId==0){
            hql = "from AttendanceLog ";
        }else {
            hql = "from AttendanceLog where staff.staffId="+staffId;
        }
        List<AttendanceLog> logList = session.createQuery(hql, AttendanceLog.class).list();
        return logList;
    }


    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }
}
