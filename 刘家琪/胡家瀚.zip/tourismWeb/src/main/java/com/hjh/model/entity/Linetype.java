package com.hjh.model.entity;

import org.springframework.stereotype.Component;
import java.util.HashSet;
import java.util.Set;
@Component("Linetype")
public class Linetype {
    private String lineTypeid;//线路类型编号
    private String typeName;//线路类型名称
    private String time;//线路类型添加时间
    private String iocn;//线路类型图标名
    private Set<Line> lineSet = new HashSet<>();

    public Set<Line> getLineSet() {
        return lineSet;
    }

    public void setLineSet(Set<Line> lineSet) {
        this.lineSet = lineSet;
    }

    public String getLineTypeid() {
        return lineTypeid;
    }

    public void setLineTypeid(String lineTypeid) {
        this.lineTypeid = lineTypeid;
    }

    public String getTypeName() {
        return typeName;
    }

    public void setTypeName(String typeName) {
        this.typeName = typeName;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getIocn() {
        return iocn;
    }

    public void setIocn(String iocn) {
        this.iocn = iocn;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Linetype linetype = (Linetype) o;

        if (lineTypeid != null ? !lineTypeid.equals(linetype.lineTypeid) : linetype.lineTypeid != null) return false;
        if (typeName != null ? !typeName.equals(linetype.typeName) : linetype.typeName != null) return false;
        if (time != null ? !time.equals(linetype.time) : linetype.time != null) return false;
        if (iocn != null ? !iocn.equals(linetype.iocn) : linetype.iocn != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = lineTypeid != null ? lineTypeid.hashCode() : 0;
        result = 31 * result + (typeName != null ? typeName.hashCode() : 0);
        result = 31 * result + (time != null ? time.hashCode() : 0);
        result = 31 * result + (iocn != null ? iocn.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "Linetype{" +
                "lineTypeid='" + lineTypeid + '\'' +
                ", typeName='" + typeName + '\'' +
                ", time='" + time + '\'' +
                ", iocn='" + iocn + '\'' +
                ", lineSet=" + lineSet +
                '}';
    }
}
