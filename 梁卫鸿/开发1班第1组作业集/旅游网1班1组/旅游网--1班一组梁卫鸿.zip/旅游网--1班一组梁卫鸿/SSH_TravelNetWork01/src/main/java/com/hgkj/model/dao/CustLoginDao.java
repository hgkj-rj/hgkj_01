package com.hgkj.model.dao;

import com.hgkj.model.entity.Customer;

public interface CustLoginDao {
    public Customer custLoginDao(Customer customer);
    public boolean custRegisterDao(Customer customer);

}
