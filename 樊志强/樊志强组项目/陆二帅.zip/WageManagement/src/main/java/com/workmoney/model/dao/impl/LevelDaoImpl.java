package com.workmoney.model.dao.impl;

import com.workmoney.model.dao.LevelDao;
import com.workmoney.model.entity.Level;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * user@Bright Rain .
 * 2019/6/30.
 */
@Repository
@Transactional
public class LevelDaoImpl implements LevelDao {

    @Autowired
    private SessionFactory sessionFactory;

    @Override
    public List<Level> getAllLevelDao() {
        Session session = sessionFactory.getCurrentSession();
        String hql = "from Level ";
        List<Level> levelList = session.createQuery(hql, Level.class).list();
        return levelList;
    }

    @Override
    public void addLevelDao(Level level) {
        Session session = sessionFactory.getCurrentSession();
        session.save(level);
    }

    @Override
    public void delLevelDao(Level level) {
        Session session = sessionFactory.getCurrentSession();
        session.delete(level);
    }

    @Override
    public Level getLevelDao(Level level) {
        Session session = sessionFactory.getCurrentSession();
        Level level1 = session.get(Level.class, level.getLevelId());
        return level1;
    }

    @Override
    public void updateLevel(Level level) {
        Session session = sessionFactory.getCurrentSession();
        session.update(level);
    }

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }
}
