package com.hgkj.model.service;

import com.hgkj.model.entity.Attendance;

import java.util.List;

public interface AttendanceService {
    //查询所有考勤项类别
    public List<Attendance> allattendanceService();
    //添加考勤项类别
    public boolean insertattendanceService(Attendance attendance);
    //删除考勤项类别
    public boolean deleteattendanceService(int id);
    //修改考勤项类别
    public boolean updateattendanceService(Attendance attendance);
    //根据Id获取考勤项信息
    public Attendance getattendanceByIdService(int id);
}
