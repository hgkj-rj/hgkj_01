package com.workmoney.model.entity;

import java.math.BigDecimal;
import java.util.Objects;

/**
 * user@Bright Rain .
 * 2019/6/21.
 */
public class SubsidyLog {
    private int stblogId;
//    private Integer staffId;
//    private Integer sunsidyId;
    private BigDecimal subsidyMoney;
    private String sublogTime;

    //多对一
    private Staff staff;

    private Subsidy subsidy;

    public int getStblogId() {
        return stblogId;
    }

    public void setStblogId(int stblogId) {
        this.stblogId = stblogId;
    }

    public Staff getStaff() {
        return staff;
    }

    public void setStaff(Staff staff) {
        this.staff = staff;
    }

    public Subsidy getSubsidy() {
        return subsidy;
    }

    public void setSubsidy(Subsidy subsidy) {
        this.subsidy = subsidy;
    }

    public BigDecimal getSubsidyMoney() {
        return subsidyMoney;
    }

    public void setSubsidyMoney(BigDecimal subsidyMoney) {
        this.subsidyMoney = subsidyMoney;
    }

    public String getSublogTime() {
        return sublogTime;
    }

    public void setSublogTime(String sublogTime) {
        this.sublogTime = sublogTime;
    }


}
