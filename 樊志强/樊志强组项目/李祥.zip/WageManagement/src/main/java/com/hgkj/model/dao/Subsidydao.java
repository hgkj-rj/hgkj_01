package com.hgkj.model.dao;

import com.hgkj.model.entity.Subsidy;

import java.util.List;

public interface Subsidydao {
    public List<Subsidy> allSubsidydao();
    public boolean updateSubsidydao(Subsidy subsidy);
    public boolean deleteSubsidydao(int subsidyId);
    public boolean addSubsidydao(Subsidy subsidy);
    public Subsidy subsidy (int subsidyId);
}
