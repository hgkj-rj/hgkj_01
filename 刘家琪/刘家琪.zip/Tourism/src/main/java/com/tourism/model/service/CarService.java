package com.tourism.model.service;

import com.tourism.model.entity.Car;
import com.tourism.model.entity.Orderdetail;

import java.util.List;

public interface CarService {
    public int gettotalpageService(int pagesize, int customerId);
    public List<Car> allCarService(int pageindex, int pagesize, int customerId);
    public boolean deleteCarService(Car car);
    public boolean addCarService(Car car);
}
