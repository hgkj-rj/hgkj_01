package com.hgkj.model.service;

import com.hgkj.model.entity.Linetype;

import java.util.List;

public interface LineTypeService {
    public List<Linetype> lineTypeAllService();
    public boolean lineTypeAddService(String lineTypeID, String typeName, String icon);
    public boolean lineTypeDeleteService(String lineTypeID);
    public Linetype lineTypeIdService(String lineTypeID);
    public boolean lineTypeUpdateService(String lineTypeID, String typeName, String icon);
}
