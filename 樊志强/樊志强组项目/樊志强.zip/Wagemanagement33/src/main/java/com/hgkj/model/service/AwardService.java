package com.hgkj.model.service;

import com.hgkj.model.entity.RewardLog;

import java.util.List;

public interface AwardService {
    public List<RewardLog> allRewardLogList();

    public boolean addRewardList(RewardLog rewardLog);

    public boolean delRewardList(RewardLog rewardLog);

    public boolean updRewardList(RewardLog rewardLog);

    public RewardLog onlyRewardList(RewardLog rewardLog);
}
