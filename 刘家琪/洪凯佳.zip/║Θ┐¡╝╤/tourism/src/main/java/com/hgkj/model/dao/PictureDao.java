package com.hgkj.model.dao;

import com.hgkj.model.entity.Picture;

import java.util.List;

public interface PictureDao {
    public List<Picture> findPictureDao(String lineId);
    public boolean addPictureDao(Picture picture);
    public boolean updatePictureDao(Picture picture);
}
