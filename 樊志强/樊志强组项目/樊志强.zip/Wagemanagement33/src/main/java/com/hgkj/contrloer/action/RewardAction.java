package com.hgkj.contrloer.action;

import com.hgkj.model.entity.Reward;
import com.hgkj.model.service.RewardService;

import com.opensymphony.xwork2.ActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import java.util.List;

@Controller
@Namespace("/")
@ParentPackage("json-default")
public class RewardAction {
    @Autowired
    private RewardService rewardService;
    private Reward reward;
    private int id;
    @Action(value = "allreward",results = {@Result(name = "all",type = "redirect",location = "html/bonusList.jsp")})
    public String allreward(){
        List<Reward> rewardList=rewardService.allrewardService();
        ActionContext.getContext().getSession().put("rewardlist",rewardList);
        return "all";
    }
    @Action(value = "insertreward",results = {@Result(name = "insert",type = "redirect",location = "allreward")})
    public String insert(){
        if(rewardService.insertrewardService(reward)){
            return "insert";
        }else {
            return "noinsert";
        }

    }
    @Action(value = "deletereward",results = {@Result(name = "delete",type = "json",params = {"root","delete"})})
    public String delete(){
       rewardService.deleterewardService(id);
            return "delete";
    }
    @Action(value = "updatereward",results = {@Result(name = "update",type = "redirectAction",location = "allreward"),@Result(name = "noupdate",type = "redirect",location = "../bonusEdist.jsp")})
    public String update(){
        if (rewardService.updaterewardService(reward)){
            return "update";
        }else {
            return "noupdate";
        }

    }
    @Action(value = "getxixi",results = {@Result(name = "get",type = "redirect",location = "html/bonusEdit.jsp")})
    public String getrewardmanage(){
        reward=rewardService.getrewardByIdService(id);
        ActionContext.getContext().getSession().put("rewards",reward);
        return "get";
    }
    public Reward getReward() {
        return reward;
    }

    public void setReward(Reward reward) {
        this.reward = reward;
    }

    public RewardService getRewardService() {
        return rewardService;
    }

    public void setRewardService(RewardService rewardService) {
        this.rewardService = rewardService;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}
