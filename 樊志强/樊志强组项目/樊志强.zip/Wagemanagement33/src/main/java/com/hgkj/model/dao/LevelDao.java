package com.hgkj.model.dao;

import com.hgkj.model.entity.Level;

import java.util.List;

public interface LevelDao {
    //查询所有员工级别类别
    public List<Level> alllevelDao();
    //添加员工级别类别
    public boolean insertlevelDao(Level level);
    //删除员工级别类别
    public boolean deletelevelDao(int id);
    //修改员工级别类别
    public boolean updatelevelDao(Level level);
    //根据Id获取员工级别信息
    public Level getlevelByIdDao(int id);
}
