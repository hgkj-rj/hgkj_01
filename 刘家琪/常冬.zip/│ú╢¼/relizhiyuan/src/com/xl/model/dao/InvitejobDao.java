package com.xl.model.dao;

import com.xl.model.entity.Department;
import com.xl.model.entity.Invitejob;

import java.util.List;

public interface InvitejobDao {
    public int invitejobDao(int pageSize);
    public List<Invitejob> allInvitejobDao(int pageIndex, int pageSize);
    public Invitejob getInvitejobByIdDao(int invitejobId);
    public boolean addInvitejobDao(Invitejob invitejob);
    public boolean deleteInvitejobDao(Invitejob invitejob);
    public boolean updateInvitejobDao(Invitejob invitejob);
}
