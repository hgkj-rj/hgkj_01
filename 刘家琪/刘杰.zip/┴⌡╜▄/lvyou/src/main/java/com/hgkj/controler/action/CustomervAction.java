package com.hgkj.controler.action;


import com.hgkj.model.entity.Customer;
import com.hgkj.model.service.CustomerSerivce;
import com.hgkj.model.service.impl.CustomerSerivceImpl;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import javax.servlet.ServletContext;
import java.util.List;

import static org.apache.struts2.ServletActionContext.getServletContext;


@Namespace("/")
@ParentPackage("struts-default")
@Controller
public class CustomervAction {
    @Autowired
    private CustomerSerivce customerSerivce = new CustomerSerivceImpl();
    private Customer customer = new Customer();
    public static int CuId;

    /*添加*/
    @Action(value = "AddCustomer",results = @Result(name = "AddCustomer",type = "redirect",location = "qt/login.jsp"))
    public String addCustomer(){
        customerSerivce.addCustomerSerivce(customer);
        return "AddCustomer";
    }



    /*登录*/
    @Action(value="LoginCustomer",results={

            @Result(name="LoginQT",location="../qt.jsp"),

            @Result(name="LoginHT",location="../ht.jsp")
    })
    public String loginCustomer(){
        List<Customer> customers = customerSerivce.loginCustomerSerivce(customer);
        int type = 0;
        for(Customer custome:customers){
            CuId = custome.getCustomerId();
        }
        for (Customer customer:customers){
            type = customer.getType();
        }
        if (type == 1){
            return "LoginHT";
        }else {
            return "LoginQT";
        }


    }



    public CustomerSerivce getCustomerSerivce() {
        return customerSerivce;
    }

    public void setCustomerSerivce(CustomerSerivce customerSerivce) {
        this.customerSerivce = customerSerivce;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {

        this.customer = customer;
    }

    public static int getCuId() {
        return CuId;
    }

    public static void setCuId(int cuId) {
        CuId = cuId;
    }
}

