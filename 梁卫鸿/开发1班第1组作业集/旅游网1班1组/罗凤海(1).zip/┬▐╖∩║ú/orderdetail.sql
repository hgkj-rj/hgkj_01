/*
 Navicat Premium Data Transfer

 Source Server         : MySQL
 Source Server Type    : MySQL
 Source Server Version : 50720
 Source Host           : localhost:3306
 Source Schema         : travel

 Target Server Type    : MySQL
 Target Server Version : 50720
 File Encoding         : 65001

 Date: 08/07/2019 09:56:24
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for orderdetail
-- ----------------------------
DROP TABLE IF EXISTS `orderdetail`;
CREATE TABLE `orderdetail`  (
  `odID` varchar(36) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `customerID` int(255) NOT NULL,
  `lineName` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `price` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `orderDate` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `travelDate` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `total` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `lineID` varchar(12) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `state` int(255) NOT NULL,
  PRIMARY KEY (`odID`) USING BTREE,
  INDEX `FK52pm7uha76cd6vt1h0blytxda`(`lineID`) USING BTREE,
  INDEX `FKatys5msi7qfc711ac9wm0nmqc`(`customerID`) USING BTREE,
  CONSTRAINT `FK52pm7uha76cd6vt1h0blytxda` FOREIGN KEY (`lineID`) REFERENCES `line` (`lineID`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `FK_OrderDetail_customer` FOREIGN KEY (`customerID`) REFERENCES `customer` (`customerID`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `FK_OrderDetail_line` FOREIGN KEY (`lineID`) REFERENCES `line` (`lineID`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `FKatys5msi7qfc711ac9wm0nmqc` FOREIGN KEY (`customerID`) REFERENCES `customer` (`customerID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of orderdetail
-- ----------------------------
INSERT INTO `orderdetail` VALUES ('yk144', 5, '凤凰古城', '5000.00', '2019-07-05', '', '5000.0', 'l1001', 1);
INSERT INTO `orderdetail` VALUES ('yk212', 5, '九寨沟7日游', '7000.00', '2019-07-04', '2019-07-06', '21000.0', 'l1002', 1);
INSERT INTO `orderdetail` VALUES ('yk310', 5, '凤凰古城', '5000.00', '2019-07-05', '2019-07-06', '5000.0', 'l1001', 1);
INSERT INTO `orderdetail` VALUES ('yk401', 5, '凤凰古城', '5000.00', '2019-07-05', '2019-07-07', '5000.0', 'l1001', 1);
INSERT INTO `orderdetail` VALUES ('yk405', 5, '凤凰古城', '5000.00', '2019-07-05', '', '15000.0', 'l1001', 1);
INSERT INTO `orderdetail` VALUES ('yk509', 5, '九寨沟', '7000.00', '2019-07-05', '2019-07-06', '21000.0', 'l1002', 1);
INSERT INTO `orderdetail` VALUES ('yk638', 5, '凤凰古城', '5000.00', '2019-07-05', '', '5000.0', 'l1001', 1);
INSERT INTO `orderdetail` VALUES ('yk744', 5, '凤凰古城', '5000.00', '2019-07-05', '', '5000.0', 'l1001', 1);
INSERT INTO `orderdetail` VALUES ('yk848', 5, '凤凰古城', '5000.00', '2019-07-05', '2019-07-25', '5000.0', 'l1001', 1);
INSERT INTO `orderdetail` VALUES ('yk867', 5, '黄果树5日游', '3000.00', '2019-07-03', '2019-07-06', '3000.0', 'l1003', 1);

SET FOREIGN_KEY_CHECKS = 1;
