package com.tourism.model.dao;

import com.tourism.model.entity.Car;
import com.tourism.model.entity.Orderdetail;

import java.util.List;

public interface CarDao {
    public int gettotalpageDao(int pagesize,int customerId);
    public List<Car> allCarDao(int pageindex, int pagesize, int customerId);
    public boolean deleteCarDao(Car car);
    public boolean addCarDao(Car car);
}
