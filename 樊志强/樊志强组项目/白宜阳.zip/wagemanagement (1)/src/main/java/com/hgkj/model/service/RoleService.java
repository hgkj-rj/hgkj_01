package com.hgkj.model.service;

import com.hgkj.model.entity.Role;

import java.util.List;

public interface RoleService {
    List<Role> allRoleService();
    boolean addRoleService(Role role);
    boolean updateRoleService(Role role);
    boolean deleteRoleService(int roleId);
    Role getByIdRoleService(int roleId);
}
