package com.hgkj.model.entity;

import java.math.BigDecimal;

public class SubsidyLog {
    private Integer stblogId;
    private BigDecimal subsidyMoney;
    private String sublogTime;

    public Integer getStblogId() {
        return stblogId;
    }

    public void setStblogId(Integer stblogId) {
        this.stblogId = stblogId;
    }

    public BigDecimal getSubsidyMoney() {
        return subsidyMoney;
    }

    public void setSubsidyMoney(BigDecimal subsidyMoney) {
        this.subsidyMoney = subsidyMoney;
    }

    public String getSublogTime() {
        return sublogTime;
    }

    public void setSublogTime(String sublogTime) {
        this.sublogTime = sublogTime;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        SubsidyLog that = (SubsidyLog) o;

        if (stblogId != null ? !stblogId.equals(that.stblogId) : that.stblogId != null) return false;
        if (subsidyMoney != null ? !subsidyMoney.equals(that.subsidyMoney) : that.subsidyMoney != null) return false;
        if (sublogTime != null ? !sublogTime.equals(that.sublogTime) : that.sublogTime != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = stblogId != null ? stblogId.hashCode() : 0;
        result = 31 * result + (subsidyMoney != null ? subsidyMoney.hashCode() : 0);
        result = 31 * result + (sublogTime != null ? sublogTime.hashCode() : 0);
        return result;
    }
}
