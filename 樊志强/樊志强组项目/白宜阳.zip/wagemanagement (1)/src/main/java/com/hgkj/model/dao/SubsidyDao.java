package com.hgkj.model.dao;

import com.hgkj.model.entity.Subsidy;

import java.util.List;

public interface SubsidyDao {
    List<Subsidy> allSubsidyDao();
    boolean addSubsidyDao(Subsidy subsidy);
    boolean updateSubsidyDao(Subsidy subsidy);
    boolean deleteSubsidyDao(int subsidyId);
    Subsidy getByIdSubsidyDao(int subsidyId);
}
