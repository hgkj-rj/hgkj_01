package com.hgkj.model.dao.impl;

import com.hgkj.model.dao.Roledao;
import com.hgkj.model.entity.Role;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
@Transactional
public class Roledaoimpl implements Roledao {
    @Autowired
    public SessionFactory sessionFactory;

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    private Session session(){
      return   sessionFactory.getCurrentSession();
    }

    @Override
    public List<Role> roledao() {
        Query query = session().createQuery("from Role ");
        return query.list();
    }
}
