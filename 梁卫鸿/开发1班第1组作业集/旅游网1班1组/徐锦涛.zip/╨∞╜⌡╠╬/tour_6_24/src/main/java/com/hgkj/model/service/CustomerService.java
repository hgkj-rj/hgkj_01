package com.hgkj.model.service;

import com.hgkj.model.entity.Customer;

import java.util.List;

public interface CustomerService {
    public List<Customer> CustomerLoginService(Customer customer);
    public boolean CustomerAddService(Customer customer);

}
