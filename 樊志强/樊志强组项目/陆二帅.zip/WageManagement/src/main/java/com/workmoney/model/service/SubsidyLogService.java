package com.workmoney.model.service;

import com.workmoney.model.entity.Subsidy;
import com.workmoney.model.entity.SubsidyLog;

import java.util.List;

/**
 * user@Bright Rain .
 * 2019/6/27.
 */
public interface SubsidyLogService {

    /**
     * 获取所有补助信息
     * @return
     */
    List<SubsidyLog> getAllSubsidyLogService();


    /**
     * 获取所有补助类别
     * @return
     */
    List<Subsidy> getAllSubsidyService();

    /**
     * 添加补助
     * @param subsidyLog
     */
    void addEmpAllowanceService(SubsidyLog subsidyLog);

    void delAllowanceById(SubsidyLog subsidyLog);

    List<SubsidyLog> serchNameAllowAction(String name);

    /**
     * 删除津贴类别
     * @param subsidy
     */
    void delSubsidyByIdService(Subsidy subsidy);
    /**
     * 获取津贴类别
     * @param subsidy
     */
    Subsidy getSubsidyByIdService(Subsidy subsidy);

    /**
     * 修改
     * @param subsidy
     */
    void editSubsidyService(Subsidy subsidy);

    void addSubSidyService(Subsidy subsidy);
}
