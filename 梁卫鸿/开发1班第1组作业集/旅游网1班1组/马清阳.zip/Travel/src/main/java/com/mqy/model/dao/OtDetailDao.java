package com.mqy.model.dao;

/**
 * @Author:马清阳
 * @Date:2019/6/26 22:45
 * InteliJ IDEA 1.8
 */
public interface OtDetailDao {
}
