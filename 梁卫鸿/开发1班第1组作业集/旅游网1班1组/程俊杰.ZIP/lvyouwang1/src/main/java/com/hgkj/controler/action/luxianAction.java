package com.hgkj.controler.action;

import com.hgkj.model.entity.Linetype;
import com.hgkj.model.service.XianluService;
import com.opensymphony.xwork2.ActionContext;
import org.apache.commons.io.FileUtils;
import org.apache.struts2.ServletActionContext;

import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;


import java.io.File;
import java.sql.Timestamp;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;


@Controller
@Namespace("/ht")
@ParentPackage("json-default")
public class luxianAction {
    @Autowired
    private XianluService xianluService;
    private Linetype linetype;
    private String message;
    private File file;
    private String fileFileName;

    public File getFile() {
        return file;
    }

    public void setFile(File file) {
        this.file = file;
    }

    public String getFileFileName() {
        return fileFileName;
    }

    public void setFileFileName(String fileFileName) {
        this.fileFileName = fileFileName;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public XianluService getXianluService() {
        return xianluService;
    }

    public void setXianluService(XianluService xianluService) {
        this.xianluService = xianluService;
    }

    public Linetype getLinetype() {
        return linetype;
    }

    public void setLinetype(Linetype linetype) {
        this.linetype = linetype;
    }

//    @Action(value = "addLineTypeAction", results = {@Result(name = "insert", type = "redirect", location = "addLineType.jsp"),
//            @Result(name = "inserror", type = "redirect", location = "addLineType.jsp")})
//    public String addLineTypeAction() {
////
//        SimpleDateFormat simpleDateFormat=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
//        Timestamp time=Timestamp.valueOf(simpleDateFormat.format(new Date()));
//        //添加时间
//        linetype.setTime(time);
//
//        String target=ServletActionContext.getServletContext().getRealPath("ht/images/"+fileFileName);
//        File targetFile=new File(target);
//
//        try {
//            FileUtils.copyFile(file.targetFile);
//            xianluService.insertxlService()
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        xianluService.insertxlService(linetype);
//
//  }
@Action(value = "addlinetypeAction",results = {@Result(name = "addlinetype",type = "redirectAction",params = {"actionName","allLineTypeAction"})})
public String addlinetypeAction(){
    //获得时间
    SimpleDateFormat simpleDateFormat=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    Timestamp time=Timestamp.valueOf(simpleDateFormat.format(new Date()));
    //添加时间
    linetype.setTime(time);

    //文件上传

    //得到文件上传在服务器的地址和路径
    String target= ServletActionContext.getServletContext().getRealPath("ht/images/"+fileFileName);
    //获得上传文件
    File targetFile=new File(target);
    try {
        //复制上传的文件
        FileUtils.copyFile(file,targetFile);
        linetype.setIcon("ht/images/"+fileFileName);
    }catch (Exception e){
        e.printStackTrace();
    }
    xianluService.insertxlService(linetype);
    return "addlinetype";
}


    @Action(value = "allLineTypeAction", results = @Result(name = "all", type = "redirect", location = "seeLineType.jsp"))
    public String allLineTypeAction() {
        List<Linetype> allLineTypeList = xianluService.allLineTypeService();
        ActionContext.getContext().getSession().put("allLineTypeList", allLineTypeList);
        return "all";
    }

    @Action(value = "delLineTypeAction", results = {@Result(name = "success", type = "redirectAction", params = {"actionName", "allLineTypeAction"}),
    @Result(name = "error" ,type = "redirect",location = "seeLineType.jsp")})
    public String delLineTypeAction() {

        boolean rs = xianluService.delLineTypeService(linetype.getLineTypeId());
        if (rs) {

            message = "删除成功";
            return "success";
        } else {

            return "error";
        }
    }
@Action(value = "updLineTypeAction",results = {@Result(name = "update",type = "redirectAction",params = {"actionName","allLineTypeAction"}),
        @Result(name = "updateerror",type = "redirect",location = "seeLineType.jsp")})

    public String updLineTypeAction() {
    SimpleDateFormat simpleDateFormat=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    Timestamp time=Timestamp.valueOf(simpleDateFormat.format(new Date()));
    //添加时间
    linetype.setTime(time);
    String target= ServletActionContext.getServletContext().getRealPath("ht/images/"+fileFileName);
    //获得上传文件
    File targetFile=new File(target);
    try {
        //复制上传的文件
        FileUtils.copyFile(file,targetFile);
        linetype.setIcon("ht/images/"+fileFileName);
    }catch (Exception e){
        e.printStackTrace();
    }
        boolean rs = xianluService.updLineTypeService(linetype);
        if (rs) {
            return "update";
        } else {
            message="修改失败";
            return "updateerror";
        }
    }
@Action(value = "linetypeByIdAction",results = {@Result(name = "find",type = "redirect",location = "updateLineType.jsp")})
public String linetypeByIdAction(){
Linetype litype=xianluService.linetypeByIdService(linetype.getLineTypeId());
    ServletActionContext.getRequest().getSession().setAttribute("litype",litype);
    return "find";
}
}


