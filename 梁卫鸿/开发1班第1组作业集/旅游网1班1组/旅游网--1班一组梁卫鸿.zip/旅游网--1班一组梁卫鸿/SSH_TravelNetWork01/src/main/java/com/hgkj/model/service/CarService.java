package com.hgkj.model.service;

import com.hgkj.model.entity.*;

import java.util.List;

public interface CarService {
    public boolean CarAddService(int customerId,String lineId,String time);
    public List<Car> carAllService();
    public List<Line> lineAllService();
    public List<Picture> pictureAllService();
    public List<Customer> customerAllService();
    public boolean carDeleteDao(int carId);
    public Orderdetail orderIdService(String orderId);
    public boolean orderDeleteService(String orderId);
    public boolean otDeleteService(int otId);
    public boolean ot1DeleteDao(String odId);
}
