package com.hgkj.model.entity;

public class Linetype {
    private int lineTypeId;
    private String typeName;
    private String icon;
    private String show;

    public int getLineTypeId() {
        return lineTypeId;
    }

    public void setLineTypeId(int lineTypeId) {
        this.lineTypeId = lineTypeId;
    }

    public String getTypeName() {
        return typeName;
    }

    public void setTypeName(String typeName) {
        this.typeName = typeName;
    }

    public String getIcon() {
        return icon;
    }

    public void setIcon(String icon) {
        this.icon = icon;
    }

    public String getShow() {
        return show;
    }

    public void setShow(String show) {
        this.show = show;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Linetype linetype = (Linetype) o;

        if (lineTypeId != linetype.lineTypeId) return false;
        if (typeName != null ? !typeName.equals(linetype.typeName) : linetype.typeName != null) return false;
        if (icon != null ? !icon.equals(linetype.icon) : linetype.icon != null) return false;
        if (show != null ? !show.equals(linetype.show) : linetype.show != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = lineTypeId;
        result = 31 * result + (typeName != null ? typeName.hashCode() : 0);
        result = 31 * result + (icon != null ? icon.hashCode() : 0);
        result = 31 * result + (show != null ? show.hashCode() : 0);
        return result;
    }
}
