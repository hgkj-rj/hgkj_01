package com.hgkj.model.entity;

public class Picture {
    private int pictureID;
    private String introduction;
    private String name;
    private Line line;
    private String lineID;
    public Picture(){}
    public Picture(String lineID,String introduction, String name) {
        this.lineID=lineID;
        this.introduction = introduction;
        this.name = name;
    }

    public Picture(int pictureID, String introduction, String name, String lineID) {
        this.pictureID = pictureID;
        this.introduction = introduction;
        this.name = name;
        this.lineID = lineID;
    }

    public Line getLine() {
        return line;
    }

    public void setLine(Line line) {
        this.line = line;
    }

    public String getLineID() {
        return lineID;
    }

    public void setLineID(String lineID) {
        this.lineID = lineID;
    }

    public int getPictureID() {
        return pictureID;
    }

    public void setPictureID(int pictureID) {
        this.pictureID = pictureID;
    }

    public String getIntroduction() {
        return introduction;
    }

    public void setIntroduction(String introduction) {
        this.introduction = introduction;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Picture picture = (Picture) o;

        if (pictureID != picture.pictureID) return false;
        if (introduction != null ? !introduction.equals(picture.introduction) : picture.introduction != null)
            return false;
        if (name != null ? !name.equals(picture.name) : picture.name != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = pictureID;
        result = 31 * result + (introduction != null ? introduction.hashCode() : 0);
        result = 31 * result + (name != null ? name.hashCode() : 0);
        return result;
    }
}
