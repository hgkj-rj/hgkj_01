package com.hgkj.model.dao.impl;

import com.hgkj.model.dao.Salary_LogDao;
import com.hgkj.model.entity.Attendance;
import com.hgkj.model.entity.AttendanceLog;
import com.hgkj.model.entity.SalaryLog;
import com.hgkj.model.entity.Staff;
import org.apache.struts2.ServletActionContext;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

@Repository
@Transactional
public class Salary_LogDaoImpl implements Salary_LogDao {
    @Autowired
    private SessionFactory sessionFactory;
    private SalaryLog salaryLog;

    @Override
    public List<SalaryLog> allSalaryList() {
        String hql="from SalaryLog ";
        List<SalaryLog> list = getSession().createQuery(hql).list();
        return list;
    }

    @Override
    public List<SalaryLog> querySalaryDao(Staff staff) {
        String hql="";
        List<SalaryLog> salaryLogList=null;
        if(staff.getRole().getRoleId()==1||staff.getRole().getRoleId()==2){
            hql="from SalaryLog where staff.staffId=?";
            salaryLogList=getSession().createQuery(hql).setParameter(0,staff.getStaffId()).list();
            String staffName = salaryLogList.get(0).getStaffName();
            ServletActionContext.getRequest().getSession().setAttribute("salaryName",staffName);
        }
        if(staff.getRole().getRoleId()==3){
             hql="FROM SalaryLog WHERE sallogId<=2 ";
            salaryLogList = getSession().createQuery(hql).list();
        }
        return salaryLogList;
    }

    @Override
    public List SalaryLog_AttendanceLog(int staffId) {
        Integer jibengongzi=getLevelPrice(staffId);
        List<Double> attendance = getAttendance();
        List<String> list=new ArrayList();
        Integer chidao=0;
        Integer zaotui=0;
        Integer kuangdao=0;
        String hql="from AttendanceLog where staff.staffId=?";
        List<AttendanceLog> list1 = getSession().createQuery(hql).setParameter(0, staffId).list();
        for(AttendanceLog attendanceLog:list1){
            if(attendanceLog.getAttendance().getAttId()==1){
                chidao+=attendanceLog.getAttlogCount();
            }
            if(attendanceLog.getAttendance().getAttId()==2){
                zaotui+=attendanceLog.getAttlogCount();
            }
            if(attendanceLog.getAttendance().getAttId()==3){
                kuangdao+=attendanceLog.getAttlogCount();
            }
        }

        Double chidaoMoney=chidao*jibengongzi.doubleValue()*attendance.get(0);
        Double zaotuiMoney=zaotui*jibengongzi.doubleValue()*attendance.get(1);
        Double kuangdaoMoney=kuangdao*jibengongzi.doubleValue()*attendance.get(2);
        list.add(chidao.toString());
        list.add(zaotui.toString());
        list.add(kuangdao.toString());
        list.add(chidaoMoney.toString());
        list.add(zaotuiMoney.toString());
        list.add(kuangdaoMoney.toString());
        return list;
    }

    @Override
    public List<SalaryLog> dimquery(String name) {
        Staff staff=(Staff)  ServletActionContext.getRequest().getSession().getAttribute("staffUser");
        String salaryName =(String) ServletActionContext.getRequest().getSession().getAttribute("salaryName");
        List<SalaryLog> salaryLogList;
        if(staff.getRole().getRoleId()==3){
            String hql="FROM SalaryLog WHERE staffName  LIKE  ?";
            salaryLogList = getSession().createQuery(hql).setParameter(0, "%"+name+"%").list();
        }else{
            String hql="FROM SalaryLog WHERE  staffName=?   and staffName  LIKE  ?";
            salaryLogList = getSession().createQuery(hql).setParameter(0,salaryName).setParameter(1, "%"+name+"%").list();
        }

        return salaryLogList;
    }


    @Override
    public List<SalaryLog> Salary_Next(int index) {
        Staff staff=(Staff)  ServletActionContext.getRequest().getSession().getAttribute("staffUser");
        List<SalaryLog> SalaryLogList=null;
        String salaryName =(String) ServletActionContext.getRequest().getSession().getAttribute("salaryName");
      if(staff.getRole().getRoleId()==3){
          String hql="  FROM SalaryLog WHERE  sallogId<=? and sallogId>? ";
          SalaryLogList = getSession().createQuery(hql).setParameter(0,index*2).setParameter(1,index*2-2).list();
      }else{
          String hql="  FROM SalaryLog WHERE  sallogId<=? and sallogId>? and staffName=?";
          SalaryLogList = getSession().createQuery(hql).setParameter(0,index*2).setParameter(1,index*2-2).setParameter(2,salaryName).list();

      }
        return SalaryLogList;
    }

    @Override
    public List<SalaryLog> Salary_End(Staff staff) {
        return null;
    }

    @Override
    public int Salary_Pages() {
       String hql="from SalaryLog ";
       List<SalaryLog> salaryLogList=getSession().createQuery(hql).list();
        return salaryLogList.size();
    }

    public List<Double> getAttendance(){
        String hql="from Attendance ";
        List<Attendance> attendanceList=getSession().createQuery(hql).list();
        List<Double> interList=new ArrayList<>();
        for(Attendance a:attendanceList){
            interList.add(Double.parseDouble(a.getAttPercent()));
        }
        return interList;
    }

    public int getLevelPrice(int staffId){
        String hql="from Staff where staffId=?";
        Staff staff = (Staff) getSession().createQuery(hql).setParameter(0, staffId).uniqueResult();
        return staff.getLevel().getLevelPrice().intValue();
    }

    public SalaryLog getSalaryLog() {
        return salaryLog;
    }

    public void setSalaryLog(SalaryLog salaryLog) {
        this.salaryLog = salaryLog;
    }



    @Override
    public boolean addSalaryDao(SalaryLog salaryLog) {
        return false;
    }

    @Override
    public boolean updSalaryDao(SalaryLog salaryLog) {
        return false;
    }

    @Override
    public boolean delSalaryDao(SalaryLog salaryLog) {
        return false;
    }


    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    public Session getSession(){
        return sessionFactory.getCurrentSession();
    }

}
