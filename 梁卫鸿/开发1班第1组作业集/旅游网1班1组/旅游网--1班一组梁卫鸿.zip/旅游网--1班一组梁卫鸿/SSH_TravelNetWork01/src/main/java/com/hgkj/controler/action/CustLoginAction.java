package com.hgkj.controler.action;

import com.hgkj.model.entity.Customer;
import com.hgkj.model.service.CustLoginService;
import org.apache.struts2.ServletActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

@Controller
@Namespace("/")
@ParentPackage("struts-default")
public class CustLoginAction {
    @Autowired
    private CustLoginService custLoginService;
    private Customer  customer;
    private String message;
    public CustLoginService getCustLoginService() {
        return custLoginService;
    }
    public void setCustLoginService(CustLoginService custLoginService) {
        this.custLoginService = custLoginService;
    }
    @Action(value = "custLogin",results = {@Result(name = "login",type = "redirectAction",params = {"actionName","allCustomer"}),@Result(name ="loginError",type = "redirect",location = "qt/login.jsp" )})
    public String custLogin() {
        Customer cust = custLoginService.custLoginService(customer);
        int customerId=cust.getCustomerId();
        ServletActionContext.getRequest().getSession().setAttribute("customerId", customerId);
        if (cust.getCustomerId() > 0) {
            ServletActionContext.getRequest().getSession().setAttribute("customer", cust);
            return "login";
        } else {
            message = "用户名密码不正确！";
            return "loginError";
        }
    }

    @Action(value = "adminLogin",results = {@Result(name = "login",type = "redirect",location = "ht/index.jsp"),@Result(name ="loginError",type = "redirect",location = "ht/adminLogin.jsp" )})
    public String adminLogin() {
        int a=0;
        Customer cust = custLoginService.custLoginService(customer);
        System.out.println(cust.getCustomerId()+"11111111111111");
        int customerId=cust.getCustomerId();
        ServletActionContext.getRequest().getSession().setAttribute("customerId", customerId);
        if (customer.getType()!=null) {
            a = customer.getType();
            if (a == 1) {
                if (cust.getCustomerId() > 0) {
                    ServletActionContext.getRequest().getSession().setAttribute("customer", cust);
                    return "login";
                } else {
                    message = "用户名密码不正确！";
                    return "loginError";
                }
            }
        }
        return "loginError";
    }

    @Action(value = "custRegisterAction",results = {@Result(name = "register",type = "redirect",location = "qt/login.jsp")})
    public String custRegisterAction(){
        boolean rs=custLoginService.custRegisterService(customer);
        if(rs){
            return "register";
        }
        return "adderror";

    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }
}
