package com.hgkj.model.service.impl;

import com.hgkj.model.dao.ImagesDao;
import com.hgkj.model.dao.LineDao;
import com.hgkj.model.entity.Car;
import com.hgkj.model.entity.Images;
import com.hgkj.model.entity.Line;
import com.hgkj.model.entity.Picture;
import com.hgkj.model.service.ImagesService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class ImagesServiceImpl implements ImagesService {
    @Autowired
    private ImagesDao imagesDao;

    public void setImagesDao(ImagesDao imagesDao) {
        this.imagesDao = imagesDao;
    }

    @Override
    public List<Picture> imagesAllService() {
        return imagesDao.imagesAllDao();
    }

    @Override
    public boolean imagesInsertService(String lineId, String introduction, String name) {
        return imagesDao.imagesInsertDao(lineId, introduction, name);
    }

    @Override
    public boolean imagesDeleteService(int pictureId) {
        return imagesDao.imagesDeleteDao(pictureId);
    }

    @Override
    public Picture imagesIdService(int pictureId) {
        return imagesDao.imagesIdDao(pictureId);
    }

    @Override
    public boolean imagesUpdateService(int pictureId, String introduction, String name, String lineId) {
        return imagesDao.imagesUpdateService(pictureId, introduction, name, lineId);
    }

    @Override
    public boolean lineAddService(Line line) {
        return imagesDao.lineAddDao(line);
    }

    @Override
    public List<Line> lineAllService() {
        return imagesDao.lineAllDao();
    }

    @Override
    public boolean lineDeleteService(String lineId) {
        return imagesDao.lineDeleteDao(lineId);
    }

    @Override
    public Line lineIdService(String lineId) {
        return imagesDao.lineIdDao(lineId);
    }

    @Override
    public boolean lineUpdateService(Line line) {
        return imagesDao.lineUpdateDao(line);

    }
}


