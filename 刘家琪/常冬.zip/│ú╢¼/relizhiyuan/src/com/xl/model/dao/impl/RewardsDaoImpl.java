package com.xl.model.dao.impl;

import com.xl.model.dao.RewardsDao;
import com.xl.model.entity.Rewards;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class RewardsDaoImpl implements RewardsDao {
    @Override
    public int RewardsDao(int pageSize) {
        int totalPage=0;
        Connection connection=DBManager.getConnection();
        PreparedStatement preparedStatement=null;
        ResultSet resultSet=null;
        String sql="select count(*) from cj";
        try {
            preparedStatement=connection.prepareStatement(sql);
            resultSet=preparedStatement.executeQuery();
            if (resultSet.next()){
                totalPage=(resultSet.getInt(1)-1)/pageSize+1;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            DBManager.closeAll(connection,preparedStatement,resultSet);
        }
        return totalPage;
    }

    @Override
    public List<Rewards> allRewardsDao(int pageIndex, int pageSize) {
        List<Rewards> rewardsList=new ArrayList<>();
        Connection connection=DBManager.getConnection();
        PreparedStatement preparedStatement=null;
        ResultSet resultSet=null;
        String sql="select * from cj limit  ?,?";
        try {
            preparedStatement=connection.prepareStatement(sql);
            preparedStatement.setInt(1,(pageIndex-1)*pageSize);
            preparedStatement.setInt(2,pageSize);
            resultSet=preparedStatement.executeQuery();
            while (resultSet.next()){
                Rewards rewards=new Rewards();
                rewards.setCjId(resultSet.getInt("cjId"));
                rewards.setCjZhuti(resultSet.getString("cjZhuti"));
                rewards.setCjJine(resultSet.getInt("cjJine"));
                rewards.setCjLeixin(resultSet.getString("cjLeixin"));
                rewards.setCjTime(resultSet.getString("cjTime"));

                rewardsList.add(rewards);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            DBManager.closeAll(connection,preparedStatement,resultSet);
        }
        return rewardsList;
    }

    @Override
    public Rewards getRewardsByIdDao(int cjId) {
        Rewards rewards=new Rewards();
        Connection connection=DBManager.getConnection();
        PreparedStatement preparedStatement=null;
        ResultSet resultSet=null;
        String sql="select * cj  where cjId=?";
        try {
            preparedStatement=connection.prepareStatement(sql);
            preparedStatement.setInt(1,cjId);
            resultSet=preparedStatement.executeQuery();
            while (resultSet.next()){

                rewards.setCjId(resultSet.getInt("cjId"));
                rewards.setCjZhuti(resultSet.getString("cjZhuti"));
                rewards.setCjJine(resultSet.getInt("cjJine"));
                rewards.setCjLeixin(resultSet.getString("cjLeixin"));
                rewards.setCjTime(resultSet.getString("cjTime"));


            }
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            DBManager.closeAll(connection,preparedStatement,resultSet);
        }
        return rewards;
    }

    @Override
    public boolean addRewardsDao(Rewards rewards) {
        return false;
    }

    @Override
    public boolean deleteRewardsDao(int rewards) {
        return false;
    }

    @Override
    public boolean updateRewardsDao(Rewards rewards) {
        return false;
    }
}
