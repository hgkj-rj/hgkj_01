package com.hgkj.model.service;

import com.hgkj.model.entity.Level;

import java.util.List;

public interface LevelService {
    List<Level> allLevelService();
    boolean addLevelService(Level level);
    boolean updateLevelService(Level level);
    boolean deleteLevelService(int levelId);
    Level getByIdLevelService(int levelId);
}
