package com.hgkj.model.service.impl;

import com.hgkj.model.service.EmpService;

public class EmpServiceImpl implements EmpService {
}
