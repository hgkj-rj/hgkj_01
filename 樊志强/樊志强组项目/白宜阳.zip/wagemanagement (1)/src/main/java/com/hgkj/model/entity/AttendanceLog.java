package com.hgkj.model.entity;

public class AttendanceLog {
    private int attenlogId;
//    private Integer staffId;
    private int attlogCount;
    private String attlogTime;
    private Attendance attendance;
    private Staff staff;

    public Staff getStaff() {
        return staff;
    }

    public void setStaff(Staff staff) {
        this.staff = staff;
    }

    public Attendance getAttendance() {
        return attendance;
    }

    public void setAttendance(Attendance attendance) {
        this.attendance = attendance;
    }

    public int getAttenlogId() {
        return attenlogId;
    }

    public void setAttenlogId(int attenlogId) {
        this.attenlogId = attenlogId;
    }

//    public Integer getStaffId() {
//        return staffId;
//    }
//
//    public void setStaffId(Integer staffId) {
//        this.staffId = staffId;
//    }

    public int getAttlogCount() {
        return attlogCount;
    }

    public void setAttlogCount(int attlogCount) {
        this.attlogCount = attlogCount;
    }

    public String getAttlogTime() {
        return attlogTime;
    }

    public void setAttlogTime(String attlogTime) {
        this.attlogTime = attlogTime;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        AttendanceLog that = (AttendanceLog) o;

        if (attenlogId != that.attenlogId) return false;
        if (attlogCount != that.attlogCount) return false;
//        if (staffId != null ? !staffId.equals(that.staffId) : that.staffId != null) return false;
        if (attlogTime != null ? !attlogTime.equals(that.attlogTime) : that.attlogTime != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = attenlogId;
//        result = 31 * result + (staffId != null ? staffId.hashCode() : 0);
        result = 31 * result + attlogCount;
        result = 31 * result + (attlogTime != null ? attlogTime.hashCode() : 0);
        return result;
    }

}
