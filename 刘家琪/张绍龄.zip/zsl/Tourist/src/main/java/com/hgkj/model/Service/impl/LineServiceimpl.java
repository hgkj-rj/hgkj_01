package com.hgkj.model.Service.impl;

import com.hgkj.model.Dao.LineDao;
import com.hgkj.model.Service.LineService;
import com.hgkj.model.entity.Line;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class LineServiceimpl implements LineService {
    @Autowired
    private LineDao lineDao;
    public LineDao getLineDao() {
        return lineDao;
    }
    public void setLineDao(LineDao lineDao) {
        this.lineDao = lineDao;
    }

    @Override
    public int getpageService(int pagesize, String time) {
        return lineDao.getpageDao(pagesize,time);
    }

    @Override
    public List<Line> allLineService(int pageIndex, int pagesize, String time) {
        return lineDao.allLineDao(pageIndex,pagesize,time);
    }

    @Override
    public List<Line> allLineService() {
        return lineDao.allLineDao();
    }

    @Override
    public List<Line> allGroupService() {
        return lineDao.allGroupDao();
    }

    @Override
    public List<Line> allGroupLineService() {
        return lineDao.allGroupLineDao();
    }

    @Override
    public List<Line> toIndexLineService(String lineTypeId) {
        return lineDao.toIndexLineDao(lineTypeId);
    }

    @Override
    public List<Line> oneLineService() {
        return lineDao.oneLineDao();
    }

    @Override
    public List<Line> twoLineService() {
        return lineDao.twoLineDao();
    }

    @Override
    public List<Line> moreLineService() {
        return lineDao.moreLineDao();
    }

    @Override
    public boolean addLineService(Line line) {
        return lineDao.addLineDao(line);
    }

    @Override
    public boolean updateLineService(Line line) {
        return lineDao.updateLineDao(line);
    }

    @Override
    public Line getLineByIdService(String lineId) {
        return lineDao.getLineByIdDao(lineId);
    }
}
