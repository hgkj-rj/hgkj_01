package com.hgkj.model.dao;

import com.hgkj.model.entity.Line;
import com.hgkj.model.entity.OtDetail;
import com.hgkj.model.entity.Picture;

import java.util.List;

public interface OtDao {
    public boolean otAddDao(String odId,String touristId);
    public boolean orderAddDao(String odId,String lineName,String price,String orderDate,String travelDate,String total,
                               String lineId,int state,int customerId);
    public boolean touristAddDao(String touristId,String idCard,String tel,String realName);
    public OtDetail OtIdDao(int  otId);
    public List<OtDetail> otAllDao();

}
