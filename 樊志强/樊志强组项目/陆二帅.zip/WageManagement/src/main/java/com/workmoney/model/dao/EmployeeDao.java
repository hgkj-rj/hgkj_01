package com.workmoney.model.dao;

import com.workmoney.model.entity.StaffFuBen;

import java.util.List;

/**
 * user@Bright Rain .
 * 2019/6/26.
 */
public interface EmployeeDao {

    void addEmployeeDao(StaffFuBen staffFuBen);

    void delEmpDao(StaffFuBen staffFuBen);

    StaffFuBen getEmpByIdDao(StaffFuBen staffFuBen);

    void updateEmployeeByIdDao(StaffFuBen staffFuBen);

    List<StaffFuBen> getAllStaffFuBenDao();

    void updateRoleByIdDao(StaffFuBen staff);
}
