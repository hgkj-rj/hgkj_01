package com.hgkj.model.service;

import com.hgkj.model.entity.Subsidy;
import java.util.List;

public interface SubsidyService {
    //查询所有补贴类别
    public List<Subsidy> allsubsidyService();
    //添加补贴类别
    public boolean insertsubsidyService(Subsidy subsidy);
    //删除补贴类别
    public boolean deletesubsidyService(int id);
    //修改补贴类别
    public boolean updatesubsidyService(Subsidy subsidy);
    //根据Id获取补贴信息
    public Subsidy getsubsidyByIdService(int id);
}
