package com.mqy.model.dao;

import com.mqy.model.entity.Linetype;

import java.util.List;

public interface LineTypeDao {

    /**
     * 查询所有线路类型
     * @return
     */
   public List<Linetype> allLineTypeDao();

    /**
     * 添加线路类型
     * @param linetype
     * @return
     */
   public void addLineTypeDao(Linetype linetype);

    /**
     * 删除线路类型
     * @param lineTypeId
     * @return
     */
   public void deleteLineTypeDao(String lineTypeId);

    /**
     * 修改线路类型
     * @param linetype
     * @return
     */
   public void updateLineTypeDao(Linetype linetype);

    /**
     * 获取线路类型
     * @param lineTypeId
     * @return
     */
   public Linetype getLineTypeDao(String lineTypeId);
}
